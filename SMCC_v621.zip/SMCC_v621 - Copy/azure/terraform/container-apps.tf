# =============================================================================
# Azure Container Apps Environment & Applications
# =============================================================================

# ── Container Apps Environment ───────────────────────────────────────────────

resource "azurerm_container_app_environment" "main" {
  name                       = "${local.name_prefix}-cae"
  location                   = azurerm_resource_group.main.location
  resource_group_name        = azurerm_resource_group.main.name
  log_analytics_workspace_id = azurerm_log_analytics_workspace.main.id
  infrastructure_subnet_id   = azurerm_subnet.container_apps.id

  workload_profile {
    name                  = "Consumption"
    workload_profile_type = "Consumption"
    minimum_count         = 0
    maximum_count         = 0
  }

  tags = local.common_tags
}

# =============================================================================
# Backend API Container App
# =============================================================================

resource "azurerm_container_app" "backend" {
  name                         = "${local.name_prefix}-backend"
  container_app_environment_id = azurerm_container_app_environment.main.id
  resource_group_name          = azurerm_resource_group.main.name
  revision_mode                = "Single"
  tags                         = local.common_tags

  identity {
    type = "SystemAssigned"
  }

  registry {
    server               = azurerm_container_registry.acr.login_server
    username             = azurerm_container_registry.acr.admin_username
    password_secret_name = "acr-password"
  }

  secret {
    name  = "acr-password"
    value = azurerm_container_registry.acr.admin_password
  }

  secret {
    name  = "db-password"
    value = random_password.db_password.result
  }

  secret {
    name  = "jwt-secret"
    value = random_password.jwt_secret.result
  }

  template {
    min_replicas = var.backend_min_replicas
    max_replicas = var.backend_max_replicas

    container {
      name   = "sds-backend"
      image  = local.backend_image
      cpu    = var.backend_cpu
      memory = var.backend_memory

      env {
        name  = "NODE_ENV"
        value = var.environment == "prod" ? "production" : "development"
      }
      env {
        name  = "PORT"
        value = "3000"
      }
      env {
        name  = "HOST"
        value = "0.0.0.0"
      }
      env {
        name  = "DB_HOST"
        value = azurerm_postgresql_flexible_server.main.fqdn
      }
      env {
        name  = "DB_PORT"
        value = "5432"
      }
      env {
        name  = "DB_NAME"
        value = "sds_mining"
      }
      env {
        name  = "DB_USER"
        value = "sdsadmin"
      }
      env {
        name       = "DB_PASSWORD"
        secret_name = "db-password"
      }
      env {
        name  = "DB_SSL"
        value = "true"
      }
      env {
        name  = "DB_POOL_MIN"
        value = "2"
      }
      env {
        name  = "DB_POOL_MAX"
        value = "10"
      }
      env {
        name       = "JWT_SECRET"
        secret_name = "jwt-secret"
      }
      env {
        name  = "JWT_EXPIRES_IN"
        value = "24h"
      }
      env {
        name  = "CORS_ORIGIN"
        value = "*"
      }
      env {
        name  = "RATE_LIMIT_WINDOW_MS"
        value = "900000"
      }
      env {
        name  = "RATE_LIMIT_MAX_REQUESTS"
        value = var.environment == "prod" ? "100" : "500"
      }
      env {
        name  = "APPLICATIONINSIGHTS_CONNECTION_STRING"
        value = azurerm_application_insights.main.connection_string
      }

      liveness_probe {
        transport        = "HTTP"
        path             = "/health"
        port             = 3000
        initial_delay    = 30
        interval_seconds = 30
        timeout          = 5
        failure_count_threshold = 3
      }

      readiness_probe {
        transport        = "HTTP"
        path             = "/health"
        port             = 3000
        interval_seconds = 10
        timeout          = 3
        failure_count_threshold = 3
      }

      startup_probe {
        transport        = "HTTP"
        path             = "/health"
        port             = 3000
        interval_seconds = 5
        timeout          = 3
        failure_count_threshold = 10
      }
    }

    http_scale_rule {
      name                = "http-scaling"
      concurrent_requests = "50"
    }
  }

  ingress {
    external_enabled = true
    target_port      = 3000
    transport        = "http"

    traffic_weight {
      latest_revision = true
      percentage      = 100
    }
  }
}

# =============================================================================
# React Frontend Container App
# =============================================================================

resource "azurerm_container_app" "frontend_react" {
  name                         = "${local.name_prefix}-react"
  container_app_environment_id = azurerm_container_app_environment.main.id
  resource_group_name          = azurerm_resource_group.main.name
  revision_mode                = "Single"
  tags                         = local.common_tags

  registry {
    server               = azurerm_container_registry.acr.login_server
    username             = azurerm_container_registry.acr.admin_username
    password_secret_name = "acr-password"
  }

  secret {
    name  = "acr-password"
    value = azurerm_container_registry.acr.admin_password
  }

  template {
    min_replicas = var.frontend_min_replicas
    max_replicas = var.frontend_max_replicas

    container {
      name   = "sds-frontend-react"
      image  = local.react_image
      cpu    = var.frontend_cpu
      memory = var.frontend_memory

      liveness_probe {
        transport        = "HTTP"
        path             = "/"
        port             = 80
        interval_seconds = 30
        timeout          = 3
        failure_count_threshold = 3
      }
    }

    http_scale_rule {
      name                = "http-scaling"
      concurrent_requests = "100"
    }
  }

  ingress {
    external_enabled = true
    target_port      = 80
    transport        = "auto"

    traffic_weight {
      latest_revision = true
      percentage      = 100
    }
  }
}

# =============================================================================
# Angular Frontend Container App
# =============================================================================

resource "azurerm_container_app" "frontend_angular" {
  name                         = "${local.name_prefix}-angular"
  container_app_environment_id = azurerm_container_app_environment.main.id
  resource_group_name          = azurerm_resource_group.main.name
  revision_mode                = "Single"
  tags                         = local.common_tags

  registry {
    server               = azurerm_container_registry.acr.login_server
    username             = azurerm_container_registry.acr.admin_username
    password_secret_name = "acr-password"
  }

  secret {
    name  = "acr-password"
    value = azurerm_container_registry.acr.admin_password
  }

  template {
    min_replicas = var.frontend_min_replicas
    max_replicas = var.frontend_max_replicas

    container {
      name   = "sds-frontend-angular"
      image  = local.angular_image
      cpu    = var.frontend_cpu
      memory = var.frontend_memory

      liveness_probe {
        transport        = "HTTP"
        path             = "/health"
        port             = 80
        interval_seconds = 30
        timeout          = 3
        failure_count_threshold = 3
      }
    }

    http_scale_rule {
      name                = "http-scaling"
      concurrent_requests = "100"
    }
  }

  ingress {
    external_enabled = true
    target_port      = 80
    transport        = "auto"

    traffic_weight {
      latest_revision = true
      percentage      = 100
    }
  }
}

# =============================================================================
# Database Seeder Job
# =============================================================================

resource "azurerm_container_app_job" "db_seed" {
  name                         = "${local.name_prefix}-db-seed"
  container_app_environment_id = azurerm_container_app_environment.main.id
  resource_group_name          = azurerm_resource_group.main.name
  location                     = azurerm_resource_group.main.location
  replica_timeout_in_seconds   = 600
  replica_retry_limit          = 1
  tags                         = local.common_tags

  manual_trigger_config {
    parallelism              = 1
    replica_completion_count = 1
  }

  registry {
    server               = azurerm_container_registry.acr.login_server
    username             = azurerm_container_registry.acr.admin_username
    password_secret_name = "acr-password"
  }

  secret {
    name  = "acr-password"
    value = azurerm_container_registry.acr.admin_password
  }

  secret {
    name  = "db-password"
    value = random_password.db_password.result
  }

  template {
    container {
      name    = "db-seeder"
      image   = local.backend_image
      cpu     = 0.5
      memory  = "1Gi"
      command = ["node", "dist/database/seed-all.js"]

      env {
        name  = "DB_HOST"
        value = azurerm_postgresql_flexible_server.main.fqdn
      }
      env {
        name  = "DB_PORT"
        value = "5432"
      }
      env {
        name  = "DB_NAME"
        value = "sds_mining"
      }
      env {
        name  = "DB_USER"
        value = "sdsadmin"
      }
      env {
        name       = "DB_PASSWORD"
        secret_name = "db-password"
      }
      env {
        name  = "DB_SSL"
        value = "true"
      }
    }
  }
}

# =============================================================================
# RBAC: Container App Managed Identity -> Key Vault
# =============================================================================

resource "azurerm_role_assignment" "backend_kv_reader" {
  scope                = azurerm_key_vault.main.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azurerm_container_app.backend.identity[0].principal_id
}

# =============================================================================
# RBAC: Container App Managed Identity -> ACR
# =============================================================================

resource "azurerm_role_assignment" "backend_acr_pull" {
  scope                = azurerm_container_registry.acr.id
  role_definition_name = "AcrPull"
  principal_id         = azurerm_container_app.backend.identity[0].principal_id
}
