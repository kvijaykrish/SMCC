# =============================================================================
# Azure Container Registry
# =============================================================================

resource "azurerm_container_registry" "acr" {
  name                = "sdsmining${var.environment}${local.name_suffix}"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  sku                 = var.acr_sku
  admin_enabled       = true
  tags                = local.common_tags

  # Geo-replication for Premium SKU only
  dynamic "georeplications" {
    for_each = var.acr_sku == "Premium" ? [var.location_secondary] : []
    content {
      location                = georeplications.value
      zone_redundancy_enabled = true
    }
  }
}
