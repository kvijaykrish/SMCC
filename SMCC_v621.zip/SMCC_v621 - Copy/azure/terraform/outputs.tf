# =============================================================================
# Terraform Outputs
# =============================================================================

# ── Resource Group ───────────────────────────────────────────────────────────

output "resource_group_name" {
  value       = azurerm_resource_group.main.name
  description = "Resource group name"
}

# ── Container Registry ──────────────────────────────────────────────────────

output "acr_login_server" {
  value       = azurerm_container_registry.acr.login_server
  description = "ACR login server URL"
}

output "acr_admin_username" {
  value       = azurerm_container_registry.acr.admin_username
  description = "ACR admin username"
  sensitive   = true
}

# ── Container Apps ───────────────────────────────────────────────────────────

output "backend_url" {
  value       = "https://${azurerm_container_app.backend.ingress[0].fqdn}"
  description = "Backend API direct URL"
}

output "react_frontend_url" {
  value       = "https://${azurerm_container_app.frontend_react.ingress[0].fqdn}"
  description = "React frontend direct URL"
}

output "angular_frontend_url" {
  value       = "https://${azurerm_container_app.frontend_angular.ingress[0].fqdn}"
  description = "Angular frontend direct URL"
}

# ── Front Door ───────────────────────────────────────────────────────────────

output "frontdoor_react_endpoint" {
  value       = "https://${azurerm_cdn_frontdoor_endpoint.react.host_name}"
  description = "Front Door React endpoint (production URL)"
}

output "frontdoor_angular_endpoint" {
  value       = "https://${azurerm_cdn_frontdoor_endpoint.angular.host_name}"
  description = "Front Door Angular endpoint (production URL)"
}

output "frontdoor_api_endpoint" {
  value       = "https://${azurerm_cdn_frontdoor_endpoint.api.host_name}"
  description = "Front Door API endpoint (production URL)"
}

# ── Database ─────────────────────────────────────────────────────────────────

output "postgres_fqdn" {
  value       = azurerm_postgresql_flexible_server.main.fqdn
  description = "PostgreSQL server FQDN (private)"
}

output "postgres_database" {
  value       = azurerm_postgresql_flexible_server_database.sds.name
  description = "PostgreSQL database name"
}

# ── Key Vault ────────────────────────────────────────────────────────────────

output "key_vault_name" {
  value       = azurerm_key_vault.main.name
  description = "Key Vault name"
}

output "key_vault_uri" {
  value       = azurerm_key_vault.main.vault_uri
  description = "Key Vault URI"
}

# ── Monitoring ───────────────────────────────────────────────────────────────

output "log_analytics_workspace_id" {
  value       = azurerm_log_analytics_workspace.main.id
  description = "Log Analytics workspace ID"
}

output "app_insights_instrumentation_key" {
  value       = azurerm_application_insights.main.instrumentation_key
  description = "Application Insights instrumentation key"
  sensitive   = true
}

output "app_insights_connection_string" {
  value       = azurerm_application_insights.main.connection_string
  description = "Application Insights connection string"
  sensitive   = true
}

# ── Storage ──────────────────────────────────────────────────────────────────

output "storage_account_name" {
  value       = azurerm_storage_account.main.name
  description = "Storage account name"
}

# ── Summary ──────────────────────────────────────────────────────────────────

output "deployment_summary" {
  value = <<-EOT

    =====================================================
    SDS Mining Command Center - Azure Deployment Summary
    =====================================================
    Environment:     ${var.environment}
    Region:          ${var.location}
    Resource Group:  ${azurerm_resource_group.main.name}

    -- Access URLs --
    React Frontend:  https://${azurerm_cdn_frontdoor_endpoint.react.host_name}
    Angular Frontend: https://${azurerm_cdn_frontdoor_endpoint.angular.host_name}
    Backend API:     https://${azurerm_cdn_frontdoor_endpoint.api.host_name}
    Health Check:    https://${azurerm_cdn_frontdoor_endpoint.api.host_name}/health

    -- Infrastructure --
    ACR:             ${azurerm_container_registry.acr.login_server}
    PostgreSQL:      ${azurerm_postgresql_flexible_server.main.fqdn}
    Key Vault:       ${azurerm_key_vault.main.vault_uri}

    -- Next Steps --
    1. Build and push Docker images to ACR
    2. Run database migration: az containerapp job start -n ${local.name_prefix}-db-seed -g ${azurerm_resource_group.main.name}
    3. Verify: curl https://${azurerm_cdn_frontdoor_endpoint.api.host_name}/health
    =====================================================
  EOT
  description = "Full deployment summary"
}
