# =============================================================================
# SDS Smart Mining Command Center - Azure Infrastructure
# Terraform Configuration
# =============================================================================

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.85"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = "~> 2.47"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # Remote state storage (uncomment for production)
  # backend "azurerm" {
  #   resource_group_name  = "sds-terraform-state-rg"
  #   storage_account_name = "sdsterraformstate"
  #   container_name       = "tfstate"
  #   key                  = "sds-mining.terraform.tfstate"
  # }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy    = var.environment == "dev" ? true : false
      recover_soft_deleted_key_vaults = true
    }
    resource_group {
      prevent_deletion_if_contains_resources = var.environment == "prod" ? true : false
    }
  }
  subscription_id = var.subscription_id
}

provider "azuread" {}

# =============================================================================
# Data Sources
# =============================================================================

data "azurerm_client_config" "current" {}

data "azuread_client_config" "current" {}

# =============================================================================
# Random Values for Unique Naming
# =============================================================================

resource "random_string" "suffix" {
  length  = 6
  special = false
  upper   = false
}

resource "random_password" "db_password" {
  length           = 32
  special          = true
  override_special = "!@#$%^&*"
  min_lower        = 4
  min_upper        = 4
  min_numeric      = 4
  min_special      = 2
}

resource "random_password" "jwt_secret" {
  length  = 64
  special = false
}

# =============================================================================
# Local Values
# =============================================================================

locals {
  project_name = "sds-mining"
  name_prefix  = "${local.project_name}-${var.environment}"
  name_suffix  = random_string.suffix.result

  common_tags = {
    Project     = "SDS Mining Command Center"
    Environment = var.environment
    ManagedBy   = "Terraform"
    Team        = "Mining Operations"
    CostCenter  = "MINING-OPS-${upper(var.environment)}"
  }

  # Container image references
  backend_image  = "${azurerm_container_registry.acr.login_server}/sds-backend:${var.image_tag}"
  react_image    = "${azurerm_container_registry.acr.login_server}/sds-frontend-react:${var.image_tag}"
  angular_image  = "${azurerm_container_registry.acr.login_server}/sds-frontend-angular:${var.image_tag}"
}
