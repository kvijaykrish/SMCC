# =============================================================================
# Azure Blob Storage (Reports, Backups, Static Assets)
# =============================================================================

resource "azurerm_storage_account" "main" {
  name                          = "stsds${var.environment}${local.name_suffix}"
  resource_group_name           = azurerm_resource_group.main.name
  location                      = azurerm_resource_group.main.location
  account_tier                  = "Standard"
  account_replication_type      = var.environment == "prod" ? "GRS" : "LRS"
  min_tls_version               = "TLS1_2"
  public_network_access_enabled = var.environment == "dev" ? true : false
  tags                          = local.common_tags

  blob_properties {
    versioning_enabled = var.environment == "prod" ? true : false

    delete_retention_policy {
      days = 7
    }

    container_delete_retention_policy {
      days = 7
    }
  }
}

# ── Containers ───────────────────────────────────────────────────────────────

resource "azurerm_storage_container" "reports" {
  name                  = "reports"
  storage_account_name  = azurerm_storage_account.main.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "backups" {
  name                  = "db-backups"
  storage_account_name  = azurerm_storage_account.main.name
  container_access_type = "private"
}

resource "azurerm_storage_container" "uploads" {
  name                  = "uploads"
  storage_account_name  = azurerm_storage_account.main.name
  container_access_type = "private"
}
