# =============================================================================
# Input Variables
# =============================================================================

# ── General ──────────────────────────────────────────────────────────────────

variable "subscription_id" {
  description = "Azure subscription ID"
  type        = string
}

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "dev"
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "Environment must be dev, staging, or prod."
  }
}

variable "location" {
  description = "Azure region for all resources"
  type        = string
  default     = "australiaeast"
}

variable "location_secondary" {
  description = "Secondary Azure region for geo-redundancy (prod only)"
  type        = string
  default     = "australiasoutheast"
}

# ── Networking ───────────────────────────────────────────────────────────────

variable "vnet_address_space" {
  description = "Virtual network CIDR block"
  type        = string
  default     = "10.0.0.0/16"
}

variable "subnet_container_apps_cidr" {
  description = "Subnet CIDR for Container Apps"
  type        = string
  default     = "10.0.0.0/21"
}

variable "subnet_postgres_cidr" {
  description = "Subnet CIDR for PostgreSQL"
  type        = string
  default     = "10.0.8.0/24"
}

variable "subnet_private_endpoints_cidr" {
  description = "Subnet CIDR for private endpoints"
  type        = string
  default     = "10.0.9.0/24"
}

# ── Container Registry ──────────────────────────────────────────────────────

variable "acr_sku" {
  description = "Azure Container Registry SKU"
  type        = string
  default     = "Basic"
  validation {
    condition     = contains(["Basic", "Standard", "Premium"], var.acr_sku)
    error_message = "ACR SKU must be Basic, Standard, or Premium."
  }
}

# ── Container Apps ───────────────────────────────────────────────────────────

variable "image_tag" {
  description = "Docker image tag to deploy"
  type        = string
  default     = "latest"
}

variable "backend_cpu" {
  description = "Backend container CPU cores"
  type        = number
  default     = 0.5
}

variable "backend_memory" {
  description = "Backend container memory (Gi)"
  type        = string
  default     = "1Gi"
}

variable "backend_min_replicas" {
  description = "Backend minimum replicas"
  type        = number
  default     = 1
}

variable "backend_max_replicas" {
  description = "Backend maximum replicas"
  type        = number
  default     = 5
}

variable "frontend_cpu" {
  description = "Frontend container CPU cores"
  type        = number
  default     = 0.25
}

variable "frontend_memory" {
  description = "Frontend container memory (Gi)"
  type        = string
  default     = "0.5Gi"
}

variable "frontend_min_replicas" {
  description = "Frontend minimum replicas"
  type        = number
  default     = 1
}

variable "frontend_max_replicas" {
  description = "Frontend maximum replicas"
  type        = number
  default     = 5
}

# ── Database ─────────────────────────────────────────────────────────────────

variable "postgres_sku" {
  description = "PostgreSQL Flexible Server SKU"
  type        = string
  default     = "B_Standard_B1ms"
}

variable "postgres_storage_mb" {
  description = "PostgreSQL storage in MB"
  type        = number
  default     = 32768
}

variable "postgres_version" {
  description = "PostgreSQL major version"
  type        = string
  default     = "14"
}

variable "postgres_ha_enabled" {
  description = "Enable zone-redundant high availability"
  type        = bool
  default     = false
}

variable "postgres_backup_retention_days" {
  description = "Backup retention period in days"
  type        = number
  default     = 7
}

variable "postgres_geo_redundant_backup" {
  description = "Enable geo-redundant backups"
  type        = bool
  default     = false
}

# ── Monitoring ───────────────────────────────────────────────────────────────

variable "log_analytics_retention_days" {
  description = "Log Analytics workspace retention in days"
  type        = number
  default     = 30
}

# ── Domain ───────────────────────────────────────────────────────────────────

variable "custom_domain" {
  description = "Custom domain for the application (optional)"
  type        = string
  default     = ""
}

# ── Alerts ───────────────────────────────────────────────────────────────────

variable "alert_email" {
  description = "Email address for Azure Monitor alerts"
  type        = string
  default     = "ops@mining-sds.com"
}
