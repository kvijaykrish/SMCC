# =============================================================================
# SDS Mining Command Center - Production Environment
# =============================================================================

subscription_id    = "YOUR_AZURE_SUBSCRIPTION_ID"
environment        = "prod"
location           = "australiaeast"
location_secondary = "australiasoutheast"

# Container Registry
acr_sku = "Standard"

# Container Apps - Backend
backend_cpu          = 2.0
backend_memory       = "4Gi"
backend_min_replicas = 2
backend_max_replicas = 20

# Container Apps - Frontend
frontend_cpu          = 0.5
frontend_memory       = "1Gi"
frontend_min_replicas = 2
frontend_max_replicas = 10

# Database
postgres_sku                   = "GP_Standard_D2s_v3"
postgres_storage_mb            = 131072
postgres_version               = "14"
postgres_ha_enabled            = true
postgres_backup_retention_days = 35
postgres_geo_redundant_backup  = true

# Monitoring
log_analytics_retention_days = 90

# Domain
custom_domain = "sds-mining.example.com"

# Alerts
alert_email = "production-ops@mining-sds.com"

# Image tag - use specific version in production
image_tag = "v2.1.0"
