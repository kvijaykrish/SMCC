# =============================================================================
# SDS Mining Command Center - Development Environment
# =============================================================================

subscription_id = "YOUR_AZURE_SUBSCRIPTION_ID"
environment     = "dev"
location        = "australiaeast"

# Container Registry
acr_sku = "Basic"

# Container Apps - Backend
backend_cpu          = 0.5
backend_memory       = "1Gi"
backend_min_replicas = 1
backend_max_replicas = 3

# Container Apps - Frontend
frontend_cpu          = 0.25
frontend_memory       = "0.5Gi"
frontend_min_replicas = 0
frontend_max_replicas = 3

# Database
postgres_sku                   = "B_Standard_B1ms"
postgres_storage_mb            = 32768
postgres_version               = "14"
postgres_ha_enabled            = false
postgres_backup_retention_days = 7
postgres_geo_redundant_backup  = false

# Monitoring
log_analytics_retention_days = 30

# Alerts
alert_email = "dev-ops@mining-sds.com"

# Image tag
image_tag = "latest"
