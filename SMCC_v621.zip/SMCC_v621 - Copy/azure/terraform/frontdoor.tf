# =============================================================================
# Azure Front Door - Global Load Balancer, CDN, WAF, SSL
# =============================================================================

resource "azurerm_cdn_frontdoor_profile" "main" {
  name                = "${local.name_prefix}-fd"
  resource_group_name = azurerm_resource_group.main.name
  sku_name            = "Standard_AzureFrontDoor"
  tags                = local.common_tags
}

# ── Endpoints ────────────────────────────────────────────────────────────────

resource "azurerm_cdn_frontdoor_endpoint" "react" {
  name                     = "${local.name_prefix}-react-ep"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.main.id
  tags                     = local.common_tags
}

resource "azurerm_cdn_frontdoor_endpoint" "angular" {
  name                     = "${local.name_prefix}-angular-ep"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.main.id
  tags                     = local.common_tags
}

resource "azurerm_cdn_frontdoor_endpoint" "api" {
  name                     = "${local.name_prefix}-api-ep"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.main.id
  tags                     = local.common_tags
}

# ── Origin Groups ────────────────────────────────────────────────────────────

resource "azurerm_cdn_frontdoor_origin_group" "react" {
  name                     = "react-origin-group"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.main.id
  session_affinity_enabled = false

  load_balancing {
    sample_size                 = 4
    successful_samples_required = 3
  }

  health_probe {
    path                = "/"
    protocol            = "Https"
    interval_in_seconds = 60
    request_type        = "HEAD"
  }
}

resource "azurerm_cdn_frontdoor_origin_group" "angular" {
  name                     = "angular-origin-group"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.main.id
  session_affinity_enabled = false

  load_balancing {
    sample_size                 = 4
    successful_samples_required = 3
  }

  health_probe {
    path                = "/health"
    protocol            = "Https"
    interval_in_seconds = 60
    request_type        = "HEAD"
  }
}

resource "azurerm_cdn_frontdoor_origin_group" "api" {
  name                     = "api-origin-group"
  cdn_frontdoor_profile_id = azurerm_cdn_frontdoor_profile.main.id
  session_affinity_enabled = true

  load_balancing {
    sample_size                 = 4
    successful_samples_required = 3
  }

  health_probe {
    path                = "/health"
    protocol            = "Https"
    interval_in_seconds = 30
    request_type        = "GET"
  }
}

# ── Origins ──────────────────────────────────────────────────────────────────

resource "azurerm_cdn_frontdoor_origin" "react" {
  name                          = "react-origin"
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.react.id
  enabled                       = true
  host_name                     = azurerm_container_app.frontend_react.ingress[0].fqdn
  http_port                     = 80
  https_port                    = 443
  origin_host_header            = azurerm_container_app.frontend_react.ingress[0].fqdn
  certificate_name_check_enabled = true
  priority                      = 1
  weight                        = 1000
}

resource "azurerm_cdn_frontdoor_origin" "angular" {
  name                          = "angular-origin"
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.angular.id
  enabled                       = true
  host_name                     = azurerm_container_app.frontend_angular.ingress[0].fqdn
  http_port                     = 80
  https_port                    = 443
  origin_host_header            = azurerm_container_app.frontend_angular.ingress[0].fqdn
  certificate_name_check_enabled = true
  priority                      = 1
  weight                        = 1000
}

resource "azurerm_cdn_frontdoor_origin" "api" {
  name                          = "api-origin"
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.api.id
  enabled                       = true
  host_name                     = azurerm_container_app.backend.ingress[0].fqdn
  http_port                     = 80
  https_port                    = 443
  origin_host_header            = azurerm_container_app.backend.ingress[0].fqdn
  certificate_name_check_enabled = true
  priority                      = 1
  weight                        = 1000
}

# ── Routes ───────────────────────────────────────────────────────────────────

resource "azurerm_cdn_frontdoor_route" "react" {
  name                          = "react-route"
  cdn_frontdoor_endpoint_id     = azurerm_cdn_frontdoor_endpoint.react.id
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.react.id
  cdn_frontdoor_origin_ids      = [azurerm_cdn_frontdoor_origin.react.id]
  enabled                       = true
  forwarding_protocol           = "HttpsOnly"
  https_redirect_enabled        = true
  patterns_to_match             = ["/*"]
  supported_protocols           = ["Http", "Https"]
  link_to_default_domain        = true

  cache {
    query_string_caching_behavior = "IgnoreQueryString"
    compression_enabled           = true
    content_types_to_compress     = [
      "text/html", "text/css", "application/javascript",
      "application/json", "image/svg+xml", "application/xml"
    ]
  }
}

resource "azurerm_cdn_frontdoor_route" "angular" {
  name                          = "angular-route"
  cdn_frontdoor_endpoint_id     = azurerm_cdn_frontdoor_endpoint.angular.id
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.angular.id
  cdn_frontdoor_origin_ids      = [azurerm_cdn_frontdoor_origin.angular.id]
  enabled                       = true
  forwarding_protocol           = "HttpsOnly"
  https_redirect_enabled        = true
  patterns_to_match             = ["/*"]
  supported_protocols           = ["Http", "Https"]
  link_to_default_domain        = true

  cache {
    query_string_caching_behavior = "IgnoreQueryString"
    compression_enabled           = true
    content_types_to_compress     = [
      "text/html", "text/css", "application/javascript",
      "application/json", "image/svg+xml", "application/xml"
    ]
  }
}

resource "azurerm_cdn_frontdoor_route" "api" {
  name                          = "api-route"
  cdn_frontdoor_endpoint_id     = azurerm_cdn_frontdoor_endpoint.api.id
  cdn_frontdoor_origin_group_id = azurerm_cdn_frontdoor_origin_group.api.id
  cdn_frontdoor_origin_ids      = [azurerm_cdn_frontdoor_origin.api.id]
  enabled                       = true
  forwarding_protocol           = "HttpsOnly"
  https_redirect_enabled        = true
  patterns_to_match             = ["/*"]
  supported_protocols           = ["Http", "Https"]
  link_to_default_domain        = true
}
