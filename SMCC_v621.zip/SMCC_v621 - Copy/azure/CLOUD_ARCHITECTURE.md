# SDS Smart Mining Command Center - Azure Cloud Architecture

## 1. Architecture Overview

```
                          +---------------------------+
                          |     Azure Front Door      |
                          |   (Global Load Balancer   |
                          |    + CDN + WAF + SSL)     |
                          +------+------+------+------+
                                 |      |      |
                    +------------+  +---+---+  +------------+
                    |               |       |               |
          +---------v---------+ +--v-------v--+ +---------v---------+
          | React Frontend    | | Angular     | | Backend API       |
          | Container App     | | Frontend    | | Container App     |
          | (Nginx + SPA)     | | Container   | | (Node.js/Express) |
          | Port 80           | | App         | | Port 3000         |
          +-------------------+ | Port 80     | | WebSocket: /ws    |
                                +-------------+ +--------+----------+
                                                         |
                                         +---------------+---------------+
                                         |               |               |
                                +--------v------+ +------v------+ +-----v--------+
                                | Azure DB for  | | Azure Key   | | Azure Monitor|
                                | PostgreSQL    | | Vault       | | + Log        |
                                | Flexible Srv  | | (Secrets)   | | Analytics    |
                                | + PostGIS     | +-------------+ +--------------+
                                +---------------+
                                         |
                                +--------v------+
                                | Azure Blob    |
                                | Storage       |
                                | (Backups,     |
                                |  Reports)     |
                                +---------------+
```

## 2. Azure Services Used

| Service | Purpose | SKU / Tier |
|---------|---------|------------|
| **Azure Container Registry** | Docker image storage | Basic (dev) / Standard (prod) |
| **Azure Container Apps** | Run backend + frontend containers | Consumption (auto-scale) |
| **Azure Container Apps Environment** | Shared networking for containers | Consumption |
| **Azure Database for PostgreSQL** | Primary database with PostGIS | Flexible Server - Burstable B1ms (dev) / GP D2s_v3 (prod) |
| **Azure Front Door** | Global LB, CDN, WAF, SSL termination | Standard |
| **Azure Key Vault** | Secret management (DB creds, JWT, API keys) | Standard |
| **Azure Virtual Network** | Network isolation | Custom /16 CIDR |
| **Azure Log Analytics Workspace** | Centralized logging | Pay-as-you-go |
| **Azure Application Insights** | APM and telemetry | Pay-as-you-go |
| **Azure Blob Storage** | Report exports, DB backups, static assets | Standard LRS |
| **Azure DNS Zone** | Custom domain management | Standard |

## 3. Network Architecture

```
VNet: 10.0.0.0/16
  |
  +-- Subnet: container-apps    10.0.0.0/21   (Container Apps Environment)
  +-- Subnet: postgres          10.0.8.0/24   (PostgreSQL Flexible Server)
  +-- Subnet: private-endpoints 10.0.9.0/24   (Key Vault, Storage, ACR)
```

- All inter-service communication stays within the VNet
- PostgreSQL uses Private Link (no public endpoint)
- Key Vault accessed via Private Endpoint
- Only Azure Front Door exposes services publicly
- NSG rules restrict east-west traffic

## 4. Security Architecture

### 4.1 Identity & Access
- Azure AD for admin/operator authentication
- Managed Identity on Container Apps for accessing Key Vault, ACR, Storage
- RBAC roles: Owner (infra), Contributor (devops), Reader (auditors)

### 4.2 Secrets Management
- All secrets stored in Azure Key Vault:
  - `db-password` - PostgreSQL admin password
  - `jwt-secret` - JWT signing key
  - `db-connection-string` - Full connection string
- Container Apps reference secrets from Key Vault via Managed Identity
- No secrets in environment variables or code

### 4.3 Network Security
- PostgreSQL: Private Link only (no public access)
- Container Apps: VNet-integrated, ingress via Front Door only
- Azure Front Door WAF: OWASP 3.2 ruleset
- TLS 1.2+ enforced everywhere
- DDoS Protection: Basic (included) / Standard (production)

### 4.4 Data Protection
- PostgreSQL: Encrypted at rest (AES-256), in transit (TLS)
- Blob Storage: Encrypted at rest (Microsoft-managed keys)
- Key Vault: HSM-backed keys (Premium tier for production)
- Automatic backups: 7-day retention (dev), 35-day (prod)

## 5. Container Apps Configuration

### 5.1 Backend API
```yaml
Name: sds-backend
Image: <acr>.azurecr.io/sds-backend:latest
CPU: 0.5 (dev) / 2.0 (prod)
Memory: 1Gi (dev) / 4Gi (prod)
Min Replicas: 1 (dev) / 2 (prod)
Max Replicas: 5 (dev) / 20 (prod)
Scale Rules:
  - HTTP: 50 concurrent requests
  - CPU: 70% threshold
Ingress:
  - External: true
  - Port: 3000
  - Transport: http (websocket enabled)
Health Probe:
  - Path: /health
  - Interval: 30s
```

### 5.2 React Frontend
```yaml
Name: sds-frontend-react
Image: <acr>.azurecr.io/sds-frontend-react:latest
CPU: 0.25
Memory: 0.5Gi
Min Replicas: 1
Max Replicas: 5
Ingress:
  - External: true
  - Port: 80
```

### 5.3 Angular Frontend
```yaml
Name: sds-frontend-angular
Image: <acr>.azurecr.io/sds-frontend-angular:latest
CPU: 0.25
Memory: 0.5Gi
Min Replicas: 1
Max Replicas: 5
Ingress:
  - External: true
  - Port: 80
```

### 5.4 DB Seeder (Job)
```yaml
Name: sds-db-seed
Type: Job (manual trigger)
Image: <acr>.azurecr.io/sds-backend:latest
Command: ["node", "dist/database/seed-all.js"]
Trigger: Manual / on-demand
```

## 6. Database Architecture

### 6.1 PostgreSQL Flexible Server
- **Version**: 14
- **Extensions**: PostGIS, uuid-ossp
- **High Availability**: Zone-redundant (production)
- **Backup**: Automated, 7-35 day retention
- **Connection Pooling**: PgBouncer built-in (enabled)
- **Firewall**: Private endpoint only (no public access)

### 6.2 Schema Highlights
- 30+ tables across 11 domains
- Time-series data: `asset_telemetry`, `water_quality_metrics`
- Spatial data: `zones` with PostGIS GEOGRAPHY columns
- Event sourcing: `mining_events` (2000+ indexed events)
- Audit trail: `audit_logs`, `ai_conversation_logs`

## 7. Observability

### 7.1 Monitoring Stack
- **Azure Monitor**: Infrastructure metrics, alerts
- **Application Insights**: APM, request tracing, dependency maps
- **Log Analytics**: Centralized log aggregation, KQL queries
- **Container Apps metrics**: CPU, memory, request count, latency

### 7.2 Alerts
| Alert | Condition | Severity |
|-------|-----------|----------|
| Backend Down | Health probe fails 3x | Critical |
| High CPU | >85% for 5 min | Warning |
| DB Connection Pool | >90% utilized | Warning |
| Error Rate | >5% 5xx responses | Critical |
| WebSocket Drops | >10 disconnects/min | Warning |
| Disk Usage | PostgreSQL >80% | Warning |

### 7.3 Dashboards
- Azure Portal: Resource health, cost analysis
- Application Insights: Live metrics, failure analysis
- Custom: Grafana via Azure Monitor data source (optional)

## 8. CI/CD Pipeline

```
GitHub Repository
       |
       v
  GitHub Actions
       |
  +----+----+
  |         |
  v         v
Build    Terraform
Images   Plan/Apply
  |         |
  v         v
Push to   Azure
ACR       Resources
  |
  v
Deploy to
Container Apps
  |
  v
Run DB Migrations
& Health Checks
```

### 8.1 Environments
| Environment | Branch | Auto-deploy | Approval |
|-------------|--------|-------------|----------|
| Development | `develop` | Yes | No |
| Staging | `staging` | Yes | No |
| Production | `main` | No | Required |

## 9. Cost Estimation (Monthly)

### Development Environment
| Service | Estimated Cost |
|---------|---------------|
| Container Apps (3 apps, min scale) | ~$30 |
| PostgreSQL Flexible (B1ms) | ~$25 |
| Container Registry (Basic) | ~$5 |
| Front Door (Standard) | ~$35 |
| Key Vault | ~$1 |
| Log Analytics (5GB/month) | ~$12 |
| Storage (10GB) | ~$1 |
| **Total** | **~$109/month** |

### Production Environment
| Service | Estimated Cost |
|---------|---------------|
| Container Apps (3 apps, auto-scale) | ~$150-400 |
| PostgreSQL Flexible (GP D2s_v3, HA) | ~$200 |
| Container Registry (Standard) | ~$20 |
| Front Door (Standard + WAF) | ~$75 |
| Key Vault + Private Endpoints | ~$10 |
| Log Analytics (50GB/month) | ~$115 |
| Storage (100GB) | ~$5 |
| **Total** | **~$575-825/month** |

## 10. Disaster Recovery

| Component | RPO | RTO | Strategy |
|-----------|-----|-----|----------|
| PostgreSQL | 5 min | 1 hour | Point-in-time restore, geo-redundant backup |
| Container Apps | 0 | 5 min | Multi-replica, auto-restart |
| Container Images | 0 | 10 min | Geo-replicated ACR |
| Secrets | 0 | 5 min | Key Vault soft-delete + purge protection |
| Static Assets | 0 | 15 min | LRS/GRS storage redundancy |

## 11. Deployment Commands

```bash
# 1. Initialize Terraform
cd azure/terraform
terraform init

# 2. Plan deployment
terraform plan -var-file="environments/dev.tfvars" -out=plan.tfplan

# 3. Apply infrastructure
terraform apply plan.tfplan

# 4. Build and push images
az acr login --name <acr-name>
docker build -t <acr>.azurecr.io/sds-backend:latest -f backend/Dockerfile.backend ./backend
docker push <acr>.azurecr.io/sds-backend:latest

# 5. Seed database
az containerapp job start -n sds-db-seed -g sds-mining-rg

# 6. Verify deployment
curl https://sds-mining.azurefd.net/health
```
