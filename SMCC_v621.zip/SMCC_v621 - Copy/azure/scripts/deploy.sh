#!/usr/bin/env bash
# =============================================================================
# SDS Mining Command Center - Azure Deployment Script
# =============================================================================
# Usage:
#   ./deploy.sh <environment> [action]
#   ./deploy.sh dev           # Full deploy (infra + images + seed)
#   ./deploy.sh prod plan     # Plan only
#   ./deploy.sh dev images    # Build & push images only
#   ./deploy.sh dev seed      # Run DB seed only
#   ./deploy.sh dev destroy   # Tear down infrastructure
# =============================================================================

set -euo pipefail

ENVIRONMENT="${1:-dev}"
ACTION="${2:-full}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
TERRAFORM_DIR="$SCRIPT_DIR/../terraform"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log() { echo -e "${BLUE}[SDS]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# ── Validate Prerequisites ──────────────────────────────────────────────────

check_prerequisites() {
  log "Checking prerequisites..."
  command -v az >/dev/null 2>&1 || error "Azure CLI not found. Install: https://aka.ms/installazurecli"
  command -v terraform >/dev/null 2>&1 || error "Terraform not found. Install: https://terraform.io/downloads"
  command -v docker >/dev/null 2>&1 || error "Docker not found. Install: https://docker.com"

  # Check Azure login
  az account show >/dev/null 2>&1 || error "Not logged in to Azure. Run: az login"
  success "All prerequisites met"
}

# ── Terraform Infrastructure ────────────────────────────────────────────────

deploy_infrastructure() {
  log "Deploying infrastructure for environment: $ENVIRONMENT"
  cd "$TERRAFORM_DIR"

  TFVARS_FILE="environments/${ENVIRONMENT}.tfvars"
  [ -f "$TFVARS_FILE" ] || error "tfvars file not found: $TFVARS_FILE"

  log "Initializing Terraform..."
  terraform init -upgrade

  log "Planning infrastructure changes..."
  terraform plan -var-file="$TFVARS_FILE" -out=plan.tfplan

  if [ "$ACTION" = "plan" ]; then
    success "Plan complete. Review above and run: ./deploy.sh $ENVIRONMENT apply"
    return
  fi

  log "Applying infrastructure..."
  terraform apply plan.tfplan
  rm -f plan.tfplan

  success "Infrastructure deployed successfully"
}

# ── Build & Push Docker Images ──────────────────────────────────────────────

build_and_push_images() {
  log "Building and pushing Docker images..."
  cd "$TERRAFORM_DIR"

  # Get ACR name from Terraform output
  ACR_SERVER=$(terraform output -raw acr_login_server 2>/dev/null)
  [ -n "$ACR_SERVER" ] || error "Cannot get ACR login server from Terraform output"

  ACR_NAME=$(echo "$ACR_SERVER" | cut -d. -f1)
  IMAGE_TAG="${IMAGE_TAG:-latest}"

  log "Logging in to ACR: $ACR_SERVER"
  az acr login --name "$ACR_NAME"

  cd "$PROJECT_ROOT"

  # Build Backend
  log "Building backend image..."
  docker build \
    -t "$ACR_SERVER/sds-backend:$IMAGE_TAG" \
    -t "$ACR_SERVER/sds-backend:latest" \
    -f backend/Dockerfile.backend \
    ./backend

  # Build React Frontend
  log "Building React frontend image..."
  docker build \
    -t "$ACR_SERVER/sds-frontend-react:$IMAGE_TAG" \
    -t "$ACR_SERVER/sds-frontend-react:latest" \
    -f Dockerfile.react \
    .

  # Build Angular Frontend
  log "Building Angular frontend image..."
  docker build \
    -t "$ACR_SERVER/sds-frontend-angular:$IMAGE_TAG" \
    -t "$ACR_SERVER/sds-frontend-angular:latest" \
    -f angular-frontend/Dockerfile.angular \
    ./angular-frontend

  # Push all images
  log "Pushing images to ACR..."
  docker push "$ACR_SERVER/sds-backend:$IMAGE_TAG"
  docker push "$ACR_SERVER/sds-backend:latest"
  docker push "$ACR_SERVER/sds-frontend-react:$IMAGE_TAG"
  docker push "$ACR_SERVER/sds-frontend-react:latest"
  docker push "$ACR_SERVER/sds-frontend-angular:$IMAGE_TAG"
  docker push "$ACR_SERVER/sds-frontend-angular:latest"

  success "All images built and pushed to $ACR_SERVER"
}

# ── Run Database Seed ───────────────────────────────────────────────────────

run_db_seed() {
  log "Running database seeder..."
  cd "$TERRAFORM_DIR"

  RG_NAME=$(terraform output -raw resource_group_name 2>/dev/null)
  JOB_NAME="sds-mining-${ENVIRONMENT}-db-seed"

  log "Starting seed job: $JOB_NAME in $RG_NAME"
  az containerapp job start \
    --name "$JOB_NAME" \
    --resource-group "$RG_NAME" \
    --output table

  success "Database seed job started. Check Azure Portal for status."
}

# ── Run Database Migration (schema only) ────────────────────────────────────

run_db_migrate() {
  log "Running database migration..."
  cd "$TERRAFORM_DIR"

  POSTGRES_FQDN=$(terraform output -raw postgres_fqdn 2>/dev/null)
  DB_PASSWORD=$(az keyvault secret show \
    --vault-name "$(terraform output -raw key_vault_name)" \
    --name "db-password" \
    --query "value" -o tsv 2>/dev/null)

  PGPASSWORD="$DB_PASSWORD" psql \
    -h "$POSTGRES_FQDN" \
    -U sdsadmin \
    -d sds_mining \
    -f "$PROJECT_ROOT/backend/src/database/schema.sql" \
    --set=sslmode=require

  success "Database migration complete"
}

# ── Health Check ────────────────────────────────────────────────────────────

health_check() {
  log "Running health checks..."
  cd "$TERRAFORM_DIR"

  API_URL=$(terraform output -raw frontdoor_api_endpoint 2>/dev/null)
  REACT_URL=$(terraform output -raw frontdoor_react_endpoint 2>/dev/null)
  ANGULAR_URL=$(terraform output -raw frontdoor_angular_endpoint 2>/dev/null)

  for URL in "$API_URL/health" "$REACT_URL" "$ANGULAR_URL"; do
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$URL" 2>/dev/null || echo "000")
    if [ "$STATUS" = "200" ]; then
      success "$URL -> HTTP $STATUS"
    else
      warn "$URL -> HTTP $STATUS"
    fi
  done
}

# ── Destroy ─────────────────────────────────────────────────────────────────

destroy_infrastructure() {
  warn "DESTROYING all infrastructure for environment: $ENVIRONMENT"
  read -p "Are you sure? Type 'yes' to confirm: " CONFIRM
  [ "$CONFIRM" = "yes" ] || error "Aborted"

  cd "$TERRAFORM_DIR"
  terraform destroy -var-file="environments/${ENVIRONMENT}.tfvars" -auto-approve
  success "Infrastructure destroyed"
}

# ── Main ────────────────────────────────────────────────────────────────────

echo ""
echo "============================================="
echo "  SDS Mining Command Center - Azure Deploy"
echo "  Environment: $ENVIRONMENT"
echo "  Action:      $ACTION"
echo "============================================="
echo ""

check_prerequisites

case "$ACTION" in
  full)
    deploy_infrastructure
    build_and_push_images
    run_db_migrate
    run_db_seed
    health_check
    ;;
  plan)
    deploy_infrastructure
    ;;
  apply)
    cd "$TERRAFORM_DIR"
    terraform apply -var-file="environments/${ENVIRONMENT}.tfvars" -auto-approve
    ;;
  images)
    build_and_push_images
    ;;
  seed)
    run_db_seed
    ;;
  migrate)
    run_db_migrate
    ;;
  health)
    health_check
    ;;
  destroy)
    destroy_infrastructure
    ;;
  *)
    error "Unknown action: $ACTION. Use: full|plan|apply|images|seed|migrate|health|destroy"
    ;;
esac

echo ""
success "Deployment script completed."
