#!/usr/bin/env bash
# =============================================================================
# Create Azure Storage Account for Terraform Remote State
# Run this ONCE before first terraform init
# =============================================================================

set -euo pipefail

RESOURCE_GROUP="sds-terraform-state-rg"
STORAGE_ACCOUNT="sdsterraformstate"
CONTAINER="tfstate"
LOCATION="australiaeast"

echo "Creating Terraform state backend..."

# Create resource group
az group create \
  --name "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --output none

# Create storage account
az storage account create \
  --name "$STORAGE_ACCOUNT" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --sku Standard_LRS \
  --kind StorageV2 \
  --min-tls-version TLS1_2 \
  --allow-blob-public-access false \
  --output none

# Create blob container
az storage container create \
  --name "$CONTAINER" \
  --account-name "$STORAGE_ACCOUNT" \
  --auth-mode login \
  --output none

echo ""
echo "Terraform backend created!"
echo ""
echo "Uncomment the backend block in main.tf:"
echo '  backend "azurerm" {'
echo "    resource_group_name  = \"$RESOURCE_GROUP\""
echo "    storage_account_name = \"$STORAGE_ACCOUNT\""
echo "    container_name       = \"$CONTAINER\""
echo '    key                  = "sds-mining.terraform.tfstate"'
echo '  }'
echo ""
echo "Then run: terraform init"
