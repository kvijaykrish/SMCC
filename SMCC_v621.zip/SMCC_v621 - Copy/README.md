# SDS Smart Mining Command Center

Enterprise-grade web application for smart mining operations management with real-time monitoring, asset tracking, network management, and comprehensive safety features.

## 🏗️ Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Angular 17     │────▶│  Node.js/Express │────▶│  PostgreSQL 14  │
│  Frontend       │◀────│  REST API       │◀────│  + PostGIS      │
│  (Port 4200)    │     │  (Port 3000)    │     │  (Port 5432)    │
└─────────────────┘     └─────────────────┘     └─────────────────┘
         │                       │
         │              ┌────────▼────────┐
         └──────────────│  WebSocket      │
                        │  Real-time Data │
                        └─────────────────┘
```

## 📋 Features

### Multi-Site Management

**Site Selection Landing Page**
- View all mining sites in your network
- Real-time metrics for each site
- Production, safety, and efficiency indicators
- Beautiful visual cards with site images
- Quick site switching

### Core Modules

1. **Dashboard**
   - Real-time KPI metrics
   - Site-specific data filtering
   - System-wide overview
   - Quick navigation to all modules

2. **Connected Assets & Digital Twins**
   - Asset lifecycle management
   - Real-time telemetry monitoring
   - 3D digital twin visualization
   - Predictive maintenance

3. **Private 5G Network**
   - Network tower monitoring
   - Device connectivity tracking
   - Bandwidth and latency metrics
   - Coverage mapping

4. **Geo-Spatial Intelligence**
   - Real-time asset location tracking
   - Zone management
   - Route optimization
   - Satellite/terrain views

5. **Security & Surveillance**
   - Camera feed monitoring
   - Security event detection
   - Access control logs
   - Perimeter breach alerts

6. **Water Management**
   - Pipeline system monitoring
   - Pump and valve control
   - Water quality tracking
   - Flow visualization

7. **Safety & Training**
   - Incident reporting and tracking
   - VR training modules
   - Safety compliance
   - Certification management

## 🚀 Quick Start

### Prerequisites

- Docker & Docker Compose
- Node.js 18+ (for local development)
- PostgreSQL 14+ (for local development without Docker)

### Option 1: One-Command Setup (Recommended)

**Linux/Mac:**
```bash
# Clone the repository
git clone <repository-url>
cd sds-mining-command-center

# Make setup script executable
chmod +x setup.sh

# Run complete setup
./setup.sh
```

**Windows:**
```bash
# Clone the repository
git clone <repository-url>
cd sds-mining-command-center

# Run complete setup
setup.bat
```

This automated script will:
- Start all Docker containers
- Run database migrations
- Create sample sites
- Seed initial data

### Option 2: Manual Docker Deployment

```bash
# Start all services
docker-compose up -d

# Run setup inside container
docker exec sds-backend npm run build
docker exec sds-postgres psql -U postgres -d sds_mining -f /app/src/database/sites-migration.sql
docker exec sds-backend node dist/database/seed-sites.js

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

**Services will be available at:**
- Frontend: http://localhost:4200
- Backend API: http://localhost:3000
- PostgreSQL: localhost:5432
- PgAdmin: http://localhost:5050

**Default Credentials:**
- Admin User: `admin@mining-sds.com` / `admin123`
- PgAdmin: `admin@mining-sds.com` / `admin`

### Option 2: Local Development

#### Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Update .env with your database credentials

# Run database migration
npm run migrate

# Seed initial data
npm run seed

# Start development server
npm run dev
```

#### Frontend Setup

```bash
cd angular-frontend

# Install dependencies
npm install

# Start development server
ng serve
```

## 📁 Project Structure

```
sds-mining-command-center/
├── angular-frontend/           # Angular application
│   ├── src/
│   │   ├── app/
│   │   │   ├── core/          # Services, guards, interceptors
│   │   │   ├── features/      # Feature modules (lazy-loaded)
│   │   │   ├── layout/        # Layout components
│   │   │   └── shared/        # Shared components
│   │   ├── environments/      # Environment configs
│   │   └── styles/           # Global styles
│   ├── Dockerfile
│   ├── nginx.conf
│   └── package.json
│
├── backend/                   # Node.js/Express API
│   ├── src/
│   │   ├── config/           # Configuration files
│   │   ├── database/         # Database schema & migrations
│   │   ├── middleware/       # Express middleware
│   │   ├── routes/           # API routes
│   │   ├── websocket/        # WebSocket server
│   │   └── server.ts         # Entry point
│   ├── Dockerfile
│   ├── .env.example
│   └── package.json
│
├── docker-compose.yml        # Docker orchestration
├── database-schema.md        # Complete database documentation
└── README.md                 # This file
```

## 🗄️ Database

### Schema Overview

The application uses PostgreSQL with PostGIS extension for geo-spatial features.

**Main Tables:**
- `users` - User authentication and profiles
- `assets` - Mining equipment and vehicles
- `asset_telemetry` - Time-series sensor data
- `asset_components` - Component health tracking
- `network_towers` - 5G network infrastructure
- `network_devices` - Connected devices
- `zones` - Operational zones (with geo-spatial boundaries)
- `cameras` - Security cameras
- `water_sources` - Water storage and sources
- `water_equipment` - Pumps, motors, valves
- `safety_incidents` - Safety incident tracking
- `training_courses` - Training content
- `alerts` - System-wide alerts

See [database-schema.md](./database-schema.md) for complete schema documentation.

### Database Management

**Using Docker:**
```bash
# Access PostgreSQL CLI
docker exec -it sds-postgres psql -U postgres -d sds_mining

# Backup database
docker exec sds-postgres pg_dump -U postgres sds_mining > backup.sql

# Restore database
docker exec -i sds-postgres psql -U postgres sds_mining < backup.sql
```

**Using PgAdmin:**
1. Open http://localhost:5050
2. Login with `admin@mining-sds.com` / `admin`
3. Add server: Host: `postgres`, Port: `5432`, User: `postgres`, Password: `postgres`

## 🔌 API Documentation

### Authentication

```bash
# Login
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@mining-sds.com",
  "password": "admin123"
}

# Response
{
  "token": "eyJhbGc...",
  "user": {
    "id": "uuid",
    "email": "admin@mining-sds.com",
    "fullName": "System Administrator",
    "role": "admin"
  }
}

# Use token in subsequent requests
GET /api/assets
Authorization: Bearer eyJhbGc...
```

### Main Endpoints

**Assets**
- `GET /api/assets` - List all assets
- `GET /api/assets/:id` - Get single asset
- `POST /api/assets` - Create asset
- `PUT /api/assets/:id` - Update asset
- `DELETE /api/assets/:id` - Delete asset
- `GET /api/assets/:id/telemetry` - Get telemetry data
- `GET /api/assets/:id/components` - Get components

**Network**
- `GET /api/network/towers` - List network towers
- `GET /api/network/devices` - List devices
- `GET /api/network/statistics` - Network statistics

**More endpoints in backend/src/routes/**

## 🔄 WebSocket Events

### Client Subscribes

```javascript
// Subscribe to asset telemetry
socket.emit('subscribe:asset:telemetry', { assetId: 'uuid' });

// Listen for updates
socket.on('asset:telemetry:uuid', (data) => {
  console.log('New telemetry:', data);
});

// Subscribe to alerts
socket.emit('subscribe:alerts');
socket.on('alert:new', (alert) => {
  console.log('New alert:', alert);
});
```

### Available Events

- `asset:telemetry:${assetId}` - Real-time asset data
- `network:metrics:${towerId}` - Network performance
- `alert:new` - New system alerts
- `security:event:new` - Security events
- `water:metrics:update` - Water system updates
- `geospatial:update` - Asset location updates

## 🔐 Security

### Implemented Security Features

- **JWT Authentication** - Secure token-based auth
- **Password Hashing** - bcrypt with salt rounds
- **HTTPS Ready** - SSL/TLS support
- **Helmet.js** - Security headers
- **Rate Limiting** - DDoS protection
- **CORS** - Cross-origin control
- **SQL Injection Prevention** - Parameterized queries
- **XSS Protection** - Input sanitization

### Production Recommendations

1. **Change default credentials**
2. **Use strong JWT secrets**
3. **Enable HTTPS**
4. **Configure firewall rules**
5. **Regular security updates**
6. **Database backups**
7. **Monitor access logs**

## 📊 Monitoring & Logging

### Application Logs

```bash
# Backend logs
docker-compose logs -f backend

# Frontend logs
docker-compose logs -f frontend

# Database logs
docker-compose logs -f postgres
```

### Health Checks

```bash
# Backend health
curl http://localhost:3000/health

# Frontend health
curl http://localhost:4200/health
```

## 🚢 Production Deployment

### Environment Variables

**Backend (.env)**
```env
NODE_ENV=production
PORT=3000
DB_HOST=your-db-host
DB_NAME=sds_mining
DB_USER=your-db-user
DB_PASSWORD=strong-password
JWT_SECRET=very-strong-secret-key
CORS_ORIGIN=https://your-domain.com
```

**Frontend (environment.prod.ts)**
```typescript
export const environment = {
  production: true,
  apiUrl: 'https://api.your-domain.com',
  wsUrl: 'wss://api.your-domain.com'
};
```

### Docker Production Build

```bash
# Build images
docker-compose build

# Deploy with production settings
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

### Cloud Deployment

**AWS**
- Use RDS for PostgreSQL
- ECS/EKS for containers
- CloudFront for frontend CDN
- Application Load Balancer

**Azure**
- Azure Database for PostgreSQL
- Azure Container Instances
- Azure CDN
- Application Gateway

**Google Cloud**
- Cloud SQL for PostgreSQL
- Google Kubernetes Engine
- Cloud CDN
- Cloud Load Balancing

## 🧪 Testing

```bash
# Backend tests
cd backend
npm test

# Frontend tests
cd angular-frontend
ng test

# E2E tests
ng e2e
```

## 📈 Performance Optimization

### Backend
- Connection pooling (configured)
- Query optimization with indexes
- Caching strategy (Redis recommended)
- Load balancing ready

### Frontend
- Lazy loading modules
- OnPush change detection
- Image optimization
- Service workers (PWA ready)
- Bundle optimization

## 🛠️ Development Tools

**Recommended VS Code Extensions:**
- Angular Language Service
- ESLint
- Prettier
- PostgreSQL
- Docker
- GitLens

## 🐛 Troubleshooting

### Common Issues

**Database connection failed**
```bash
# Check if PostgreSQL is running
docker ps | grep postgres

# Check database logs
docker-compose logs postgres

# Restart database
docker-compose restart postgres
```

**Frontend can't connect to backend**
- Check CORS settings in backend
- Verify API URL in frontend environment
- Check if backend is running on correct port

**WebSocket connection issues**
- Ensure WebSocket port is not blocked
- Check firewall settings
- Verify CORS for WebSocket

## 📝 License

Proprietary - All rights reserved

## 👥 Support

For support and questions:
- Email: support@mining-sds.com
- Documentation: https://docs.mining-sds.com

## 🔄 Version History

### v1.0.0 (2024)
- Initial release
- Complete 6-module implementation
- Real-time WebSocket support
- Docker deployment ready
- Production-grade security

---

**Built with ❤️ for Smart Mining Operations**
