# SDS Mining Command Center - Deployment Checklist

## Pre-Deployment

### System Requirements
- [ ] Docker Desktop installed and running
- [ ] 4GB+ RAM available
- [ ] 10GB+ disk space available
- [ ] Ports 3000, 4200, 5432, 5050 available

### Files Present
- [ ] docker-compose.yml exists
- [ ] backend/ directory with all files
- [ ] angular-frontend/ directory with all files
- [ ] setup.sh (Linux/Mac) or setup.bat (Windows)
- [ ] All documentation files

## Deployment Steps

### 1. Initial Setup
```bash
# Linux/Mac
□ chmod +x setup.sh
□ ./setup.sh

# Windows
□ setup.bat
```

### 2. Verify Containers
```bash
□ docker-compose ps
```

Expected output:
- [ ] sds-postgres - Up (healthy)
- [ ] sds-backend - Up
- [ ] sds-frontend - Up
- [ ] sds-pgadmin - Up

### 3. Verify Services

#### Frontend
```bash
□ curl http://localhost:4200/health
```
- [ ] Returns "healthy"

#### Backend
```bash
□ curl http://localhost:3000/health
```
- [ ] Returns JSON with status "OK"

#### Database
```bash
□ docker exec sds-postgres pg_isready
```
- [ ] Returns "accepting connections"

### 4. Database Verification

```bash
□ docker exec sds-postgres psql -U postgres -d sds_mining -c "SELECT COUNT(*) FROM sites"
```
- [ ] Returns count = 6

```bash
□ docker exec sds-postgres psql -U postgres -d sds_mining -c "SELECT COUNT(*) FROM users"
```
- [ ] Returns count >= 1 (admin user)

```bash
□ docker exec sds-postgres psql -U postgres -d sds_mining -c "SELECT COUNT(*) FROM assets"
```
- [ ] Returns count >= 5

### 5. Application Testing

#### Login Test
- [ ] Open http://localhost:4200
- [ ] See login page
- [ ] Enter: admin@mining-sds.com / admin123
- [ ] Successfully login

#### Site Selection Test
- [ ] Redirected to site selection page
- [ ] See 6 mining sites
- [ ] Each site shows:
  - [ ] Site image
  - [ ] Site name and location
  - [ ] Status badge
  - [ ] Metrics (assets, workforce, etc.)
  - [ ] Performance indicators
  - [ ] View button

#### Site Navigation Test
- [ ] Click on any site card
- [ ] Redirected to dashboard
- [ ] Header shows selected site name
- [ ] Dashboard loads without errors

#### Module Access Test
- [ ] Dashboard accessible
- [ ] Sidebar shows all modules
- [ ] Click each module link (should navigate even if placeholder)

#### Site Switching Test
- [ ] Click "Change Site" in header
- [ ] Return to site selection
- [ ] Select different site
- [ ] Dashboard updates with new site

### 6. Real-time Features

#### WebSocket Connection
- [ ] Open browser console (F12)
- [ ] Check for WebSocket connection message
- [ ] No WebSocket errors

#### Live Data Updates
- [ ] Stay on dashboard for 30 seconds
- [ ] Check if any metrics update
- [ ] Check browser console for telemetry data

### 7. API Testing

#### Authentication
```bash
□ curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@mining-sds.com","password":"admin123"}'
```
- [ ] Returns token and user object

#### Sites Endpoint
```bash
□ curl http://localhost:3000/api/sites \
  -H "Authorization: Bearer <TOKEN>"
```
- [ ] Returns array of 6 sites

#### Assets Endpoint
```bash
□ curl http://localhost:3000/api/assets \
  -H "Authorization: Bearer <TOKEN>"
```
- [ ] Returns array of assets

### 8. Database Admin

#### PgAdmin Access
- [ ] Open http://localhost:5050
- [ ] Login: admin@mining-sds.com / admin
- [ ] Dashboard loads

#### Add Server
- [ ] Click "Add New Server"
- [ ] General > Name: SDS Mining
- [ ] Connection > Host: postgres
- [ ] Connection > Port: 5432
- [ ] Connection > Database: sds_mining
- [ ] Connection > Username: postgres
- [ ] Connection > Password: postgres
- [ ] Save and connect successfully

#### Browse Data
- [ ] Expand: Servers > SDS Mining > Databases > sds_mining > Schemas > public > Tables
- [ ] Right-click on "sites" > View/Edit Data > All Rows
- [ ] See 6 sites
- [ ] Right-click on "users" > View/Edit Data > All Rows
- [ ] See admin user

## Post-Deployment

### Performance Checks

#### Resource Usage
```bash
□ docker stats
```
- [ ] All containers using < 500MB RAM
- [ ] CPU usage < 50% at idle

#### Log Checks
```bash
□ docker-compose logs backend | grep ERROR
□ docker-compose logs frontend | grep ERROR
□ docker-compose logs postgres | grep ERROR
```
- [ ] No critical errors
- [ ] No connection failures

### Security Verification

#### Default Credentials
- [ ] Note: Change these in production!
- [ ] Database password documented
- [ ] JWT secret documented
- [ ] Admin password documented

#### Network Security
- [ ] CORS origin set correctly
- [ ] Ports exposed only as needed
- [ ] No sensitive data in logs

### Browser Compatibility

Test in multiple browsers:
- [ ] Chrome/Edge (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)

For each browser:
- [ ] Login works
- [ ] Site selection loads
- [ ] Dashboard displays correctly
- [ ] No console errors

### Responsive Design

Test different screen sizes:
- [ ] Desktop (1920x1080)
- [ ] Laptop (1366x768)
- [ ] Tablet (768x1024)
- [ ] Mobile (375x667)

For each size:
- [ ] Layout adapts correctly
- [ ] Navigation accessible
- [ ] Images load properly
- [ ] Text readable

## Troubleshooting Results

### Common Issues Encountered
- [ ] None - Smooth deployment ✅
- [ ] Port conflicts - Resolved by changing ports
- [ ] Database connection - Resolved by restart
- [ ] Container startup - Resolved by rebuild
- [ ] Other: ___________________________

### Resolution Steps Taken
```
Document any issues and resolutions here:

Issue 1:
- Problem:
- Solution:

Issue 2:
- Problem:
- Solution:
```

## Production Readiness

### Before Going Live

#### Configuration
- [ ] Update backend/.env with production values
- [ ] Change JWT_SECRET to strong random value
- [ ] Change DB_PASSWORD to strong password
- [ ] Update CORS_ORIGIN to production domain
- [ ] Set NODE_ENV=production

#### Security
- [ ] Change admin password
- [ ] Change database password
- [ ] Enable HTTPS/SSL
- [ ] Configure firewall rules
- [ ] Set up rate limiting
- [ ] Enable authentication for all routes

#### Performance
- [ ] Set up CDN for frontend
- [ ] Configure database connection pooling
- [ ] Enable gzip compression (✓ already enabled)
- [ ] Set up caching layer (Redis recommended)
- [ ] Optimize database indexes

#### Monitoring
- [ ] Set up logging service
- [ ] Configure error tracking (e.g., Sentry)
- [ ] Set up uptime monitoring
- [ ] Configure alerts for critical errors
- [ ] Set up performance monitoring

#### Backup
- [ ] Configure automated database backups
- [ ] Test backup restoration
- [ ] Set up backup retention policy
- [ ] Document backup procedure
- [ ] Store backups securely off-site

#### Documentation
- [ ] API documentation complete
- [ ] Deployment runbook created
- [ ] User guide available
- [ ] Admin guide available
- [ ] Troubleshooting guide complete

## Sign-Off

### Deployment Team

**Deployed By:** ___________________________
**Date:** ___________________________
**Environment:** ☐ Development  ☐ Staging  ☐ Production

### Verification

**Tested By:** ___________________________
**Date:** ___________________________
**Status:** ☐ Pass  ☐ Fail  ☐ Conditional Pass

### Approval

**Approved By:** ___________________________
**Date:** ___________________________
**Signature:** ___________________________

## Notes

```
Additional deployment notes:











```

---

## Quick Status Summary

**Overall Status:** ☐ Ready  ☐ Issues Found  ☐ Not Ready

**Critical Issues:** ☐ None  ☐ Some  ☐ Blocking

**Recommendation:** ☐ Proceed  ☐ Fix Issues First  ☐ Abort

---

**Deployment Checklist v1.0**
