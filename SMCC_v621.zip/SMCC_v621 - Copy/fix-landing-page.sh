#!/bin/bash

# Fix Landing Page Script

echo "=========================================="
echo "🔧 Fixing Landing Page Issues"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "Step 1: Checking if sites table exists..."
SITES_EXISTS=$(docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT to_regclass('public.sites')" 2>&1)

if echo "$SITES_EXISTS" | grep -q "sites"; then
    echo -e "${GREEN}✓ Sites table exists${NC}"
else
    echo -e "${YELLOW}⚠ Creating sites table...${NC}"
    docker exec sds-postgres psql -U postgres -d sds_mining -f /app/src/database/sites-migration.sql
fi

echo ""
echo "Step 2: Checking if sites data exists..."
SITES_COUNT=$(docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT COUNT(*) FROM sites" 2>&1 | tr -d ' ')

if [ "$SITES_COUNT" -ge 1 ]; then
    echo -e "${GREEN}✓ Found $SITES_COUNT sites${NC}"
else
    echo -e "${YELLOW}⚠ No sites found. Seeding...${NC}"
    
    # Build backend first
    echo "   Building TypeScript..."
    docker exec sds-backend npm run build
    
    # Run seeding
    echo "   Seeding sites..."
    docker exec sds-backend node dist/database/seed-sites.js
    
    # Verify
    SITES_COUNT=$(docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT COUNT(*) FROM sites" 2>&1 | tr -d ' ')
    echo -e "${GREEN}✓ Created $SITES_COUNT sites${NC}"
fi

echo ""
echo "Step 3: Listing sites..."
docker exec sds-postgres psql -U postgres -d sds_mining -c "SELECT site_id, name, location FROM sites"

echo ""
echo "Step 4: Testing API endpoint..."
# Get token
echo "   Getting auth token..."
TOKEN=$(curl -s -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@mining-sds.com","password":"admin123"}' \
  | grep -o '"token":"[^"]*' | cut -d'"' -f4)

if [ -n "$TOKEN" ]; then
    echo -e "${GREEN}✓ Got auth token${NC}"
    
    # Test sites endpoint
    echo "   Testing /api/sites..."
    SITES_API=$(curl -s http://localhost:3000/api/sites \
      -H "Authorization: Bearer $TOKEN")
    
    if echo "$SITES_API" | grep -q "site_id"; then
        echo -e "${GREEN}✓ Sites API is working${NC}"
        echo "   Response preview:"
        echo "$SITES_API" | head -c 200
        echo "..."
    else
        echo "✗ Sites API failed"
        echo "   Response: $SITES_API"
    fi
else
    echo "✗ Could not get auth token"
fi

echo ""
echo "Step 5: Restarting frontend..."
docker-compose restart frontend

echo ""
echo "=========================================="
echo -e "${GREEN}✅ Fix Complete!${NC}"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Wait 10 seconds for frontend to restart"
echo "2. Clear your browser cache (Ctrl+Shift+Delete)"
echo "3. Open http://localhost:4200"
echo "4. Login with: admin@mining-sds.com / admin123"
echo "5. You should see 6 mining sites!"
echo ""
echo "If still not working:"
echo "- Check browser console (F12) for errors"
echo "- Run: docker-compose logs -f backend"
echo "- Try: docker-compose down -v && ./setup.sh"
echo ""
