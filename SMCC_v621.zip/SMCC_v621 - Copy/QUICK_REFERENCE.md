# SDS Mining Command Center - Quick Reference

## 🚀 Instant Setup

### One Command (Easiest)

**Linux/Mac:**
```bash
./setup.sh
```

**Windows:**
```bash
setup.bat
```

### Access the Application

```
URL:      http://localhost:4200
Email:    admin@mining-sds.com
Password: admin123
```

## 📊 What You Get

### 6 Mining Sites

1. **Northern Ridge Mine** (Australia) - Iron Ore - 25M tonnes/year
2. **Sierra Verde Complex** (Chile) - Copper - 18M tonnes/year
3. **Goldstream Underground** (Canada) - Gold - 2.5M tonnes/year
4. **Eastern Bauxite Fields** (Australia) - Bauxite - 12M tonnes/year
5. **Platinum Ridge** (South Africa) - Platinum - 1.8M tonnes/year
6. **Central Processing Hub** (USA) - Processing - 5M tonnes/year

### 7 Command Center Modules

1. **Site Selection** - Choose which mine to manage
2. **Dashboard** - Real-time KPIs and metrics
3. **Connected Assets** - Equipment & digital twins
4. **Private 5G Network** - Network monitoring
5. **Geo-Spatial Intelligence** - Location tracking
6. **Security** - Cameras & surveillance
7. **Water & Safety** - Management systems

## 🎯 User Flow

```
Login → Select Site → View Dashboard → Explore Modules
   ↓         ↓              ↓              ↓
 Auth    Site Mgmt    Site-specific   Real-time
         Landing        Metrics          Data
```

## 🛠️ Common Commands

### Start
```bash
docker-compose up -d
```

### Stop
```bash
docker-compose down
```

### View Logs
```bash
docker-compose logs -f
docker-compose logs -f backend
docker-compose logs -f frontend
```

### Restart
```bash
docker-compose restart
docker-compose restart backend
```

### Full Reset
```bash
docker-compose down -v
docker-compose up -d
./setup.sh  # or setup.bat on Windows
```

## 🔌 Service URLs

| Service | URL | Credentials |
|---------|-----|-------------|
| Frontend | http://localhost:4200 | admin@mining-sds.com / admin123 |
| Backend API | http://localhost:3000 | Bearer token required |
| Database | localhost:5432 | postgres / postgres |
| PgAdmin | http://localhost:5050 | admin@mining-sds.com / admin |

## 🗄️ Database Quick Access

### Via Docker
```bash
# PostgreSQL CLI
docker exec -it sds-postgres psql -U postgres -d sds_mining

# Common queries
SELECT COUNT(*) FROM sites;
SELECT COUNT(*) FROM assets;
SELECT * FROM users;
```

### Via PgAdmin
1. Open http://localhost:5050
2. Login: admin@mining-sds.com / admin
3. Add Server:
   - Name: SDS Mining
   - Host: postgres
   - Port: 5432
   - Database: sds_mining
   - User: postgres
   - Password: postgres

## 📡 API Quick Test

```bash
# Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@mining-sds.com","password":"admin123"}'

# Get sites (replace TOKEN)
curl http://localhost:3000/api/sites \
  -H "Authorization: Bearer TOKEN"

# Health check
curl http://localhost:3000/health
```

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Find process using port 4200
netstat -ano | findstr :4200  # Windows
lsof -i :4200                  # Mac/Linux

# Change port in docker-compose.yml
ports:
  - "8080:80"  # Changed from 4200
```

### Database Not Connecting
```bash
# Check if PostgreSQL is running
docker ps | grep postgres

# Check logs
docker-compose logs postgres

# Restart database
docker-compose restart postgres
```

### Frontend Not Loading
```bash
# Check if frontend container is running
docker ps | grep frontend

# Rebuild frontend
docker-compose build frontend
docker-compose up -d frontend
```

### Backend Errors
```bash
# View backend logs
docker-compose logs -f backend

# Restart backend
docker-compose restart backend

# Check environment variables
docker exec sds-backend env | grep DB_
```

## 📦 Project Structure

```
sds-mining-command-center/
├── backend/              # Node.js API
│   ├── src/
│   │   ├── routes/      # API endpoints
│   │   ├── database/    # Migrations & seeds
│   │   └── server.ts    # Entry point
│   └── Dockerfile
├── angular-frontend/     # Angular UI
│   ├── src/app/
│   │   ├── features/    # Pages
│   │   ├── core/        # Services
│   │   └── layout/      # Layout
│   └── Dockerfile
├── docker-compose.yml   # Container orchestration
├── setup.sh            # Linux/Mac setup
├── setup.bat           # Windows setup
└── README.md           # Full documentation
```

## 🔐 Security Notes

### Change Before Production
1. JWT secret in backend/.env
2. Database password
3. Admin user password
4. CORS origin settings

### Default Passwords to Change
- Database: postgres/postgres
- Admin: admin@mining-sds.com/admin123
- PgAdmin: admin@mining-sds.com/admin

## 📚 Documentation

- **Full Setup**: See README.md
- **Deployment**: See DEPLOYMENT.md
- **Site Feature**: See SETUP_SITES.md
- **Quick Start**: See START.md

## 🎓 Learning Path

### Day 1 - Setup & Explore
1. Run setup script
2. Login and explore site selection
3. Choose a site and view dashboard
4. Check each module

### Day 2 - Understand Architecture
1. Review database schema
2. Test API endpoints
3. Understand WebSocket updates
4. Explore Angular components

### Day 3 - Customize
1. Add a new site
2. Modify site metrics
3. Update branding
4. Add custom features

## 💡 Tips

- **Logs**: Always check logs first when troubleshooting
- **Cache**: Clear browser cache if UI doesn't update
- **Database**: Use PgAdmin for easy database management
- **API**: Use Postman or curl to test API endpoints
- **Development**: Edit files locally, containers auto-reload

## 🆘 Getting Help

1. Check logs: `docker-compose logs -f`
2. Review documentation files
3. Verify Docker is running
4. Ensure ports are available
5. Try full reset if stuck

---

**Quick Reference v1.0** | For detailed info, see README.md
