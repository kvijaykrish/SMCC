@echo off

echo ==========================================
echo 🔄 Rebuilding Frontend with Fixes
echo ==========================================
echo.

REM Stop frontend
echo 1. Stopping frontend container...
docker-compose stop frontend

REM Rebuild frontend (no cache to ensure fresh build)
echo.
echo 2. Rebuilding frontend with latest code...
docker-compose build --no-cache frontend

REM Start frontend
echo.
echo 3. Starting frontend...
docker-compose up -d frontend

echo.
echo 4. Waiting for frontend to start (20 seconds)...
timeout /t 20 /nobreak >nul

REM Ensure backend has sites
echo.
echo 5. Ensuring sites exist in database...
docker exec sds-backend npm run build
docker exec sds-backend node dist/database/seed-sites.js

echo.
echo ==========================================
echo ✅ Frontend Rebuilt!
echo ==========================================
echo.
echo NOW:
echo 1. Open: http://localhost:4200
echo 2. Clear browser cache (Ctrl+Shift+Delete)
echo 3. Login: admin@mining-sds.com / admin123
echo 4. You should see the SITE SELECTION PAGE!
echo.
echo If still not working, open browser console (F12)
echo and share any error messages you see.
echo.
pause
