import { pool } from '../config/database';
import bcrypt from 'bcrypt';

async function seed() {
  console.log('🌱 Starting database seeding...');

  try {
    // Create admin user
    const hashedPassword = await bcrypt.hash('admin123', 10);
    await pool.query(`
      INSERT INTO users (email, password_hash, full_name, role, department)
      VALUES ($1, $2, $3, $4, $5)
      ON CONFLICT (email) DO NOTHING
    `, ['admin@mining-sds.com', hashedPassword, 'System Administrator', 'admin', 'IT']);

    console.log('✅ Admin user created (email: admin@mining-sds.com, password: admin123)');

    // Create sample zones
    const zones = [
      { zone_id: 'zone-a', name: 'Zone A - Primary Pit', type: 'primary_pit', lat: -23.5505, lng: 46.6333 },
      { zone_id: 'zone-b', name: 'Zone B - Processing', type: 'processing', lat: -23.5515, lng: 46.6343 },
      { zone_id: 'zone-c', name: 'Zone C - Secondary Pit', type: 'secondary_pit', lat: -23.5525, lng: 46.6353 },
      { zone_id: 'zone-d', name: 'Zone D - Maintenance', type: 'maintenance', lat: -23.5535, lng: 46.6363 }
    ];

    for (const zone of zones) {
      await pool.query(`
        INSERT INTO zones (zone_id, name, zone_type, center_latitude, center_longitude, max_capacity, speed_limit)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (zone_id) DO NOTHING
      `, [zone.zone_id, zone.name, zone.type, zone.lat, zone.lng, 20, 40]);
    }

    console.log('✅ Sample zones created');

    // Create sample assets
    const assets = [
      { asset_id: 'EXC-001', name: 'Excavator Unit 1', type: 'excavator', manufacturer: 'Caterpillar', model: '336F' },
      { asset_id: 'HTK-001', name: 'Haul Truck Unit 1', type: 'haul_truck', manufacturer: 'Komatsu', model: '930E-4' },
      { asset_id: 'DRL-001', name: 'Drill Unit 1', type: 'drill', manufacturer: 'Sandvik', model: 'DI650i' },
      { asset_id: 'DOZ-001', name: 'Dozer Unit 1', type: 'dozer', manufacturer: 'Caterpillar', model: 'D11T' },
      { asset_id: 'LDR-001', name: 'Loader Unit 1', type: 'loader', manufacturer: 'Komatsu', model: 'WA900-8' }
    ];

    for (const asset of assets) {
      await pool.query(`
        INSERT INTO assets (asset_id, name, type, manufacturer, model, operating_hours, status)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (asset_id) DO NOTHING
      `, [asset.asset_id, asset.name, asset.type, asset.manufacturer, asset.model, 1250.5, 'active']);
    }

    console.log('✅ Sample assets created');

    // Create network towers
    const towers = [
      { tower_id: 'TWR-001', name: 'Tower 1 - North', lat: -23.5500, lng: 46.6320, band: 'n77', bandwidth: 1000 },
      { tower_id: 'TWR-002', name: 'Tower 2 - South', lat: -23.5530, lng: 46.6350, band: 'n78', bandwidth: 1000 },
      { tower_id: 'TWR-003', name: 'Tower 3 - East', lat: -23.5520, lng: 46.6370, band: 'n77', bandwidth: 1000 }
    ];

    for (const tower of towers) {
      await pool.query(`
        INSERT INTO network_towers (tower_id, name, latitude, longitude, frequency_band, max_bandwidth, coverage_radius, uptime_percentage)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        ON CONFLICT (tower_id) DO NOTHING
      `, [tower.tower_id, tower.name, tower.lat, tower.lng, tower.band, tower.bandwidth, 5000, 99.8]);
    }

    console.log('✅ Network towers created');

    // Create water sources
    const waterSources = [
      { source_id: 'RES-001', name: 'Main Reservoir', type: 'reservoir', capacity: 5000000 },
      { source_id: 'TNK-001', name: 'Storage Tank 1', type: 'tank', capacity: 500000 }
    ];

    for (const source of waterSources) {
      await pool.query(`
        INSERT INTO water_sources (source_id, name, source_type, capacity_liters, current_level_liters, water_quality_score, ph_level)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (source_id) DO NOTHING
      `, [source.source_id, source.name, source.type, source.capacity, source.capacity * 0.75, 95.5, 7.2]);
    }

    console.log('✅ Water sources created');

    // Create sample cameras
    const cameras = [
      { camera_id: 'CAM-001', name: 'Gate 1 Camera', type: 'fixed', resolution: '4K' },
      { camera_id: 'CAM-002', name: 'Zone A Overview', type: 'ptz', resolution: '1080p' },
      { camera_id: 'CAM-003', name: 'Perimeter North', type: '360', resolution: '4K' }
    ];

    for (const camera of cameras) {
      await pool.query(`
        INSERT INTO cameras (camera_id, name, camera_type, resolution, has_night_vision, has_motion_detection, uptime_percentage)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        ON CONFLICT (camera_id) DO NOTHING
      `, [camera.camera_id, camera.name, camera.type, camera.resolution, true, true, 98.5]);
    }

    console.log('✅ Cameras created');

    console.log('🎉 Database seeding completed successfully');
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

// Run seeding if called directly
if (require.main === module) {
  seed()
    .then(() => {
      console.log('✅ Seeding completed');
      process.exit(0);
    })
    .catch((error) => {
      console.error('❌ Seeding failed:', error);
      process.exit(1);
    });
}

export default seed;
