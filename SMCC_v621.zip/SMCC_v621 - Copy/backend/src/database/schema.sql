-- SDS Mining Command Center Database Schema
-- PostgreSQL 14+ with PostGIS

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- =============================================
-- USERS & AUTHENTICATION
-- =============================================

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL CHECK (role IN ('admin', 'operator', 'supervisor', 'engineer', 'safety_officer')),
  department VARCHAR(100),
  phone VARCHAR(20),
  avatar_url TEXT,
  is_active BOOLEAN DEFAULT true,
  last_login_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active);

-- =============================================
-- SITES / MINES
-- =============================================

CREATE TABLE IF NOT EXISTS sites (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  site_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  location VARCHAR(255) NOT NULL,
  country VARCHAR(100),
  region VARCHAR(100),
  site_type VARCHAR(50) CHECK (site_type IN ('open_pit', 'underground', 'processing_plant', 'exploration')),
  status VARCHAR(50) DEFAULT 'operational' CHECK (status IN ('operational', 'maintenance', 'commissioning', 'decommissioning', 'closed')),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  timezone VARCHAR(50) DEFAULT 'UTC',
  established_date DATE,
  area_sq_km DECIMAL(10, 2),
  max_depth_meters DECIMAL(8, 2),
  primary_commodity VARCHAR(100),
  secondary_commodities TEXT[],
  annual_capacity_tonnes DECIMAL(12, 2),
  workforce_count INTEGER,
  site_manager_id UUID REFERENCES users(id),
  contact_email VARCHAR(255),
  contact_phone VARCHAR(20),
  image_url TEXT,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sites_status ON sites(status);
CREATE INDEX IF NOT EXISTS idx_sites_type ON sites(site_type);
CREATE INDEX IF NOT EXISTS idx_sites_active ON sites(is_active);

-- Site Metrics (real-time KPIs)
CREATE TABLE IF NOT EXISTS site_metrics (
  id BIGSERIAL PRIMARY KEY,
  site_id UUID REFERENCES sites(id) ON DELETE CASCADE,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  total_assets INTEGER DEFAULT 0,
  active_assets INTEGER DEFAULT 0,
  assets_in_maintenance INTEGER DEFAULT 0,
  production_tonnes_today DECIMAL(10, 2) DEFAULT 0,
  production_tonnes_mtd DECIMAL(10, 2) DEFAULT 0,
  network_uptime_percentage DECIMAL(5, 2) DEFAULT 100,
  active_alerts INTEGER DEFAULT 0,
  critical_alerts INTEGER DEFAULT 0,
  safety_incidents_today INTEGER DEFAULT 0,
  safety_incidents_mtd INTEGER DEFAULT 0,
  water_consumption_liters_today DECIMAL(12, 2) DEFAULT 0,
  power_consumption_kwh_today DECIMAL(10, 2) DEFAULT 0,
  workforce_present INTEGER DEFAULT 0,
  operational_efficiency DECIMAL(5, 2) DEFAULT 0,
  environmental_compliance_score DECIMAL(5, 2) DEFAULT 100
);

CREATE INDEX IF NOT EXISTS idx_site_metrics_site ON site_metrics(site_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_site_metrics_timestamp ON site_metrics(timestamp DESC);

-- =============================================
-- ZONES (GEO-SPATIAL)
-- =============================================

CREATE TABLE IF NOT EXISTS zones (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  zone_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  zone_type VARCHAR(50) CHECK (zone_type IN ('primary_pit', 'secondary_pit', 'processing', 'maintenance', 'office', 'restricted', 'mining', 'storage', 'administration')),
  boundary GEOGRAPHY(POLYGON, 4326),
  area_sq_meters DECIMAL(12, 2),
  area_sq_km DECIMAL(10, 4),
  center_latitude DECIMAL(10, 8),
  center_longitude DECIMAL(11, 8),
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'maintenance', 'restricted')),
  max_capacity INTEGER,
  current_asset_count INTEGER DEFAULT 0,
  personnel_count INTEGER DEFAULT 0,
  speed_limit INTEGER,
  requires_permit BOOLEAN DEFAULT false,
  hazard_level VARCHAR(20) CHECK (hazard_level IN ('low', 'medium', 'high', 'critical')),
  color VARCHAR(20) DEFAULT '#3B82F6',
  description TEXT,
  supervisor_id UUID REFERENCES users(id),
  site_id UUID REFERENCES sites(id),
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_zones_type ON zones(zone_type);
CREATE INDEX IF NOT EXISTS idx_zones_status ON zones(status);
CREATE INDEX IF NOT EXISTS idx_zones_site ON zones(site_id);

-- Geo-Fences
CREATE TABLE IF NOT EXISTS geofences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  fence_type VARCHAR(50) CHECK (fence_type IN ('inclusion', 'exclusion', 'speed_limit')),
  coordinates JSONB NOT NULL,
  radius DECIMAL(10, 2),
  speed_limit INTEGER,
  alert_on_breach BOOLEAN DEFAULT true,
  is_active BOOLEAN DEFAULT true,
  site_id UUID REFERENCES sites(id),
  zone_id UUID REFERENCES zones(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_geofences_active ON geofences(is_active);
CREATE INDEX IF NOT EXISTS idx_geofences_site ON geofences(site_id);

-- Geo-Spatial Alerts
CREATE TABLE IF NOT EXISTS geospatial_alerts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  alert_type VARCHAR(50) CHECK (alert_type IN ('boundary_breach', 'speed_violation', 'unauthorized_zone', 'proximity_warning')),
  asset_id UUID,
  asset_name VARCHAR(255),
  zone VARCHAR(255),
  message TEXT NOT NULL,
  severity VARCHAR(20) CHECK (severity IN ('low', 'medium', 'high')),
  resolved BOOLEAN DEFAULT false,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_geo_alerts_resolved ON geospatial_alerts(resolved);

-- =============================================
-- ASSETS
-- =============================================

CREATE TABLE IF NOT EXISTS assets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  asset_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL CHECK (type IN ('excavator', 'haul_truck', 'drill', 'dozer', 'loader', 'grader', 'water_truck')),
  manufacturer VARCHAR(100),
  model VARCHAR(100),
  serial_number VARCHAR(100) UNIQUE,
  year_manufactured INTEGER,
  purchase_date DATE,
  warranty_expires_at DATE,
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'maintenance', 'inactive', 'retired')),
  current_zone_id UUID REFERENCES zones(id),
  assigned_operator_id UUID REFERENCES users(id),
  operating_hours DECIMAL(10,2) DEFAULT 0,
  last_maintenance_at TIMESTAMP,
  next_maintenance_at TIMESTAMP,
  maintenance_interval_hours INTEGER DEFAULT 250,
  site_id UUID REFERENCES sites(id),
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_assets_type ON assets(type);
CREATE INDEX IF NOT EXISTS idx_assets_status ON assets(status);
CREATE INDEX IF NOT EXISTS idx_assets_zone ON assets(current_zone_id);
CREATE INDEX IF NOT EXISTS idx_assets_site ON assets(site_id);

-- Asset Telemetry (Time-series data)
CREATE TABLE IF NOT EXISTS asset_telemetry (
  id BIGSERIAL PRIMARY KEY,
  asset_id UUID REFERENCES assets(id) ON DELETE CASCADE,
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  altitude DECIMAL(8, 2),
  heading DECIMAL(5, 2),
  speed DECIMAL(6, 2),
  engine_temp DECIMAL(5, 2),
  hydraulic_pressure DECIMAL(6, 2),
  fuel_level DECIMAL(5, 2),
  battery_voltage DECIMAL(4, 2),
  load_weight DECIMAL(10, 2),
  vibration_level DECIMAL(5, 2),
  rpm INTEGER,
  gear INTEGER,
  is_operating BOOLEAN DEFAULT false,
  error_codes TEXT[],
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_telemetry_asset ON asset_telemetry(asset_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_timestamp ON asset_telemetry(timestamp DESC);

-- Asset Components
CREATE TABLE IF NOT EXISTS asset_components (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  asset_id UUID REFERENCES assets(id) ON DELETE CASCADE,
  component_id VARCHAR(50) NOT NULL,
  name VARCHAR(255) NOT NULL,
  health_score DECIMAL(5, 2) DEFAULT 100,
  status VARCHAR(50) DEFAULT 'optimal' CHECK (status IN ('optimal', 'good', 'warning', 'critical')),
  temperature DECIMAL(5, 2),
  pressure DECIMAL(6, 2),
  vibration DECIMAL(5, 2),
  wear_level DECIMAL(5, 2),
  operating_hours DECIMAL(10, 2) DEFAULT 0,
  last_maintenance_at TIMESTAMP,
  next_maintenance_hours INTEGER,
  metadata JSONB,
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_components_asset ON asset_components(asset_id);
CREATE INDEX IF NOT EXISTS idx_components_status ON asset_components(status);

-- =============================================
-- NETWORK (Private 5G)
-- =============================================

CREATE TABLE IF NOT EXISTS network_towers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  tower_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  altitude DECIMAL(8, 2),
  frequency_band VARCHAR(20),
  max_bandwidth INTEGER,
  coverage_radius INTEGER,
  antenna_type VARCHAR(100),
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'maintenance', 'offline')),
  uptime_percentage DECIMAL(5, 2) DEFAULT 100,
  current_load DECIMAL(5, 2) DEFAULT 0,
  connected_devices INTEGER DEFAULT 0,
  signal_strength DECIMAL(5, 2),
  installed_at DATE,
  last_maintenance_at TIMESTAMP,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_towers_status ON network_towers(status);
CREATE INDEX IF NOT EXISTS idx_towers_site ON network_towers(site_id);

CREATE TABLE IF NOT EXISTS network_devices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  device_id VARCHAR(100) UNIQUE NOT NULL,
  device_name VARCHAR(255),
  device_type VARCHAR(50) CHECK (device_type IN ('asset', 'sensor', 'camera', 'gateway', 'router')),
  asset_id UUID REFERENCES assets(id),
  tower_id UUID REFERENCES network_towers(id),
  ip_address INET,
  mac_address MACADDR,
  imei VARCHAR(20),
  sim_card_id VARCHAR(50),
  signal_strength DECIMAL(5, 2),
  latency INTEGER,
  bandwidth_up INTEGER,
  bandwidth_down INTEGER,
  packet_loss DECIMAL(5, 2),
  status VARCHAR(50) DEFAULT 'online' CHECK (status IN ('online', 'offline', 'error')),
  last_seen_at TIMESTAMP DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_devices_type ON network_devices(device_type);
CREATE INDEX IF NOT EXISTS idx_devices_asset ON network_devices(asset_id);
CREATE INDEX IF NOT EXISTS idx_devices_tower ON network_devices(tower_id);

-- =============================================
-- SECURITY
-- =============================================

CREATE TABLE IF NOT EXISTS cameras (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  camera_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  zone_id UUID REFERENCES zones(id),
  installation_location VARCHAR(255),
  camera_type VARCHAR(50) CHECK (camera_type IN ('fixed', 'ptz', 'thermal', '360')),
  resolution VARCHAR(20),
  fps INTEGER DEFAULT 30,
  field_of_view INTEGER,
  has_night_vision BOOLEAN DEFAULT false,
  has_motion_detection BOOLEAN DEFAULT false,
  ptz_enabled BOOLEAN DEFAULT false,
  stream_url TEXT,
  rtsp_url TEXT,
  thumbnail_url TEXT,
  status VARCHAR(50) DEFAULT 'online' CHECK (status IN ('online', 'offline', 'maintenance', 'error')),
  is_recording BOOLEAN DEFAULT true,
  uptime_percentage DECIMAL(5, 2) DEFAULT 100,
  last_maintenance_at TIMESTAMP,
  installed_at TIMESTAMP,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cameras_zone ON cameras(zone_id);
CREATE INDEX IF NOT EXISTS idx_cameras_status ON cameras(status);
CREATE INDEX IF NOT EXISTS idx_cameras_site ON cameras(site_id);

-- Security Events
CREATE TABLE IF NOT EXISTS security_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  event_type VARCHAR(50) NOT NULL CHECK (event_type IN ('access_alert', 'perimeter_breach', 'unauthorized_vehicle', 'motion_detected', 'personnel_safety')),
  severity VARCHAR(20) NOT NULL CHECK (severity IN ('critical', 'warning', 'info')),
  location VARCHAR(255),
  camera_id UUID REFERENCES cameras(id),
  description TEXT NOT NULL,
  status VARCHAR(50) DEFAULT 'new' CHECK (status IN ('new', 'reviewing', 'investigating', 'resolved', 'dismissed')),
  detected_at TIMESTAMP NOT NULL DEFAULT NOW(),
  resolved_at TIMESTAMP,
  assigned_to UUID REFERENCES users(id),
  site_id UUID REFERENCES sites(id),
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_security_events_type ON security_events(event_type);
CREATE INDEX IF NOT EXISTS idx_security_events_status ON security_events(status);
CREATE INDEX IF NOT EXISTS idx_security_events_severity ON security_events(severity);
CREATE INDEX IF NOT EXISTS idx_security_events_site ON security_events(site_id);

-- Access Logs
CREATE TABLE IF NOT EXISTS access_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  access_point_id VARCHAR(50) NOT NULL,
  access_point_name VARCHAR(255) NOT NULL,
  person_id UUID REFERENCES users(id),
  person_name VARCHAR(255),
  direction VARCHAR(10) CHECK (direction IN ('entry', 'exit')),
  access_type VARCHAR(20) CHECK (access_type IN ('authorized', 'unauthorized', 'denied')),
  credential_type VARCHAR(20) CHECK (credential_type IN ('badge', 'biometric', 'pin', 'vehicle')),
  vehicle_id VARCHAR(50),
  site_id UUID REFERENCES sites(id),
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_access_logs_point ON access_logs(access_point_id);
CREATE INDEX IF NOT EXISTS idx_access_logs_type ON access_logs(access_type);
CREATE INDEX IF NOT EXISTS idx_access_logs_timestamp ON access_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_access_logs_site ON access_logs(site_id);

-- Security Zones
CREATE TABLE IF NOT EXISTS security_zones (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  zone_type VARCHAR(50) CHECK (zone_type IN ('perimeter', 'restricted', 'general', 'emergency')),
  status VARCHAR(20) DEFAULT 'secure' CHECK (status IN ('secure', 'alert', 'breach')),
  camera_count INTEGER DEFAULT 0,
  sensor_count INTEGER DEFAULT 0,
  access_point_count INTEGER DEFAULT 0,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_security_zones_site ON security_zones(site_id);

-- =============================================
-- WATER MANAGEMENT
-- =============================================

CREATE TABLE IF NOT EXISTS water_sources (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  source_type VARCHAR(50) NOT NULL CHECK (source_type IN ('reservoir', 'tank', 'well', 'treatment_plant')),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  zone_id UUID REFERENCES zones(id),
  capacity_liters DECIMAL(12, 2) NOT NULL,
  current_level_liters DECIMAL(12, 2) DEFAULT 0,
  water_quality_score DECIMAL(5, 2),
  ph_level DECIMAL(4, 2),
  turbidity DECIMAL(6, 2),
  temperature DECIMAL(5, 2),
  dissolved_oxygen DECIMAL(5, 2),
  status VARCHAR(50) DEFAULT 'optimal' CHECK (status IN ('optimal', 'warning', 'critical', 'offline')),
  inflow_rate DECIMAL(8, 2),
  outflow_rate DECIMAL(8, 2),
  last_inspection_at TIMESTAMP,
  next_inspection_at TIMESTAMP,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_water_sources_type ON water_sources(source_type);
CREATE INDEX IF NOT EXISTS idx_water_sources_status ON water_sources(status);
CREATE INDEX IF NOT EXISTS idx_water_sources_site ON water_sources(site_id);

CREATE TABLE IF NOT EXISTS water_equipment (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  equipment_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  equipment_type VARCHAR(50) NOT NULL CHECK (equipment_type IN ('pump', 'motor', 'valve')),
  source_id UUID REFERENCES water_sources(id),
  status VARCHAR(50) DEFAULT 'running' CHECK (status IN ('running', 'stopped', 'maintenance', 'error')),
  flow_rate DECIMAL(8, 2),
  pressure DECIMAL(6, 2),
  temperature DECIMAL(5, 2),
  rpm INTEGER,
  power_consumption DECIMAL(8, 2),
  position_percentage DECIMAL(5, 2),
  operating_hours DECIMAL(10, 2) DEFAULT 0,
  last_maintenance_at TIMESTAMP,
  next_maintenance_hours INTEGER,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_water_equipment_type ON water_equipment(equipment_type);
CREATE INDEX IF NOT EXISTS idx_water_equipment_source ON water_equipment(source_id);

-- Water Pipelines
CREATE TABLE IF NOT EXISTS water_pipelines (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  pipeline_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  location VARCHAR(255),
  status VARCHAR(50) DEFAULT 'optimal' CHECK (status IN ('optimal', 'warning', 'critical', 'offline')),
  flow_rate DECIMAL(8, 2),
  pressure DECIMAL(6, 2),
  temperature DECIMAL(5, 2),
  capacity DECIMAL(10, 2),
  material VARCHAR(50),
  diameter_mm DECIMAL(8, 2),
  length_m DECIMAL(10, 2),
  installed_at TIMESTAMP,
  last_inspection_at TIMESTAMP,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pipelines_status ON water_pipelines(status);
CREATE INDEX IF NOT EXISTS idx_pipelines_site ON water_pipelines(site_id);

-- Water Quality Metrics
CREATE TABLE IF NOT EXISTS water_quality_metrics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  parameter VARCHAR(100) NOT NULL,
  value DECIMAL(10, 4) NOT NULL,
  unit VARCHAR(20) NOT NULL,
  optimal_value DECIMAL(10, 4),
  min_threshold DECIMAL(10, 4),
  max_threshold DECIMAL(10, 4),
  status VARCHAR(20) CHECK (status IN ('excellent', 'good', 'warning', 'critical')),
  sensor_id VARCHAR(50),
  source_id UUID REFERENCES water_sources(id),
  site_id UUID REFERENCES sites(id),
  measured_at TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_water_quality_measured ON water_quality_metrics(measured_at DESC);
CREATE INDEX IF NOT EXISTS idx_water_quality_site ON water_quality_metrics(site_id);

-- Water Usage Records
CREATE TABLE IF NOT EXISTS water_usage_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  zone VARCHAR(255),
  usage_liters DECIMAL(12, 2) NOT NULL,
  quality_percentage DECIMAL(5, 2),
  pressure DECIMAL(6, 2),
  temperature DECIMAL(5, 2),
  site_id UUID REFERENCES sites(id),
  timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_water_usage_timestamp ON water_usage_records(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_water_usage_site ON water_usage_records(site_id);

-- Water Treatment Plants
CREATE TABLE IF NOT EXISTS water_treatment_plants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  status VARCHAR(50) DEFAULT 'operational' CHECK (status IN ('operational', 'maintenance', 'offline')),
  capacity_liters_per_day DECIMAL(12, 2) NOT NULL,
  current_throughput DECIMAL(12, 2) DEFAULT 0,
  efficiency_percentage DECIMAL(5, 2) DEFAULT 100,
  last_maintenance_at TIMESTAMP,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_treatment_plants_site ON water_treatment_plants(site_id);

-- Water Flow Network Nodes (for animated flow system)
CREATE TABLE IF NOT EXISTS water_flow_nodes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  node_key VARCHAR(50) UNIQUE NOT NULL,
  label VARCHAR(255) NOT NULL,
  subtitle VARCHAR(255),
  node_type VARCHAR(50) NOT NULL CHECK (node_type IN ('reservoir', 'pump_station', 'treatment_plant', 'distribution_hub', 'mining_zone', 'processing_zone', 'dust_suppression', 'cooling_system', 'tailings_dam', 'reclaim_facility', 'storage')),
  icon VARCHAR(10),
  color VARCHAR(20) DEFAULT '#3b82f6',
  x_position DECIMAL(8, 2) NOT NULL,
  y_position DECIMAL(8, 2) NOT NULL,
  capacity_liters DECIMAL(12, 2),
  current_level_percentage DECIMAL(5, 2),
  flow_rate DECIMAL(8, 2) DEFAULT 0,
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'warning', 'offline', 'maintenance')),
  site_id UUID REFERENCES sites(id),
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_flow_nodes_site ON water_flow_nodes(site_id);
CREATE INDEX IF NOT EXISTS idx_flow_nodes_type ON water_flow_nodes(node_type);

-- Water Flow Connections (pipes between nodes)
CREATE TABLE IF NOT EXISTS water_flow_connections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  from_node_key VARCHAR(50) NOT NULL REFERENCES water_flow_nodes(node_key),
  to_node_key VARCHAR(50) NOT NULL REFERENCES water_flow_nodes(node_key),
  pipeline_id VARCHAR(50) REFERENCES water_pipelines(pipeline_id),
  flow_rate DECIMAL(8, 2) DEFAULT 0,
  status VARCHAR(50) DEFAULT 'optimal' CHECK (status IN ('optimal', 'warning', 'critical', 'offline')),
  is_reclaim BOOLEAN DEFAULT false,
  pipe_diameter_mm DECIMAL(8, 2),
  pipe_material VARCHAR(50),
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_flow_connections_site ON water_flow_connections(site_id);
CREATE INDEX IF NOT EXISTS idx_flow_connections_pipeline ON water_flow_connections(pipeline_id);

-- Digital Twin Sensor Readings (real-time sensor data for 3D model)
CREATE TABLE IF NOT EXISTS digital_twin_sensors (
  id BIGSERIAL PRIMARY KEY,
  asset_id UUID REFERENCES assets(id) ON DELETE CASCADE,
  sensor_key VARCHAR(50) NOT NULL,
  label VARCHAR(100) NOT NULL,
  value VARCHAR(50) NOT NULL,
  unit VARCHAR(20),
  color VARCHAR(20) DEFAULT '#10b981',
  cx DECIMAL(6, 2),
  cy DECIMAL(6, 2),
  timestamp TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_dt_sensors_asset ON digital_twin_sensors(asset_id, timestamp DESC);

-- =============================================
-- SAFETY & TRAINING
-- =============================================

CREATE TABLE IF NOT EXISTS safety_incidents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  incident_id VARCHAR(50) UNIQUE NOT NULL,
  incident_type VARCHAR(50) NOT NULL CHECK (incident_type IN ('injury', 'near_miss', 'equipment_failure', 'spill', 'fire', 'equipment', 'slip_fall', 'ppe_violation', 'chemical', 'electrical', 'environmental')),
  severity VARCHAR(20) NOT NULL CHECK (severity IN ('minor', 'moderate', 'serious', 'critical', 'fatal', 'major')),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  zone_id UUID REFERENCES zones(id),
  zone_name VARCHAR(255),
  location_description TEXT,
  reported_by UUID REFERENCES users(id),
  reported_by_name VARCHAR(255),
  occurred_at TIMESTAMP NOT NULL,
  reported_at TIMESTAMP NOT NULL DEFAULT NOW(),
  description TEXT NOT NULL,
  immediate_actions_taken TEXT,
  status VARCHAR(50) DEFAULT 'reported' CHECK (status IN ('reported', 'investigating', 'resolved', 'closed', 'open')),
  investigated_by UUID REFERENCES users(id),
  root_cause TEXT,
  corrective_actions TEXT[],
  injuries_count INTEGER DEFAULT 0,
  requires_medical_attention BOOLEAN DEFAULT false,
  resolved_at TIMESTAMP,
  closed_at TIMESTAMP,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_incidents_type ON safety_incidents(incident_type);
CREATE INDEX IF NOT EXISTS idx_incidents_severity ON safety_incidents(severity);
CREATE INDEX IF NOT EXISTS idx_incidents_status ON safety_incidents(status);
CREATE INDEX IF NOT EXISTS idx_incidents_site ON safety_incidents(site_id);

-- Training Courses / Programs
CREATE TABLE IF NOT EXISTS training_courses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  course_id VARCHAR(50) UNIQUE NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  course_type VARCHAR(50) CHECK (course_type IN ('safety', 'equipment', 'emergency', 'compliance')),
  training_type VARCHAR(50) CHECK (training_type IN ('vr_simulation', 'classroom', 'practical', 'online', 'on_the_job', 'hands_on')),
  duration_minutes INTEGER NOT NULL,
  duration_label VARCHAR(50),
  content_type VARCHAR(50) CHECK (content_type IN ('vr', 'video', 'classroom', 'online', 'hands_on')),
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'scheduled', 'completed', 'cancelled')),
  enrolled_count INTEGER DEFAULT 0,
  completed_count INTEGER DEFAULT 0,
  instructor VARCHAR(255),
  scheduled_date TIMESTAMP,
  completion_deadline TIMESTAMP,
  is_mandatory BOOLEAN DEFAULT false,
  provides_certification BOOLEAN DEFAULT false,
  certification_valid_days INTEGER,
  passing_score DECIMAL(5, 2),
  is_active BOOLEAN DEFAULT true,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_courses_type ON training_courses(course_type);
CREATE INDEX IF NOT EXISTS idx_courses_site ON training_courses(site_id);

-- VR Simulations
CREATE TABLE IF NOT EXISTS vr_simulations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  simulation_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  difficulty VARCHAR(20) CHECK (difficulty IN ('beginner', 'intermediate', 'advanced', 'expert')),
  completion_rate DECIMAL(5, 2) DEFAULT 0,
  average_score DECIMAL(5, 2) DEFAULT 0,
  total_sessions INTEGER DEFAULT 0,
  description TEXT,
  scenario_type VARCHAR(100),
  course_id UUID REFERENCES training_courses(id),
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_vr_sims_difficulty ON vr_simulations(difficulty);

-- User Certifications
CREATE TABLE IF NOT EXISTS user_certifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  employee_id UUID REFERENCES users(id) ON DELETE CASCADE,
  employee_name VARCHAR(255),
  certification_name VARCHAR(255) NOT NULL,
  issued_at TIMESTAMP NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  status VARCHAR(20) DEFAULT 'current' CHECK (status IN ('current', 'expiring_soon', 'expired')),
  issuing_authority VARCHAR(255),
  course_id UUID REFERENCES training_courses(id),
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_certifications_employee ON user_certifications(employee_id);
CREATE INDEX IF NOT EXISTS idx_certifications_status ON user_certifications(status);
CREATE INDEX IF NOT EXISTS idx_certifications_expires ON user_certifications(expires_at);

-- =============================================
-- ALERTS & NOTIFICATIONS
-- =============================================

CREATE TABLE IF NOT EXISTS alerts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  alert_id VARCHAR(50) UNIQUE NOT NULL,
  alert_type VARCHAR(50) NOT NULL,
  category VARCHAR(50),
  severity VARCHAR(20) NOT NULL CHECK (severity IN ('info', 'warning', 'critical', 'emergency')),
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  source_type VARCHAR(50),
  source_id VARCHAR(100),
  zone_id UUID REFERENCES zones(id),
  site_id UUID REFERENCES sites(id),
  triggered_at TIMESTAMP NOT NULL DEFAULT NOW(),
  status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'acknowledged', 'resolved', 'dismissed')),
  acknowledged_by UUID REFERENCES users(id),
  acknowledged_at TIMESTAMP,
  resolved_by UUID REFERENCES users(id),
  resolved_at TIMESTAMP,
  resolution_notes TEXT,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_alerts_type ON alerts(alert_type);
CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_alerts_triggered ON alerts(triggered_at DESC);
CREATE INDEX IF NOT EXISTS idx_alerts_site ON alerts(site_id);

-- =============================================
-- AUDIT LOGS
-- =============================================

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100),
  entity_id VARCHAR(100),
  old_values JSONB,
  new_values JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);

-- =============================================
-- HISTORICAL REPORTS
-- =============================================

CREATE TABLE IF NOT EXISTS historical_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  report_id VARCHAR(50) UNIQUE NOT NULL,
  report_type VARCHAR(50) NOT NULL CHECK (report_type IN ('production', 'safety', 'equipment', 'water', 'energy', 'security')),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  time_range_start TIMESTAMP NOT NULL,
  time_range_end TIMESTAMP NOT NULL,
  time_range_preset VARCHAR(20) CHECK (time_range_preset IN ('7d', '30d', '90d', '6m', '1y', 'custom')),
  generated_by UUID REFERENCES users(id),
  status VARCHAR(20) DEFAULT 'completed' CHECK (status IN ('pending', 'generating', 'completed', 'failed')),
  format VARCHAR(10) DEFAULT 'json' CHECK (format IN ('json', 'csv', 'pdf')),
  data JSONB,
  kpi_summary JSONB,
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_reports_type ON historical_reports(report_type);
CREATE INDEX IF NOT EXISTS idx_reports_site ON historical_reports(site_id);
CREATE INDEX IF NOT EXISTS idx_reports_created ON historical_reports(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_generated_by ON historical_reports(generated_by);

-- Report Scheduled Jobs
CREATE TABLE IF NOT EXISTS report_schedules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  report_type VARCHAR(50) NOT NULL CHECK (report_type IN ('production', 'safety', 'equipment', 'water', 'energy', 'security')),
  schedule_frequency VARCHAR(20) NOT NULL CHECK (schedule_frequency IN ('daily', 'weekly', 'monthly', 'quarterly')),
  next_run_at TIMESTAMP NOT NULL,
  last_run_at TIMESTAMP,
  recipients TEXT[],
  is_active BOOLEAN DEFAULT true,
  site_id UUID REFERENCES sites(id),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_report_schedules_next ON report_schedules(next_run_at);
CREATE INDEX IF NOT EXISTS idx_report_schedules_active ON report_schedules(is_active);

-- =============================================
-- MINING EVENTS (AI Assistant query source)
-- =============================================

CREATE TABLE IF NOT EXISTS mining_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  event_id VARCHAR(50) UNIQUE NOT NULL,
  event_type VARCHAR(50) NOT NULL CHECK (event_type IN (
    'breakdown', 'maintenance', 'inspection', 'incident', 'alert',
    'production_milestone', 'shift_change', 'equipment_transfer',
    'fuel_delivery', 'blasting', 'survey', 'environmental',
    'safety_drill', 'training_completed', 'certification_expired',
    'geofence_breach', 'speed_violation', 'water_quality_alert',
    'network_outage', 'sensor_malfunction'
  )),
  category VARCHAR(50) NOT NULL CHECK (category IN (
    'equipment', 'safety', 'production', 'environment', 'network',
    'water', 'security', 'training', 'logistics', 'maintenance'
  )),
  severity VARCHAR(20) NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  status VARCHAR(20) DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  equipment_type VARCHAR(50),
  equipment_id VARCHAR(50),
  equipment_name VARCHAR(255),
  location VARCHAR(255),
  zone_name VARCHAR(255),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  reported_by VARCHAR(255),
  assigned_to VARCHAR(255),
  duration_minutes INTEGER,
  cost_impact DECIMAL(12, 2),
  production_impact_tonnes DECIMAL(10, 2),
  resolution_notes TEXT,
  tags TEXT[],
  site_id UUID REFERENCES sites(id),
  occurred_at TIMESTAMP NOT NULL,
  resolved_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mining_events_type ON mining_events(event_type);
CREATE INDEX IF NOT EXISTS idx_mining_events_category ON mining_events(category);
CREATE INDEX IF NOT EXISTS idx_mining_events_severity ON mining_events(severity);
CREATE INDEX IF NOT EXISTS idx_mining_events_status ON mining_events(status);
CREATE INDEX IF NOT EXISTS idx_mining_events_equipment ON mining_events(equipment_type);
CREATE INDEX IF NOT EXISTS idx_mining_events_occurred ON mining_events(occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_mining_events_site ON mining_events(site_id);
CREATE INDEX IF NOT EXISTS idx_mining_events_location ON mining_events(location);

-- AI Assistant Conversation Logs
CREATE TABLE IF NOT EXISTS ai_conversation_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id VARCHAR(100) NOT NULL,
  user_id UUID REFERENCES users(id),
  query_text TEXT NOT NULL,
  parsed_filters JSONB,
  result_count INTEGER DEFAULT 0,
  response_text TEXT,
  response_time_ms INTEGER,
  input_method VARCHAR(10) DEFAULT 'text' CHECK (input_method IN ('text', 'voice')),
  site_id UUID REFERENCES sites(id),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ai_logs_session ON ai_conversation_logs(session_id);
CREATE INDEX IF NOT EXISTS idx_ai_logs_user ON ai_conversation_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_logs_created ON ai_conversation_logs(created_at DESC);

-- =============================================
-- FUNCTIONS & TRIGGERS
-- =============================================

-- Update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers to all tables with updated_at
DO $$
DECLARE
  t TEXT;
BEGIN
  FOR t IN
    SELECT unnest(ARRAY[
      'users', 'sites', 'zones', 'geofences', 'assets', 'asset_components',
      'network_towers', 'network_devices', 'cameras', 'security_events',
      'security_zones', 'water_sources', 'water_equipment', 'water_pipelines',
      'water_treatment_plants', 'water_flow_nodes', 'water_flow_connections',
      'safety_incidents', 'training_courses',
      'vr_simulations', 'user_certifications', 'alerts',
      'historical_reports', 'report_schedules', 'mining_events'
    ])
  LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS update_%s_updated_at ON %I; CREATE TRIGGER update_%s_updated_at BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();',
      t, t, t, t
    );
  END LOOP;
END;
$$;