import { pool } from '../config/database';
import fs from 'fs';
import path from 'path';

async function migrate() {
  console.log('===========================================');
  console.log('  SDS Mining - Database Migration');
  console.log('===========================================');

  try {
    // Read and execute the unified schema
    const schemaPath = path.join(__dirname, 'schema.sql');
    
    if (!fs.existsSync(schemaPath)) {
      // When running from dist/, look for SQL in dist/database/
      const altPath = path.join(__dirname, '..', 'database', 'schema.sql');
      if (fs.existsSync(altPath)) {
        const schema = fs.readFileSync(altPath, 'utf8');
        await pool.query(schema);
      } else {
        throw new Error(`Schema file not found at ${schemaPath} or ${altPath}`);
      }
    } else {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      await pool.query(schema);
    }

    console.log('  Schema created/updated successfully');

    // Verify tables
    const tablesResult = await pool.query(`
      SELECT table_name FROM information_schema.tables 
      WHERE table_schema = 'public' 
      ORDER BY table_name
    `);

    console.log(`\n  Tables created: ${tablesResult.rows.length}`);
    tablesResult.rows.forEach((row: any) => {
      console.log(`    - ${row.table_name}`);
    });

    console.log('\n  Migration completed successfully!');
    console.log('===========================================');
  } catch (error) {
    console.error('  Migration failed:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

// Run migration if called directly
if (require.main === module) {
  migrate()
    .then(() => process.exit(0))
    .catch((error) => {
      console.error('Migration failed:', error);
      process.exit(1);
    });
}

export default migrate;
