import { pool } from '../config/database';
import bcrypt from 'bcrypt';

async function seedAll() {
  console.log('===========================================');
  console.log('  SDS Mining Command Center - Full Seed');
  console.log('===========================================');

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // =============================================
    // 1. USERS
    // =============================================
    console.log('\n--- Seeding Users ---');
    const hashedPassword = await bcrypt.hash('admin123', 10);
    const operatorPassword = await bcrypt.hash('operator123', 10);

    const users = [
      { email: 'admin@mining-sds.com', password: hashedPassword, name: 'System Administrator', role: 'admin', dept: 'IT' },
      { email: 'john.operator@mining-sds.com', password: operatorPassword, name: 'John Mitchell', role: 'operator', dept: 'Operations' },
      { email: 'sarah.engineer@mining-sds.com', password: operatorPassword, name: 'Sarah Chen', role: 'engineer', dept: 'Engineering' },
      { email: 'mike.supervisor@mining-sds.com', password: operatorPassword, name: 'Mike Rodriguez', role: 'supervisor', dept: 'Operations' },
      { email: 'lisa.safety@mining-sds.com', password: operatorPassword, name: 'Lisa Thompson', role: 'safety_officer', dept: 'Safety' },
    ];

    const userIds: string[] = [];
    for (const user of users) {
      const result = await client.query(
        `INSERT INTO users (email, password_hash, full_name, role, department)
         VALUES ($1, $2, $3, $4, $5)
         ON CONFLICT (email) DO UPDATE SET full_name = EXCLUDED.full_name
         RETURNING id`,
        [user.email, user.password, user.name, user.role, user.dept]
      );
      userIds.push(result.rows[0].id);
    }
    console.log(`  Created ${users.length} users`);

    // =============================================
    // 2. SITES
    // =============================================
    console.log('\n--- Seeding Sites ---');
    const sitesData = [
      { site_id: 'SITE-001', name: 'Northern Ridge Mine', location: 'Pilbara, Western Australia', country: 'Australia', region: 'Western Australia', site_type: 'open_pit', lat: -22.9576, lng: 118.5986, commodity: 'Iron Ore', capacity: 25000000, workforce: 850, email: 'northern.ridge@mining-sds.com', phone: '+61-8-9000-1234' },
      { site_id: 'SITE-002', name: 'Sierra Verde Complex', location: 'Atacama Desert, Chile', country: 'Chile', region: 'Atacama', site_type: 'open_pit', lat: -23.6345, lng: -70.3975, commodity: 'Copper', capacity: 18000000, workforce: 1200, email: 'sierra.verde@mining-sds.com', phone: '+56-2-2000-5678' },
      { site_id: 'SITE-003', name: 'Goldstream Underground', location: 'Ontario, Canada', country: 'Canada', region: 'Ontario', site_type: 'underground', lat: 48.4634, lng: -81.9978, commodity: 'Gold', capacity: 2500000, workforce: 450, email: 'goldstream@mining-sds.com', phone: '+1-705-555-9876' },
      { site_id: 'SITE-004', name: 'Eastern Bauxite Fields', location: 'Queensland, Australia', country: 'Australia', region: 'Queensland', site_type: 'open_pit', lat: -27.4698, lng: 153.0251, commodity: 'Bauxite', capacity: 12000000, workforce: 320, email: 'eastern.bauxite@mining-sds.com', phone: '+61-7-3000-4321' },
      { site_id: 'SITE-005', name: 'Platinum Ridge', location: 'Limpopo, South Africa', country: 'South Africa', region: 'Limpopo', site_type: 'underground', lat: -24.7761, lng: 29.4698, commodity: 'Platinum', capacity: 1800000, workforce: 680, email: 'platinum.ridge@mining-sds.com', phone: '+27-12-555-7890' },
      { site_id: 'SITE-006', name: 'Central Processing Hub', location: 'Nevada, USA', country: 'United States', region: 'Nevada', site_type: 'processing_plant', lat: 39.5296, lng: -119.8138, commodity: 'Multi-mineral', capacity: 5000000, workforce: 280, email: 'central.processing@mining-sds.com', phone: '+1-775-555-4567' },
    ];

    const siteIds: string[] = [];
    for (const site of sitesData) {
      const result = await client.query(
        `INSERT INTO sites (site_id, name, location, country, region, site_type, status, latitude, longitude, primary_commodity, annual_capacity_tonnes, workforce_count, contact_email, contact_phone, site_manager_id)
         VALUES ($1, $2, $3, $4, $5, $6, 'operational', $7, $8, $9, $10, $11, $12, $13, $14)
         ON CONFLICT (site_id) DO UPDATE SET name = EXCLUDED.name
         RETURNING id`,
        [site.site_id, site.name, site.location, site.country, site.region, site.site_type, site.lat, site.lng, site.commodity, site.capacity, site.workforce, site.email, site.phone, userIds[0]]
      );
      siteIds.push(result.rows[0].id);
    }
    console.log(`  Created ${sitesData.length} sites`);

    // Site metrics for each site
    // If subsequent sections fail we still want the admin user preserved,
    // so commit after users have been seeded. This ensures at least primary
    // authentication works even if other sample data has issues.
    await client.query('COMMIT');
    await client.query('BEGIN');

    for (let i = 0; i < siteIds.length; i++) {
      // workforce_present originally used a decimal computation which caused
      // an error when inserting into an integer column.  Round to avoid
      // invalid input syntax.
      const workforcePresent = Math.round(sitesData[i].workforce * 0.85);

      await client.query(
        `INSERT INTO site_metrics (site_id, total_assets, active_assets, assets_in_maintenance, production_tonnes_today, production_tonnes_mtd, network_uptime_percentage, active_alerts, critical_alerts, safety_incidents_today, safety_incidents_mtd, workforce_present, operational_efficiency, environmental_compliance_score)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
        [siteIds[i], 20 + i * 5, 15 + i * 4, 2 + i, 50000 + i * 15000, 1500000 + i * 200000, 95 + Math.random() * 5, Math.floor(Math.random() * 5), Math.floor(Math.random() * 2), Math.floor(Math.random() * 2), Math.floor(Math.random() * 8), workforcePresent, 85 + Math.random() * 15, 90 + Math.random() * 10]
      );
    }
    console.log('  Created site metrics');

    // =============================================
    // 3. ZONES
    // =============================================
    console.log('\n--- Seeding Zones ---');
    const zonesData = [
      { zone_id: 'zone-a', name: 'Zone A - Primary Pit', type: 'primary_pit', lat: -22.9576, lng: 118.5986, color: '#EF4444', area: 12.5 },
      { zone_id: 'zone-b', name: 'Zone B - Processing', type: 'processing', lat: -22.9590, lng: 118.6000, color: '#3B82F6', area: 5.2 },
      { zone_id: 'zone-c', name: 'Zone C - Secondary Pit', type: 'secondary_pit', lat: -22.9600, lng: 118.5970, color: '#F59E0B', area: 8.7 },
      { zone_id: 'zone-d', name: 'Zone D - Maintenance', type: 'maintenance', lat: -22.9610, lng: 118.6010, color: '#10B981', area: 3.1 },
      { zone_id: 'zone-e', name: 'Zone E - Administration', type: 'administration', lat: -22.9550, lng: 118.6020, color: '#8B5CF6', area: 1.8 },
      { zone_id: 'zone-f', name: 'Zone F - Restricted', type: 'restricted', lat: -22.9620, lng: 118.5950, color: '#DC2626', area: 4.5 },
    ];

    const zoneIds: string[] = [];
    for (const zone of zonesData) {
      const result = await client.query(
        `INSERT INTO zones (zone_id, name, zone_type, center_latitude, center_longitude, color, area_sq_km, max_capacity, speed_limit, site_id, current_asset_count, personnel_count)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
         ON CONFLICT (zone_id) DO UPDATE SET name = EXCLUDED.name
         RETURNING id`,
        [zone.zone_id, zone.name, zone.type, zone.lat, zone.lng, zone.color, zone.area, 25, 40, siteIds[0], Math.floor(3 + Math.random() * 8), Math.floor(10 + Math.random() * 50)]
      );
      zoneIds.push(result.rows[0].id);
    }
    console.log(`  Created ${zonesData.length} zones`);

    // Geofences
    const geofences = [
      { name: 'Pit Safety Perimeter', type: 'exclusion', coords: [{ latitude: -22.955, longitude: 118.596 }, { latitude: -22.960, longitude: 118.600 }] },
      { name: 'Speed Zone - Processing', type: 'speed_limit', coords: [{ latitude: -22.958, longitude: 118.599 }], speedLimit: 20 },
      { name: 'Restricted Blasting Area', type: 'exclusion', coords: [{ latitude: -22.962, longitude: 118.594 }], radius: 500 },
    ];
    for (const gf of geofences) {
      await client.query(
        `INSERT INTO geofences (name, fence_type, coordinates, radius, speed_limit, alert_on_breach, is_active, site_id)
         VALUES ($1, $2, $3, $4, $5, true, true, $6)`,
        [gf.name, gf.type, JSON.stringify(gf.coords), (gf as any).radius || null, (gf as any).speedLimit || null, siteIds[0]]
      );
    }
    console.log('  Created geofences');

    // =============================================
    // 4. ASSETS
    // =============================================
    console.log('\n--- Seeding Assets ---');
    const assetsData = [
      { asset_id: 'EXC-001', name: 'Excavator Unit 1', type: 'excavator', manufacturer: 'Caterpillar', model: '336F', hours: 1250.5 },
      { asset_id: 'EXC-002', name: 'Excavator Unit 2', type: 'excavator', manufacturer: 'Komatsu', model: 'PC800', hours: 980.2 },
      { asset_id: 'HTK-001', name: 'Haul Truck Unit 1', type: 'haul_truck', manufacturer: 'Komatsu', model: '930E-4', hours: 2100.7 },
      { asset_id: 'HTK-002', name: 'Haul Truck Unit 2', type: 'haul_truck', manufacturer: 'Caterpillar', model: '797F', hours: 1850.3 },
      { asset_id: 'HTK-003', name: 'Haul Truck Unit 3', type: 'haul_truck', manufacturer: 'Komatsu', model: '930E-4', hours: 1600.1 },
      { asset_id: 'DRL-001', name: 'Drill Unit 1', type: 'drill', manufacturer: 'Sandvik', model: 'DI650i', hours: 750.8 },
      { asset_id: 'DOZ-001', name: 'Dozer Unit 1', type: 'dozer', manufacturer: 'Caterpillar', model: 'D11T', hours: 3200.4 },
      { asset_id: 'LDR-001', name: 'Loader Unit 1', type: 'loader', manufacturer: 'Komatsu', model: 'WA900-8', hours: 1420.6 },
      { asset_id: 'GRD-001', name: 'Grader Unit 1', type: 'grader', manufacturer: 'Caterpillar', model: '24M', hours: 890.9 },
    ];

    const assetIds: string[] = [];
    for (let i = 0; i < assetsData.length; i++) {
      const asset = assetsData[i];
      const statusVal = i < 7 ? 'active' : (i === 7 ? 'maintenance' : 'active');
      const result = await client.query(
        `INSERT INTO assets (asset_id, name, type, manufacturer, model, operating_hours, status, current_zone_id, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         ON CONFLICT (asset_id) DO UPDATE SET name = EXCLUDED.name
         RETURNING id`,
        [asset.asset_id, asset.name, asset.type, asset.manufacturer, asset.model, asset.hours, statusVal, zoneIds[i % zoneIds.length], siteIds[0]]
      );
      assetIds.push(result.rows[0].id);
    }
    console.log(`  Created ${assetsData.length} assets`);

    // Asset Components
    const componentTypes = ['Engine', 'Hydraulic System', 'Transmission', 'Electrical', 'Cooling System', 'Tracks/Tires'];
    for (const assetId of assetIds.slice(0, 5)) {
      for (let j = 0; j < componentTypes.length; j++) {
        const health = 60 + Math.random() * 40;
        const compStatus = health > 90 ? 'optimal' : health > 70 ? 'good' : health > 50 ? 'warning' : 'critical';
        await client.query(
          `INSERT INTO asset_components (asset_id, component_id, name, health_score, status, temperature, pressure, vibration, wear_level, operating_hours)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
          [assetId, `COMP-${j + 1}`, componentTypes[j], health.toFixed(1), compStatus, (170 + Math.random() * 50).toFixed(1), (2000 + Math.random() * 600).toFixed(1), (0.5 + Math.random() * 3).toFixed(2), (100 - health).toFixed(1), (500 + Math.random() * 2000).toFixed(1)]
        );
      }
    }
    console.log('  Created asset components');

    // Sample Telemetry
    for (const assetId of assetIds.slice(0, 5)) {
      for (let t = 0; t < 10; t++) {
        const ts = new Date(Date.now() - t * 300000);
        await client.query(
          `INSERT INTO asset_telemetry (asset_id, timestamp, latitude, longitude, speed, engine_temp, hydraulic_pressure, fuel_level, battery_voltage, rpm, is_operating)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
          [assetId, ts, -22.9576 + (Math.random() - 0.5) * 0.01, 118.5986 + (Math.random() - 0.5) * 0.01, (Math.random() * 45).toFixed(1), (180 + Math.random() * 40).toFixed(1), (2000 + Math.random() * 500).toFixed(0), (40 + Math.random() * 55).toFixed(1), (12 + Math.random() * 2).toFixed(1), Math.floor(1400 + Math.random() * 600), Math.random() > 0.15]
        );
      }
    }
    console.log('  Created sample telemetry data');

    // =============================================
    // 5. NETWORK TOWERS & DEVICES
    // =============================================
    console.log('\n--- Seeding Network ---');
    const towersData = [
      { tower_id: 'TWR-001', name: 'Tower 1 - North Pit', lat: -22.9560, lng: 118.5970, band: 'n77', bw: 1000 },
      { tower_id: 'TWR-002', name: 'Tower 2 - Processing', lat: -22.9590, lng: 118.6000, band: 'n78', bw: 1000 },
      { tower_id: 'TWR-003', name: 'Tower 3 - South Entry', lat: -22.9620, lng: 118.5990, band: 'n77', bw: 800 },
      { tower_id: 'TWR-004', name: 'Tower 4 - Maintenance Bay', lat: -22.9610, lng: 118.6015, band: 'n78', bw: 600 },
    ];

    const towerIds: string[] = [];
    for (const tower of towersData) {
      const result = await client.query(
        `INSERT INTO network_towers (tower_id, name, latitude, longitude, frequency_band, max_bandwidth, coverage_radius, uptime_percentage, current_load, connected_devices, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
         ON CONFLICT (tower_id) DO UPDATE SET name = EXCLUDED.name
         RETURNING id`,
        [tower.tower_id, tower.name, tower.lat, tower.lng, tower.band, tower.bw, 5000, (97 + Math.random() * 3).toFixed(1), (30 + Math.random() * 40).toFixed(1), Math.floor(40 + Math.random() * 60), siteIds[0]]
      );
      towerIds.push(result.rows[0].id);
    }
    console.log(`  Created ${towersData.length} network towers`);

    // Network devices
    const deviceTypes: Array<'asset' | 'sensor' | 'camera' | 'gateway' | 'router'> = ['asset', 'sensor', 'camera', 'gateway', 'router'];
    for (let d = 0; d < 15; d++) {
      const devType = deviceTypes[d % deviceTypes.length];
      await client.query(
        `INSERT INTO network_devices (device_id, device_name, device_type, tower_id, signal_strength, latency, bandwidth_up, bandwidth_down, packet_loss, status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
         ON CONFLICT (device_id) DO NOTHING`,
        [`DEV-${String(d + 1).padStart(3, '0')}`, `${devType.charAt(0).toUpperCase() + devType.slice(1)} Device ${d + 1}`, devType, towerIds[d % towerIds.length], (-40 - Math.random() * 30).toFixed(0), Math.floor(5 + Math.random() * 25), Math.floor(50 + Math.random() * 200), Math.floor(100 + Math.random() * 400), (Math.random() * 1.5).toFixed(2), Math.random() > 0.1 ? 'online' : 'offline']
      );
    }
    console.log('  Created 15 network devices');

    // =============================================
    // 6. CAMERAS & SECURITY
    // =============================================
    console.log('\n--- Seeding Security ---');
    const camerasData = [
      { camera_id: 'CAM-001', name: 'Gate 1 - Main Entry', type: 'fixed', location: 'Main Gate', res: '4K', fps: 30 },
      { camera_id: 'CAM-002', name: 'Zone A - Pit Overview', type: 'ptz', location: 'Zone A Tower', res: '4K', fps: 30 },
      { camera_id: 'CAM-003', name: 'Perimeter North', type: '360', location: 'North Fence', res: '1080p', fps: 25 },
      { camera_id: 'CAM-004', name: 'Processing Plant Entry', type: 'fixed', location: 'Zone B Gate', res: '1080p', fps: 30 },
      { camera_id: 'CAM-005', name: 'Maintenance Bay', type: 'ptz', location: 'Zone D', res: '4K', fps: 30 },
      { camera_id: 'CAM-006', name: 'Thermal - Pit Floor', type: 'thermal', location: 'Zone A Floor', res: '720p', fps: 15 },
      { camera_id: 'CAM-007', name: 'Perimeter South', type: '360', location: 'South Fence', res: '1080p', fps: 25 },
      { camera_id: 'CAM-008', name: 'Loading Bay', type: 'fixed', location: 'Loading Zone', res: '4K', fps: 30 },
    ];

    for (let i = 0; i < camerasData.length; i++) {
      const cam = camerasData[i];
      const camStatus = i < 7 ? 'online' : 'maintenance';
      await client.query(
        `INSERT INTO cameras (camera_id, name, camera_type, installation_location, resolution, fps, has_night_vision, has_motion_detection, ptz_enabled, status, is_recording, uptime_percentage, zone_id, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, true, true, $7, $8, true, $9, $10, $11)
         ON CONFLICT (camera_id) DO NOTHING`,
        [cam.camera_id, cam.name, cam.type, cam.location, cam.res, cam.fps, cam.type === 'ptz', camStatus, (96 + Math.random() * 4).toFixed(1), zoneIds[i % zoneIds.length], siteIds[0]]
      );
    }
    console.log(`  Created ${camerasData.length} cameras`);

    // Security Events
    const eventTypes = ['access_alert', 'perimeter_breach', 'unauthorized_vehicle', 'motion_detected', 'personnel_safety'] as const;
    const eventSeverities = ['critical', 'warning', 'info'] as const;
    const eventStatuses = ['new', 'reviewing', 'investigating', 'resolved'] as const;
    for (let e = 0; e < 12; e++) {
      const hoursAgo = Math.floor(Math.random() * 72);
      await client.query(
        `INSERT INTO security_events (event_type, severity, location, description, status, detected_at, site_id)
         VALUES ($1, $2, $3, $4, $5, NOW() - INTERVAL '${hoursAgo} hours', $6)`,
        [eventTypes[e % eventTypes.length], eventSeverities[e % eventSeverities.length], `Zone ${String.fromCharCode(65 + (e % 6))}`, `Security event detected: ${eventTypes[e % eventTypes.length].replace(/_/g, ' ')}`, eventStatuses[e % eventStatuses.length], siteIds[0]]
      );
    }
    console.log('  Created 12 security events');

    // Access Logs
    const directions = ['entry', 'exit'] as const;
    const credTypes = ['badge', 'biometric', 'pin', 'vehicle'] as const;
    for (let a = 0; a < 30; a++) {
      const hoursAgo = Math.floor(Math.random() * 24);
      const accessType = Math.random() > 0.05 ? 'authorized' : (Math.random() > 0.5 ? 'denied' : 'unauthorized');
      await client.query(
        `INSERT INTO access_logs (access_point_id, access_point_name, person_name, direction, access_type, credential_type, timestamp, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, NOW() - INTERVAL '${hoursAgo} hours', $7)`,
        [`AP-${String(Math.floor(a / 5) + 1).padStart(2, '0')}`, `Access Point ${Math.floor(a / 5) + 1}`, `Worker ${a + 1}`, directions[a % 2], accessType, credTypes[a % credTypes.length], siteIds[0]]
      );
    }
    console.log('  Created 30 access logs');

    // Security Zones
    const secZones = [
      { name: 'Outer Perimeter', type: 'perimeter', cameras: 4, sensors: 12, access: 3 },
      { name: 'Restricted Operations', type: 'restricted', cameras: 3, sensors: 8, access: 2 },
      { name: 'General Site', type: 'general', cameras: 6, sensors: 15, access: 5 },
      { name: 'Emergency Assembly', type: 'emergency', cameras: 2, sensors: 4, access: 4 },
    ];
    for (const sz of secZones) {
      await client.query(
        `INSERT INTO security_zones (name, zone_type, status, camera_count, sensor_count, access_point_count, site_id)
         VALUES ($1, $2, 'secure', $3, $4, $5, $6)`,
        [sz.name, sz.type, sz.cameras, sz.sensors, sz.access, siteIds[0]]
      );
    }
    console.log('  Created 4 security zones');

    // =============================================
    // 7. WATER MANAGEMENT
    // =============================================
    console.log('\n--- Seeding Water Management ---');
    const waterSources = [
      { source_id: 'RES-001', name: 'Main Reservoir', type: 'reservoir', capacity: 5000000 },
      { source_id: 'TNK-001', name: 'Storage Tank Alpha', type: 'tank', capacity: 500000 },
      { source_id: 'TNK-002', name: 'Storage Tank Bravo', type: 'tank', capacity: 350000 },
      { source_id: 'WEL-001', name: 'Groundwater Well 1', type: 'well', capacity: 200000 },
    ];

    const sourceIds: string[] = [];
    for (const src of waterSources) {
      const result = await client.query(
        `INSERT INTO water_sources (source_id, name, source_type, capacity_liters, current_level_liters, water_quality_score, ph_level, temperature, dissolved_oxygen, status, inflow_rate, outflow_rate, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'optimal', $10, $11, $12)
         ON CONFLICT (source_id) DO UPDATE SET name = EXCLUDED.name
         RETURNING id`,
        [src.source_id, src.name, src.type, src.capacity, src.capacity * (0.6 + Math.random() * 0.35), (90 + Math.random() * 10).toFixed(1), (6.8 + Math.random() * 0.8).toFixed(1), (18 + Math.random() * 8).toFixed(1), (7 + Math.random() * 3).toFixed(1), (100 + Math.random() * 200).toFixed(0), (80 + Math.random() * 180).toFixed(0), siteIds[0]]
      );
      sourceIds.push(result.rows[0].id);
    }
    console.log(`  Created ${waterSources.length} water sources`);

    // Water Equipment
    const equipments = [
      { eq_id: 'PMP-001', name: 'Main Pump 1', type: 'pump', flow: 450, pressure: 8.5, rpm: 1750 },
      { eq_id: 'PMP-002', name: 'Main Pump 2', type: 'pump', flow: 420, pressure: 8.2, rpm: 1740 },
      { eq_id: 'MTR-001', name: 'Drive Motor 1', type: 'motor', flow: 0, pressure: 0, rpm: 3000 },
      { eq_id: 'VLV-001', name: 'Control Valve A', type: 'valve', flow: 380, pressure: 6.0, rpm: 0 },
      { eq_id: 'VLV-002', name: 'Control Valve B', type: 'valve', flow: 350, pressure: 5.8, rpm: 0 },
    ];
    for (const eq of equipments) {
      await client.query(
        `INSERT INTO water_equipment (equipment_id, name, equipment_type, source_id, status, flow_rate, pressure, rpm, power_consumption, operating_hours)
         VALUES ($1, $2, $3, $4, 'running', $5, $6, $7, $8, $9)
         ON CONFLICT (equipment_id) DO NOTHING`,
        [eq.eq_id, eq.name, eq.type, sourceIds[0], eq.flow, eq.pressure, eq.rpm, (50 + Math.random() * 100).toFixed(1), (2000 + Math.random() * 5000).toFixed(0)]
      );
    }
    console.log('  Created water equipment');

    // Water Pipelines
    const pipelines = [
      { pipe_id: 'PIP-001', name: 'Main Supply Line', location: 'Reservoir to Plant', material: 'HDPE', diameter: 600, length: 2500 },
      { pipe_id: 'PIP-002', name: 'Processing Feed', location: 'Plant to Zone B', material: 'Steel', diameter: 400, length: 1200 },
      { pipe_id: 'PIP-003', name: 'Dust Suppression Line', location: 'Zone A Pit', material: 'HDPE', diameter: 200, length: 3800 },
      { pipe_id: 'PIP-004', name: 'Tailings Return', location: 'Zone B to Reservoir', material: 'Steel', diameter: 500, length: 1800 },
    ];
    for (const pipe of pipelines) {
      await client.query(
        `INSERT INTO water_pipelines (pipeline_id, name, location, status, flow_rate, pressure, temperature, capacity, material, diameter_mm, length_m, site_id)
         VALUES ($1, $2, $3, 'optimal', $4, $5, $6, $7, $8, $9, $10, $11)
         ON CONFLICT (pipeline_id) DO NOTHING`,
        [pipe.pipe_id, pipe.name, pipe.location, (200 + Math.random() * 300).toFixed(0), (4 + Math.random() * 6).toFixed(1), (15 + Math.random() * 10).toFixed(1), (pipe.diameter * pipe.length * 0.001).toFixed(0), pipe.material, pipe.diameter, pipe.length, siteIds[0]]
      );
    }
    console.log('  Created water pipelines');

    // Water Treatment Plants
    const treatmentPlants = [
      { name: 'Primary Treatment Plant', capacity: 2000000, throughput: 1650000 },
      { name: 'Secondary Recycling Plant', capacity: 800000, throughput: 620000 },
    ];
    for (const plant of treatmentPlants) {
      await client.query(
        `INSERT INTO water_treatment_plants (name, status, capacity_liters_per_day, current_throughput, efficiency_percentage, site_id)
         VALUES ($1, 'operational', $2, $3, $4, $5)`,
        [plant.name, plant.capacity, plant.throughput, (85 + Math.random() * 12).toFixed(1), siteIds[0]]
      );
    }
    console.log('  Created treatment plants');

    // Water Quality Metrics
    const qualityParams = [
      { param: 'pH', unit: 'pH', optimal: 7.0, min: 6.5, max: 8.5 },
      { param: 'Turbidity', unit: 'NTU', optimal: 1.0, min: 0, max: 5.0 },
      { param: 'Dissolved Oxygen', unit: 'mg/L', optimal: 8.0, min: 5.0, max: 12.0 },
      { param: 'Total Dissolved Solids', unit: 'mg/L', optimal: 300, min: 0, max: 500 },
      { param: 'Temperature', unit: 'C', optimal: 20, min: 5, max: 30 },
    ];
    for (const qp of qualityParams) {
      const value = qp.optimal + (Math.random() - 0.5) * (qp.max - qp.min) * 0.3;
      const qStatus = Math.abs(value - qp.optimal) < (qp.max - qp.min) * 0.1 ? 'excellent' : Math.abs(value - qp.optimal) < (qp.max - qp.min) * 0.25 ? 'good' : 'warning';
      await client.query(
        `INSERT INTO water_quality_metrics (parameter, value, unit, optimal_value, min_threshold, max_threshold, status, sensor_id, source_id, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [qp.param, value.toFixed(2), qp.unit, qp.optimal, qp.min, qp.max, qStatus, 'SENSOR-WQ-001', sourceIds[0], siteIds[0]]
      );
    }
    console.log('  Created water quality metrics');

    // Water Usage Records
    const usageZones = ['Zone A', 'Zone B', 'Zone C', 'Zone D'];
    for (let u = 0; u < 24; u++) {
      for (const uz of usageZones) {
        await client.query(
          `INSERT INTO water_usage_records (zone, usage_liters, quality_percentage, pressure, temperature, site_id, timestamp)
           VALUES ($1, $2, $3, $4, $5, $6, NOW() - INTERVAL '${u} hours')`,
          [uz, (5000 + Math.random() * 15000).toFixed(0), (85 + Math.random() * 15).toFixed(1), (4 + Math.random() * 4).toFixed(1), (16 + Math.random() * 8).toFixed(1), siteIds[0]]
        );
      }
    }
    console.log('  Created water usage records (24h)');

    // =============================================
    // 8. SAFETY & TRAINING
    // =============================================
    console.log('\n--- Seeding Safety & Training ---');
    const incidentTypes = ['near_miss', 'equipment', 'slip_fall', 'ppe_violation', 'near_miss', 'environmental'] as const;
    const incidentSeverities = ['minor', 'minor', 'moderate', 'minor', 'moderate', 'serious'] as const;
    const incidentStatuses = ['resolved', 'resolved', 'investigating', 'closed', 'resolved', 'open'] as const;

    for (let i = 0; i < 6; i++) {
      const daysAgo = Math.floor(Math.random() * 60);
      await client.query(
        `INSERT INTO safety_incidents (incident_id, incident_type, severity, location_description, zone_name, description, reported_by_name, occurred_at, reported_at, status, injuries_count, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW() - INTERVAL '${daysAgo} days', NOW() - INTERVAL '${daysAgo} days', $8, $9, $10)
         ON CONFLICT (incident_id) DO NOTHING`,
        [`INC-${String(i + 1).padStart(4, '0')}`, incidentTypes[i], incidentSeverities[i], `Location near ${zonesData[i].name}`, zonesData[i].name, `Incident report: ${incidentTypes[i].replace(/_/g, ' ')} occurred in ${zonesData[i].name}`, users[i % users.length].name, incidentStatuses[i], i === 2 ? 1 : 0, siteIds[0]]
      );
    }
    console.log('  Created 6 safety incidents');

    // Training Courses
    const courses = [
      { id: 'TRN-001', title: 'Underground Safety Fundamentals', type: 'safety', training: 'classroom', dur: 120, label: '2 hours', enrolled: 45, completed: 38, instructor: 'Dr. Sarah Williams' },
      { id: 'TRN-002', title: 'Heavy Equipment Operation', type: 'equipment', training: 'practical', dur: 480, label: '8 hours', enrolled: 30, completed: 22, instructor: 'Mike Davidson' },
      { id: 'TRN-003', title: 'Emergency Response Protocol', type: 'emergency', training: 'vr_simulation', dur: 90, label: '1.5 hours', enrolled: 60, completed: 55, instructor: 'Lisa Thompson' },
      { id: 'TRN-004', title: 'Environmental Compliance', type: 'compliance', training: 'online', dur: 60, label: '1 hour', enrolled: 100, completed: 87, instructor: 'Prof. James Carter' },
      { id: 'TRN-005', title: 'Explosives Handling Safety', type: 'safety', training: 'classroom', dur: 240, label: '4 hours', enrolled: 25, completed: 20, instructor: 'Tom Anderson' },
      { id: 'TRN-006', title: 'First Aid & CPR', type: 'safety', training: 'practical', dur: 180, label: '3 hours', enrolled: 80, completed: 72, instructor: 'Nurse Kelly Martin' },
    ];

    const courseIds: string[] = [];
    for (const course of courses) {
      const result = await client.query(
        `INSERT INTO training_courses (course_id, title, description, course_type, training_type, duration_minutes, duration_label, status, enrolled_count, completed_count, instructor, is_mandatory, is_active, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, 'active', $8, $9, $10, $11, true, $12)
         ON CONFLICT (course_id) DO UPDATE SET title = EXCLUDED.title
         RETURNING id`,
        [course.id, course.title, `Comprehensive training on ${course.title.toLowerCase()}`, course.type, course.training, course.dur, course.label, course.enrolled, course.completed, course.instructor, course.type === 'safety', siteIds[0]]
      );
      courseIds.push(result.rows[0].id);
    }
    console.log(`  Created ${courses.length} training courses`);

    // VR Simulations
    const vrSims = [
      { sim_id: 'VR-001', name: 'Underground Evacuation', difficulty: 'intermediate', rate: 78.5, score: 82.3, sessions: 245, scenario: 'Emergency Evacuation' },
      { sim_id: 'VR-002', name: 'Equipment Malfunction Response', difficulty: 'advanced', rate: 65.2, score: 74.8, sessions: 180, scenario: 'Equipment Failure' },
      { sim_id: 'VR-003', name: 'Confined Space Entry', difficulty: 'expert', rate: 55.0, score: 71.2, sessions: 120, scenario: 'Confined Space' },
      { sim_id: 'VR-004', name: 'Hazmat Spill Containment', difficulty: 'intermediate', rate: 82.1, score: 85.6, sessions: 310, scenario: 'Chemical Spill' },
      { sim_id: 'VR-005', name: 'Fall Protection Basics', difficulty: 'beginner', rate: 92.3, score: 91.0, sessions: 450, scenario: 'Fall Protection' },
    ];
    for (let i = 0; i < vrSims.length; i++) {
      const vr = vrSims[i];
      await client.query(
        `INSERT INTO vr_simulations (simulation_id, name, difficulty, completion_rate, average_score, total_sessions, description, scenario_type, course_id, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
         ON CONFLICT (simulation_id) DO NOTHING`,
        [vr.sim_id, vr.name, vr.difficulty, vr.rate, vr.score, vr.sessions, `VR simulation for ${vr.scenario.toLowerCase()} scenarios`, vr.scenario, courseIds[i % courseIds.length], siteIds[0]]
      );
    }
    console.log(`  Created ${vrSims.length} VR simulations`);

    // User Certifications
    const certNames = ['Mine Safety', 'Heavy Equipment Operator', 'First Aid', 'Explosives Handling', 'Environmental Compliance', 'Confined Space Entry'];
    const issuingAuthorities = ['Mining Safety Authority', 'Equipment Training Institute', 'Red Cross', 'National Mining Board', 'EPA', 'OSHA'];
    for (let c = 0; c < 15; c++) {
      const certIdx = c % certNames.length;
      const userIdx = c % userIds.length;
      const daysUntilExpiry = Math.floor(-30 + Math.random() * 400);
      const status = daysUntilExpiry < 0 ? 'expired' : daysUntilExpiry < 60 ? 'expiring_soon' : 'current';
      await client.query(
        `INSERT INTO user_certifications (employee_id, employee_name, certification_name, issued_at, expires_at, status, issuing_authority, site_id)
         VALUES ($1, $2, $3, NOW() - INTERVAL '${Math.floor(180 + Math.random() * 365)} days', NOW() + INTERVAL '${daysUntilExpiry} days', $4, $5, $6)`,
        [userIds[userIdx], users[userIdx].name, certNames[certIdx], status, issuingAuthorities[certIdx], siteIds[0]]
      );
    }
    console.log('  Created 15 certifications');

    // =============================================
    // 9. ALERTS
    // =============================================
    console.log('\n--- Seeding Alerts ---');
    const alertData = [
      { type: 'asset_malfunction', severity: 'critical', title: 'Engine Overheating', message: 'Excavator EXC-001 engine temperature exceeded threshold' },
      { type: 'maintenance_due', severity: 'warning', title: 'Maintenance Due', message: 'Haul Truck HTK-002 approaching maintenance interval' },
      { type: 'network_outage', severity: 'warning', title: 'Signal Degradation', message: 'Tower TWR-003 experiencing reduced signal strength' },
      { type: 'safety_violation', severity: 'critical', title: 'PPE Violation', message: 'Personnel detected without hard hat in Zone A' },
      { type: 'asset_malfunction', severity: 'info', title: 'Battery Low', message: 'Drill DRL-001 battery voltage below optimal range' },
    ];
    for (let a = 0; a < alertData.length; a++) {
      const alert = alertData[a];
      await client.query(
        `INSERT INTO alerts (alert_id, alert_type, severity, title, message, triggered_at, status, site_id)
         VALUES ($1, $2, $3, $4, $5, NOW() - INTERVAL '${a * 2} hours', $6, $7)
         ON CONFLICT (alert_id) DO NOTHING`,
        [`ALT-SEED-${String(a + 1).padStart(3, '0')}`, alert.type, alert.severity, alert.title, alert.message, a < 3 ? 'active' : 'acknowledged', siteIds[0]]
      );
    }
    console.log(`  Created ${alertData.length} alerts`);

    // =============================================
    // WATER FLOW NETWORK
    // =============================================
    console.log('\n--- Seeding Water Flow Network ---');

    const flowNodes = [
      { key: 'reservoir', label: 'Water Reservoir', subtitle: '85% Full', type: 'reservoir', icon: '\uD83D\uDCA7', color: '#3b82f6', x: 60, y: 85 },
      { key: 'pumpStation1', label: 'Pump Station #1', subtitle: '1,250 L/min', type: 'pump_station', icon: '\u26A1', color: '#8b5cf6', x: 195, y: 85 },
      { key: 'treatment', label: 'Treatment Plant', subtitle: '98.5% Efficiency', type: 'treatment_plant', icon: '\uD83E\uDDEA', color: '#10b981', x: 345, y: 85 },
      { key: 'mainDist', label: 'Main Distribution', subtitle: 'Hub', type: 'distribution_hub', icon: '\uD83D\uDD00', color: '#06b6d4', x: 500, y: 85 },
      { key: 'zoneA', label: 'Zone A - Mining', subtitle: '3,200 m\u00B3/day', type: 'mining_zone', icon: '\u26CF\uFE0F', color: '#f59e0b', x: 640, y: 35 },
      { key: 'zoneB', label: 'Zone B - Processing', subtitle: '2,800 m\u00B3/day', type: 'processing_zone', icon: '\uD83C\uDFED', color: '#ef4444', x: 640, y: 85 },
      { key: 'zoneC', label: 'Zone C - Dust Supp.', subtitle: '1,900 m\u00B3/day', type: 'dust_suppression', icon: '\uD83D\uDCA8', color: '#f97316', x: 640, y: 135 },
      { key: 'dustSupp', label: 'Dust Suppression', subtitle: '650 L/min', type: 'dust_suppression', icon: '\uD83D\uDEBF', color: '#06b6d4', x: 780, y: 135 },
      { key: 'cooling', label: 'Equipment Cooling', subtitle: '420 L/min', type: 'cooling_system', icon: '\u2744\uFE0F', color: '#a855f7', x: 780, y: 85 },
      { key: 'tailings', label: 'Tailings Dam', subtitle: '72% Capacity', type: 'tailings_dam', icon: '\uD83C\uDFD7\uFE0F', color: '#64748b', x: 780, y: 35 },
      { key: 'reclaim', label: 'Reclaim Facility', subtitle: '780 L/min', type: 'reclaim_facility', icon: '\u267B\uFE0F', color: '#22c55e', x: 640, y: 195 },
      { key: 'pumpStation2', label: 'Pump Station #2', subtitle: 'Recirculation', type: 'pump_station', icon: '\u26A1', color: '#8b5cf6', x: 345, y: 195 },
      { key: 'storage', label: 'Emergency Storage', subtitle: '50 PSI Ready', type: 'storage', icon: '\uD83D\uDEE2\uFE0F', color: '#64748b', x: 195, y: 195 },
    ];

    for (const node of flowNodes) {
      await client.query(
        `INSERT INTO water_flow_nodes (node_key, label, subtitle, node_type, icon, color, x_position, y_position, site_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         ON CONFLICT (node_key) DO UPDATE SET label = EXCLUDED.label`,
        [node.key, node.label, node.subtitle, node.type, node.icon, node.color, node.x, node.y, siteIds[0]]
      );
    }
    console.log(`  Created ${flowNodes.length} flow nodes`);

    const flowConnections = [
      { from: 'reservoir', to: 'pumpStation1', flow: 1250, pipeId: 'P-01', status: 'optimal', reclaim: false },
      { from: 'pumpStation1', to: 'treatment', flow: 1250, pipeId: 'P-01', status: 'optimal', reclaim: false },
      { from: 'treatment', to: 'mainDist', flow: 1100, pipeId: 'P-02', status: 'optimal', reclaim: false },
      { from: 'mainDist', to: 'zoneA', flow: 450, pipeId: 'P-02', status: 'optimal', reclaim: false },
      { from: 'mainDist', to: 'zoneB', flow: 390, pipeId: 'P-02', status: 'optimal', reclaim: false },
      { from: 'mainDist', to: 'zoneC', flow: 260, pipeId: 'P-03', status: 'optimal', reclaim: false },
      { from: 'zoneA', to: 'tailings', flow: 200, pipeId: 'P-05', status: 'optimal', reclaim: false },
      { from: 'zoneB', to: 'cooling', flow: 420, pipeId: 'P-04', status: 'warning', reclaim: false },
      { from: 'zoneC', to: 'dustSupp', flow: 650, pipeId: 'P-03', status: 'optimal', reclaim: false },
      { from: 'tailings', to: 'reclaim', flow: 300, pipeId: 'P-05', status: 'optimal', reclaim: true },
      { from: 'cooling', to: 'reclaim', flow: 350, pipeId: 'P-05', status: 'optimal', reclaim: true },
      { from: 'dustSupp', to: 'reclaim', flow: 130, pipeId: 'P-05', status: 'optimal', reclaim: true },
      { from: 'reclaim', to: 'pumpStation2', flow: 780, pipeId: 'P-05', status: 'optimal', reclaim: true },
      { from: 'pumpStation2', to: 'storage', flow: 200, pipeId: 'P-06', status: 'optimal', reclaim: true },
      { from: 'pumpStation2', to: 'treatment', flow: 580, pipeId: 'P-05', status: 'optimal', reclaim: true },
    ];

    for (const conn of flowConnections) {
      await client.query(
        `INSERT INTO water_flow_connections (from_node_key, to_node_key, flow_rate, status, is_reclaim, site_id)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [conn.from, conn.to, conn.flow, conn.status, conn.reclaim, siteIds[0]]
      );
    }
    console.log(`  Created ${flowConnections.length} flow connections`);

    // =============================================
    // DIGITAL TWIN SENSORS
    // =============================================
    console.log('\n--- Seeding Digital Twin Sensors ---');

    // Get first 4 asset IDs
    const dtAssets = await client.query('SELECT id, type FROM assets ORDER BY asset_id LIMIT 4');
    
    const sensorConfigs: Record<string, Array<{ key: string; label: string; value: string; unit: string; color: string; cx: number; cy: number }>> = {
      excavator: [
        { key: 'engine', label: 'ENGINE', value: '2,100 RPM', unit: 'RPM', color: '#10b981', cx: 230, cy: 280 },
        { key: 'hydraulic', label: 'HYDRAULIC', value: '3,200 PSI', unit: 'PSI', color: '#3b82f6', cx: 335, cy: 330 },
        { key: 'track', label: 'TRACK WEAR', value: '68%', unit: '%', color: '#f59e0b', cx: 270, cy: 400 },
      ],
      haul_truck: [
        { key: 'engine', label: 'ENGINE', value: '1,800 RPM', unit: 'RPM', color: '#10b981', cx: 157, cy: 280 },
        { key: 'payload', label: 'PAYLOAD', value: '220 tonnes', unit: 'tonnes', color: '#3b82f6', cx: 350, cy: 290 },
        { key: 'tire', label: 'TIRE PSI', value: '110 PSI', unit: 'PSI', color: '#f59e0b', cx: 435, cy: 380 },
      ],
      drill: [
        { key: 'engine', label: 'ENGINE', value: '1,650 RPM', unit: 'RPM', color: '#10b981', cx: 225, cy: 330 },
        { key: 'depth', label: 'DRILL DEPTH', value: '45.2m', unit: 'm', color: '#3b82f6', cx: 417, cy: 200 },
        { key: 'torque', label: 'TORQUE', value: '85 kN\u00B7m', unit: 'kN\u00B7m', color: '#f59e0b', cx: 330, cy: 350 },
      ],
      dozer: [
        { key: 'engine', label: 'ENGINE', value: '1,950 RPM', unit: 'RPM', color: '#10b981', cx: 247, cy: 260 },
        { key: 'fuel', label: 'FUEL LEVEL', value: '78%', unit: '%', color: '#3b82f6', cx: 380, cy: 270 },
        { key: 'blade', label: 'BLADE LOAD', value: '14.2 kN', unit: 'kN', color: '#f59e0b', cx: 130, cy: 295 },
      ],
    };

    let sensorCount = 0;
    for (const asset of dtAssets.rows) {
      const sensors = sensorConfigs[asset.type] || sensorConfigs['excavator'];
      for (const sensor of sensors) {
        await client.query(
          `INSERT INTO digital_twin_sensors (asset_id, sensor_key, label, value, unit, color, cx, cy)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [asset.id, sensor.key, sensor.label, sensor.value, sensor.unit, sensor.color, sensor.cx, sensor.cy]
        );
        sensorCount++;
      }
    }
    console.log(`  Created ${sensorCount} digital twin sensor readings`);

    // =============================================
    // 10. MINING EVENTS (for AI Assistant)
    // =============================================
    console.log('\n--- Seeding Mining Events ---');

    const miningEventTypes = [
      'breakdown', 'maintenance', 'inspection', 'incident', 'alert',
      'production_milestone', 'shift_change', 'equipment_transfer',
      'fuel_delivery', 'blasting', 'survey', 'environmental',
      'safety_drill', 'training_completed', 'certification_expired',
      'geofence_breach', 'speed_violation', 'water_quality_alert',
      'network_outage', 'sensor_malfunction'
    ];
    const miningCategories = [
      'equipment', 'safety', 'production', 'environment', 'network',
      'water', 'security', 'training', 'logistics', 'maintenance'
    ];
    const miningSeverities = ['low', 'medium', 'high', 'critical'] as const;
    const miningStatuses = ['open', 'in_progress', 'resolved', 'closed'] as const;
    const equipTypes = ['excavator', 'haul_truck', 'drill', 'dozer', 'loader', 'grader', 'water_truck'];
    const locList = ['Zone A - Primary Pit', 'Zone B - Processing', 'Zone C - Secondary Pit', 'Zone D - Maintenance', 'Zone E - Administration', 'Zone F - Restricted', 'Main Gate', 'North Perimeter', 'South Perimeter', 'Loading Bay'];
    const reporters = ['John Mitchell', 'Sarah Chen', 'Mike Rodriguez', 'Lisa Thompson', 'System Administrator', 'Auto-Sensor', 'Control Room'];
    const tagPool = ['urgent', 'scheduled', 'recurring', 'weather-related', 'nightshift', 'dayshift', 'regulatory', 'contractor', 'overtime', 'warranty'];

    const eventTemplates = [
      { title: 'Excavator hydraulic line failure', desc: 'Hydraulic line burst on boom cylinder. Emergency shutdown initiated.', eq: 'excavator' },
      { title: 'Haul truck tire blowout', desc: 'Rear tire blowout on haul road. Truck safely pulled over.', eq: 'haul_truck' },
      { title: 'Drill bit replacement completed', desc: 'Scheduled drill bit replacement after 150 hours.', eq: 'drill' },
      { title: 'Dozer track tension adjustment', desc: 'Track tension out of spec. Adjusted to manufacturer specs.', eq: 'dozer' },
      { title: 'Production target exceeded', desc: 'Daily target exceeded by 12%. Total: 5,840 tonnes.', eq: null },
      { title: 'Blasting event Zone C', desc: 'Controlled blasting in sector 7. 450kg ANFO detonated.', eq: null },
      { title: 'Water quality pH alert', desc: 'pH below threshold in tailings dam. Lime dosing activated.', eq: null },
      { title: 'Network Tower outage', desc: 'Tower lost connectivity for 8 min. Backup handled traffic.', eq: null },
      { title: 'Geofence breach detected', desc: 'Unauthorized vehicle in restricted zone. Security dispatched.', eq: 'haul_truck' },
      { title: 'Safety drill completed', desc: 'Emergency evacuation drill. All personnel accounted for.', eq: null },
      { title: 'PPE compliance check', desc: 'Random PPE audit. 2 minor violations. Warnings issued.', eq: null },
      { title: 'Fuel delivery received', desc: 'Bulk delivery: 45,000L diesel. Quality checks passed.', eq: null },
      { title: 'Loader engine overheating', desc: 'Engine temp warning. Operator parked unit. Coolant low.', eq: 'loader' },
      { title: 'Shift change handover', desc: 'Day to night shift. 3 tickets transferred. Zero incidents.', eq: null },
      { title: 'Environmental monitoring survey', desc: 'Quarterly survey. Air quality and dust within limits.', eq: null },
      { title: 'Training session completed', desc: 'Heavy equipment certification renewed for 8 operators.', eq: null },
      { title: 'Grader road maintenance', desc: 'Haul road grading completed. Speed limit restored.', eq: 'grader' },
      { title: 'Water pump malfunction', desc: 'Primary pump abnormal vibration. Standby pump activated.', eq: null },
      { title: 'Speed violation recorded', desc: 'Truck at 52 km/h in 40 zone near processing plant.', eq: 'haul_truck' },
      { title: 'Sensor malfunction alert', desc: 'Vibration sensor erratic readings. Sensor replaced.', eq: 'dozer' },
    ];

    let eventCount = 0;
    for (let e = 0; e < 200; e++) {
      const tmpl = eventTemplates[e % eventTemplates.length];
      const daysAgo = Math.floor(Math.random() * 365);
      const hoursAgo = Math.floor(Math.random() * 24);
      const evtType = miningEventTypes[e % miningEventTypes.length];
      const cat = miningCategories[e % miningCategories.length];
      const sev = miningSeverities[Math.floor(Math.random() * miningSeverities.length)];
      const stat = miningStatuses[Math.floor(Math.random() * miningStatuses.length)];
      const loc = locList[e % locList.length];
      const rep = reporters[e % reporters.length];
      const eqt = tmpl.eq || equipTypes[e % equipTypes.length];
      const dur = Math.floor(15 + Math.random() * 480);
      const cost = Math.round(Math.random() * 50000);
      const prod = Math.round(Math.random() * 500);
      const tgs = [tagPool[e % tagPool.length], tagPool[(e + 3) % tagPool.length]];

      await client.query(
        `INSERT INTO mining_events (event_id, event_type, category, severity, status, title, description, equipment_type, equipment_name, location, zone_name, reported_by, duration_minutes, cost_impact, production_impact_tonnes, tags, site_id, occurred_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, NOW() - INTERVAL '${daysAgo} days' - INTERVAL '${hoursAgo} hours')
         ON CONFLICT (event_id) DO NOTHING`,
        [
          `EVT-${String(e + 1).padStart(4, '0')}`,
          evtType, cat, sev, stat,
          `${tmpl.title} #${e + 1}`,
          tmpl.desc,
          eqt,
          `${eqt.replace(/_/g, ' ').replace(/\b\w/g, (c: string) => c.toUpperCase())} Unit ${1 + (e % 5)}`,
          loc, loc.split(' - ')[0],
          rep, dur, cost, prod, tgs, siteIds[0]
        ]
      );
      eventCount++;
    }
    console.log(`  Created ${eventCount} mining events`);

    // =============================================
    // 11. HISTORICAL REPORTS (sample)
    // =============================================
    console.log('\n--- Seeding Historical Reports ---');
    const rptTypes = ['production', 'safety', 'equipment', 'water', 'energy', 'security'] as const;
    for (let r = 0; r < rptTypes.length; r++) {
      const rDays = r * 7 + Math.floor(Math.random() * 7);
      await client.query(
        `INSERT INTO historical_reports (report_id, report_type, title, time_range_start, time_range_end, time_range_preset, status, kpi_summary, site_id, created_at)
         VALUES ($1, $2, $3, NOW() - INTERVAL '${rDays + 30} days', NOW() - INTERVAL '${rDays} days', '30d', 'completed', $4, $5, NOW() - INTERVAL '${rDays} days')
         ON CONFLICT (report_id) DO NOTHING`,
        [
          `RPT-SEED-${String(r + 1).padStart(3, '0')}`,
          rptTypes[r],
          `${rptTypes[r].charAt(0).toUpperCase() + rptTypes[r].slice(1)} Monthly Report`,
          JSON.stringify([
            { label: 'Metric 1', value: `${Math.floor(1000 + Math.random() * 9000)}`, change: +(Math.random() * 20 - 5).toFixed(1), trend: Math.random() > 0.3 ? 'up' : 'down' },
            { label: 'Metric 2', value: `${(80 + Math.random() * 18).toFixed(1)}%`, change: +(Math.random() * 10 - 2).toFixed(1), trend: 'up' },
          ]),
          siteIds[0]
        ]
      );
    }
    console.log(`  Created ${rptTypes.length} sample reports`);

    await client.query('COMMIT');

    console.log('\n===========================================');
    console.log('  Database seeding completed successfully!');
    console.log('===========================================');
    console.log('\n  Login credentials:');
    console.log('  Admin:    admin@mining-sds.com / admin123');
    console.log('  Operator: john.operator@mining-sds.com / operator123');
    console.log('===========================================\n');

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Seeding failed:', error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

// Run if called directly
if (require.main === module) {
  seedAll()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}

export default seedAll;