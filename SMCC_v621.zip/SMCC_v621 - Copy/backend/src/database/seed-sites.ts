import { pool } from '../config/database';

async function seedSites() {
  console.log('🌱 Starting sites seeding...');

  try {
    // Create sample mining sites
    const sites = [
      {
        site_id: 'SITE-001',
        name: 'Northern Ridge Mine',
        location: 'Pilbara, Western Australia',
        country: 'Australia',
        region: 'Western Australia',
        site_type: 'open_pit',
        status: 'operational',
        latitude: -22.9576,
        longitude: 118.5986,
        timezone: 'Australia/Perth',
        area_sq_km: 45.5,
        max_depth_meters: 350,
        primary_commodity: 'Iron Ore',
        secondary_commodities: ['Manganese', 'Nickel'],
        annual_capacity_tonnes: 25000000,
        workforce_count: 850,
        contact_email: 'northern.ridge@mining-sds.com',
        contact_phone: '+61-8-9000-1234',
        image_url: 'https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?w=800',
        description: 'Large-scale open-pit iron ore mine in the Pilbara region with state-of-the-art autonomous operations.'
      },
      {
        site_id: 'SITE-002',
        name: 'Sierra Verde Complex',
        location: 'Atacama Desert, Chile',
        country: 'Chile',
        region: 'Atacama',
        site_type: 'open_pit',
        status: 'operational',
        latitude: -23.6345,
        longitude: -70.3975,
        timezone: 'America/Santiago',
        area_sq_km: 62.3,
        max_depth_meters: 425,
        primary_commodity: 'Copper',
        secondary_commodities: ['Gold', 'Molybdenum'],
        annual_capacity_tonnes: 18000000,
        workforce_count: 1200,
        contact_email: 'sierra.verde@mining-sds.com',
        contact_phone: '+56-2-2000-5678',
        image_url: 'https://images.unsplash.com/photo-1584464491033-06628f3a6b7b?w=800',
        description: 'Premium copper mine complex featuring advanced hydrometallurgical processing and sustainable water management.'
      },
      {
        site_id: 'SITE-003',
        name: 'Goldstream Underground',
        location: 'Ontario, Canada',
        country: 'Canada',
        region: 'Ontario',
        site_type: 'underground',
        status: 'operational',
        latitude: 48.4634,
        longitude: -81.9978,
        timezone: 'America/Toronto',
        area_sq_km: 12.8,
        max_depth_meters: 2400,
        primary_commodity: 'Gold',
        secondary_commodities: ['Silver', 'Copper'],
        annual_capacity_tonnes: 2500000,
        workforce_count: 450,
        contact_email: 'goldstream@mining-sds.com',
        contact_phone: '+1-705-555-9876',
        image_url: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=800',
        description: 'Deep underground gold mine utilizing cutting-edge ventilation and safety systems.'
      },
      {
        site_id: 'SITE-004',
        name: 'Eastern Bauxite Fields',
        location: 'Queensland, Australia',
        country: 'Australia',
        region: 'Queensland',
        site_type: 'open_pit',
        status: 'operational',
        latitude: -27.4698,
        longitude: 153.0251,
        timezone: 'Australia/Brisbane',
        area_sq_km: 34.2,
        max_depth_meters: 180,
        primary_commodity: 'Bauxite',
        secondary_commodities: ['Alumina'],
        annual_capacity_tonnes: 12000000,
        workforce_count: 320,
        contact_email: 'eastern.bauxite@mining-sds.com',
        contact_phone: '+61-7-3000-4321',
        image_url: 'https://images.unsplash.com/photo-1615811361523-6bd03d7748e7?w=800',
        description: 'Modern bauxite extraction facility with integrated alumina refinery and rehabilitation program.'
      },
      {
        site_id: 'SITE-005',
        name: 'Platinum Ridge',
        location: 'Limpopo, South Africa',
        country: 'South Africa',
        region: 'Limpopo',
        site_type: 'underground',
        status: 'operational',
        latitude: -24.7761,
        longitude: 29.4698,
        timezone: 'Africa/Johannesburg',
        area_sq_km: 18.5,
        max_depth_meters: 1800,
        primary_commodity: 'Platinum',
        secondary_commodities: ['Palladium', 'Rhodium'],
        annual_capacity_tonnes: 1800000,
        workforce_count: 680,
        contact_email: 'platinum.ridge@mining-sds.com',
        contact_phone: '+27-12-555-7890',
        image_url: 'https://images.unsplash.com/photo-1614359036973-a3c72c017f9f?w=800',
        description: 'High-grade platinum group metals mine with advanced safety protocols and community development programs.'
      },
      {
        site_id: 'SITE-006',
        name: 'Central Processing Hub',
        location: 'Nevada, USA',
        country: 'United States',
        region: 'Nevada',
        site_type: 'processing_plant',
        status: 'operational',
        latitude: 39.5296,
        longitude: -119.8138,
        timezone: 'America/Los_Angeles',
        area_sq_km: 8.5,
        max_depth_meters: 0,
        primary_commodity: 'Multi-mineral',
        secondary_commodities: [],
        annual_capacity_tonnes: 5000000,
        workforce_count: 280,
        contact_email: 'central.processing@mining-sds.com',
        contact_phone: '+1-775-555-4567',
        image_url: 'https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800',
        description: 'State-of-the-art ore processing and concentration facility serving multiple regional mines.'
      }
    ];

    for (const site of sites) {
      const siteResult = await pool.query(
        `INSERT INTO sites (
          site_id, name, location, country, region, site_type, status,
          latitude, longitude, timezone, area_sq_km, max_depth_meters,
          primary_commodity, secondary_commodities, annual_capacity_tonnes,
          workforce_count, contact_email, contact_phone, image_url, description
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)
        ON CONFLICT (site_id) DO UPDATE SET
          name = EXCLUDED.name,
          image_url = EXCLUDED.image_url
        RETURNING id, site_id, name`,
        [
          site.site_id, site.name, site.location, site.country, site.region,
          site.site_type, site.status, site.latitude, site.longitude, site.timezone,
          site.area_sq_km, site.max_depth_meters, site.primary_commodity,
          site.secondary_commodities, site.annual_capacity_tonnes, site.workforce_count,
          site.contact_email, site.contact_phone, site.image_url, site.description
        ]
      );

      console.log(`✅ Created site: ${siteResult.rows[0].name}`);

      // Create initial metrics for the site
      await pool.query(
        `INSERT INTO site_metrics (
          site_id, total_assets, active_assets, assets_in_maintenance,
          production_tonnes_today, production_tonnes_mtd, network_uptime_percentage,
          active_alerts, critical_alerts, safety_incidents_today, safety_incidents_mtd,
          workforce_present, operational_efficiency, environmental_compliance_score
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
        [
          siteResult.rows[0].id,
          Math.floor(20 + Math.random() * 30), // total_assets
          Math.floor(15 + Math.random() * 25), // active_assets
          Math.floor(2 + Math.random() * 5),   // assets_in_maintenance
          Math.floor(50000 + Math.random() * 100000), // production_tonnes_today
          Math.floor(1500000 + Math.random() * 500000), // production_tonnes_mtd
          95 + Math.random() * 5, // network_uptime
          Math.floor(Math.random() * 5), // active_alerts
          Math.floor(Math.random() * 2), // critical_alerts
          Math.floor(Math.random() * 2), // safety_incidents_today
          Math.floor(Math.random() * 10), // safety_incidents_mtd
          Math.floor(site.workforce_count * (0.7 + Math.random() * 0.3)), // workforce_present
          85 + Math.random() * 15, // operational_efficiency
          90 + Math.random() * 10  // environmental_compliance_score
        ]
      );
    }

    console.log('✅ Sites and metrics created successfully');

  } catch (error) {
    console.error('❌ Sites seeding failed:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

// Run seeding if called directly
if (require.main === module) {
  seedSites()
    .then(() => {
      console.log('✅ Sites seeding completed');
      process.exit(0);
    })
    .catch((error) => {
      console.error('❌ Sites seeding failed:', error);
      process.exit(1);
    });
}

export default seedSites;
