import { Router } from 'express';
import { pool } from '../config/database';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();
router.use(authenticate);

// =============================================
// ZONES
// =============================================

// Get all zones
router.get('/zones', async (req, res) => {
  try {
    const { zone_type, status, site_id } = req.query;

    let query = 'SELECT * FROM zones WHERE 1=1';
    const params: any[] = [];
    let paramIndex = 1;

    if (zone_type) {
      query += ` AND zone_type = $${paramIndex}`;
      params.push(zone_type);
      paramIndex++;
    }

    if (status) {
      query += ` AND status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (site_id) {
      query += ` AND site_id = $${paramIndex}`;
      params.push(site_id);
      paramIndex++;
    }

    query += ' ORDER BY name';

    const result = await pool.query(query, params);

    // Map to frontend model
    const zones = result.rows.map((row: any) => ({
      id: row.id,
      zoneId: row.zone_id,
      name: row.name,
      type: row.zone_type,
      status: row.status,
      areaSqKm: parseFloat(row.area_sq_km || 0),
      assetCount: row.current_asset_count || 0,
      personnelCount: row.personnel_count || 0,
      color: row.color || '#3B82F6',
      description: row.description,
      coordinates: [],
      centerLatitude: parseFloat(row.center_latitude || 0),
      centerLongitude: parseFloat(row.center_longitude || 0)
    }));

    res.json(zones);
  } catch (error) {
    console.error('Get zones error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single zone
router.get('/zones/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM zones WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Zone not found' });
    }

    const row = result.rows[0];
    res.json({
      id: row.id,
      zoneId: row.zone_id,
      name: row.name,
      type: row.zone_type,
      status: row.status,
      areaSqKm: parseFloat(row.area_sq_km || 0),
      assetCount: row.current_asset_count || 0,
      personnelCount: row.personnel_count || 0,
      color: row.color || '#3B82F6',
      description: row.description
    });
  } catch (error) {
    console.error('Get zone error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create zone
router.post('/zones', async (req, res) => {
  try {
    const { zoneId, name, zoneType, centerLatitude, centerLongitude, areaSqKm, maxCapacity, speedLimit, siteId } = req.body;

    const result = await pool.query(
      `INSERT INTO zones (zone_id, name, zone_type, center_latitude, center_longitude, area_sq_km, max_capacity, speed_limit, site_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [zoneId, name, zoneType, centerLatitude, centerLongitude, areaSqKm, maxCapacity, speedLimit, siteId]
    );

    res.status(201).json(result.rows[0]);
  } catch (error: any) {
    console.error('Create zone error:', error);
    if (error.code === '23505') {
      return res.status(400).json({ error: 'Zone ID already exists' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// ASSET LOCATIONS
// =============================================

// Get asset locations (latest telemetry with asset info)
router.get('/assets', async (req, res) => {
  try {
    const { zone_id, status, site_id } = req.query;

    let query = `
      SELECT a.id, a.asset_id, a.type as asset_type, a.name, a.status,
             t.latitude, t.longitude, t.altitude, t.heading, t.speed, t.timestamp as last_updated,
             z.name as zone_name
      FROM assets a
      LEFT JOIN LATERAL (
        SELECT * FROM asset_telemetry WHERE asset_id = a.id ORDER BY timestamp DESC LIMIT 1
      ) t ON true
      LEFT JOIN zones z ON a.current_zone_id = z.id
      WHERE 1=1
    `;
    const params: any[] = [];
    let paramIndex = 1;

    if (zone_id) {
      query += ` AND a.current_zone_id = $${paramIndex}`;
      params.push(zone_id);
      paramIndex++;
    }

    if (status) {
      query += ` AND a.status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (site_id) {
      query += ` AND a.site_id = $${paramIndex}`;
      params.push(site_id);
      paramIndex++;
    }

    const result = await pool.query(query, params);

    const locations = result.rows.map((row: any) => ({
      id: row.id,
      assetId: row.asset_id,
      assetType: row.asset_type,
      name: row.name,
      latitude: parseFloat(row.latitude || 0),
      longitude: parseFloat(row.longitude || 0),
      altitude: parseFloat(row.altitude || 0),
      heading: parseFloat(row.heading || 0),
      speed: parseFloat(row.speed || 0),
      zone: row.zone_name || 'Unknown',
      status: row.status === 'active' ? 'active' : row.status === 'maintenance' ? 'maintenance' : 'idle',
      lastUpdated: row.last_updated || new Date()
    }));

    res.json(locations);
  } catch (error) {
    console.error('Get asset locations error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single asset location
router.get('/assets/:assetId', async (req, res) => {
  try {
    const { assetId } = req.params;

    const result = await pool.query(`
      SELECT a.id, a.asset_id, a.type as asset_type, a.name, a.status,
             t.latitude, t.longitude, t.altitude, t.heading, t.speed, t.timestamp as last_updated,
             z.name as zone_name
      FROM assets a
      LEFT JOIN LATERAL (
        SELECT * FROM asset_telemetry WHERE asset_id = a.id ORDER BY timestamp DESC LIMIT 1
      ) t ON true
      LEFT JOIN zones z ON a.current_zone_id = z.id
      WHERE a.id = $1 OR a.asset_id = $1
    `, [assetId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Asset not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get asset location error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// GEO-FENCES
// =============================================

// Get all geo-fences
router.get('/geofences', async (req, res) => {
  try {
    const { site_id } = req.query;

    let query = 'SELECT * FROM geofences WHERE 1=1';
    const params: any[] = [];

    if (site_id) {
      query += ' AND site_id = $1';
      params.push(site_id);
    }

    query += ' ORDER BY name';

    const result = await pool.query(query, params);

    const fences = result.rows.map((row: any) => ({
      id: row.id,
      name: row.name,
      type: row.fence_type,
      coordinates: row.coordinates || [],
      radius: parseFloat(row.radius || 0),
      speedLimit: row.speed_limit,
      alertOnBreach: row.alert_on_breach,
      isActive: row.is_active
    }));

    res.json(fences);
  } catch (error) {
    console.error('Get geofences error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create geo-fence
router.post('/geofences', async (req, res) => {
  try {
    const { name, type, coordinates, radius, speedLimit, alertOnBreach, isActive, siteId } = req.body;

    const result = await pool.query(
      `INSERT INTO geofences (name, fence_type, coordinates, radius, speed_limit, alert_on_breach, is_active, site_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [name, type, JSON.stringify(coordinates), radius, speedLimit, alertOnBreach ?? true, isActive ?? true, siteId]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Create geofence error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update geo-fence
router.put('/geofences/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, type, coordinates, radius, speedLimit, alertOnBreach, isActive } = req.body;

    const result = await pool.query(
      `UPDATE geofences 
       SET name = COALESCE($1, name),
           fence_type = COALESCE($2, fence_type),
           coordinates = COALESCE($3, coordinates),
           radius = COALESCE($4, radius),
           speed_limit = COALESCE($5, speed_limit),
           alert_on_breach = COALESCE($6, alert_on_breach),
           is_active = COALESCE($7, is_active)
       WHERE id = $8
       RETURNING *`,
      [name, type, coordinates ? JSON.stringify(coordinates) : null, radius, speedLimit, alertOnBreach, isActive, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Geofence not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update geofence error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete geo-fence
router.delete('/geofences/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM geofences WHERE id = $1 RETURNING id', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Geofence not found' });
    }

    res.json({ message: 'Geofence deleted successfully' });
  } catch (error) {
    console.error('Delete geofence error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// GEO-SPATIAL ALERTS
// =============================================

router.get('/alerts', async (req, res) => {
  try {
    const { resolved, severity, site_id } = req.query;

    let query = 'SELECT * FROM geospatial_alerts WHERE 1=1';
    const params: any[] = [];
    let paramIndex = 1;

    if (resolved !== undefined) {
      query += ` AND resolved = $${paramIndex}`;
      params.push(resolved === 'true');
      paramIndex++;
    }

    if (severity) {
      query += ` AND severity = $${paramIndex}`;
      params.push(severity);
      paramIndex++;
    }

    if (site_id) {
      query += ` AND site_id = $${paramIndex}`;
      params.push(site_id);
      paramIndex++;
    }

    query += ' ORDER BY created_at DESC LIMIT 100';

    const result = await pool.query(query, params);

    const alerts = result.rows.map((row: any) => ({
      id: row.id,
      type: row.alert_type,
      assetId: row.asset_id,
      assetName: row.asset_name,
      zone: row.zone,
      message: row.message,
      severity: row.severity,
      timestamp: row.created_at,
      resolved: row.resolved
    }));

    res.json(alerts);
  } catch (error) {
    console.error('Get geo alerts error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// STATISTICS
// =============================================

router.get('/statistics', async (req, res) => {
  try {
    const [zonesResult, assetsResult, alertsResult, geofencesResult] = await Promise.all([
      pool.query(`
        SELECT 
          COUNT(*) as total_zones,
          COUNT(CASE WHEN status = 'active' THEN 1 END) as active_zones,
          SUM(current_asset_count) as total_assets_in_zones,
          SUM(personnel_count) as total_personnel,
          SUM(area_sq_km) as total_area_sq_km
        FROM zones
      `),
      pool.query(`
        SELECT COUNT(*) as total_tracked_assets
        FROM assets WHERE status = 'active'
      `),
      pool.query(`
        SELECT 
          COUNT(*) as total_alerts,
          COUNT(CASE WHEN resolved = false THEN 1 END) as unresolved_alerts
        FROM geospatial_alerts
      `),
      pool.query(`
        SELECT COUNT(*) as total_geofences
        FROM geofences WHERE is_active = true
      `)
    ]);

    res.json({
      zones: zonesResult.rows[0],
      trackedAssets: parseInt(assetsResult.rows[0].total_tracked_assets || 0),
      alerts: alertsResult.rows[0],
      geofences: parseInt(geofencesResult.rows[0].total_geofences || 0),
      coverageAreaSqKm: parseFloat(zonesResult.rows[0].total_area_sq_km || 0)
    });
  } catch (error) {
    console.error('Get geo statistics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// MAP TILE CONFIGURATION
// =============================================

// Get available map tile layers
router.get('/map-layers', (req, res) => {
  res.json({
    layers: [
      { id: 'satellite', name: 'Satellite', url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', maxZoom: 19 },
      { id: 'terrain', name: 'Terrain', url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', maxZoom: 17, subdomains: 'abc' },
      { id: 'dark', name: 'Dark', url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', maxZoom: 19, subdomains: 'abcd' },
      { id: 'labels', name: 'Labels Overlay', url: 'https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png', maxZoom: 19, subdomains: 'abcd' },
    ]
  });
});

export default router;