import { Router } from 'express';
import { pool } from '../config/database';
import { authenticate, AuthRequest } from '../middleware/auth.middleware';

const router = Router();
router.use(authenticate);

// Get all alerts
router.get('/', async (req, res) => {
  try {
    const { alert_type, severity, status, site_id, limit = 100 } = req.query;

    let query = 'SELECT * FROM alerts WHERE 1=1';
    const params: any[] = [];
    let paramIndex = 1;

    if (alert_type) {
      query += ` AND alert_type = $${paramIndex}`;
      params.push(alert_type);
      paramIndex++;
    }

    if (severity) {
      query += ` AND severity = $${paramIndex}`;
      params.push(severity);
      paramIndex++;
    }

    if (status) {
      query += ` AND status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (site_id) {
      query += ` AND site_id = $${paramIndex}`;
      params.push(site_id);
      paramIndex++;
    }

    query += ` ORDER BY triggered_at DESC LIMIT $${paramIndex}`;
    params.push(limit);

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get alerts error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single alert
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM alerts WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Alert not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get alert error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Acknowledge alert
router.put('/:id/acknowledge', async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      `UPDATE alerts 
       SET status = 'acknowledged',
           acknowledged_by = $1,
           acknowledged_at = NOW()
       WHERE id = $2
       RETURNING *`,
      [req.user!.id, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Alert not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Acknowledge alert error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Resolve alert
router.put('/:id/resolve', async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { resolutionNotes } = req.body;

    const result = await pool.query(
      `UPDATE alerts 
       SET status = 'resolved',
           resolved_by = $1,
           resolved_at = NOW(),
           resolution_notes = $2
       WHERE id = $3
       RETURNING *`,
      [req.user!.id, resolutionNotes, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Alert not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Resolve alert error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get alert statistics
router.get('/statistics/summary', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        COUNT(*) as total_alerts,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active_alerts,
        COUNT(CASE WHEN status = 'acknowledged' THEN 1 END) as acknowledged_alerts,
        COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved_alerts,
        COUNT(CASE WHEN severity = 'critical' AND status = 'active' THEN 1 END) as critical_active,
        COUNT(CASE WHEN severity = 'emergency' AND status = 'active' THEN 1 END) as emergency_active,
        COUNT(CASE WHEN triggered_at > NOW() - INTERVAL '24 hours' THEN 1 END) as alerts_24h
      FROM alerts
    `);

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get alert statistics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
