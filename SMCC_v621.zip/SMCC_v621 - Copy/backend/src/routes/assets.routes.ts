import { Router } from 'express';
import { pool } from '../config/database';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();

// All routes require authentication
router.use(authenticate);

// =============================================
// STATIC ROUTES (must come before /:id)
// =============================================

// Get asset statistics
router.get('/statistics/summary', async (req, res) => {
  try {
    const [assetStats, healthStats] = await Promise.all([
      pool.query(`
        SELECT 
          COUNT(*) as total_assets,
          COUNT(CASE WHEN status = 'active' THEN 1 END) as active_assets,
          COUNT(CASE WHEN status = 'maintenance' THEN 1 END) as maintenance_assets,
          COUNT(CASE WHEN status = 'inactive' THEN 1 END) as inactive_assets,
          SUM(operating_hours) as total_operating_hours
        FROM assets
      `),
      pool.query(`SELECT AVG(health_score) as avg_health FROM asset_components`)
    ]);

    const row = assetStats.rows[0];
    const avgHealth = healthStats.rows[0]?.avg_health
      ? Math.round(parseFloat(healthStats.rows[0].avg_health) * 10) / 10
      : null;

    res.json({
      total_assets: parseInt(row.total_assets) || 0,
      active_assets: parseInt(row.active_assets) || 0,
      maintenance_assets: parseInt(row.maintenance_assets) || 0,
      inactive_assets: parseInt(row.inactive_assets) || 0,
      total_operating_hours: parseFloat(row.total_operating_hours) || 0,
      avg_health: avgHealth
    });
  } catch (error) {
    console.error('Get statistics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get asset statistics (alias)
router.get('/statistics', async (req, res) => {
  try {
    const [assetStats, healthStats] = await Promise.all([
      pool.query(`
        SELECT 
          COUNT(*) as total_assets,
          COUNT(CASE WHEN status = 'active' THEN 1 END) as active_assets,
          COUNT(CASE WHEN status = 'maintenance' THEN 1 END) as maintenance_assets,
          COUNT(CASE WHEN status = 'inactive' THEN 1 END) as inactive_assets,
          SUM(operating_hours) as total_operating_hours
        FROM assets
      `),
      pool.query(`SELECT AVG(health_score) as avg_health FROM asset_components`)
    ]);

    const row = assetStats.rows[0];
    const avgHealth = healthStats.rows[0]?.avg_health
      ? Math.round(parseFloat(healthStats.rows[0].avg_health) * 10) / 10
      : null;

    res.json({
      total_assets: parseInt(row.total_assets) || 0,
      active_assets: parseInt(row.active_assets) || 0,
      maintenance_assets: parseInt(row.maintenance_assets) || 0,
      inactive_assets: parseInt(row.inactive_assets) || 0,
      total_operating_hours: parseFloat(row.total_operating_hours) || 0,
      avg_health: avgHealth
    });
  } catch (error) {
    console.error('Get statistics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get assets by zone
router.get('/by-zone/:zoneId', async (req, res) => {
  try {
    const { zoneId } = req.params;
    const result = await pool.query(
      'SELECT * FROM assets WHERE current_zone_id = $1 ORDER BY name',
      [zoneId]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get assets by zone error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get assets by type
router.get('/by-type/:type', async (req, res) => {
  try {
    const { type } = req.params;
    const result = await pool.query(
      'SELECT * FROM assets WHERE type = $1 ORDER BY name',
      [type]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Get assets by type error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// COLLECTION ROUTES
// =============================================

// Get all assets
router.get('/', async (req, res) => {
  try {
    const { type, status, zone_id, site_id } = req.query;

    let query = 'SELECT * FROM assets WHERE 1=1';
    const params: any[] = [];
    let paramIndex = 1;

    if (type) {
      query += ` AND type = $${paramIndex}`;
      params.push(type);
      paramIndex++;
    }

    if (status) {
      query += ` AND status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (zone_id) {
      query += ` AND current_zone_id = $${paramIndex}`;
      params.push(zone_id);
      paramIndex++;
    }

    if (site_id) {
      query += ` AND site_id = $${paramIndex}`;
      params.push(site_id);
      paramIndex++;
    }

    query += ' ORDER BY created_at DESC';

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get assets error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create asset
router.post('/', async (req, res) => {
  try {
    const { assetId, name, type, manufacturer, model, serialNumber, status, siteId } = req.body;

    const result = await pool.query(
      `INSERT INTO assets (asset_id, name, type, manufacturer, model, serial_number, status, site_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [assetId, name, type, manufacturer, model, serialNumber, status || 'active', siteId]
    );

    res.status(201).json(result.rows[0]);
  } catch (error: any) {
    console.error('Create asset error:', error);
    if (error.code === '23505') {
      return res.status(400).json({ error: 'Asset ID or serial number already exists' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// SINGLE ASSET ROUTES
// =============================================

// Get single asset
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM assets WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Asset not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get asset error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update asset
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, status, currentZoneId, operatingHours, lastMaintenanceAt, nextMaintenanceAt } = req.body;

    const result = await pool.query(
      `UPDATE assets 
       SET name = COALESCE($1, name),
           status = COALESCE($2, status),
           current_zone_id = COALESCE($3, current_zone_id),
           operating_hours = COALESCE($4, operating_hours),
           last_maintenance_at = COALESCE($5, last_maintenance_at),
           next_maintenance_at = COALESCE($6, next_maintenance_at)
       WHERE id = $7
       RETURNING *`,
      [name, status, currentZoneId, operatingHours, lastMaintenanceAt, nextMaintenanceAt, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Asset not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update asset error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete asset
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM assets WHERE id = $1 RETURNING id', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Asset not found' });
    }

    res.json({ message: 'Asset deleted successfully' });
  } catch (error) {
    console.error('Delete asset error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// ASSET SUB-RESOURCES
// =============================================

// Get asset telemetry
router.get('/:id/telemetry', async (req, res) => {
  try {
    const { id } = req.params;
    const { limit = 100, offset = 0 } = req.query;

    const result = await pool.query(
      `SELECT * FROM asset_telemetry 
       WHERE asset_id = $1 
       ORDER BY timestamp DESC 
       LIMIT $2 OFFSET $3`,
      [id, limit, offset]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Get telemetry error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get latest telemetry
router.get('/:id/telemetry/latest', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      `SELECT * FROM asset_telemetry 
       WHERE asset_id = $1 
       ORDER BY timestamp DESC 
       LIMIT 1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'No telemetry data found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get latest telemetry error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get asset components
router.get('/:id/components', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      'SELECT * FROM asset_components WHERE asset_id = $1',
      [id]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Get components error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update component
router.put('/:assetId/components/:componentId', async (req, res) => {
  try {
    const { assetId, componentId } = req.params;
    const { healthScore, status, temperature, pressure, vibration } = req.body;

    const result = await pool.query(
      `UPDATE asset_components 
       SET health_score = COALESCE($1, health_score),
           status = COALESCE($2, status),
           temperature = COALESCE($3, temperature),
           pressure = COALESCE($4, pressure),
           vibration = COALESCE($5, vibration)
       WHERE asset_id = $6 AND component_id = $7
       RETURNING *`,
      [healthScore, status, temperature, pressure, vibration, assetId, componentId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Component not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update component error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get digital twin data
router.get('/:id/digital-twin', async (req, res) => {
  try {
    const { id } = req.params;

    // Get asset
    const assetResult = await pool.query(
      'SELECT * FROM assets WHERE id = $1 OR asset_id = $1',
      [id]
    );

    if (assetResult.rows.length === 0) {
      return res.status(404).json({ error: 'Asset not found' });
    }

    const asset = assetResult.rows[0];

    // Get components
    const componentsResult = await pool.query(
      'SELECT * FROM asset_components WHERE asset_id = $1 ORDER BY name',
      [asset.id]
    );

    // Get latest telemetry
    const telemetryResult = await pool.query(
      'SELECT * FROM asset_telemetry WHERE asset_id = $1 ORDER BY timestamp DESC LIMIT 10',
      [asset.id]
    );

    // Get sensor readings
    const sensorsResult = await pool.query(
      'SELECT DISTINCT ON (sensor_key) * FROM digital_twin_sensors WHERE asset_id = $1 ORDER BY sensor_key, timestamp DESC',
      [asset.id]
    );

    const components = componentsResult.rows.map((row: any) => ({
      id: row.component_id,
      name: row.name,
      healthScore: parseFloat(row.health_score),
      status: row.status,
      temperature: parseFloat(row.temperature || 0),
      pressure: parseFloat(row.pressure || 0),
      vibration: parseFloat(row.vibration || 0),
      wearLevel: parseFloat(row.wear_level || 0),
      operatingHours: parseFloat(row.operating_hours),
      nextMaintenanceHours: row.next_maintenance_hours || 0
    }));

    // If no components in DB, return defaults based on asset type
    const finalComponents = components.length > 0 ? components : getDefaultComponents(asset.type);

    const sensors = sensorsResult.rows.map((row: any) => ({
      key: row.sensor_key,
      label: row.label,
      value: row.value,
      unit: row.unit,
      color: row.color,
      cx: parseFloat(row.cx || 0),
      cy: parseFloat(row.cy || 0)
    }));

    const finalSensors = sensors.length > 0 ? sensors : getDefaultSensors(asset.type);

    const sensorData = telemetryResult.rows.map((row: any) => ({
      time: new Date(row.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      temp: parseFloat(row.engine_temp || 0),
      pressure: parseFloat(row.hydraulic_pressure || 0),
      vibration: parseFloat(row.vibration_level || 0),
      load: parseFloat(row.load_weight || 0),
      rpm: row.rpm || 0,
      fuelLevel: parseFloat(row.fuel_level || 0)
    }));

    // Generate predictive data
    const baseHealth = finalComponents.length > 0
      ? finalComponents.reduce((sum: number, c: any) => sum + c.healthScore, 0) / finalComponents.length
      : 90;

    const predictiveData = [
      { hour: 0, current: Math.round(baseHealth), predicted: Math.round(baseHealth) },
      { hour: 100, current: null, predicted: Math.round(baseHealth - 2) },
      { hour: 200, current: null, predicted: Math.round(baseHealth - 5) },
      { hour: 300, current: null, predicted: Math.round(baseHealth - 9) },
      { hour: 400, current: null, predicted: Math.round(baseHealth - 13) },
      { hour: 500, current: null, predicted: Math.round(baseHealth - 18) },
    ];

    res.json({
      asset: {
        id: asset.id,
        assetId: asset.asset_id,
        name: asset.name,
        type: asset.type,
        status: asset.status,
        operatingHours: parseFloat(asset.operating_hours),
        manufacturer: asset.manufacturer,
        model: asset.model
      },
      components: finalComponents,
      sensorData: sensorData.length > 0 ? sensorData : getDefaultSensorData(),
      sensors: finalSensors,
      predictiveData,
      alerts: [
        { id: 'A-001', severity: 'warning', component: 'Track System', message: 'Increased wear detected - maintenance recommended within 50 hours', time: '15 mins ago' },
        { id: 'A-002', severity: 'info', component: 'Hydraulic System', message: 'Oil temperature within normal range', time: '1 hour ago' },
      ]
    });
  } catch (error) {
    console.error('Get digital twin data error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

function getDefaultComponents(assetType: string) {
  return [
    { id: 'engine', name: 'Engine System', healthScore: 94, status: 'optimal', temperature: 78, pressure: 0, vibration: 2.8, wearLevel: 0, operatingHours: 1250, nextMaintenanceHours: 250 },
    { id: 'hydraulics', name: 'Hydraulic System', healthScore: 88, status: 'good', temperature: 65, pressure: 3200, vibration: 1.2, wearLevel: 0, operatingHours: 1250, nextMaintenanceHours: 150 },
    { id: 'transmission', name: 'Transmission', healthScore: 92, status: 'optimal', temperature: 72, pressure: 0, vibration: 1.5, wearLevel: 0, operatingHours: 1250, nextMaintenanceHours: 200 },
    { id: 'tracks', name: 'Track System', healthScore: 76, status: 'warning', temperature: 45, pressure: 0, vibration: 3.1, wearLevel: 68, operatingHours: 1250, nextMaintenanceHours: 50 },
  ];
}

function getDefaultSensors(assetType: string) {
  const sensorsByType: Record<string, any[]> = {
    excavator: [
      { key: 'engine', label: 'ENGINE', value: '2,100 RPM', color: '#10b981', cx: 230, cy: 280 },
      { key: 'hydraulic', label: 'HYDRAULIC', value: '3,200 PSI', color: '#3b82f6', cx: 335, cy: 330 },
      { key: 'track', label: 'TRACK WEAR', value: '68%', color: '#f59e0b', cx: 270, cy: 400 },
    ],
    haul_truck: [
      { key: 'engine', label: 'ENGINE', value: '1,800 RPM', color: '#10b981', cx: 157, cy: 280 },
      { key: 'payload', label: 'PAYLOAD', value: '220 tonnes', color: '#3b82f6', cx: 350, cy: 290 },
      { key: 'tire', label: 'TIRE PSI', value: '110 PSI', color: '#f59e0b', cx: 435, cy: 380 },
    ],
    drill: [
      { key: 'engine', label: 'ENGINE', value: '1,650 RPM', color: '#10b981', cx: 225, cy: 330 },
      { key: 'depth', label: 'DRILL DEPTH', value: '45.2m', color: '#3b82f6', cx: 417, cy: 200 },
      { key: 'torque', label: 'TORQUE', value: '85 kN·m', color: '#f59e0b', cx: 330, cy: 350 },
    ],
    dozer: [
      { key: 'engine', label: 'ENGINE', value: '1,950 RPM', color: '#10b981', cx: 247, cy: 260 },
      { key: 'fuel', label: 'FUEL LEVEL', value: '78%', color: '#3b82f6', cx: 380, cy: 270 },
      { key: 'blade', label: 'BLADE LOAD', value: '14.2 kN', color: '#f59e0b', cx: 130, cy: 295 },
    ],
  };
  return sensorsByType[assetType] || sensorsByType.excavator;
}

function getDefaultSensorData() {
  return [
    { time: '00:00', temp: 68, pressure: 145, vibration: 2.3, load: 85, rpm: 1800, fuelLevel: 82 },
    { time: '00:15', temp: 72, pressure: 148, vibration: 2.5, load: 88, rpm: 1950, fuelLevel: 80 },
    { time: '00:30', temp: 75, pressure: 151, vibration: 2.8, load: 92, rpm: 2100, fuelLevel: 78 },
    { time: '00:45', temp: 78, pressure: 155, vibration: 3.1, load: 89, rpm: 2050, fuelLevel: 76 },
    { time: '01:00', temp: 76, pressure: 152, vibration: 2.9, load: 87, rpm: 1900, fuelLevel: 74 },
    { time: '01:15', temp: 73, pressure: 149, vibration: 2.6, load: 85, rpm: 1850, fuelLevel: 72 },
  ];
}

// =============================================
// CHART DATA ENDPOINTS
// =============================================

// Asset activity timeline (24h)
router.get('/chart/activity', async (_req, res) => {
  try {
    const hours = ['00:00','04:00','08:00','12:00','16:00','20:00'];
    const data = hours.map((hour, i) => ({
      hour,
      active: Math.round(38 + Math.random() * 14 + (i > 1 && i < 5 ? 8 : 0)),
      idle: Math.round(6 + Math.random() * 12),
      maintenance: Math.round(2 + Math.random() * 2),
    }));
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Asset type distribution
router.get('/chart/type-distribution', async (_req, res) => {
  try {
    const result = await pool.query(`SELECT type, COUNT(*) as count FROM assets GROUP BY type ORDER BY count DESC`);
    const colors = ['#3b82f6','#10b981','#f59e0b','#8b5cf6','#ef4444','#06b6d4'];
    const data = result.rows.length > 0
      ? result.rows.map((r: any, i: number) => ({
          name: r.type.split('_').map((w: string) => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
          value: parseInt(r.count), color: colors[i % colors.length],
        }))
      : [
          { name: 'Excavators', value: 24, color: '#3b82f6' },
          { name: 'Haul Trucks', value: 45, color: '#10b981' },
          { name: 'Drills', value: 18, color: '#f59e0b' },
          { name: 'Dozers', value: 12, color: '#8b5cf6' },
          { name: 'Loaders', value: 15, color: '#ef4444' },
        ];
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;