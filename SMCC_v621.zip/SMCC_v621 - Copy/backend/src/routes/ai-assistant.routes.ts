import { Router } from 'express';
import { pool } from '../config/database';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();
router.use(authenticate);

// Query mining events with natural language filters
router.post('/query', async (req, res) => {
  try {
    const startTime = Date.now();
    const { filters, queryText, sessionId, inputMethod } = req.body;
    const {
      equipmentTypes, eventTypes, severities, statuses, locations,
      categories, timeRangeStart, timeRangeEnd
    } = filters || {};

    let query = 'SELECT * FROM mining_events WHERE 1=1';
    const params: any[] = [];
    let idx = 1;

    if (equipmentTypes?.length) {
      query += ` AND equipment_type = ANY($${idx}::text[])`;
      params.push(equipmentTypes);
      idx++;
    }
    if (eventTypes?.length) {
      query += ` AND event_type = ANY($${idx}::text[])`;
      params.push(eventTypes);
      idx++;
    }
    if (severities?.length) {
      query += ` AND severity = ANY($${idx}::text[])`;
      params.push(severities);
      idx++;
    }
    if (statuses?.length) {
      query += ` AND status = ANY($${idx}::text[])`;
      params.push(statuses);
      idx++;
    }
    if (locations?.length) {
      query += ` AND (location = ANY($${idx}::text[]) OR zone_name = ANY($${idx}::text[]))`;
      params.push(locations);
      idx++;
    }
    if (categories?.length) {
      query += ` AND category = ANY($${idx}::text[])`;
      params.push(categories);
      idx++;
    }
    if (timeRangeStart) {
      query += ` AND occurred_at >= $${idx}`;
      params.push(timeRangeStart);
      idx++;
    }
    if (timeRangeEnd) {
      query += ` AND occurred_at <= $${idx}`;
      params.push(timeRangeEnd);
      idx++;
    }

    query += ' ORDER BY occurred_at DESC LIMIT 500';

    const result = await pool.query(query, params);
    const responseTimeMs = Date.now() - startTime;

    // Generate summary statistics
    const events = result.rows;
    const severityCounts: Record<string, number> = {};
    const typeCounts: Record<string, number> = {};
    events.forEach((e: any) => {
      severityCounts[e.severity] = (severityCounts[e.severity] || 0) + 1;
      typeCounts[e.event_type] = (typeCounts[e.event_type] || 0) + 1;
    });

    const responseText = `Found ${events.length} matching events. ` +
      Object.entries(severityCounts).map(([k, v]) => `${v} ${k}`).join(', ') + '.';

    // Log conversation
    if (sessionId && queryText) {
      await pool.query(
        `INSERT INTO ai_conversation_logs (session_id, query_text, parsed_filters, result_count, response_text, response_time_ms, input_method)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [sessionId, queryText, JSON.stringify(filters), events.length, responseText, responseTimeMs, inputMethod || 'text']
      ).catch(() => {}); // non-blocking
    }

    res.json({
      events,
      summary: {
        totalResults: events.length,
        severityCounts,
        typeCounts,
        responseTimeMs,
      },
      responseText,
    });
  } catch (error) {
    console.error('AI query error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all mining events (paginated)
router.get('/events', async (req, res) => {
  try {
    const { limit = 100, offset = 0, site_id, category, severity } = req.query;
    let query = 'SELECT * FROM mining_events WHERE 1=1';
    const params: any[] = [];
    let idx = 1;

    if (site_id) { query += ` AND site_id = $${idx}`; params.push(site_id); idx++; }
    if (category) { query += ` AND category = $${idx}`; params.push(category); idx++; }
    if (severity) { query += ` AND severity = $${idx}`; params.push(severity); idx++; }

    query += ` ORDER BY occurred_at DESC LIMIT $${idx} OFFSET $${idx + 1}`;
    params.push(limit, offset);

    const result = await pool.query(query, params);
    const countResult = await pool.query('SELECT COUNT(*) FROM mining_events');

    res.json({
      events: result.rows,
      total: parseInt(countResult.rows[0].count),
    });
  } catch (error) {
    console.error('Get events error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get mining events statistics
router.get('/events/statistics', async (req, res) => {
  try {
    const [byCategory, bySeverity, byType, byMonth] = await Promise.all([
      pool.query('SELECT category, COUNT(*) as count FROM mining_events GROUP BY category ORDER BY count DESC'),
      pool.query('SELECT severity, COUNT(*) as count FROM mining_events GROUP BY severity ORDER BY count DESC'),
      pool.query('SELECT event_type, COUNT(*) as count FROM mining_events GROUP BY event_type ORDER BY count DESC LIMIT 10'),
      pool.query(`SELECT DATE_TRUNC('month', occurred_at) as month, COUNT(*) as count 
                  FROM mining_events GROUP BY month ORDER BY month DESC LIMIT 12`),
    ]);

    res.json({
      byCategory: byCategory.rows,
      bySeverity: bySeverity.rows,
      byType: byType.rows,
      byMonth: byMonth.rows,
    });
  } catch (error) {
    console.error('Get event statistics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get conversation history
router.get('/conversations', async (req, res) => {
  try {
    const { session_id, limit = 50 } = req.query;
    let query = 'SELECT * FROM ai_conversation_logs';
    const params: any[] = [];

    if (session_id) {
      query += ' WHERE session_id = $1';
      params.push(session_id);
    }

    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1}`;
    params.push(limit);

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get conversations error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get suggested prompts
router.get('/prompts', async (_req, res) => {
  res.json([
    { text: 'Show all excavator breakdowns in the last 3 months', category: 'equipment' },
    { text: 'What safety incidents happened this week?', category: 'safety' },
    { text: 'List all critical alerts from Zone A', category: 'alerts' },
    { text: 'Show production milestones for the past year', category: 'production' },
    { text: 'Any water quality alerts recently?', category: 'water' },
    { text: 'Show network outages in the last 30 days', category: 'network' },
    { text: 'Which equipment has the most maintenance events?', category: 'equipment' },
    { text: 'Show all high-severity events from last month', category: 'general' },
    { text: 'List blasting events for this quarter', category: 'production' },
    { text: 'Are there any expired certifications?', category: 'training' },
    { text: 'Show geofence breaches from the processing zone', category: 'security' },
    { text: 'What are the most common event types?', category: 'general' },
  ]);
});

export default router;
