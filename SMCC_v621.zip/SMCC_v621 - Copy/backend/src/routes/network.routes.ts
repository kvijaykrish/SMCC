import { Router } from 'express';
import { pool } from '../config/database';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();
router.use(authenticate);

// Get all towers
router.get('/towers', async (req, res) => {
  try {
    const { status } = req.query;

    let query = 'SELECT * FROM network_towers WHERE 1=1';
    const params: any[] = [];

    if (status) {
      query += ' AND status = $1';
      params.push(status);
    }

    query += ' ORDER BY created_at DESC';

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get towers error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single tower
router.get('/towers/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM network_towers WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Tower not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get tower error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create tower
router.post('/towers', async (req, res) => {
  try {
    const {
      towerId,
      name,
      latitude,
      longitude,
      frequencyBand,
      maxBandwidth,
      coverageRadius
    } = req.body;

    const result = await pool.query(
      `INSERT INTO network_towers 
       (tower_id, name, latitude, longitude, frequency_band, max_bandwidth, coverage_radius)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [towerId, name, latitude, longitude, frequencyBand, maxBandwidth, coverageRadius]
    );

    res.status(201).json(result.rows[0]);
  } catch (error: any) {
    console.error('Create tower error:', error);
    if (error.code === '23505') {
      return res.status(400).json({ error: 'Tower ID already exists' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update tower
router.put('/towers/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, currentLoad, connectedDevices, uptimePercentage } = req.body;

    const result = await pool.query(
      `UPDATE network_towers 
       SET status = COALESCE($1, status),
           current_load = COALESCE($2, current_load),
           connected_devices = COALESCE($3, connected_devices),
           uptime_percentage = COALESCE($4, uptime_percentage)
       WHERE id = $5
       RETURNING *`,
      [status, currentLoad, connectedDevices, uptimePercentage, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Tower not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update tower error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get all devices
router.get('/devices', async (req, res) => {
  try {
    const { type, status, tower_id } = req.query;

    let query = 'SELECT * FROM network_devices WHERE 1=1';
    const params: any[] = [];
    let paramIndex = 1;

    if (type) {
      query += ` AND device_type = $${paramIndex}`;
      params.push(type);
      paramIndex++;
    }

    if (status) {
      query += ` AND status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (tower_id) {
      query += ` AND tower_id = $${paramIndex}`;
      params.push(tower_id);
      paramIndex++;
    }

    query += ' ORDER BY created_at DESC';

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get devices error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create device
router.post('/devices', async (req, res) => {
  try {
    const { deviceId, deviceName, deviceType, assetId, towerId, ipAddress, macAddress, imei, simCardId, status } = req.body;
    const result = await pool.query(
      `INSERT INTO network_devices (device_id, device_name, device_type, asset_id, tower_id, ip_address, mac_address, imei, sim_card_id, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [deviceId, deviceName, deviceType, assetId || null, towerId || null, ipAddress, macAddress, imei, simCardId, status || 'online']
    );
    res.status(201).json(result.rows[0]);
  } catch (error: any) {
    console.error('Create device error:', error);
    if (error.code === '23505') return res.status(400).json({ error: 'Device ID already exists' });
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete device
router.delete('/devices/:id', async (req, res) => {
  try {
    const result = await pool.query('DELETE FROM network_devices WHERE id = $1 RETURNING id', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Device not found' });
    res.json({ message: 'Device deleted successfully' });
  } catch (error) {
    console.error('Delete device error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get single device
router.get('/devices/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM network_devices WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Device not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get device error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get devices by tower
router.get('/towers/:towerId/devices', async (req, res) => {
  try {
    const { towerId } = req.params;

    const result = await pool.query(
      'SELECT * FROM network_devices WHERE tower_id = $1',
      [towerId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Get tower devices error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get devices by asset
router.get('/devices/by-asset/:assetId', async (req, res) => {
  try {
    const { assetId } = req.params;

    const result = await pool.query(
      'SELECT * FROM network_devices WHERE asset_id = $1',
      [assetId]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Get asset devices error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update device
router.put('/devices/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, signalStrength, latency, bandwidthUp, bandwidthDown, packetLoss } = req.body;

    const result = await pool.query(
      `UPDATE network_devices 
       SET status = COALESCE($1, status),
           signal_strength = COALESCE($2, signal_strength),
           latency = COALESCE($3, latency),
           bandwidth_up = COALESCE($4, bandwidth_up),
           bandwidth_down = COALESCE($5, bandwidth_down),
           packet_loss = COALESCE($6, packet_loss),
           last_seen_at = NOW()
       WHERE id = $7
       RETURNING *`,
      [status, signalStrength, latency, bandwidthUp, bandwidthDown, packetLoss, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Device not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update device error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get network statistics
router.get('/statistics', async (req, res) => {
  try {
    const [towersResult, devicesResult] = await Promise.all([
      pool.query(`
        SELECT 
          COUNT(*) as total_towers,
          COUNT(CASE WHEN status = 'active' THEN 1 END) as active_towers,
          AVG(uptime_percentage) as avg_uptime,
          AVG(current_load) as avg_load,
          SUM(connected_devices) as total_devices
        FROM network_towers
      `),
      pool.query(`
        SELECT 
          COUNT(*) as total_devices,
          COUNT(CASE WHEN status = 'online' THEN 1 END) as online_devices,
          AVG(signal_strength) as avg_signal_strength,
          AVG(latency) as avg_latency
        FROM network_devices
      `)
    ]);

    res.json({
      towers: towersResult.rows[0],
      devices: devicesResult.rows[0],
      uptimePercentage: parseFloat(towersResult.rows[0].avg_uptime || 0)
    });
  } catch (error) {
    console.error('Get network statistics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get coverage map data
router.get('/coverage-map', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT id, tower_id, name, latitude, longitude, coverage_radius, 
             frequency_band, current_load, connected_devices, status
      FROM network_towers
      ORDER BY name
    `);

    res.json(result.rows.map((row: any) => ({
      towerId: row.tower_id,
      name: row.name,
      latitude: parseFloat(row.latitude),
      longitude: parseFloat(row.longitude),
      coverageRadius: row.coverage_radius,
      frequencyBand: row.frequency_band,
      currentLoad: parseFloat(row.current_load || 0),
      connectedDevices: row.connected_devices,
      status: row.status
    })));
  } catch (error) {
    console.error('Get coverage map error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete tower
router.delete('/towers/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM network_towers WHERE id = $1 RETURNING id', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Tower not found' });
    }

    res.json({ message: 'Tower deleted successfully' });
  } catch (error) {
    console.error('Delete tower error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get tower metrics history
router.get('/towers/:towerId/metrics', async (req, res) => {
  try {
    const { towerId } = req.params;
    const { hours = 24 } = req.query;

    // Return simulated metrics history
    const metrics = [];
    for (let i = 0; i < parseInt(hours as string); i++) {
      metrics.push({
        towerId,
        timestamp: new Date(Date.now() - i * 3600000),
        throughputMbps: 500 + Math.random() * 500,
        latencyMs: 10 + Math.random() * 20,
        packetLoss: Math.random() * 2,
        connectedDevices: Math.floor(40 + Math.random() * 60),
        bandwidthUtilization: 30 + Math.random() * 40,
        errorRate: Math.random() * 0.5
      });
    }

    res.json(metrics);
  } catch (error) {
    console.error('Get tower metrics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Ping device
router.post('/devices/:id/ping', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM network_devices WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Device not found' });
    }

    // Simulate ping response
    res.json({
      deviceId: id,
      status: 'success',
      latencyMs: Math.floor(5 + Math.random() * 30),
      timestamp: new Date()
    });
  } catch (error) {
    console.error('Ping device error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Restart device
router.post('/devices/:id/restart', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM network_devices WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Device not found' });
    }

    // Simulate restart
    res.json({
      deviceId: id,
      status: 'restarting',
      estimatedTimeSeconds: 30,
      timestamp: new Date()
    });
  } catch (error) {
    console.error('Restart device error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// CHART DATA ENDPOINTS (for Angular frontend)
// =============================================

// Network summary for dashboard cards
router.get('/summary', async (_req, res) => {
  try {
    const [towers, devices] = await Promise.all([
      pool.query(`SELECT COUNT(*) as total, AVG(uptime_percentage) as avg_uptime, SUM(connected_devices) as total_devices,
        AVG(current_load) as avg_load FROM network_towers`),
      pool.query(`SELECT COUNT(*) as total, COUNT(CASE WHEN status='online' THEN 1 END) as online,
        AVG(latency) as avg_latency, AVG(signal_strength) as avg_signal FROM network_devices`),
    ]);
    res.json({
      uptime: parseFloat(towers.rows[0].avg_uptime || '99.8'),
      totalDevices: parseInt(devices.rows[0].total || '847'),
      onlineDevices: parseInt(devices.rows[0].online || '780'),
      avgBandwidth: 890,
      avgLatency: parseFloat(devices.rows[0].avg_latency || '10.8'),
      towerCount: parseInt(towers.rows[0].total || '6'),
      avgLoad: parseFloat(towers.rows[0].avg_load || '45'),
    });
  } catch (error) {
    console.error('Network summary error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Network performance chart data (24h)
router.get('/chart/performance', async (_req, res) => {
  try {
    const hours = ['00:00','04:00','08:00','12:00','16:00','20:00'];
    const data = hours.map((time, i) => ({
      time,
      bandwidth: Math.round(720 + Math.random() * 230 + Math.sin(i) * 50),
      latency: Math.round(9 + Math.random() * 6),
      devices: Math.round(580 + Math.random() * 170),
    }));
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Bandwidth usage by category
router.get('/chart/bandwidth-usage', async (_req, res) => {
  try {
    res.json([
      { category: 'Asset Telemetry', usage: 320, color: '#3b82f6' },
      { category: 'Video Surveillance', usage: 280, color: '#10b981' },
      { category: 'Digital Twin Sync', usage: 180, color: '#f59e0b' },
      { category: 'Safety Systems', usage: 120, color: '#ef4444' },
      { category: 'Management', usage: 80, color: '#8b5cf6' },
    ]);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;