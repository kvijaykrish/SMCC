import { Router } from 'express';
import { pool } from '../config/database';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();
router.use(authenticate);

// Get all reports
router.get('/', async (req, res) => {
  try {
    const { report_type, site_id, limit = 50, offset = 0 } = req.query;
    let query = 'SELECT * FROM historical_reports WHERE 1=1';
    const params: any[] = [];
    let idx = 1;

    if (report_type) { query += ` AND report_type = $${idx}`; params.push(report_type); idx++; }
    if (site_id) { query += ` AND site_id = $${idx}`; params.push(site_id); idx++; }

    query += ` ORDER BY created_at DESC LIMIT $${idx} OFFSET $${idx + 1}`;
    params.push(limit, offset);

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get reports error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get report by ID
router.get('/:id', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM historical_reports WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Report not found' });
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get report error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Generate a new report
router.post('/generate', async (req, res) => {
  try {
    const { reportType, timeRangeStart, timeRangeEnd, timeRangePreset, siteId } = req.body;
    const reportId = `RPT-${Date.now()}`;

    // Generate mock KPI summary based on report type
    const kpiSummary = generateKpiSummary(reportType);
    const chartData = generateChartData(reportType, timeRangeStart, timeRangeEnd);

    const result = await pool.query(
      `INSERT INTO historical_reports 
       (report_id, report_type, title, time_range_start, time_range_end, time_range_preset, 
        status, data, kpi_summary, site_id)
       VALUES ($1, $2, $3, $4, $5, $6, 'completed', $7, $8, $9)
       RETURNING *`,
      [
        reportId,
        reportType,
        `${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report`,
        timeRangeStart,
        timeRangeEnd,
        timeRangePreset || 'custom',
        JSON.stringify(chartData),
        JSON.stringify(kpiSummary),
        siteId
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Generate report error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get report types summary / statistics
router.get('/statistics/summary', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT report_type, COUNT(*) as count, MAX(created_at) as last_generated
      FROM historical_reports
      GROUP BY report_type
      ORDER BY report_type
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Get report stats error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Delete a report
router.delete('/:id', async (req, res) => {
  try {
    const result = await pool.query('DELETE FROM historical_reports WHERE id = $1 RETURNING id', [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Report not found' });
    res.json({ message: 'Report deleted successfully' });
  } catch (error) {
    console.error('Delete report error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ─── Helper functions ───

function generateKpiSummary(reportType: string) {
  const summaries: Record<string, any> = {
    production: [
      { label: 'Total Output', value: '156,240 T', change: 8.2, trend: 'up' },
      { label: 'Avg Daily', value: '5,208 T', change: 3.1, trend: 'up' },
      { label: 'Efficiency', value: '92.4%', change: 1.7, trend: 'up' },
      { label: 'Downtime', value: '4.2 hrs', change: -12.5, trend: 'down' },
    ],
    safety: [
      { label: 'Total Incidents', value: '3', change: -40, trend: 'down' },
      { label: 'Near Misses', value: '12', change: -15, trend: 'down' },
      { label: 'Days Without Injury', value: '87', change: 100, trend: 'up' },
      { label: 'Compliance Score', value: '97.8%', change: 2.1, trend: 'up' },
    ],
    equipment: [
      { label: 'Fleet Health', value: '91.2%', change: 1.5, trend: 'up' },
      { label: 'MTBF', value: '342 hrs', change: 8.4, trend: 'up' },
      { label: 'Maintenance Events', value: '28', change: -5.2, trend: 'down' },
      { label: 'Utilization', value: '84.6%', change: 3.8, trend: 'up' },
    ],
    water: [
      { label: 'Total Usage', value: '285K m³', change: -2.3, trend: 'down' },
      { label: 'Reclamation', value: '45.2%', change: 4.1, trend: 'up' },
      { label: 'Quality Score', value: '97.8%', change: 0.5, trend: 'up' },
      { label: 'Pipeline Health', value: '98.1%', change: 1.2, trend: 'up' },
    ],
    energy: [
      { label: 'Total Consumption', value: '1.2 GWh', change: -3.4, trend: 'down' },
      { label: 'Cost per Tonne', value: '$2.14', change: -8.1, trend: 'down' },
      { label: 'Renewable %', value: '28.5%', change: 12.3, trend: 'up' },
      { label: 'Peak Demand', value: '45 MW', change: 2.1, trend: 'up' },
    ],
    security: [
      { label: 'Security Events', value: '156', change: -10.2, trend: 'down' },
      { label: 'Camera Uptime', value: '99.7%', change: 0.3, trend: 'up' },
      { label: 'Access Violations', value: '2', change: -50, trend: 'down' },
      { label: 'Response Time', value: '2.1 min', change: -15.4, trend: 'down' },
    ],
  };
  return summaries[reportType] || summaries.production;
}

function generateChartData(reportType: string, start: string, end: string) {
  const days = 30;
  const data = [];
  for (let i = 0; i < days; i++) {
    const date = new Date();
    date.setDate(date.getDate() - (days - i));
    data.push({
      date: date.toISOString().split('T')[0],
      value: Math.round(3000 + Math.random() * 4000),
      secondary: Math.round(80 + Math.random() * 15),
    });
  }
  return data;
}

export default router;
