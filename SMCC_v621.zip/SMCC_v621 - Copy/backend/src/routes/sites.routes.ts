import { Router } from 'express';
import { pool } from '../config/database';
import { authenticate } from '../middleware/auth.middleware';

const router = Router();
router.use(authenticate);

// =============================================
// STATIC ROUTES (must come before /:id)
// =============================================

// Get sites summary statistics
router.get('/statistics/summary', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        COUNT(*) as total_sites,
        COUNT(CASE WHEN status = 'operational' THEN 1 END) as operational_sites,
        COUNT(CASE WHEN status = 'maintenance' THEN 1 END) as maintenance_sites,
        SUM(annual_capacity_tonnes) as total_annual_capacity,
        SUM(workforce_count) as total_workforce,
        COUNT(DISTINCT country) as countries_count
      FROM sites
      WHERE is_active = true
    `);

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get sites statistics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// COLLECTION ROUTES
// =============================================

// Get all sites
router.get('/', async (req, res) => {
  try {
    const { status, country, site_type } = req.query;

    let query = `
      SELECT 
        s.*,
        sm.total_assets,
        sm.active_assets,
        sm.assets_in_maintenance,
        sm.production_tonnes_today,
        sm.production_tonnes_mtd,
        sm.network_uptime_percentage,
        sm.active_alerts,
        sm.critical_alerts,
        sm.safety_incidents_today,
        sm.safety_incidents_mtd,
        sm.workforce_present,
        sm.operational_efficiency,
        sm.environmental_compliance_score,
        sm.timestamp as metrics_updated_at
      FROM sites s
      LEFT JOIN LATERAL (
        SELECT * FROM site_metrics 
        WHERE site_id = s.id 
        ORDER BY timestamp DESC 
        LIMIT 1
      ) sm ON true
      WHERE s.is_active = true
    `;
    
    const params: any[] = [];
    let paramIndex = 1;

    if (status) {
      query += ` AND s.status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (country) {
      query += ` AND s.country = $${paramIndex}`;
      params.push(country);
      paramIndex++;
    }

    if (site_type) {
      query += ` AND s.site_type = $${paramIndex}`;
      params.push(site_type);
      paramIndex++;
    }

    query += ' ORDER BY s.name';

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('Get sites error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Create site
router.post('/', async (req, res) => {
  try {
    const {
      siteId, name, location, country, region, siteType,
      latitude, longitude, primaryCommodity, annualCapacityTonnes,
      workforceCount, contactEmail, contactPhone, imageUrl, description
    } = req.body;

    const result = await pool.query(
      `INSERT INTO sites (
        site_id, name, location, country, region, site_type,
        latitude, longitude, primary_commodity, annual_capacity_tonnes,
        workforce_count, contact_email, contact_phone, image_url, description
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
      RETURNING *`,
      [
        siteId, name, location, country, region, siteType,
        latitude, longitude, primaryCommodity, annualCapacityTonnes,
        workforceCount, contactEmail, contactPhone, imageUrl, description
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error: any) {
    console.error('Create site error:', error);
    if (error.code === '23505') {
      return res.status(400).json({ error: 'Site ID already exists' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// =============================================
// SINGLE SITE ROUTES
// =============================================

// Get single site with detailed metrics
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const siteResult = await pool.query(
      `SELECT 
        s.*,
        u.full_name as site_manager_name,
        u.email as site_manager_email,
        u.phone as site_manager_phone
      FROM sites s
      LEFT JOIN users u ON s.site_manager_id = u.id
      WHERE s.id = $1`,
      [id]
    );

    if (siteResult.rows.length === 0) {
      return res.status(404).json({ error: 'Site not found' });
    }

    // Get latest metrics
    const metricsResult = await pool.query(
      `SELECT * FROM site_metrics 
       WHERE site_id = $1 
       ORDER BY timestamp DESC 
       LIMIT 1`,
      [id]
    );

    // Get asset counts by type
    const assetTypesResult = await pool.query(
      `SELECT type, COUNT(*) as count 
       FROM assets 
       WHERE site_id = $1 
       GROUP BY type`,
      [id]
    );

    // Get zone count
    const zonesResult = await pool.query(
      'SELECT COUNT(*) as count FROM zones WHERE site_id = $1',
      [id]
    );

    // Get network tower count
    const towersResult = await pool.query(
      'SELECT COUNT(*) as count FROM network_towers WHERE site_id = $1',
      [id]
    );

    const site = siteResult.rows[0];
    
    res.json({
      ...site,
      metrics: metricsResult.rows[0] || null,
      assetsByType: assetTypesResult.rows,
      totalZones: parseInt(zonesResult.rows[0].count),
      totalNetworkTowers: parseInt(towersResult.rows[0].count)
    });
  } catch (error) {
    console.error('Get site error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update site
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, status, siteManagerId, contactEmail, contactPhone, imageUrl, description } = req.body;

    const result = await pool.query(
      `UPDATE sites 
       SET name = COALESCE($1, name),
           status = COALESCE($2, status),
           site_manager_id = COALESCE($3, site_manager_id),
           contact_email = COALESCE($4, contact_email),
           contact_phone = COALESCE($5, contact_phone),
           image_url = COALESCE($6, image_url),
           description = COALESCE($7, description)
       WHERE id = $8
       RETURNING *`,
      [name, status, siteManagerId, contactEmail, contactPhone, imageUrl, description, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Site not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Update site error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get site metrics history
router.get('/:id/metrics', async (req, res) => {
  try {
    const { id } = req.params;
    const { hours = 24 } = req.query;

    const result = await pool.query(
      `SELECT * FROM site_metrics 
       WHERE site_id = $1 
       AND timestamp > NOW() - INTERVAL '${hours} hours'
       ORDER BY timestamp DESC`,
      [id]
    );

    res.json(result.rows);
  } catch (error) {
    console.error('Get site metrics error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
