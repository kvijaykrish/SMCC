import express, { Application } from 'express';
import http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import dotenv from 'dotenv';
import rateLimit from 'express-rate-limit';
import { testConnection, closePool } from './config/database';
import { WebSocketServer } from './websocket';

// Import routes
import authRoutes from './routes/auth.routes';
import assetsRoutes from './routes/assets.routes';
import networkRoutes from './routes/network.routes';
import sitesRoutes from './routes/sites.routes';
import geospatialRoutes from './routes/geospatial.routes';
import securityRoutes from './routes/security.routes';
import waterRoutes from './routes/water.routes';
import safetyRoutes from './routes/safety.routes';
import alertsRoutes from './routes/alerts.routes';
import reportsRoutes from './routes/reports.routes';
import aiAssistantRoutes from './routes/ai-assistant.routes';
import dashboardRoutes from './routes/dashboard.routes';

// Load environment variables
dotenv.config();

const app: Application = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || 'localhost';

// Create HTTP server
const httpServer = http.createServer(app);

// Initialize WebSocket
const wsServer = new WebSocketServer(httpServer);

// Middleware
app.use(helmet()); // Security headers
app.use(compression()); // Gzip compression
app.use(cors({
  origin: process.env.CORS_ORIGIN?.split(',').map(s => s.trim()) || ['http://localhost:4200', 'http://localhost:5173'],
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined')); // Logging

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'), // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100')
});
app.use('/api/', limiter);

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/assets', assetsRoutes);
app.use('/api/network', networkRoutes);
app.use('/api/sites', sitesRoutes);
app.use('/api/geospatial', geospatialRoutes);
app.use('/api/security', securityRoutes);
app.use('/api/water', waterRoutes);
app.use('/api/safety', safetyRoutes);
app.use('/api/alerts', alertsRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/ai-assistant', aiAssistantRoutes);
app.use('/api/dashboard', dashboardRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Error handler
app.use((error: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Error:', error);
  res.status(error.status || 500).json({
    error: error.message || 'Internal server error'
  });
});

// Start server
async function startServer() {
  try {
    // Test database connection
    await testConnection();

    // Start HTTP server
    httpServer.listen(PORT, () => {
      console.log('===========================================');
      console.log('🚀 SDS Mining Command Center Backend');
      console.log('===========================================');
      console.log(`📡 HTTP Server: http://${HOST}:${PORT}`);
      console.log(`🔌 WebSocket Server: ws://${HOST}:${PORT}`);
      console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`🗄️  Database: Connected`);
      console.log('===========================================');
    });
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('🛑 SIGTERM signal received: closing HTTP server');
  httpServer.close(async () => {
    console.log('✅ HTTP server closed');
    await closePool();
    process.exit(0);
  });
});

process.on('SIGINT', async () => {
  console.log('\n🛑 SIGINT signal received: closing HTTP server');
  httpServer.close(async () => {
    console.log('✅ HTTP server closed');
    await closePool();
    process.exit(0);
  });
});

// Unhandled promise rejection
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

// Start the server
startServer();

export { app, httpServer, wsServer };