import { Server as HTTPServer } from 'http';
import { Server as SocketIOServer, Socket } from 'socket.io';
import { pool } from '../config/database';

export class WebSocketServer {
  private io: SocketIOServer;
  private simulationIntervals: NodeJS.Timeout[] = [];

  constructor(httpServer: HTTPServer) {
    this.io = new SocketIOServer(httpServer, {
      cors: {
        origin: process.env.CORS_ORIGIN?.split(',').map(s => s.trim()) || ['http://localhost:4200', 'http://localhost:5173'],
        methods: ['GET', 'POST'],
        credentials: true
      },
      transports: ['websocket', 'polling']
    });

    this.setupEventHandlers();
    this.startSimulations();
  }

  private setupEventHandlers(): void {
    this.io.on('connection', (socket: Socket) => {
      console.log(`✅ Client connected: ${socket.id}`);

      // Asset telemetry subscription
      socket.on('subscribe:asset:telemetry', (data: { assetId: string }) => {
        socket.join(`asset:${data.assetId}`);
      });

      socket.on('unsubscribe:asset:telemetry', (data: { assetId: string }) => {
        socket.leave(`asset:${data.assetId}`);
      });

      // Network metrics subscription
      socket.on('subscribe:network:metrics', (data: { towerId?: string }) => {
        const room = data.towerId ? `network:${data.towerId}` : 'network:all';
        socket.join(room);
      });

      // Alerts subscription
      socket.on('subscribe:alerts', () => {
        socket.join('alerts');
      });

      // Security events subscription
      socket.on('subscribe:security:events', () => {
        socket.join('security:events');
      });

      // Water metrics subscription
      socket.on('subscribe:water:metrics', () => {
        socket.join('water:metrics');
      });

      // Water flow network subscription
      socket.on('subscribe:water:flow', () => {
        socket.join('water:flow');
      });

      // Geospatial subscription
      socket.on('subscribe:geospatial', () => {
        socket.join('geospatial');
      });

      // Digital twin subscription
      socket.on('subscribe:digital-twin', (data: { assetId: string }) => {
        socket.join(`digital-twin:${data.assetId}`);
      });

      socket.on('unsubscribe:digital-twin', (data: { assetId: string }) => {
        socket.leave(`digital-twin:${data.assetId}`);
      });

      // Dashboard subscription
      socket.on('subscribe:dashboard', () => {
        socket.join('dashboard');
      });

      // Safety subscription
      socket.on('subscribe:safety', () => {
        socket.join('safety');
      });

      // Reports subscription
      socket.on('subscribe:reports', () => {
        socket.join('reports');
      });

      // AI assistant events subscription
      socket.on('subscribe:ai-events', () => {
        socket.join('ai-events');
      });

      socket.on('disconnect', () => {
        console.log(`❌ Client disconnected: ${socket.id}`);
      });
    });
  }

  // Simulate real-time data - all simulations are resilient to empty tables
  private startSimulations(): void {

    // ── Asset Telemetry: every 3 seconds ──
    this.simulationIntervals.push(setInterval(async () => {
      try {
        let assets: any[] = [];
        try {
          const result = await pool.query('SELECT id, asset_id, type FROM assets WHERE status = $1 LIMIT 5', ['active']);
          assets = result.rows;
        } catch { /* table may not exist yet */ }

        // Generate simulated data even if no assets in DB
        if (assets.length === 0) {
          assets = [
            { id: 'sim-1', asset_id: 'EXC-001', type: 'excavator' },
            { id: 'sim-2', asset_id: 'HTK-001', type: 'haul_truck' },
            { id: 'sim-3', asset_id: 'DRL-001', type: 'drill' },
          ];
        }

        for (const asset of assets) {
          const telemetry = {
            assetId: asset.id,
            assetIdLabel: asset.asset_id,
            assetType: asset.type,
            timestamp: new Date(),
            latitude: -22.31 + (Math.random() - 0.5) * 0.04,
            longitude: 118.42 + (Math.random() - 0.5) * 0.04,
            speed: Math.round(Math.random() * 45 * 10) / 10,
            engineTemp: Math.round((175 + Math.random() * 45) * 10) / 10,
            hydraulicPressure: Math.round((2500 + Math.random() * 800) * 10) / 10,
            fuelLevel: Math.round((40 + Math.random() * 55) * 10) / 10,
            batteryVoltage: Math.round((12 + Math.random() * 2) * 100) / 100,
            rpm: Math.round(1500 + Math.random() * 600),
            vibration: Math.round((1.5 + Math.random() * 3) * 100) / 100,
            loadWeight: Math.round(Math.random() * 220),
            isOperating: Math.random() > 0.15,
            heading: Math.round(Math.random() * 360),
          };

          // Try to persist to DB (non-blocking)
          if (asset.id && !asset.id.startsWith('sim-')) {
            pool.query(
              `INSERT INTO asset_telemetry 
              (asset_id, timestamp, latitude, longitude, speed, engine_temp, hydraulic_pressure, 
               fuel_level, battery_voltage, rpm, vibration_level, load_weight, is_operating)
              VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
              [asset.id, telemetry.timestamp, telemetry.latitude, telemetry.longitude,
               telemetry.speed, telemetry.engineTemp, telemetry.hydraulicPressure,
               telemetry.fuelLevel, telemetry.batteryVoltage, telemetry.rpm,
               telemetry.vibration, telemetry.loadWeight, telemetry.isOperating]
            ).catch(() => {}); // Silent fail for DB write
          }

          // Always emit to subscribers
          this.io.to(`asset:${asset.id}`).emit(`asset:telemetry:${asset.id}`, telemetry);
          this.io.to('geospatial').emit('geospatial:update', {
            assetId: asset.id,
            assetIdLabel: asset.asset_id,
            type: asset.type,
            latitude: telemetry.latitude,
            longitude: telemetry.longitude,
            heading: telemetry.heading,
            speed: telemetry.speed,
            isOperating: telemetry.isOperating,
          });
        }
      } catch (error) {
        // Don't crash - just log
        console.error('Telemetry simulation error:', (error as Error).message);
      }
    }, 3000));

    // ── Network metrics: every 5 seconds ──
    this.simulationIntervals.push(setInterval(async () => {
      try {
        let towers: any[] = [];
        try {
          const result = await pool.query('SELECT id, tower_id, name FROM network_towers LIMIT 6');
          towers = result.rows;
        } catch { /* table may not exist */ }

        if (towers.length === 0) {
          towers = [
            { id: 'sim-t1', tower_id: 'TOWER-01', name: 'North Sector Alpha' },
            { id: 'sim-t2', tower_id: 'TOWER-02', name: 'South Sector Beta' },
            { id: 'sim-t3', tower_id: 'TOWER-03', name: 'East Sector Gamma' },
          ];
        }

        for (const tower of towers) {
          const metrics = {
            towerId: tower.id,
            towerIdLabel: tower.tower_id,
            towerName: tower.name,
            timestamp: new Date(),
            throughputMbps: Math.round((500 + Math.random() * 500) * 10) / 10,
            latencyMs: Math.round((8 + Math.random() * 15) * 10) / 10,
            packetLoss: Math.round(Math.random() * 2 * 100) / 100,
            connectedDevices: Math.floor(80 + Math.random() * 80),
            bandwidthUtilization: Math.round((30 + Math.random() * 40) * 10) / 10,
            signalStrength: Math.round((85 + Math.random() * 14) * 10) / 10,
            errorRate: Math.round(Math.random() * 0.5 * 100) / 100,
          };

          if (tower.id && !tower.id.startsWith('sim-')) {
            pool.query(
              `UPDATE network_towers SET current_load = $1, connected_devices = $2 WHERE id = $3`,
              [metrics.bandwidthUtilization, metrics.connectedDevices, tower.id]
            ).catch(() => {});
          }

          this.io.to(`network:${tower.id}`).emit(`network:metrics:${tower.id}`, metrics);
          this.io.to('network:all').emit('network:metrics', metrics);
        }
      } catch (error) {
        console.error('Network simulation error:', (error as Error).message);
      }
    }, 5000));

    // ── Water flow + metrics: every 4 seconds ──
    this.simulationIntervals.push(setInterval(async () => {
      try {
        const flowData = {
          timestamp: new Date(),
          nodes: [
            { key: 'reservoir', levelPercentage: Math.round((80 + Math.random() * 10) * 10) / 10 },
            { key: 'pumpStation1', flowRate: Math.round(1200 + Math.random() * 100) },
            { key: 'treatment', efficiency: Math.round((96 + Math.random() * 3) * 10) / 10 },
            { key: 'mainDist', throughput: Math.round(1050 + Math.random() * 100) },
            { key: 'reclaim', flowRate: Math.round(700 + Math.random() * 120) },
          ],
          connections: [
            { from: 'reservoir', to: 'pumpStation1', flowRate: Math.round(1200 + Math.random() * 100) },
            { from: 'treatment', to: 'mainDist', flowRate: Math.round(1050 + Math.random() * 100) },
            { from: 'reclaim', to: 'pumpStation2', flowRate: Math.round(700 + Math.random() * 120) },
          ]
        };

        this.io.to('water:flow').emit('water:flow:update', flowData);
        this.io.to('water:metrics').emit('water:metrics:update', {
          timestamp: new Date(),
          totalUsageToday: Math.round(9500 + Math.random() * 1000),
          qualityScore: Math.round((96 + Math.random() * 3) * 10) / 10,
          systemPressure: Math.round((42 + Math.random() * 6) * 10) / 10,
          activePipelines: 5,
          ph: Math.round((7.0 + Math.random() * 0.4) * 100) / 100,
          turbidity: Math.round((1.5 + Math.random() * 1.0) * 100) / 100,
        });
      } catch (error) {
        console.error('Water simulation error:', (error as Error).message);
      }
    }, 4000));

    // ── Digital twin sensor updates: every 3 seconds ──
    this.simulationIntervals.push(setInterval(async () => {
      try {
        let assets: any[] = [];
        try {
          const result = await pool.query('SELECT id, asset_id, type FROM assets WHERE status = $1 LIMIT 4', ['active']);
          assets = result.rows;
        } catch { /* table may not exist */ }

        if (assets.length === 0) {
          assets = [
            { id: 'sim-dt1', asset_id: 'EXC-001', type: 'excavator' },
            { id: 'sim-dt2', asset_id: 'HTK-001', type: 'haul_truck' },
          ];
        }

        for (const asset of assets) {
          const sensorUpdate = {
            assetId: asset.id,
            assetIdLabel: asset.asset_id,
            assetType: asset.type,
            timestamp: new Date(),
            sensors: {
              engineRpm: Math.round(1700 + Math.random() * 500),
              engineTemp: Math.round((170 + Math.random() * 30) * 10) / 10,
              hydraulicPressure: Math.round(2800 + Math.random() * 600),
              fuelLevel: Math.round((40 + Math.random() * 50) * 10) / 10,
              vibration: Math.round((2 + Math.random() * 2) * 100) / 100,
              oilPressure: Math.round((140 + Math.random() * 20) * 10) / 10,
              coolantTemp: Math.round((80 + Math.random() * 15) * 10) / 10,
            }
          };

          this.io.to(`digital-twin:${asset.id}`).emit(`digital-twin:sensor:${asset.id}`, sensorUpdate);
        }
      } catch (error) {
        console.error('Digital twin simulation error:', (error as Error).message);
      }
    }, 3000));

    // ── Security events: every 20 seconds ──
    this.simulationIntervals.push(setInterval(async () => {
      try {
        if (Math.random() > 0.6) { // 40% chance
          const eventTypes = ['access_granted', 'access_denied', 'motion_detected', 'perimeter_alert', 'vehicle_tracking'];
          const severities = ['info', 'warning', 'critical'];
          const locations = ['Main Gate', 'Zone A', 'Zone B', 'Perimeter North', 'Workshop', 'Office Building'];

          const event = {
            id: `SEC-SIM-${Date.now()}`,
            type: eventTypes[Math.floor(Math.random() * eventTypes.length)],
            severity: severities[Math.floor(Math.random() * 3)],
            location: locations[Math.floor(Math.random() * locations.length)],
            message: 'Simulated security event',
            timestamp: new Date(),
          };

          this.io.to('security:events').emit('security:event:new', event);
        }
      } catch (error) {
        console.error('Security simulation error:', (error as Error).message);
      }
    }, 20000));

    // ── Random alerts: every 30 seconds ──
    this.simulationIntervals.push(setInterval(async () => {
      try {
        if (Math.random() > 0.7) { // 30% chance
          const alertTypes = ['asset_malfunction', 'network_outage', 'maintenance_due', 'safety_violation', 'water_quality', 'security_breach'];
          const severities: Array<'info' | 'warning' | 'critical'> = ['info', 'warning', 'critical'];
          const titles = [
            'Equipment temperature warning', 'Network latency spike', 'Scheduled maintenance reminder',
            'Safety zone violation', 'Water quality alert', 'Unauthorized access attempt'
          ];

          const idx = Math.floor(Math.random() * alertTypes.length);
          const alert = {
            alertId: `ALT-${Date.now()}`,
            alertType: alertTypes[idx],
            severity: severities[Math.floor(Math.random() * severities.length)],
            title: titles[idx],
            message: `Automated alert triggered at ${new Date().toLocaleTimeString()}`,
            timestamp: new Date()
          };

          // Try persisting
          pool.query(
            `INSERT INTO alerts (alert_id, alert_type, severity, title, message, triggered_at)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [alert.alertId, alert.alertType, alert.severity, alert.title, alert.message, alert.timestamp]
          ).catch(() => {});

          this.io.to('alerts').emit('alert:new', alert);
          this.io.to('dashboard').emit('dashboard:alert', alert);
        }
      } catch (error) {
        console.error('Alert simulation error:', (error as Error).message);
      }
    }, 30000));

    // ── Dashboard summary update: every 10 seconds ──
    this.simulationIntervals.push(setInterval(async () => {
      try {
        this.io.to('dashboard').emit('dashboard:metrics', {
          timestamp: new Date(),
          activeAssets: Math.round(680 + Math.random() * 20),
          networkUptime: Math.round((99.5 + Math.random() * 0.4) * 100) / 100,
          safetyScore: Math.round((97 + Math.random() * 2.5) * 10) / 10,
          waterQuality: Math.round((96 + Math.random() * 3) * 10) / 10,
        });
      } catch (error) {
        console.error('Dashboard simulation error:', (error as Error).message);
      }
    }, 10000));

    console.log('📡 All WebSocket simulations started (7 channels)');
  }

  public emitAlert(alert: any): void {
    this.io.to('alerts').emit('alert:new', alert);
  }

  public emitSecurityEvent(event: any): void {
    this.io.to('security:events').emit('security:event:new', event);
  }

  public emitWaterMetrics(metrics: any): void {
    this.io.to('water:metrics').emit('water:metrics:update', metrics);
  }

  public emitWaterFlowUpdate(data: any): void {
    this.io.to('water:flow').emit('water:flow:update', data);
  }

  public emitDigitalTwinSensor(assetId: string, data: any): void {
    this.io.to(`digital-twin:${assetId}`).emit(`digital-twin:sensor:${assetId}`, data);
  }

  public getIO(): SocketIOServer {
    return this.io;
  }

  public shutdown(): void {
    this.simulationIntervals.forEach(interval => clearInterval(interval));
    this.io.close();
  }
}
