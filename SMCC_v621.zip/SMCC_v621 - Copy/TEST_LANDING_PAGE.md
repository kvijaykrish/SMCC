# Testing the Landing Page

## Quick Test Steps

### 1. Verify Backend is Running

```bash
# Check if containers are up
docker-compose ps

# Should show all containers running
# sds-postgres   Up (healthy)
# sds-backend    Up
# sds-frontend   Up
```

### 2. Check Backend API

```bash
# Test sites endpoint (replace TOKEN with actual token from login)
curl http://localhost:3000/api/sites \
  -H "Authorization: Bearer YOUR_TOKEN"

# Or get token first
TOKEN=$(curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@mining-sds.com","password":"admin123"}' \
  | jq -r '.token')

# Then get sites
curl http://localhost:3000/api/sites \
  -H "Authorization: Bearer $TOKEN"
```

### 3. Check Database

```bash
# Check if sites exist
docker exec sds-postgres psql -U postgres -d sds_mining -c "SELECT COUNT(*) FROM sites"

# Should return: count = 6

# View all sites
docker exec sds-postgres psql -U postgres -d sds_mining -c "SELECT site_id, name, location FROM sites"
```

### 4. Test Frontend

1. Open browser: http://localhost:4200
2. You should see the login page
3. Enter credentials:
   - Email: `admin@mining-sds.com`
   - Password: `admin123`
4. Click "Sign In"
5. **You should be redirected to the site selection page** showing 6 mining sites

## If Landing Page Doesn't Show

### Debug Steps

#### Step 1: Check Browser Console

1. Open browser developer tools (F12)
2. Go to Console tab
3. Look for any errors
4. Common issues:
   - CORS errors
   - 404 errors for API calls
   - Authentication errors
   - Route errors

#### Step 2: Check Network Tab

1. In developer tools, go to Network tab
2. After login, check for these requests:
   - POST `/api/auth/login` - Should return 200 with token
   - GET `/api/sites` - Should return 200 with array of sites
   - GET `/api/sites/statistics/summary` - Should return 200

#### Step 3: Verify Routing

1. After login, check the browser URL
2. It should be: `http://localhost:4200/sites`
3. If it's different, there's a routing issue

#### Step 4: Check localStorage

1. In developer tools, go to Application tab (Chrome) or Storage tab (Firefox)
2. Look at localStorage
3. You should see:
   - `authToken` - JWT token
   - `selectedSite` - Will be set after selecting a site

### Common Issues & Fixes

#### Issue 1: "Failed to load sites"

**Cause**: Backend not returning sites data

**Fix**:
```bash
# Check if sites were seeded
docker exec sds-backend node dist/database/seed-sites.js

# Or recreate everything
docker-compose down -v
docker-compose up -d
./setup.sh  # or setup.bat on Windows
```

#### Issue 2: Login redirects to blank page

**Cause**: Routes configuration issue

**Fix**:
1. Check that `/sites` route exists in `app.routes.ts`
2. Verify login component redirects to `/sites`
3. Clear browser cache and localStorage
4. Try again

#### Issue 3: "Unauthorized" error

**Cause**: Token not being sent or invalid

**Fix**:
1. Clear localStorage
2. Logout and login again
3. Check HTTP interceptor is adding Authorization header

#### Issue 4: CORS errors

**Cause**: Backend CORS not configured for frontend

**Fix**:
```bash
# Check backend .env file
docker exec sds-backend cat .env | grep CORS_ORIGIN

# Should be: CORS_ORIGIN=http://localhost:4200

# If wrong, update and restart
docker-compose restart backend
```

#### Issue 5: Sites have no images

**Cause**: Image URLs not accessible

**Fix**:
- Images are loaded from Unsplash
- Check internet connection
- Images should still work without internet (will show placeholder)

#### Issue 6: Blank white screen

**Cause**: JavaScript errors preventing app from loading

**Fix**:
1. Check browser console for errors
2. Rebuild frontend:
   ```bash
   docker-compose build frontend
   docker-compose up -d frontend
   ```

## Manual Verification

### 1. Check Angular Component Exists

```bash
# Verify file exists
ls -la angular-frontend/src/app/features/site-selection/

# Should show:
# site-selection.component.ts
# site-selection.component.html
# site-selection.component.scss
```

### 2. Check Routes Configuration

```bash
# View routes file
cat angular-frontend/src/app/app.routes.ts | grep -A5 "sites"

# Should include:
# path: 'sites',
# canActivate: [AuthGuard],
# loadComponent: ...SiteSelectionComponent
```

### 3. Check Backend Routes

```bash
# Verify sites routes are registered
docker exec sds-backend grep -r "sites.routes" src/server.ts

# Should show:
# import sitesRoutes from './routes/sites.routes';
# app.use('/api/sites', sitesRoutes);
```

## Expected Flow

```
1. User opens http://localhost:4200
   ↓
2. Redirects to /login (not authenticated)
   ↓
3. User enters credentials
   ↓
4. POST /api/auth/login
   ↓
5. Receives JWT token
   ↓
6. Redirects to /sites
   ↓
7. GET /api/sites (with Authorization header)
   ↓
8. GET /api/sites/statistics/summary
   ↓
9. Displays 6 mining sites with metrics
   ↓
10. User clicks a site
   ↓
11. Site saved to localStorage
   ↓
12. Redirects to /dashboard
```

## Test Data

The seeded sites are:

1. **Northern Ridge Mine** - Australia - Iron Ore
2. **Sierra Verde Complex** - Chile - Copper
3. **Goldstream Underground** - Canada - Gold
4. **Eastern Bauxite Fields** - Australia - Bauxite
5. **Platinum Ridge** - South Africa - Platinum
6. **Central Processing Hub** - USA - Processing Plant

Each site should show:
- Site name and location
- Status badge (operational/maintenance/etc.)
- Site type (open pit/underground/processing plant)
- Total assets count
- Active assets count
- Workforce present/total
- Network uptime percentage
- Operational efficiency percentage
- Production data
- Active alerts count

## Still Not Working?

### Full Reset

```bash
# Stop everything
docker-compose down -v

# Remove containers and volumes
docker system prune -a --volumes

# Start fresh
docker-compose up -d

# Wait 30 seconds

# Run setup
./setup.sh  # or setup.bat

# Try again
```

### Check Logs

```bash
# Backend logs
docker-compose logs -f backend

# Frontend logs
docker-compose logs -f frontend

# Database logs
docker-compose logs -f postgres
```

### Manual Database Setup

```bash
# Connect to database
docker exec -it sds-postgres psql -U postgres -d sds_mining

# Run migrations manually
\i /app/src/database/schema.sql
\i /app/src/database/sites-migration.sql

# Check tables
\dt

# Should show sites and site_metrics tables

# Exit
\q
```

## Contact Support

If none of these steps work:

1. Collect logs:
   ```bash
   docker-compose logs > debug-logs.txt
   ```

2. Take screenshot of:
   - Browser console errors
   - Network tab showing failed requests
   - Browser URL after login

3. Note:
   - Operating System
   - Docker version
   - Browser used
   - Exact error messages

---

**Test Guide v1.0** | The landing page should show 6 mining sites after login
