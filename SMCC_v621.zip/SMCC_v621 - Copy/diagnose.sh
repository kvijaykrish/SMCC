#!/bin/bash

# SDS Mining Command Center - Diagnostic Script

echo "=========================================="
echo "🔍 SDS Mining Diagnostic Tool"
echo "=========================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check Docker
echo "1. Checking Docker..."
if docker info > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Docker is running${NC}"
else
    echo -e "${RED}✗ Docker is not running${NC}"
    exit 1
fi

# Check containers
echo ""
echo "2. Checking containers..."
docker-compose ps

# Check backend health
echo ""
echo "3. Checking backend health..."
BACKEND_HEALTH=$(curl -s http://localhost:3000/health)
if [ -n "$BACKEND_HEALTH" ]; then
    echo -e "${GREEN}✓ Backend is responding${NC}"
    echo "   Response: $BACKEND_HEALTH"
else
    echo -e "${RED}✗ Backend is not responding${NC}"
fi

# Check frontend
echo ""
echo "4. Checking frontend..."
FRONTEND_HEALTH=$(curl -s http://localhost:4200/health)
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Frontend is responding${NC}"
else
    echo -e "${YELLOW}⚠ Frontend may not be ready yet${NC}"
fi

# Check database
echo ""
echo "5. Checking database..."
DB_CHECK=$(docker exec sds-postgres pg_isready -U postgres 2>&1)
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Database is ready${NC}"
else
    echo -e "${RED}✗ Database is not ready${NC}"
fi

# Check sites table
echo ""
echo "6. Checking sites table..."
SITES_COUNT=$(docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT COUNT(*) FROM sites" 2>&1)
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Sites table exists${NC}"
    echo "   Sites count: $SITES_COUNT"
    if [ "$SITES_COUNT" -lt 1 ]; then
        echo -e "${YELLOW}⚠ No sites found. Run: docker exec sds-backend node dist/database/seed-sites.js${NC}"
    fi
else
    echo -e "${RED}✗ Sites table not found${NC}"
    echo -e "${YELLOW}⚠ Run: docker exec sds-postgres psql -U postgres -d sds_mining -f /app/src/database/sites-migration.sql${NC}"
fi

# Check users table
echo ""
echo "7. Checking users table..."
USERS_COUNT=$(docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT COUNT(*) FROM users" 2>&1)
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Users table exists${NC}"
    echo "   Users count: $USERS_COUNT"
else
    echo -e "${RED}✗ Users table not found${NC}"
fi

# Test login endpoint
echo ""
echo "8. Testing login endpoint..."
LOGIN_RESPONSE=$(curl -s -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@mining-sds.com","password":"admin123"}')

if echo "$LOGIN_RESPONSE" | grep -q "token"; then
    echo -e "${GREEN}✓ Login endpoint working${NC}"
    TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"token":"[^"]*' | cut -d'"' -f4)
    echo "   Token received: ${TOKEN:0:20}..."
else
    echo -e "${RED}✗ Login endpoint failed${NC}"
    echo "   Response: $LOGIN_RESPONSE"
fi

# Test sites endpoint
echo ""
echo "9. Testing sites endpoint..."
if [ -n "$TOKEN" ]; then
    SITES_RESPONSE=$(curl -s http://localhost:3000/api/sites \
      -H "Authorization: Bearer $TOKEN")
    
    if echo "$SITES_RESPONSE" | grep -q "site_id"; then
        echo -e "${GREEN}✓ Sites endpoint working${NC}"
        SITES_RETURNED=$(echo "$SITES_RESPONSE" | grep -o "site_id" | wc -l)
        echo "   Sites returned: $SITES_RETURNED"
    else
        echo -e "${RED}✗ Sites endpoint failed${NC}"
        echo "   Response: $SITES_RESPONSE"
    fi
else
    echo -e "${YELLOW}⚠ Skipping (no token)${NC}"
fi

# Check logs for errors
echo ""
echo "10. Checking for errors in logs..."
BACKEND_ERRORS=$(docker-compose logs backend 2>&1 | grep -i "error" | wc -l)
if [ "$BACKEND_ERRORS" -gt 0 ]; then
    echo -e "${YELLOW}⚠ Found $BACKEND_ERRORS error lines in backend logs${NC}"
    echo "   Run: docker-compose logs backend | grep -i error"
else
    echo -e "${GREEN}✓ No errors in backend logs${NC}"
fi

echo ""
echo "=========================================="
echo "📊 Diagnostic Summary"
echo "=========================================="
echo ""
echo "Access URLs:"
echo "  Frontend:  http://localhost:4200"
echo "  Backend:   http://localhost:3000"
echo "  PgAdmin:   http://localhost:5050"
echo ""
echo "Login Credentials:"
echo "  Email:     admin@mining-sds.com"
echo "  Password:  admin123"
echo ""
echo "Next Steps:"
echo "  1. Open http://localhost:4200 in your browser"
echo "  2. Login with the credentials above"
echo "  3. You should see the site selection page with 6 mines"
echo ""
echo "Troubleshooting:"
echo "  - View logs:    docker-compose logs -f"
echo "  - Restart:      docker-compose restart"
echo "  - Full reset:   docker-compose down -v && ./setup.sh"
echo ""
