# SDS Mining Command Center - Deployment Guide

Complete step-by-step guide to deploy the application.

## 📦 What You're Deploying

- **Frontend**: Angular 17 SPA (Single Page Application)
- **Backend**: Node.js/Express REST API with WebSocket
- **Database**: PostgreSQL 14 with PostGIS extension

## 🚀 Quick Start (5 Minutes)

### Prerequisites

Install Docker Desktop:
- **Windows/Mac**: Download from https://www.docker.com/products/docker-desktop
- **Linux**: `sudo apt-get install docker docker-compose` (Ubuntu/Debian)

### One-Command Deployment

```bash
# 1. Clone or extract the project
cd sds-mining-command-center

# 2. Start everything
docker-compose up -d

# 3. Wait 30 seconds for services to initialize

# 4. Open your browser
# Frontend: http://localhost:4200
# API: http://localhost:3000
# Database Admin: http://localhost:5050
```

### Default Login

```
Email: admin@mining-sds.com
Password: admin123
```

## 📋 Step-by-Step Deployment

### Step 1: Verify Prerequisites

```bash
# Check Docker installation
docker --version
# Should show: Docker version 20.x or higher

docker-compose --version
# Should show: docker-compose version 1.29.x or higher
```

### Step 2: Prepare the Environment

```bash
# Navigate to project directory
cd sds-mining-command-center

# Create backend .env file
cd backend
cp .env.example .env

# Edit .env if needed (optional for local deployment)
# nano .env or use any text editor
```

### Step 3: Build and Start Services

```bash
# Return to root directory
cd ..

# Build all Docker images
docker-compose build

# Start all services in detached mode
docker-compose up -d

# View logs to verify startup
docker-compose logs -f
```

### Step 4: Initialize Database

The database is automatically initialized with schema and seed data on first startup.

To manually re-run migrations:

```bash
# Access backend container
docker exec -it sds-backend sh

# Run migrations
npm run migrate

# Seed data
npm run seed

# Exit container
exit
```

### Step 5: Verify Deployment

```bash
# Check all services are running
docker-compose ps

# Should show:
# sds-postgres   - Up (healthy)
# sds-backend    - Up
# sds-frontend   - Up
# sds-pgadmin    - Up

# Test backend health
curl http://localhost:3000/health

# Test frontend
curl http://localhost:4200/health
```

### Step 6: Access the Application

Open browser and navigate to:
- **Application**: http://localhost:4200
- **API Docs**: http://localhost:3000/health
- **Database UI**: http://localhost:5050

Login with:
- Email: `admin@mining-sds.com`
- Password: `admin123`

## 🔧 Configuration

### Environment Variables

#### Backend (.env)

```env
# Server
NODE_ENV=production
PORT=3000
HOST=0.0.0.0

# Database
DB_HOST=postgres
DB_PORT=5432
DB_NAME=sds_mining
DB_USER=postgres
DB_PASSWORD=CHANGE_THIS_PASSWORD

# Security
JWT_SECRET=CHANGE_THIS_TO_RANDOM_STRING
JWT_EXPIRES_IN=24h

# CORS
CORS_ORIGIN=http://localhost:4200

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

#### Frontend (environment.ts)

```typescript
// src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000',
  wsUrl: 'http://localhost:3000'
};
```

### Port Configuration

Default ports used:
- `4200` - Angular Frontend
- `3000` - Node.js Backend
- `5432` - PostgreSQL
- `5050` - PgAdmin

To change ports, edit `docker-compose.yml`:

```yaml
services:
  frontend:
    ports:
      - "8080:80"  # Change 8080 to your desired port
```

## 🌐 Production Deployment

### Option 1: Cloud Platform (AWS/Azure/GCP)

#### AWS Deployment

**Architecture:**
```
CloudFront (CDN) → S3 (Frontend)
                 ↓
Application Load Balancer → ECS (Backend)
                           ↓
                         RDS (PostgreSQL)
```

**Steps:**

1. **Database Setup (RDS)**
```bash
# Create RDS PostgreSQL instance
aws rds create-db-instance \
  --db-instance-identifier sds-mining-db \
  --db-instance-class db.t3.medium \
  --engine postgres \
  --master-username admin \
  --master-user-password YOUR_PASSWORD \
  --allocated-storage 100
```

2. **Backend Deployment (ECS)**
```bash
# Build and push Docker image
docker build -t sds-backend ./backend
docker tag sds-backend:latest YOUR_ECR_REPO/sds-backend:latest
docker push YOUR_ECR_REPO/sds-backend:latest

# Create ECS task definition and service
aws ecs create-service \
  --cluster sds-cluster \
  --service-name sds-backend \
  --task-definition sds-backend:1 \
  --desired-count 2
```

3. **Frontend Deployment (S3 + CloudFront)**
```bash
# Build frontend
cd angular-frontend
npm run build

# Upload to S3
aws s3 sync dist/sds-mining-command-center s3://your-bucket-name

# Create CloudFront distribution
aws cloudfront create-distribution \
  --origin-domain-name your-bucket-name.s3.amazonaws.com
```

#### Azure Deployment

1. **Create Azure PostgreSQL Database**
2. **Deploy backend to Azure Container Instances**
3. **Host frontend on Azure Static Web Apps**

#### Google Cloud Deployment

1. **Create Cloud SQL PostgreSQL instance**
2. **Deploy backend to Cloud Run**
3. **Host frontend on Firebase Hosting or Cloud CDN**

### Option 2: Virtual Private Server (VPS)

For DigitalOcean, Linode, AWS EC2, etc.

```bash
# SSH into your server
ssh user@your-server-ip

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Clone your repository
git clone YOUR_REPO_URL
cd sds-mining-command-center

# Update environment variables
nano backend/.env
# Set production values

# Start services
docker-compose up -d

# Setup SSL with Let's Encrypt (optional but recommended)
sudo apt install certbot
sudo certbot --nginx -d yourdomain.com
```

### Option 3: Kubernetes Deployment

```bash
# Create namespace
kubectl create namespace sds-mining

# Deploy PostgreSQL
kubectl apply -f k8s/postgres-deployment.yaml

# Deploy Backend
kubectl apply -f k8s/backend-deployment.yaml

# Deploy Frontend
kubectl apply -f k8s/frontend-deployment.yaml

# Create Ingress
kubectl apply -f k8s/ingress.yaml
```

## 🔐 Security Hardening

### 1. Change Default Credentials

```bash
# Update backend/.env
JWT_SECRET=<generate-random-64-char-string>
DB_PASSWORD=<strong-password>

# Update database password
docker-compose down
# Edit docker-compose.yml with new password
docker-compose up -d
```

### 2. Enable HTTPS

**Using Nginx Reverse Proxy:**

```nginx
server {
    listen 443 ssl http2;
    server_name yourdomain.com;

    ssl_certificate /etc/ssl/certs/your-cert.pem;
    ssl_certificate_key /etc/ssl/private/your-key.pem;

    location / {
        proxy_pass http://localhost:4200;
    }

    location /api {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
    }
}
```

### 3. Configure Firewall

```bash
# Ubuntu/Debian
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable

# Block direct database access
sudo ufw deny 5432/tcp
```

### 4. Set Up Automated Backups

```bash
# Create backup script
cat > backup.sh << 'EOF'
#!/bin/bash
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
docker exec sds-postgres pg_dump -U postgres sds_mining > backup_$TIMESTAMP.sql
# Upload to S3 or backup location
EOF

chmod +x backup.sh

# Add to crontab (daily at 2 AM)
crontab -e
# Add: 0 2 * * * /path/to/backup.sh
```

## 📊 Monitoring

### Application Logs

```bash
# View all logs
docker-compose logs -f

# View specific service
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f postgres

# Save logs to file
docker-compose logs > logs.txt
```

### Health Monitoring

```bash
# Backend health
curl http://localhost:3000/health

# Response:
# {
#   "status": "OK",
#   "timestamp": "2024-01-01T00:00:00.000Z",
#   "uptime": 12345
# }
```

### Database Monitoring

Use PgAdmin at http://localhost:5050

## 🔄 Updates and Maintenance

### Update Application

```bash
# Pull latest code
git pull origin main

# Rebuild containers
docker-compose build

# Restart with zero downtime
docker-compose up -d --no-deps --build backend
docker-compose up -d --no-deps --build frontend
```

### Database Migrations

```bash
# Create new migration
# Edit backend/src/database/migrations/XXX_description.sql

# Run migration
docker exec -it sds-backend npm run migrate
```

### Scale Services

```bash
# Scale backend to 3 instances
docker-compose up -d --scale backend=3

# Use nginx for load balancing
```

## 🐛 Troubleshooting

### Services Won't Start

```bash
# Check logs
docker-compose logs

# Verify ports are available
netstat -tulpn | grep :3000
netstat -tulpn | grep :4200

# Restart everything
docker-compose down
docker-compose up -d
```

### Database Connection Issues

```bash
# Check if PostgreSQL is running
docker ps | grep postgres

# Check PostgreSQL logs
docker-compose logs postgres

# Reset database
docker-compose down -v
docker-compose up -d
```

### Frontend Can't Connect to Backend

```bash
# Check CORS settings
# backend/.env should have:
CORS_ORIGIN=http://localhost:4200

# Verify backend is running
curl http://localhost:3000/health

# Check frontend environment
# angular-frontend/src/environments/environment.ts
```

### Performance Issues

```bash
# Check resource usage
docker stats

# Increase Docker resources
# Docker Desktop → Settings → Resources
# Increase CPU and Memory allocation
```

## 📞 Support

If you encounter issues:

1. Check logs: `docker-compose logs -f`
2. Verify all services are healthy: `docker-compose ps`
3. Check documentation: README.md
4. Contact: support@mining-sds.com

## ✅ Post-Deployment Checklist

- [ ] All services running (`docker-compose ps`)
- [ ] Can access frontend (http://localhost:4200)
- [ ] Can login with admin credentials
- [ ] Backend health check passing
- [ ] Database accessible via PgAdmin
- [ ] WebSocket connections working
- [ ] Changed default passwords
- [ ] Configured HTTPS (production)
- [ ] Set up automated backups
- [ ] Configured monitoring
- [ ] Firewall rules configured
- [ ] SSL certificates installed (production)

---

**Deployment Complete! 🎉**

Your SDS Mining Command Center is now running and ready to use.
