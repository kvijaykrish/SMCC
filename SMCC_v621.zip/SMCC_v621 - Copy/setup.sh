#!/bin/bash

# SDS Mining Command Center - Complete Setup Script
# This script sets up the entire application including sites

set -e  # Exit on error

echo "=========================================="
echo "🚀 SDS Mining Command Center Setup"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo -e "${RED}❌ Docker is not running. Please start Docker Desktop and try again.${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Docker is running${NC}"
echo ""

# Step 1: Start Docker Compose
echo -e "${BLUE}Step 1: Starting Docker containers...${NC}"
docker-compose up -d

echo -e "${YELLOW}Waiting for services to be healthy (30 seconds)...${NC}"
sleep 30

# Step 2: Check if containers are running
echo -e "${BLUE}Step 2: Checking container status...${NC}"
docker-compose ps

# Step 3: Run database migrations
echo -e "${BLUE}Step 3: Running database migrations...${NC}"
echo "  - Creating main schema..."
docker exec sds-backend npm run migrate || true

echo "  - Creating sites schema..."
docker exec sds-postgres psql -U postgres -d sds_mining -f /app/src/database/sites-migration.sql || true

# Step 4: Seed database
echo -e "${BLUE}Step 4: Seeding database...${NC}"
echo "  - Seeding main data..."
docker exec sds-backend npm run seed || true

echo "  - Building TypeScript..."
docker exec sds-backend npm run build

echo "  - Seeding sites..."
docker exec sds-backend node dist/database/seed-sites.js || true

echo ""
echo "=========================================="
echo -e "${GREEN}✅ Setup Complete!${NC}"
echo "=========================================="
echo ""
echo "📱 Application URLs:"
echo "  Frontend:      http://localhost:4200"
echo "  Backend API:   http://localhost:3000"
echo "  PgAdmin:       http://localhost:5050"
echo ""
echo "🔑 Login Credentials:"
echo "  Email:         admin@mining-sds.com"
echo "  Password:      admin123"
echo ""
echo "🗄️  Database:"
echo "  Host:          localhost"
echo "  Port:          5432"
echo "  Database:      sds_mining"
echo "  User:          postgres"
echo "  Password:      postgres"
echo ""
echo "📊 Features Available:"
echo "  ✓ 6 Mining Sites with Real-time Metrics"
echo "  ✓ Asset Management & Digital Twins"
echo "  ✓ Private 5G Network Monitoring"
echo "  ✓ Geo-Spatial Intelligence"
echo "  ✓ Security & Surveillance"
echo "  ✓ Water Management"
echo "  ✓ Safety & Training"
echo ""
echo -e "${BLUE}Next Steps:${NC}"
echo "1. Open http://localhost:4200 in your browser"
echo "2. Login with the credentials above"
echo "3. Select a mining site from the landing page"
echo "4. Explore the command center dashboard"
echo ""
echo "📝 View logs:        docker-compose logs -f"
echo "🛑 Stop application: docker-compose down"
echo "🔄 Restart:          docker-compose restart"
echo ""
echo -e "${GREEN}Happy Mining! ⛏️${NC}"
