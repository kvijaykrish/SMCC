@echo off
REM SDS Mining Command Center - Diagnostic Script for Windows

echo ==========================================
echo 🔍 SDS Mining Diagnostic Tool
echo ==========================================
echo.

REM Check Docker
echo 1. Checking Docker...
docker info >nul 2>&1
if %errorlevel% equ 0 (
    echo ✓ Docker is running
) else (
    echo ✗ Docker is not running
    exit /b 1
)

REM Check containers
echo.
echo 2. Checking containers...
docker-compose ps

REM Check backend health
echo.
echo 3. Checking backend health...
curl -s http://localhost:3000/health
if %errorlevel% equ 0 (
    echo ✓ Backend is responding
) else (
    echo ✗ Backend is not responding
)

REM Check database
echo.
echo 4. Checking database...
docker exec sds-postgres pg_isready -U postgres
if %errorlevel% equ 0 (
    echo ✓ Database is ready
) else (
    echo ✗ Database is not ready
)

REM Check sites table
echo.
echo 5. Checking sites table...
docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT COUNT(*) FROM sites"
if %errorlevel% equ 0 (
    echo ✓ Sites table exists
) else (
    echo ✗ Sites table not found
    echo ⚠ Run: docker exec sds-postgres psql -U postgres -d sds_mining -f /app/src/database/sites-migration.sql
)

REM Check users table
echo.
echo 6. Checking users table...
docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT COUNT(*) FROM users"
if %errorlevel% equ 0 (
    echo ✓ Users table exists
) else (
    echo ✗ Users table not found
)

echo.
echo ==========================================
echo 📊 Diagnostic Summary
echo ==========================================
echo.
echo Access URLs:
echo   Frontend:  http://localhost:4200
echo   Backend:   http://localhost:3000
echo   PgAdmin:   http://localhost:5050
echo.
echo Login Credentials:
echo   Email:     admin@mining-sds.com
echo   Password:  admin123
echo.
echo Next Steps:
echo   1. Open http://localhost:4200 in your browser
echo   2. Login with the credentials above
echo   3. You should see the site selection page with 6 mines
echo.
echo Troubleshooting:
echo   - View logs:    docker-compose logs -f
echo   - Restart:      docker-compose restart
echo   - Full reset:   docker-compose down -v ^&^& setup.bat
echo.
