# SDS Smart Mining Command Center - Angular Frontend

Enterprise-grade Angular application for mining operations management with real-time monitoring, asset tracking, and comprehensive safety features.

## Features

### Core Modules
- **Dashboard**: Real-time overview of all mining operations
- **Connected Assets & Digital Twins**: Asset management with 3D digital twin visualization
- **Private 5G Network**: Network infrastructure monitoring and management
- **Geo-Spatial Intelligence**: Real-time asset tracking with satellite/terrain views
- **Security & Surveillance**: Video monitoring and security event management
- **Water Management**: Pipeline system monitoring with animated flow visualization
- **Safety & Training**: VR training modules and safety incident management

### Technical Features
- **Real-time Updates**: WebSocket integration for live data streaming
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Modular Architecture**: Standalone components with lazy loading
- **Type Safety**: Full TypeScript implementation
- **Authentication**: JWT-based auth with role-based access control
- **State Management**: RxJS observables for reactive data flow
- **API Integration**: RESTful API client with interceptors

## Prerequisites

- Node.js (v18 or higher)
- npm or pnpm
- Angular CLI (v17 or higher)

## Installation

```bash
# Install dependencies
npm install

# Or with pnpm
pnpm install
```

## Development

```bash
# Start development server
npm start

# Or
ng serve

# Application will be available at http://localhost:4200
```

## Project Structure

```
src/
├── app/
│   ├── core/                    # Core services, guards, interceptors
│   │   ├── guards/             # Route guards (auth, role)
│   │   ├── interceptors/       # HTTP interceptors
│   │   ├── models/             # TypeScript interfaces/types
│   │   └── services/           # Singleton services
│   │       ├── auth.service.ts
│   │       ├── asset.service.ts
│   │       ├── network.service.ts
│   │       └── websocket.service.ts
│   ├── features/               # Feature modules (lazy-loaded)
│   │   ├── dashboard/
│   │   ├── connected-assets/
│   │   ├── digital-twin/
│   │   ├── private-5g/
│   │   ├── geo-spatial/
│   │   ├── security/
│   │   ├── video-stream/
│   │   ├── water-management/
│   │   └── safety-training/
│   ├── layout/                 # Layout components
│   │   ├── main-layout/
│   │   ├── sidebar/
│   │   └── header/
│   ├── shared/                 # Shared components, directives, pipes
│   ├── app.config.ts          # Application configuration
│   └── app.routes.ts          # Routing configuration
├── environments/               # Environment configurations
└── styles/                     # Global styles
```

## Services

### AssetService
Manages all asset-related operations:
- CRUD operations for assets
- Real-time telemetry data
- Component health monitoring
- Digital twin synchronization
- Maintenance record management

### NetworkService
Handles network infrastructure:
- Tower management and monitoring
- Device connectivity tracking
- Network metrics and analytics
- Coverage map data

### WebSocketService
Real-time communication:
- Asset telemetry streaming
- Network metrics updates
- Alert notifications
- Security event broadcasting

### AuthService
Authentication and authorization:
- JWT token management
- User profile management
- Role-based access control
- Session handling

## API Integration

The application connects to a Node.js/Express backend:

```typescript
// Environment configuration
export const environment = {
  apiUrl: 'http://localhost:3000',
  wsUrl: 'http://localhost:3000'
};
```

### API Endpoints

```
POST   /api/auth/login
POST   /api/auth/register
GET    /api/auth/profile

GET    /api/assets
GET    /api/assets/:id
POST   /api/assets
PUT    /api/assets/:id
DELETE /api/assets/:id
GET    /api/assets/:id/telemetry
GET    /api/assets/:id/components
GET    /api/assets/:id/digital-twin

GET    /api/network/towers
GET    /api/network/devices
GET    /api/network/statistics

GET    /api/zones
GET    /api/zones/:id/assets
GET    /api/routes

GET    /api/cameras
GET    /api/security/events

GET    /api/water/sources
GET    /api/water/equipment

GET    /api/safety/incidents
GET    /api/training/courses
```

## WebSocket Events

### Client Subscribes To:
```typescript
'asset:telemetry:${assetId}'    // Real-time asset data
'network:metrics:${towerId}'     // Network performance
'alert:new'                      // New alerts
'security:event:new'             // Security events
'water:metrics:update'           // Water system updates
'geospatial:update'              // Asset location updates
```

### Client Emits:
```typescript
'subscribe:asset:telemetry'      // Subscribe to asset updates
'subscribe:network:metrics'      // Subscribe to network metrics
'subscribe:alerts'               // Subscribe to alerts
'subscribe:security:events'      // Subscribe to security events
```

## Authentication

The application uses JWT tokens for authentication:

```typescript
// Login
authService.login(email, password).subscribe({
  next: (response) => {
    // Token stored automatically
    // User redirected to dashboard
  }
});

// Access protected resources
// Token automatically attached via auth interceptor
assetService.getAssets().subscribe(...);
```

## Guards

### AuthGuard
Protects routes requiring authentication:

```typescript
{
  path: 'dashboard',
  component: DashboardComponent,
  canActivate: [AuthGuard]
}
```

## Interceptors

### AuthInterceptor
Automatically attaches JWT token to requests:

```typescript
Authorization: Bearer <token>
```

### ErrorInterceptor
Handles HTTP errors globally:
- 401: Redirect to login
- 403: Show permission error
- 500: Show server error

## Building for Production

```bash
# Production build
npm run build

# Build output in dist/
# Optimized, minified, and tree-shaken
```

## Deployment

### Docker

```dockerfile
FROM node:18-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist/sds-mining-command-center /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### Environment Variables

Update `src/environments/environment.prod.ts`:

```typescript
export const environment = {
  production: true,
  apiUrl: 'https://api.your-domain.com',
  wsUrl: 'wss://api.your-domain.com'
};
```

## Testing

```bash
# Unit tests
npm test

# E2E tests
npm run e2e

# Code coverage
npm run test:coverage
```

## Code Style

```bash
# Lint
npm run lint

# Format
npm run format
```

## Performance Optimization

- **Lazy Loading**: Feature modules loaded on demand
- **OnPush Change Detection**: Used where applicable
- **TrackBy Functions**: For efficient list rendering
- **Image Optimization**: Lazy loading images
- **Bundle Optimization**: Code splitting and tree shaking

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## License

Proprietary - All rights reserved

## Support

For support, email support@mining-sds.com
