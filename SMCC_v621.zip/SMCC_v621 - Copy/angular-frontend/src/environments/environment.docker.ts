export const environment = {
  production: true,
  apiUrl: '',
  wsUrl: '',
  version: '2.1.0'
};
