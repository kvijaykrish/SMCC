export const environment = {
  production: true,
  apiUrl: 'https://api.mining-sds.com',
  wsUrl: 'wss://api.mining-sds.com',
  version: '2.1.0'
};