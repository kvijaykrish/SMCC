// Azure deployment environment
// The API URL should be configured via the ANGULAR_API_URL environment variable
// at build time or replaced in the Docker entrypoint script.
//
// For Azure Container Apps deployment:
//   docker build --build-arg API_URL=https://sds-api.azurecontainerapps.io .
//
// Or set via Container App environment variable and replace at runtime:
//   In entrypoint.sh: sed -i "s|__API_URL__|$API_URL|g" /usr/share/nginx/html/main*.js
//   In entrypoint.sh: sed -i "s|__WS_URL__|$WS_URL|g" /usr/share/nginx/html/main*.js

export const environment = {
  production: true,
  apiUrl: '__API_URL__', // Replaced at build/deploy time
  wsUrl: '__WS_URL__',   // Replaced at build/deploy time - use wss:// for production
  version: '2.1.0'
};
