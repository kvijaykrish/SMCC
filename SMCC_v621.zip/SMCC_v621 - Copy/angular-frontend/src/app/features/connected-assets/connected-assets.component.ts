import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Subject, takeUntil, forkJoin } from 'rxjs';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartConfiguration } from 'chart.js';
import { AssetService } from '../../core/services/asset.service';
import { WebSocketService } from '../../core/services/websocket.service';

@Component({
  selector: 'app-connected-assets',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, BaseChartDirective],
  templateUrl: './connected-assets.component.html',
  styleUrls: ['./connected-assets.component.scss']
})
export class ConnectedAssetsComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private assetService = inject(AssetService);
  private wsService = inject(WebSocketService);

  assets: any[] = [];
  filteredAssets: any[] = [];
  searchTerm = '';
  filterStatus = 'all';
  loading = true;

  summary = { total: 0, active: 0, maintenance: 0, avgHealth: 0 };
  assetTypeDistribution: { name: string; value: number; color: string }[] = [];

  // Activity Bar Chart
  activityChartData: ChartData<'bar'> = { labels: [], datasets: [] };
  activityChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' }, stacked: true },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' }, stacked: true },
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  // Asset Type Doughnut
  typePieData: ChartData<'doughnut'> = { labels: [], datasets: [] };
  typePieOptions: ChartConfiguration<'doughnut'>['options'] = {
    responsive: true, maintainAspectRatio: false, cutout: '60%',
    plugins: { legend: { display: false } },
  };

  ngOnInit(): void {
    this.loadAllData();
    this.subscribeToRealtime();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadAllData(): void {
    forkJoin({
      assets: this.assetService.getAssets(),
      stats: this.assetService.getAssetStatistics(),
      activityChart: this.assetService.getActivityChartData(),
      typeDistribution: this.assetService.getTypeDistribution(),
    }).pipe(takeUntil(this.destroy$)).subscribe({
      next: ({ assets, stats, activityChart, typeDistribution }) => {
        // Map snake_case DB fields to camelCase
        this.assets = assets.map((a: any) => ({
          id: a.id,
          assetId: a.asset_id || a.assetId,
          name: a.name,
          type: a.type,
          status: a.status,
          operatingHours: parseFloat(a.operating_hours || a.operatingHours || 0),
          manufacturer: a.manufacturer,
          model: a.model,
          serialNumber: a.serial_number || a.serialNumber,
          currentZoneId: a.current_zone_id || a.currentZoneId,
          createdAt: a.created_at || a.createdAt,
        }));

        // Summary from stats endpoint
        this.summary = {
          total: parseInt(stats.total_assets) || this.assets.length,
          active: parseInt(stats.active_assets) || this.assets.filter((a: any) => a.status === 'active').length,
          maintenance: parseInt(stats.maintenance_assets) || this.assets.filter((a: any) => a.status === 'maintenance').length,
          avgHealth: stats.avg_health != null ? stats.avg_health : this.computeFallbackHealth(),
        };

        // Charts from API
        this.buildActivityChart(activityChart);
        this.buildTypeDistribution(typeDistribution);

        this.applyFilters();
        this.loading = false;
      },
      error: () => {
        // Fallback
        this.assets = this.getFallbackAssets();
        this.summary = { total: this.assets.length, active: this.assets.filter(a => a.status === 'active').length, maintenance: this.assets.filter(a => a.status === 'maintenance').length, avgHealth: 92 };
        this.buildActivityChart(this.getFallbackActivity());
        this.buildTypeDistributionFromAssets();
        this.applyFilters();
        this.loading = false;
      }
    });
  }

  private buildActivityChart(data: any[]): void {
    this.activityChartData = {
      labels: data.map(d => d.hour),
      datasets: [
        { data: data.map(d => d.active), label: 'Active', backgroundColor: '#10b981' },
        { data: data.map(d => d.idle), label: 'Idle', backgroundColor: '#f59e0b' },
        { data: data.map(d => d.maintenance), label: 'Maintenance', backgroundColor: '#ef4444' },
      ],
    };
  }

  private buildTypeDistribution(data: any[]): void {
    this.assetTypeDistribution = data;
    this.typePieData = {
      labels: data.map(d => d.name),
      datasets: [{ data: data.map(d => d.value), backgroundColor: data.map(d => d.color), borderWidth: 0 }],
    };
  }

  private buildTypeDistributionFromAssets(): void {
    const typeGroups = this.assets.reduce((acc, a) => {
      acc[a.type] = (acc[a.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const colors = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4'];
    this.assetTypeDistribution = Object.entries(typeGroups).map(([name, value], i) => ({
      name: this.formatAssetType(name),
      value: value as number,
      color: colors[i % colors.length]
    }));

    this.typePieData = {
      labels: this.assetTypeDistribution.map(d => d.name),
      datasets: [{ data: this.assetTypeDistribution.map(d => d.value), backgroundColor: this.assetTypeDistribution.map(d => d.color), borderWidth: 0 }],
    };
  }

  private subscribeToRealtime(): void {
    this.wsService.subscribeToAlerts()
      .pipe(takeUntil(this.destroy$))
      .subscribe((alert: any) => {
        if (alert.alertType === 'asset_malfunction' || alert.alertType === 'maintenance_due') {
          // Refresh assets on relevant alerts
          this.loadAllData();
        }
      });
  }

  private computeFallbackHealth(): number {
    return 92; // Reasonable default when no component data exists
  }

  applyFilters(): void {
    this.filteredAssets = this.assets.filter(asset => {
      const matchesSearch = !this.searchTerm ||
        asset.name?.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        asset.assetId?.toLowerCase().includes(this.searchTerm.toLowerCase());
      const matchesFilter = this.filterStatus === 'all' || asset.status === this.filterStatus;
      return matchesSearch && matchesFilter;
    });
  }

  getStatusClass(status: string): string {
    const classes: Record<string, string> = {
      active: 'bg-green-500/10 text-green-400 border-green-500/20',
      maintenance: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
      inactive: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
    };
    return classes[status] || classes['inactive'];
  }

  formatAssetType(type: string): string {
    return (type || '').split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
  }

  getHealthColor(health: number): string {
    if (health >= 85) return 'bg-green-500';
    if (health >= 70) return 'bg-amber-500';
    return 'bg-red-500';
  }

  private getFallbackAssets(): any[] {
    return [
      { id: '1', assetId: 'EXC-001', name: 'Excavator CAT 336', type: 'excavator', status: 'active', operatingHours: 1250.5, manufacturer: 'Caterpillar', model: '336F' },
      { id: '2', assetId: 'HTK-001', name: 'Haul Truck Komatsu 930E', type: 'haul_truck', status: 'active', operatingHours: 2100.7, manufacturer: 'Komatsu', model: '930E-4' },
      { id: '3', assetId: 'DRL-001', name: 'Drill Rig Sandvik DI650i', type: 'drill', status: 'active', operatingHours: 750.8, manufacturer: 'Sandvik', model: 'DI650i' },
      { id: '4', assetId: 'DOZ-001', name: 'Dozer CAT D11T', type: 'dozer', status: 'maintenance', operatingHours: 3200.4, manufacturer: 'Caterpillar', model: 'D11T' },
      { id: '5', assetId: 'LDR-001', name: 'Loader Komatsu WA900', type: 'loader', status: 'active', operatingHours: 1420.6, manufacturer: 'Komatsu', model: 'WA900-8' },
      { id: '6', assetId: 'EXC-002', name: 'Excavator Komatsu PC800', type: 'excavator', status: 'active', operatingHours: 980.2, manufacturer: 'Komatsu', model: 'PC800' },
      { id: '7', assetId: 'HTK-002', name: 'Haul Truck CAT 797F', type: 'haul_truck', status: 'active', operatingHours: 1850.3, manufacturer: 'Caterpillar', model: '797F' },
      { id: '8', assetId: 'GRD-001', name: 'Grader CAT 24M', type: 'grader', status: 'active', operatingHours: 890.9, manufacturer: 'Caterpillar', model: '24M' },
    ];
  }

  private getFallbackActivity(): any[] {
    return [
      { hour: '00:00', active: 45, idle: 12, maintenance: 3 },
      { hour: '04:00', active: 38, idle: 18, maintenance: 4 },
      { hour: '08:00', active: 52, idle: 6, maintenance: 2 },
      { hour: '12:00', active: 48, idle: 10, maintenance: 2 },
      { hour: '16:00', active: 50, idle: 8, maintenance: 2 },
      { hour: '20:00', active: 46, idle: 11, maintenance: 3 },
    ];
  }
}
