import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Subject, takeUntil, forkJoin } from 'rxjs';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartConfiguration } from 'chart.js';
import { SecurityService } from '../../core/services/security.service';
import { WebSocketService } from '../../core/services/websocket.service';

@Component({
  selector: 'app-security',
  standalone: true,
  imports: [CommonModule, RouterModule, BaseChartDirective],
  templateUrl: './security.component.html',
  styleUrls: ['./security.component.scss']
})
export class SecurityComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private securityService = inject(SecurityService);
  private wsService = inject(WebSocketService);

  loading = true;
  selectedCamera: string | null = null;

  summary = { activeCameras: 0, events24h: 0, accessPoints: 16, personnelOnSite: 342 };

  securityEvents: any[] = [];
  cameras: any[] = [];

  statusItems = [
    { label: 'Perimeter Security', status: 'Secure', color: 'text-green-400' },
    { label: 'Access Control', status: 'Active', color: 'text-green-400' },
    { label: 'Video Surveillance', status: 'Online', color: 'text-green-400' },
    { label: 'Alarm Systems', status: 'Armed', color: 'text-green-400' },
  ];

  // Access Control Bar Chart
  accessChartData: ChartData<'bar'> = { labels: [], datasets: [] };
  accessChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  // Event Type Horizontal Bar
  eventTypeChartData: ChartData<'bar'> = { labels: [], datasets: [] };
  eventTypeChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true, maintainAspectRatio: false, indexAxis: 'y',
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8', font: { size: 11 } }, grid: { color: '#334155' } },
    },
    plugins: { legend: { display: false } },
  };

  ngOnInit(): void {
    this.loadData();
    this.subscribeToRealtime();
  }

  ngOnDestroy(): void { this.destroy$.next(); this.destroy$.complete(); }

  loadData(): void {
    forkJoin({
      summary: this.securityService.getSummary(),
      events: this.securityService.getSecurityEvents(),
      cameras: this.securityService.getCameras(),
      accessChart: this.securityService.getAccessChartData(),
      eventTypes: this.securityService.getEventTypeChartData(),
    }).pipe(takeUntil(this.destroy$)).subscribe({
      next: ({ summary, events, cameras, accessChart, eventTypes }) => {
        // Summary
        this.summary = {
          activeCameras: summary.activeCameras || 128,
          events24h: summary.events24h || 24,
          accessPoints: summary.accessPoints || 16,
          personnelOnSite: summary.personnelOnSite || 342,
        };

        // Events
        this.securityEvents = (events || []).slice(0, 6).map((e: any) => ({
          id: e.id || e.event_id,
          type: e.type || e.event_type || 'Event',
          severity: e.severity || 'info',
          location: e.location || 'Unknown',
          time: this.timeAgo(e.detectedAt || e.detected_at),
          camera: e.cameraId || e.camera_id || '',
          status: e.status || 'active',
        }));

        // Cameras
        this.cameras = (cameras || []).slice(0, 8).map((c: any) => ({
          id: c.cameraId || c.camera_id || c.id,
          name: c.name,
          location: c.location || c.zone || '',
          status: c.status === 'online' ? 'active' : (c.status || 'active'),
          resolution: c.resolution || '1080p',
          fps: c.fps || 30,
        }));

        // Update status based on camera health
        const warningCams = this.cameras.filter(c => c.status === 'warning').length;
        if (warningCams > 0) {
          this.statusItems[2] = { label: 'Video Surveillance', status: `${warningCams} Warning${warningCams > 1 ? 's' : ''}`, color: 'text-amber-400' };
        }

        // Access chart
        if (accessChart && accessChart.length > 0) {
          this.accessChartData = {
            labels: accessChart.map((d: any) => d.hour),
            datasets: [
              { data: accessChart.map((d: any) => d.authorized), label: 'Authorized', backgroundColor: '#10b981' },
              { data: accessChart.map((d: any) => d.denied), label: 'Denied', backgroundColor: '#f59e0b' },
              { data: accessChart.map((d: any) => d.unauthorized), label: 'Unauthorized', backgroundColor: '#ef4444' },
            ],
          };
        } else {
          this.buildFallbackAccessChart();
        }

        // Event types chart
        if (eventTypes && eventTypes.length > 0) {
          this.eventTypeChartData = {
            labels: eventTypes.map((d: any) => d.type),
            datasets: [{ data: eventTypes.map((d: any) => d.count), label: 'Events', backgroundColor: '#3b82f6' }],
          };
        } else {
          this.buildFallbackEventTypeChart();
        }

        this.loading = false;
      },
      error: () => {
        this.buildFallbackAccessChart();
        this.buildFallbackEventTypeChart();
        this.buildFallbackEvents();
        this.buildFallbackCameras();
        this.loading = false;
      }
    });
  }

  private subscribeToRealtime(): void {
    this.wsService.subscribeToSecurityEvents()
      .pipe(takeUntil(this.destroy$))
      .subscribe((event: any) => {
        this.securityEvents.unshift({
          id: event.id, type: event.type, severity: event.severity,
          location: event.location, time: 'just now', camera: '', status: 'active',
        });
        if (this.securityEvents.length > 6) this.securityEvents.pop();
        this.summary.events24h++;
      });
  }

  private buildFallbackAccessChart(): void {
    const data = [
      { hour: '00:00', authorized: 12, unauthorized: 0, denied: 1 },
      { hour: '06:00', authorized: 45, unauthorized: 0, denied: 2 },
      { hour: '08:00', authorized: 89, unauthorized: 1, denied: 3 },
      { hour: '12:00', authorized: 67, unauthorized: 0, denied: 1 },
      { hour: '16:00', authorized: 72, unauthorized: 0, denied: 2 },
      { hour: '20:00', authorized: 34, unauthorized: 0, denied: 1 },
    ];
    this.accessChartData = {
      labels: data.map(d => d.hour),
      datasets: [
        { data: data.map(d => d.authorized), label: 'Authorized', backgroundColor: '#10b981' },
        { data: data.map(d => d.denied), label: 'Denied', backgroundColor: '#f59e0b' },
        { data: data.map(d => d.unauthorized), label: 'Unauthorized', backgroundColor: '#ef4444' },
      ],
    };
  }

  private buildFallbackEventTypeChart(): void {
    const types = [
      { type: 'Access Control', count: 145 }, { type: 'Motion Detection', count: 89 },
      { type: 'Perimeter Alert', count: 23 }, { type: 'Vehicle Tracking', count: 67 },
      { type: 'Personnel Safety', count: 12 },
    ];
    this.eventTypeChartData = {
      labels: types.map(d => d.type),
      datasets: [{ data: types.map(d => d.count), label: 'Events', backgroundColor: '#3b82f6' }],
    };
  }

  private buildFallbackEvents(): void {
    this.securityEvents = [
      { id: 'SEC-001', type: 'Access Alert', severity: 'warning', location: 'Gate A', time: '2 min ago', camera: 'CAM-12', status: 'reviewing' },
      { id: 'SEC-002', type: 'Perimeter Breach', severity: 'critical', location: 'Zone C-North', time: '15 min ago', camera: 'CAM-34', status: 'resolved' },
      { id: 'SEC-003', type: 'Unauthorized Vehicle', severity: 'warning', location: 'Parking Lot B', time: '32 min ago', camera: 'CAM-08', status: 'investigating' },
      { id: 'SEC-004', type: 'Motion Detected', severity: 'info', location: 'Warehouse 2', time: '1 hour ago', camera: 'CAM-45', status: 'resolved' },
    ];
  }

  private buildFallbackCameras(): void {
    this.cameras = [
      { id: 'CAM-01', name: 'Main Gate North', location: 'Entrance', status: 'active', resolution: '4K', fps: 30 },
      { id: 'CAM-02', name: 'Main Gate South', location: 'Entrance', status: 'active', resolution: '4K', fps: 30 },
      { id: 'CAM-12', name: 'Perimeter NE', location: 'Zone A', status: 'active', resolution: '1080p', fps: 25 },
      { id: 'CAM-23', name: 'Mining Pit', location: 'Zone B', status: 'active', resolution: '4K', fps: 30 },
      { id: 'CAM-34', name: 'Perimeter SW', location: 'Zone C', status: 'warning', resolution: '1080p', fps: 20 },
      { id: 'CAM-45', name: 'Warehouse', location: 'Storage', status: 'active', resolution: '1080p', fps: 25 },
    ];
    this.summary = { activeCameras: 128, events24h: 24, accessPoints: 16, personnelOnSite: 342 };
  }

  private timeAgo(dateStr: string): string {
    if (!dateStr) return 'recently';
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins} min ago`;
    return `${Math.floor(mins / 60)} hour${Math.floor(mins / 60) > 1 ? 's' : ''} ago`;
  }

  getSeverityClass(severity: string): string {
    const m: Record<string, string> = { critical: 'bg-red-500/20 text-red-400', warning: 'bg-amber-500/20 text-amber-400', info: 'bg-blue-500/20 text-blue-400' };
    return m[severity] || m['info'];
  }
}
