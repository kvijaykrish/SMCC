import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
  timestamp: Date;
  resultCount?: number;
  filters?: Record<string, string[]>;
}

interface SuggestedPrompt {
  text: string;
  category: string;
  icon: string;
}

@Component({
  selector: 'app-ai-assistant',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './ai-assistant.component.html',
  styleUrls: ['./ai-assistant.component.scss']
})
export class AiAssistantComponent implements OnInit {
  @ViewChild('chatContainer') chatContainer!: ElementRef;
  @ViewChild('queryInput') queryInput!: ElementRef;

  query = '';
  messages: ChatMessage[] = [];
  loading = false;
  isListening = false;

  suggestedPrompts: SuggestedPrompt[] = [
    { text: 'Show all excavator breakdowns in the last 3 months', category: 'equipment', icon: '🔧' },
    { text: 'What safety incidents happened this week?', category: 'safety', icon: '🛡️' },
    { text: 'List all critical alerts from Zone A', category: 'alerts', icon: '🚨' },
    { text: 'Show production milestones this year', category: 'production', icon: '⛏️' },
    { text: 'Any water quality alerts recently?', category: 'water', icon: '💧' },
    { text: 'Show network outages in the last 30 days', category: 'network', icon: '📡' },
    { text: 'Which equipment has the most maintenance?', category: 'equipment', icon: '🔩' },
    { text: 'Show high-severity events from last month', category: 'general', icon: '📊' },
    { text: 'List blasting events for this quarter', category: 'production', icon: '💥' },
    { text: 'Are there any expired certifications?', category: 'training', icon: '📋' },
    { text: 'Show geofence breaches in processing zone', category: 'security', icon: '🔒' },
    { text: 'What are the most common event types?', category: 'general', icon: '📈' },
  ];

  ngOnInit(): void {}

  submitQuery(text?: string): void {
    const queryText = text || this.query.trim();
    if (!queryText) return;

    this.messages.push({
      role: 'user',
      text: queryText,
      timestamp: new Date(),
    });

    this.query = '';
    this.loading = true;

    // Simulate AI response
    setTimeout(() => {
      const resultCount = Math.floor(Math.random() * 50) + 5;
      const filters = this.parseQuery(queryText);
      const response = this.generateResponse(queryText, resultCount, filters);

      this.messages.push({
        role: 'assistant',
        text: response,
        timestamp: new Date(),
        resultCount,
        filters,
      });

      this.loading = false;
      this.scrollToBottom();
      this.speakResponse(response);
    }, 800 + Math.random() * 1200);
  }

  toggleVoiceInput(): void {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Speech recognition is not supported in this browser.');
      return;
    }

    if (this.isListening) {
      this.isListening = false;
      return;
    }

    this.isListening = true;
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      this.query = transcript;
      this.isListening = false;
      this.submitQuery(transcript);
    };

    recognition.onerror = () => {
      this.isListening = false;
    };

    recognition.onend = () => {
      this.isListening = false;
    };

    recognition.start();
  }

  clearChat(): void {
    this.messages = [];
  }

  private parseQuery(text: string): Record<string, string[]> {
    const filters: Record<string, string[]> = {};
    const lower = text.toLowerCase();

    const equipmentTypes = ['excavator', 'haul truck', 'drill', 'dozer', 'loader', 'grader'];
    const matched = equipmentTypes.filter(e => lower.includes(e));
    if (matched.length) filters['Equipment'] = matched;

    const severities = ['critical', 'high', 'medium', 'low'];
    const matchedSev = severities.filter(s => lower.includes(s));
    if (matchedSev.length) filters['Severity'] = matchedSev;

    const categories = ['safety', 'production', 'maintenance', 'water', 'network', 'security'];
    const matchedCat = categories.filter(c => lower.includes(c));
    if (matchedCat.length) filters['Category'] = matchedCat;

    if (lower.includes('breakdown')) filters['Event Type'] = ['breakdown'];
    if (lower.includes('incident')) filters['Event Type'] = ['incident'];
    if (lower.includes('alert')) filters['Event Type'] = ['alert'];

    return filters;
  }

  private generateResponse(query: string, count: number, filters: Record<string, string[]>): string {
    const filterSummary = Object.entries(filters)
      .map(([k, v]) => `${k}: ${v.join(', ')}`)
      .join('; ');

    return `Found ${count} matching events${filterSummary ? ` with filters [${filterSummary}]` : ''}. ` +
      `The data shows ${Math.floor(count * 0.3)} high-severity events and ${Math.floor(count * 0.5)} resolved cases. ` +
      `The majority occurred in the Primary Pit zone during day shifts.`;
  }

  private speakResponse(text: string): void {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.volume = 0.7;
      const voices = speechSynthesis.getVoices();
      const preferred = voices.find(v => v.lang.startsWith('en'));
      if (preferred) utterance.voice = preferred;
      speechSynthesis.speak(utterance);
    }
  }

  private scrollToBottom(): void {
    setTimeout(() => {
      if (this.chatContainer) {
        this.chatContainer.nativeElement.scrollTop = this.chatContainer.nativeElement.scrollHeight;
      }
    }, 100);
  }

  getFilterKeys(filters?: Record<string, string[]>): string[] {
    return filters ? Object.keys(filters) : [];
  }
}
