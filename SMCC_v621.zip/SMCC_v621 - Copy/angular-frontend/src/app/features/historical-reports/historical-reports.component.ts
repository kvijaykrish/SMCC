import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartConfiguration } from 'chart.js';
import { ReportService } from '../../core/services/report.service';
import { ReportType, ReportKpi } from '../../core/models/report.model';
import { inject } from '@angular/core';

interface ReportConfig {
  type: ReportType;
  label: string;
  icon: string;
  color: string;
  chartColor: string;
  bgColor: string;
}

@Component({
  selector: 'app-historical-reports',
  standalone: true,
  imports: [CommonModule, FormsModule, BaseChartDirective],
  templateUrl: './historical-reports.component.html',
  styleUrls: ['./historical-reports.component.scss']
})
export class HistoricalReportsComponent implements OnInit {
  private reportService = inject(ReportService);

  reportTypes: ReportConfig[] = [
    { type: 'production', label: 'Production', icon: '⛏️', color: 'text-blue-400', chartColor: '#3b82f6', bgColor: 'bg-blue-500/10 border-blue-500/20' },
    { type: 'safety', label: 'Safety & Compliance', icon: '🛡️', color: 'text-amber-400', chartColor: '#f59e0b', bgColor: 'bg-amber-500/10 border-amber-500/20' },
    { type: 'equipment', label: 'Equipment & Fleet', icon: '🔧', color: 'text-purple-400', chartColor: '#8b5cf6', bgColor: 'bg-purple-500/10 border-purple-500/20' },
    { type: 'water', label: 'Water Management', icon: '💧', color: 'text-cyan-400', chartColor: '#06b6d4', bgColor: 'bg-cyan-500/10 border-cyan-500/20' },
    { type: 'energy', label: 'Energy & Power', icon: '⚡', color: 'text-green-400', chartColor: '#10b981', bgColor: 'bg-green-500/10 border-green-500/20' },
    { type: 'security', label: 'Security', icon: '🔒', color: 'text-red-400', chartColor: '#ef4444', bgColor: 'bg-red-500/10 border-red-500/20' },
  ];

  selectedReportType: ReportType = 'production';
  selectedTimeRange = '30d';
  timeRanges = [
    { value: '7d', label: 'Last 7 Days' },
    { value: '30d', label: 'Last 30 Days' },
    { value: '90d', label: 'Last 90 Days' },
    { value: '6m', label: 'Last 6 Months' },
    { value: '1y', label: 'Last Year' },
  ];

  kpis: ReportKpi[] = [];
  tableData: any[] = [];
  loading = false;

  // Main trend chart (Area/Line)
  trendChartData: ChartData<'line'> = { labels: [], datasets: [] };
  trendChartOptions: ChartConfiguration<'line'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8', maxTicksLimit: 10 }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  // Pie chart
  pieChartData: ChartData<'doughnut'> = { labels: [], datasets: [] };
  pieChartOptions: ChartConfiguration<'doughnut'>['options'] = {
    responsive: true, maintainAspectRatio: false, cutout: '55%',
    plugins: { legend: { position: 'bottom', labels: { color: '#e2e8f0', padding: 12 } } },
  };

  // Bar chart
  barChartData: ChartData<'bar'> = { labels: [], datasets: [] };
  barChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4'];

  ngOnInit(): void {
    this.generateReport();
  }

  selectReportType(type: ReportType): void {
    this.selectedReportType = type;
    this.generateReport();
  }

  onTimeRangeChange(): void {
    this.generateReport();
  }

  generateReport(): void {
    this.loading = true;

    // Try to generate via API first
    const now = new Date();
    const start = new Date();
    start.setDate(start.getDate() - this.getNumDays());

    this.reportService.generateReport({
      reportType: this.selectedReportType,
      timeRangeStart: start.toISOString(),
      timeRangeEnd: now.toISOString(),
      timeRangePreset: this.selectedTimeRange,
    }).subscribe({
      next: (report: any) => {
        // Use API data if available
        if (report.kpi_summary) {
          this.kpis = report.kpi_summary;
        } else {
          this.kpis = this.getMockKpis(this.selectedReportType);
        }
        if (report.data && Array.isArray(report.data) && report.data.length > 0) {
          // Build charts from API data
          this.buildChartsFromApiData(report.data);
        } else {
          this.buildCharts();
        }
        this.tableData = this.getMockTableData(this.selectedReportType);
        this.loading = false;
      },
      error: () => {
        // Fallback to client-side data
        this.kpis = this.getMockKpis(this.selectedReportType);
        this.buildCharts();
        this.tableData = this.getMockTableData(this.selectedReportType);
        this.loading = false;
      }
    });
  }

  private buildChartsFromApiData(data: any[]): void {
    const config = this.getSelectedConfig();
    this.trendChartData = {
      labels: data.map(d => d.date),
      datasets: [
        {
          data: data.map(d => d.value), label: this.getPrimaryLabel(),
          borderColor: config.chartColor, backgroundColor: config.chartColor + '20',
          fill: true, tension: 0.4,
        },
        {
          data: data.map(d => d.secondary), label: this.getSecondaryLabel(),
          borderColor: '#10b981', backgroundColor: 'transparent', tension: 0.4,
        },
      ],
    };

    // Still use local pie/bar data since API doesn't provide category breakdown
    const pieData = this.getPieData();
    this.pieChartData = {
      labels: pieData.map(d => d.name),
      datasets: [{ data: pieData.map(d => d.value), backgroundColor: this.COLORS, borderWidth: 0 }],
    };
    this.barChartData = {
      labels: pieData.map(d => d.name),
      datasets: [{ data: pieData.map(d => d.value), label: 'Distribution', backgroundColor: this.COLORS }],
    };
  }

  private buildCharts(): void {
    const config = this.getSelectedConfig();
    const days = this.getNumDays();
    const labels: string[] = [];
    const primary: number[] = [];
    const secondary: number[] = [];

    for (let i = 0; i < Math.min(days, 30); i++) {
      const d = new Date();
      d.setDate(d.getDate() - (Math.min(days, 30) - i));
      labels.push(d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
      primary.push(Math.round(2200 + Math.random() * 800 + Math.sin(i * 0.5) * 300));
      secondary.push(Math.round(80 + Math.random() * 15));
    }

    this.trendChartData = {
      labels,
      datasets: [
        {
          data: primary, label: this.getPrimaryLabel(),
          borderColor: config.chartColor, backgroundColor: config.chartColor + '20',
          fill: true, tension: 0.4,
        },
        {
          data: secondary, label: this.getSecondaryLabel(),
          borderColor: '#10b981', backgroundColor: 'transparent', tension: 0.4,
        },
      ],
    };

    // Pie data varies by type
    const pieData = this.getPieData();
    this.pieChartData = {
      labels: pieData.map(d => d.name),
      datasets: [{ data: pieData.map(d => d.value), backgroundColor: this.COLORS, borderWidth: 0 }],
    };

    // Bar breakdown
    this.barChartData = {
      labels: pieData.map(d => d.name),
      datasets: [{ data: pieData.map(d => d.value), label: 'Distribution', backgroundColor: this.COLORS }],
    };
  }

  getSelectedConfig(): ReportConfig {
    return this.reportTypes.find(r => r.type === this.selectedReportType)!;
  }

  private getNumDays(): number {
    const m: Record<string, number> = { '7d': 7, '30d': 30, '90d': 90, '6m': 180, '1y': 365 };
    return m[this.selectedTimeRange] || 30;
  }

  private getPrimaryLabel(): string {
    const m: Record<string, string> = { production: 'Ore Extracted (tons)', safety: 'Compliance Score', equipment: 'Uptime %', water: 'Consumption (m³)', energy: 'Total kWh', security: 'Access Events' };
    return m[this.selectedReportType] || 'Value';
  }

  private getSecondaryLabel(): string {
    const m: Record<string, string> = { production: 'Yield %', safety: 'Inspections', equipment: 'Fleet Active', water: 'Quality %', energy: 'Solar kWh', security: 'Camera Uptime %' };
    return m[this.selectedReportType] || 'Secondary';
  }

  private getPieData(): { name: string; value: number }[] {
    const data: Record<string, { name: string; value: number }[]> = {
      production: [
        { name: 'Copper Ore', value: 42 }, { name: 'Gold Ore', value: 18 },
        { name: 'Silver Ore', value: 12 }, { name: 'Iron Ore', value: 20 }, { name: 'Other', value: 8 },
      ],
      safety: [
        { name: 'Equipment', value: 35 }, { name: 'Slip/Fall', value: 25 },
        { name: 'Chemical', value: 15 }, { name: 'Vehicle', value: 18 }, { name: 'Other', value: 7 },
      ],
      equipment: [
        { name: 'Excavators', value: 28 }, { name: 'Haul Trucks', value: 32 },
        { name: 'Drills', value: 15 }, { name: 'Dozers', value: 14 }, { name: 'Loaders', value: 11 },
      ],
      water: [
        { name: 'Process Water', value: 45 }, { name: 'Dust Suppression', value: 20 },
        { name: 'Cooling', value: 15 }, { name: 'Domestic', value: 10 }, { name: 'Other', value: 10 },
      ],
      energy: [
        { name: 'Processing', value: 40 }, { name: 'Hauling', value: 25 },
        { name: 'Drilling', value: 15 }, { name: 'Lighting', value: 10 }, { name: 'Office', value: 10 },
      ],
      security: [
        { name: 'Gate Access', value: 38 }, { name: 'Perimeter', value: 22 },
        { name: 'Restricted', value: 20 }, { name: 'CCTV Alerts', value: 12 }, { name: 'Other', value: 8 },
      ],
    };
    return data[this.selectedReportType] || data['production'];
  }

  exportCSV(): void {
    if (!this.tableData.length) return;
    const headers = Object.keys(this.tableData[0]).join(',');
    const rows = this.tableData.map(r => Object.values(r).join(',')).join('\n');
    const blob = new Blob([headers + '\n' + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${this.selectedReportType}_report_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  exportPDF(): void {
    window.print();
  }

  private getMockKpis(type: ReportType): ReportKpi[] {
    const data: Record<string, ReportKpi[]> = {
      production: [
        { label: 'Total Ore Extracted', value: '156.2K tons', change: 4.2, trend: 'up' },
        { label: 'Avg Yield Rate', value: '88.4%', change: 1.8, trend: 'up' },
        { label: 'Peak Output', value: '2,840 tons', change: 0, trend: 'up' },
        { label: 'Target Achievement', value: '94.2%', change: 2.1, trend: 'up' },
      ],
      safety: [
        { label: 'Total Incidents', value: '3', change: -12, trend: 'down' },
        { label: 'Compliance Score', value: '96.5%', change: 1.4, trend: 'up' },
        { label: 'Near Misses', value: '12', change: -8, trend: 'down' },
        { label: 'Inspections Done', value: '601', change: 5, trend: 'up' },
      ],
      equipment: [
        { label: 'Avg Uptime', value: '93.2%', change: 2.3, trend: 'up' },
        { label: 'Maintenance Hours', value: '284h', change: -6, trend: 'down' },
        { label: 'Fuel Consumed', value: '45.2K L', change: -3.2, trend: 'down' },
        { label: 'Avg Active Fleet', value: '89', change: 1, trend: 'up' },
      ],
      water: [
        { label: 'Total Consumption', value: '285K m³', change: -2.1, trend: 'down' },
        { label: 'Water Recycled', value: '128K m³', change: 5.4, trend: 'up' },
        { label: 'Avg pH Level', value: '7.18', change: 0, trend: 'up' },
        { label: 'Recycling Rate', value: '71.2%', change: 3.8, trend: 'up' },
      ],
      energy: [
        { label: 'Total Consumption', value: '425K kWh', change: -1.5, trend: 'down' },
        { label: 'Solar Generation', value: '105K kWh', change: 8.2, trend: 'up' },
        { label: 'Avg Cost/kWh', value: '$0.098', change: -4.1, trend: 'down' },
        { label: 'Renewable Share', value: '24.8%', change: 6.3, trend: 'up' },
      ],
      security: [
        { label: 'Access Events', value: '4,230', change: 0, trend: 'up' },
        { label: 'Total Alerts', value: '34', change: -15, trend: 'down' },
        { label: 'Camera Uptime', value: '98.2%', change: 0.5, trend: 'up' },
        { label: 'Perimeter Breaches', value: '2', change: -20, trend: 'down' },
      ],
    };
    return data[type] || data['production'];
  }

  private getMockTableData(type: string): any[] {
    const rows = [];
    for (let i = 0; i < 15; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      rows.push({
        date: d.toLocaleDateString(),
        metric1: Math.round(2000 + Math.random() * 4000),
        metric2: (80 + Math.random() * 15).toFixed(1) + '%',
        metric3: Math.round(50 + Math.random() * 100),
        status: ['Optimal', 'Good', 'Warning'][Math.floor(Math.random() * 3)],
      });
    }
    return rows;
  }
}