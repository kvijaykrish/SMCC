import { Component } from '@angular/core';

@Component({
  selector: 'app-geo-spatial',
  standalone: true,
  template: '<p>Geo-Spatial component disabled for build</p>',
})
export class GeoSpatialComponent {}
