import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { Subject, takeUntil, interval } from 'rxjs';
import { AssetService } from '../../core/services/asset.service';
import { WebSocketService } from '../../core/services/websocket.service';
import { Asset } from '../../core/models/asset.model';

interface MockComponent {
  id: string;
  name: string;
  healthScore: number;
  status: 'optimal' | 'good' | 'warning' | 'critical';
  temperature: number;
  operatingHours: number;
  nextMaintenanceHours: number;
}

interface SensorNode {
  key: string;
  label: string;
  value: string;
  color: string;
  cx: number;
  cy: number;
}

const SENSOR_DATA: Record<string, SensorNode[]> = {
  Excavator: [
    { key: 'engine', label: 'ENGINE', value: '2,100 RPM', color: '#10b981', cx: 230, cy: 280 },
    { key: 'hydraulic', label: 'HYDRAULIC', value: '3,200 PSI', color: '#3b82f6', cx: 335, cy: 330 },
    { key: 'track', label: 'TRACK WEAR', value: '68%', color: '#f59e0b', cx: 270, cy: 400 },
  ],
  'Haul Truck': [
    { key: 'engine', label: 'ENGINE', value: '1,800 RPM', color: '#10b981', cx: 157, cy: 280 },
    { key: 'payload', label: 'PAYLOAD', value: '220 tonnes', color: '#3b82f6', cx: 350, cy: 290 },
    { key: 'tire', label: 'TIRE PSI', value: '110 PSI', color: '#f59e0b', cx: 435, cy: 380 },
  ],
  Drill: [
    { key: 'engine', label: 'ENGINE', value: '1,650 RPM', color: '#10b981', cx: 225, cy: 330 },
    { key: 'depth', label: 'DRILL DEPTH', value: '45.2m', color: '#3b82f6', cx: 417, cy: 200 },
    { key: 'torque', label: 'TORQUE', value: '85 kN\u00B7m', color: '#f59e0b', cx: 330, cy: 350 },
  ],
  Dozer: [
    { key: 'engine', label: 'ENGINE', value: '1,950 RPM', color: '#10b981', cx: 247, cy: 260 },
    { key: 'fuel', label: 'FUEL LEVEL', value: '78%', color: '#3b82f6', cx: 380, cy: 270 },
    { key: 'blade', label: 'BLADE LOAD', value: '14.2 kN', color: '#f59e0b', cx: 130, cy: 295 },
  ],
};

const POLYGON_COUNTS: Record<string, string> = {
  Excavator: '42.5K', 'Haul Truck': '36.2K', Drill: '28.8K', Dozer: '31.3K',
};
const VERTEX_COUNTS: Record<string, string> = {
  Excavator: '21.3K', 'Haul Truck': '18.1K', Drill: '14.4K', Dozer: '15.7K',
};

@Component({
  selector: 'app-digital-twin',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './digital-twin.component.html',
  styleUrls: ['./digital-twin.component.scss']
})
export class DigitalTwinComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private route = inject(ActivatedRoute);
  private assetService = inject(AssetService);
  private wsService = inject(WebSocketService);

  assetId = '';
  selectedAsset: Asset | null = null;
  selectedComponent: MockComponent | null = null;
  isSimulating = true;
  viewMode: 'solid' | 'wireframe' | '3d' = '3d';
  loading = true;
  selectedAssetType = 'Excavator';
  rotationX = 20;
  rotationY = 0;

  assetList = [
    { id: 'EXC-001', name: 'Excavator Alpha', type: 'Excavator' },
    { id: 'HTK-045', name: 'Haul Truck 45', type: 'Haul Truck' },
    { id: 'DRL-012', name: 'Drill Rig 12', type: 'Drill' },
    { id: 'DOZ-008', name: 'Dozer Delta', type: 'Dozer' },
  ];

  // Helper arrays for ngFor
  trackPads = Array.from({ length: 14 }, (_, i) => i);

  sensorNodes: SensorNode[] = SENSOR_DATA['Excavator'];

  mockComponents: MockComponent[] = [
    { id: 'engine', name: 'Engine System', healthScore: 94, status: 'optimal', temperature: 78, operatingHours: 1250, nextMaintenanceHours: 250 },
    { id: 'hydraulics', name: 'Hydraulic System', healthScore: 88, status: 'good', temperature: 65, operatingHours: 1250, nextMaintenanceHours: 150 },
    { id: 'transmission', name: 'Transmission', healthScore: 92, status: 'optimal', temperature: 72, operatingHours: 1250, nextMaintenanceHours: 200 },
    { id: 'tracks', name: 'Track System', healthScore: 76, status: 'warning', temperature: 45, operatingHours: 1250, nextMaintenanceHours: 50 },
  ];

  alerts = [
    { id: 'A-001', severity: 'warning', component: 'Track System', message: 'Increased wear detected - maintenance recommended within 50 hours', time: '15 mins ago' },
    { id: 'A-002', severity: 'info', component: 'Hydraulic System', message: 'Oil temperature within normal range', time: '1 hour ago' },
  ];

  get opVal(): number {
    return this.viewMode === '3d' ? 0.88 : 1;
  }

  ngOnInit(): void {
    this.route.params.pipe(takeUntil(this.destroy$)).subscribe(params => {
      this.assetId = params['id'];
      this.loadAssetData();
    });

    // Auto-rotate
    interval(50).pipe(takeUntil(this.destroy$)).subscribe(() => {
      if (this.isSimulating) {
        this.rotationY = (this.rotationY + 0.4) % 360;
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  private loadAssetData(): void {
    if (this.assetId && this.assetId !== 'default') {
      // Use the digital-twin endpoint which returns components, sensors, alerts
      this.assetService.getDigitalTwin(this.assetId)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (twinData: any) => {
            if (twinData.asset) {
              this.selectedAsset = {
                id: twinData.asset.id,
                assetId: twinData.asset.assetId,
                name: twinData.asset.name,
                type: twinData.asset.type,
                status: twinData.asset.status,
                operatingHours: twinData.asset.operatingHours,
                manufacturer: twinData.asset.manufacturer,
                model: twinData.asset.model,
              } as any;

              // Map type for dropdown
              const typeMap: Record<string, string> = {
                excavator: 'Excavator', haul_truck: 'Haul Truck',
                drill: 'Drill', dozer: 'Dozer', loader: 'Loader',
              };
              this.selectedAssetType = typeMap[twinData.asset.type] || 'Excavator';
              this.sensorNodes = SENSOR_DATA[this.selectedAssetType] || SENSOR_DATA['Excavator'];
            }

            // Integrate real components
            if (twinData.components && twinData.components.length > 0) {
              this.mockComponents = twinData.components.map((c: any) => ({
                id: c.id,
                name: c.name,
                healthScore: c.healthScore,
                status: c.status,
                temperature: c.temperature,
                operatingHours: c.operatingHours,
                nextMaintenanceHours: c.nextMaintenanceHours,
              }));
            }

            // Integrate real alerts
            if (twinData.alerts && twinData.alerts.length > 0) {
              this.alerts = twinData.alerts;
            }

            // Integrate real sensor data
            if (twinData.sensors && twinData.sensors.length > 0) {
              this.sensorNodes = twinData.sensors;
            }

            this.selectedComponent = this.mockComponents[0];
            this.loading = false;

            // Subscribe to real-time sensor updates
            this.wsService.subscribeToDigitalTwin(twinData.asset?.id || this.assetId)
              .pipe(takeUntil(this.destroy$))
              .subscribe((sensorUpdate: any) => {
                if (sensorUpdate.sensors) {
                  // Update component temperatures from live data
                  const engineComp = this.mockComponents.find(c => c.id === 'engine');
                  if (engineComp && sensorUpdate.sensors.engineTemp) {
                    engineComp.temperature = Math.round(sensorUpdate.sensors.engineTemp);
                  }
                }
              });
          },
          error: () => {
            this.loading = false;
            this.selectedComponent = this.mockComponents[0];
          }
        });
    } else {
      this.loading = false;
      this.selectedComponent = this.mockComponents[0];
    }
  }

  onAssetTypeChange(type: string): void {
    this.selectedAssetType = type;
    this.sensorNodes = SENSOR_DATA[type] || SENSOR_DATA['Excavator'];
  }

  getCurrentAssetName(): string {
    const a = this.assetList.find(x => x.type === this.selectedAssetType);
    return this.selectedAsset?.name || a?.name || 'Unknown Asset';
  }

  getCurrentAssetId(): string {
    const a = this.assetList.find(x => x.type === this.selectedAssetType);
    return this.selectedAsset?.assetId || a?.id || 'N/A';
  }

  getPolygonCount(): string {
    return POLYGON_COUNTS[this.selectedAssetType] || '24.5K';
  }

  getVertexCount(): string {
    return VERTEX_COUNTS[this.selectedAssetType] || '12.3K';
  }

  resetRotation(): void {
    this.rotationX = 20;
    this.rotationY = 0;
  }

  fillGrad(grad: string): string {
    return this.viewMode === 'wireframe' ? 'none' : grad;
  }

  strokeColor(col: string): string {
    return this.viewMode === 'wireframe' ? '#3b82f6' : col;
  }

  selectComponent(comp: MockComponent): void {
    this.selectedComponent = comp;
  }

  getHealthColor(health: number): string {
    if (health >= 90) return 'bg-green-500';
    if (health >= 75) return 'bg-blue-500';
    return 'bg-amber-500';
  }

  getHealthTextColor(health: number): string {
    if (health >= 90) return 'text-green-400';
    if (health >= 75) return 'text-blue-400';
    return 'text-amber-400';
  }

  getStatusClass(status: string): string {
    const classes: Record<string, string> = {
      optimal: 'bg-green-500/10 text-green-400',
      good: 'bg-blue-500/10 text-blue-400',
      warning: 'bg-amber-500/10 text-amber-400',
      critical: 'bg-red-500/10 text-red-400'
    };
    return classes[status] || classes['optimal'];
  }
}