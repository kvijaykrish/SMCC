import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { SecurityService } from '../../core/services/security.service';
import { WebSocketService } from '../../core/services/websocket.service';

interface CameraFeed {
  id: string;
  name: string;
  location: string;
  status: 'live' | 'offline';
  zone: string;
  resolution: string;
  fps: number;
  recording: boolean;
}

@Component({
  selector: 'app-video-stream',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './video-stream.component.html',
  styleUrls: ['./video-stream.component.scss']
})
export class VideoStreamComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private securityService = inject(SecurityService);
  private wsService = inject(WebSocketService);

  viewMode: 'single' | 'quad' | 'grid' = 'single';
  selectedCamera!: CameraFeed;
  zoom = 100;
  loading = true;

  cameras: CameraFeed[] = [];

  recentEvents: any[] = [];

  ngOnInit(): void {
    this.loadCameras();
    this.subscribeToRealtime();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadCameras(): void {
    this.securityService.getCameras().pipe(takeUntil(this.destroy$)).subscribe({
      next: (cams: any[]) => {
        if (cams && cams.length > 0) {
          this.cameras = cams.map((c: any) => ({
            id: c.camera_id || c.cameraId || c.id,
            name: c.name,
            location: c.location || c.zone_name || '',
            status: (c.status === 'active' || c.status === 'online') ? 'live' as const : 'offline' as const,
            zone: c.zone_name || c.zone || '',
            resolution: c.resolution || '1080p',
            fps: c.fps || 30,
            recording: c.status === 'active' || c.status === 'online',
          }));
        } else {
          this.cameras = this.getFallbackCameras();
        }
        this.selectedCamera = this.cameras[0];
        this.loading = false;
      },
      error: () => {
        this.cameras = this.getFallbackCameras();
        this.selectedCamera = this.cameras[0];
        this.loading = false;
      }
    });
  }

  private subscribeToRealtime(): void {
    this.wsService.subscribeToSecurityEvents()
      .pipe(takeUntil(this.destroy$))
      .subscribe((event: any) => {
        this.recentEvents.unshift({
          id: event.id,
          camera: event.camera || 'CAM-XXX',
          type: event.type || 'Event',
          timestamp: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          severity: event.severity || 'info',
        });
        if (this.recentEvents.length > 6) this.recentEvents.pop();
      });
  }

  private getFallbackCameras(): CameraFeed[] {
    return [
      { id: 'CAM-001', name: 'Main Gate', location: 'Perimeter - North', status: 'live', zone: 'Perimeter', resolution: '1080p', fps: 30, recording: true },
      { id: 'CAM-002', name: 'Zone A Entry', location: 'Zone A - Primary Pit', status: 'live', zone: 'Zone A', resolution: '1080p', fps: 30, recording: true },
      { id: 'CAM-003', name: 'Processing Plant', location: 'Zone B - Processing', status: 'live', zone: 'Zone B', resolution: '4K', fps: 60, recording: true },
      { id: 'CAM-004', name: 'Maintenance Bay', location: 'Zone D - Maintenance', status: 'offline', zone: 'Zone D', resolution: '1080p', fps: 30, recording: false },
      { id: 'CAM-005', name: 'Fuel Station', location: 'Zone B - Fuel Depot', status: 'live', zone: 'Zone B', resolution: '1080p', fps: 30, recording: true },
      { id: 'CAM-006', name: 'South Perimeter', location: 'Perimeter - South', status: 'live', zone: 'Perimeter', resolution: '1080p', fps: 30, recording: true },
    ];
  }

  get activeCameras(): CameraFeed[] {
    return this.cameras.filter(c => c.status === 'live');
  }

  selectCamera(camera: CameraFeed): void {
    this.selectedCamera = camera;
    this.viewMode = 'single';
  }

  setZoom(value: number): void {
    this.zoom = Math.max(100, Math.min(400, value));
  }
}