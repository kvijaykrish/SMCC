import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subject, takeUntil, forkJoin } from 'rxjs';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartConfiguration } from 'chart.js';
import { SafetyService } from '../../core/services/safety.service';

@Component({
  selector: 'app-safety-training',
  standalone: true,
  imports: [CommonModule, BaseChartDirective],
  templateUrl: './safety-training.component.html',
  styleUrls: ['./safety-training.component.scss']
})
export class SafetyTrainingComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private safetyService = inject(SafetyService);
  loading = true;

  summary = { safetyScore: 0, activeTraining: 0, incidents30d: 0, certifications: 0 };

  trainingPrograms: any[] = [];
  vrSimulations: any[] = [];

  statsCards = [
    { title: 'Days Without Incident', value: '87', desc: 'Target: 365 days', color: 'from-green-600 to-green-700' },
    { title: 'Training Completion', value: '94%', desc: 'Above industry average', color: 'from-blue-600 to-blue-700' },
    { title: 'Safety Compliance', value: '99.2%', desc: 'Meets all regulations', color: 'from-purple-600 to-purple-700' },
  ];

  // Safety Metrics Bar Chart
  metricsChartData: ChartData<'bar'> = { labels: [], datasets: [] };
  metricsChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  // Certification Doughnut
  certChartData: ChartData<'doughnut'> = { labels: [], datasets: [] };
  certChartOptions: ChartConfiguration<'doughnut'>['options'] = {
    responsive: true, maintainAspectRatio: false, cutout: '60%',
    plugins: { legend: { display: false } },
  };

  certStatus = [
    { name: 'Current', value: 285, color: '#10b981' },
    { name: 'Expiring Soon', value: 45, color: '#f59e0b' },
    { name: 'Expired', value: 12, color: '#ef4444' },
  ];

  ngOnInit(): void {
    this.loadData();
  }

  ngOnDestroy(): void { this.destroy$.next(); this.destroy$.complete(); }

  loadData(): void {
    forkJoin({
      summary: this.safetyService.getSummary(),
      training: this.safetyService.getTrainingPrograms(),
      vr: this.safetyService.getVRSimulations(),
      metricsChart: this.safetyService.getMetricsChartData(),
      certChart: this.safetyService.getCertificationChartData(),
    }).pipe(takeUntil(this.destroy$)).subscribe({
      next: ({ summary, training, vr, metricsChart, certChart }) => {
        // Summary
        this.summary = {
          safetyScore: summary.safetyScore || 98.5,
          activeTraining: summary.activeTraining || 342,
          incidents30d: summary.incidents30d || 1,
          certifications: summary.certifications || 285,
        };

        // Training programs from API
        if (training && training.length > 0) {
          this.trainingPrograms = training.map((t: any) => ({
            id: t.programId || t.id,
            name: t.name || t.title,
            type: t.type || t.training_type || 'Classroom',
            status: t.status || 'active',
            enrolled: t.enrolledCount || t.enrolled_count || 0,
            completed: t.completedCount || t.completed_count || 0,
            duration: t.duration || `${t.duration_hours || 2} hours`,
          }));
        } else {
          this.trainingPrograms = this.getFallbackTraining();
        }

        // VR Simulations from API
        if (vr && vr.length > 0) {
          this.vrSimulations = vr.map((v: any) => ({
            id: v.simulationId || v.id,
            name: v.name,
            difficulty: v.difficulty || 'Intermediate',
            completionRate: v.completionRate || v.completion_rate || 0,
            avgScore: v.averageScore || v.average_score || 0,
          }));
        } else {
          this.vrSimulations = this.getFallbackVR();
        }

        // Metrics chart
        if (metricsChart && metricsChart.length > 0) {
          this.metricsChartData = {
            labels: metricsChart.map((d: any) => d.week),
            datasets: [
              { data: metricsChart.map((d: any) => d.incidents), label: 'Incidents', backgroundColor: '#ef4444' },
              { data: metricsChart.map((d: any) => d.nearMiss), label: 'Near Miss', backgroundColor: '#f59e0b' },
              { data: metricsChart.map((d: any) => d.inspections), label: 'Inspections', backgroundColor: '#10b981' },
            ],
          };
        } else {
          this.buildFallbackMetricsChart();
        }

        // Cert chart
        if (certChart && certChart.length > 0) {
          this.certStatus = certChart;
        }
        this.certChartData = {
          labels: this.certStatus.map(d => d.name),
          datasets: [{ data: this.certStatus.map(d => d.value), backgroundColor: this.certStatus.map(d => d.color), borderWidth: 0 }],
        };

        this.loading = false;
      },
      error: () => {
        this.trainingPrograms = this.getFallbackTraining();
        this.vrSimulations = this.getFallbackVR();
        this.buildFallbackMetricsChart();
        this.certChartData = {
          labels: this.certStatus.map(d => d.name),
          datasets: [{ data: this.certStatus.map(d => d.value), backgroundColor: this.certStatus.map(d => d.color), borderWidth: 0 }],
        };
        this.loading = false;
      }
    });
  }

  private buildFallbackMetricsChart(): void {
    const metrics = [
      { week: 'Week 1', incidents: 0, nearMiss: 2, inspections: 145 },
      { week: 'Week 2', incidents: 1, nearMiss: 1, inspections: 152 },
      { week: 'Week 3', incidents: 0, nearMiss: 3, inspections: 148 },
      { week: 'Week 4', incidents: 0, nearMiss: 1, inspections: 156 },
    ];
    this.metricsChartData = {
      labels: metrics.map(d => d.week),
      datasets: [
        { data: metrics.map(d => d.incidents), label: 'Incidents', backgroundColor: '#ef4444' },
        { data: metrics.map(d => d.nearMiss), label: 'Near Miss', backgroundColor: '#f59e0b' },
        { data: metrics.map(d => d.inspections), label: 'Inspections', backgroundColor: '#10b981' },
      ],
    };
  }

  private getFallbackTraining(): any[] {
    return [
      { id: 'TR-001', name: 'Emergency Response Procedures', type: 'VR Simulation', status: 'active', enrolled: 145, completed: 132, duration: '2 hours' },
      { id: 'TR-002', name: 'Heavy Equipment Operation', type: 'VR Simulation', status: 'active', enrolled: 89, completed: 76, duration: '4 hours' },
      { id: 'TR-003', name: 'Hazard Identification', type: 'Classroom', status: 'active', enrolled: 210, completed: 198, duration: '3 hours' },
      { id: 'TR-004', name: 'First Aid & CPR', type: 'Practical', status: 'active', enrolled: 156, completed: 143, duration: '6 hours' },
      { id: 'TR-005', name: 'Mine Safety Protocols', type: 'VR Simulation', status: 'scheduled', enrolled: 67, completed: 0, duration: '5 hours' },
    ];
  }

  private getFallbackVR(): any[] {
    return [
      { id: 'VR-001', name: 'Underground Evacuation', difficulty: 'Advanced', completionRate: 87, avgScore: 92 },
      { id: 'VR-002', name: 'Fire Response Training', difficulty: 'Intermediate', completionRate: 94, avgScore: 88 },
      { id: 'VR-003', name: 'Equipment Failure Scenarios', difficulty: 'Advanced', completionRate: 78, avgScore: 85 },
      { id: 'VR-004', name: 'Chemical Spill Response', difficulty: 'Expert', completionRate: 65, avgScore: 81 },
    ];
  }

  getProgress(enrolled: number, completed: number): number {
    return enrolled > 0 ? Math.round((completed / enrolled) * 100) : 0;
  }

  getTypeClass(type: string): string {
    const m: Record<string, string> = {
      'VR Simulation': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
      'Classroom': 'bg-green-500/10 text-green-400 border-green-500/20',
      'Practical': 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    };
    return m[type] || m['Classroom'];
  }

  getDifficultyColor(d: string): string {
    const m: Record<string, string> = { 'Beginner': 'text-green-400', 'Intermediate': 'text-blue-400', 'Advanced': 'text-amber-400', 'Expert': 'text-red-400' };
    return m[d] || 'text-slate-400';
  }
}
