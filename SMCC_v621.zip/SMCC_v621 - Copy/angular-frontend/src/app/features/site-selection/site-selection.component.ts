import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { SiteService } from '../../core/services/site.service';
import { AuthService } from '../../core/services/auth.service';
import { Site } from '../../core/models/site.model';
import { MineMapComponent } from '../../components/mine-map.component';

@Component({
  selector: 'app-site-selection',
  standalone: true,
  imports: [CommonModule, MineMapComponent],
  templateUrl: './site-selection.component.html',
  styleUrls: ['./site-selection.component.scss']
})
export class SiteSelectionComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private siteService = inject(SiteService);
  private authService = inject(AuthService);
  private router = inject(Router);

  sites: Site[] = [];
  loading = true;
  error = '';
  currentUser$ = this.authService.currentUser$;

  // view mode (grid or map) and selection state when in map mode
  viewMode: 'grid' | 'map' = 'grid';
  selectedMapSite: string | null = null;
  
  statistics = {
    totalSites: 0,
    operationalSites: 0,
    totalAnnualCapacity: 0,
    totalWorkforce: 0,
    countriesCount: 0
  };

  ngOnInit(): void {
    this.loadSites();
    this.loadStatistics();

    // listen for navigation events from map component (fallback for custom events)
    window.addEventListener('mine-site-navigate', this.onMapNavigate as EventListener);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    window.removeEventListener('mine-site-navigate', this.onMapNavigate as EventListener);
  }

  loadSites(): void {
    this.siteService.getSites()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (sites) => {
          this.sites = sites;
          this.loading = false;
        },
        error: (error) => {
          this.error = 'Failed to load sites. Please try again.';
          this.loading = false;
          console.error('Error loading sites:', error);
        }
      });
  }

  private loadStatistics(): void {
    this.siteService.getSitesStatistics()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (stats) => {
          this.statistics = {
            totalSites: parseInt(stats.total_sites) || 0,
            operationalSites: parseInt(stats.operational_sites) || 0,
            totalAnnualCapacity: parseFloat(stats.total_annual_capacity) || 0,
            totalWorkforce: parseInt(stats.total_workforce) || 0,
            countriesCount: parseInt(stats.countries_count) || 0
          };
        },
        error: (error) => {
          console.error('Error loading statistics:', error);
        }
      });
  }

  selectSite(site: Site): void {
    this.siteService.selectSite(site);
    this.router.navigate(['/dashboard']);
  }

  /** called when a marker is clicked on the map */
  onMapSiteSelected(siteId: string): void {
    this.selectedMapSite = siteId;
  }

  /** called when the "enter" button in a popup is pressed */
  onMapNavigate = (e: any): void => {
    const siteId = e.detail || e; // support event data or direct emit
    const site = this.sites.find(s => s.id === siteId);
    if (site) {
      this.selectSite(site);
    }
  };

  getStatusColor(status: string): string {
    const colors: Record<string, string> = {
      'operational': 'bg-green-100 text-green-800 border-green-200',
      'maintenance': 'bg-amber-100 text-amber-800 border-amber-200',
      'commissioning': 'bg-blue-100 text-blue-800 border-blue-200',
      'decommissioning': 'bg-orange-100 text-orange-800 border-orange-200',
      'closed': 'bg-slate-100 text-slate-800 border-slate-200'
    };
    return colors[status] || 'bg-slate-100 text-slate-800 border-slate-200';
  }

  getStatusIcon(status: string): string {
    const icons: Record<string, string> = {
      'operational': '✓',
      'maintenance': '⚙',
      'commissioning': '⚡',
      'decommissioning': '⚠',
      'closed': '✕'
    };
    return icons[status] || '•';
  }

  getSiteTypeLabel(type: string): string {
    const labels: Record<string, string> = {
      'open_pit': 'Open Pit',
      'underground': 'Underground',
      'processing_plant': 'Processing Plant',
      'exploration': 'Exploration'
    };
    return labels[type] || type;
  }

  formatNumber(num: number | undefined): string {
    if (!num) return '0';
    return num.toLocaleString();
  }

  formatCapacity(tonnes: number | undefined): string {
    if (!tonnes) return '0';
    if (tonnes >= 1000000) {
      return (tonnes / 1000000).toFixed(1) + 'M';
    }
    if (tonnes >= 1000) {
      return (tonnes / 1000).toFixed(0) + 'K';
    }
    return tonnes.toString();
  }

  onLogout(): void {
    this.authService.logout();
  }
}
