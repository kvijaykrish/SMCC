import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Subject, takeUntil, forkJoin } from 'rxjs';
import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration, ChartData } from 'chart.js';
import { DashboardService } from '../../core/services/dashboard.service';
import { WebSocketService } from '../../core/services/websocket.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, BaseChartDirective],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private dashboardService = inject(DashboardService);
  private wsService = inject(WebSocketService);

  loading = true;
  currentTime = new Date();
  siteName = 'Mining Site';

  metrics = {
    totalAssets: 0, activeAssets: 0, networkUptime: 0,
    activeAlerts: 0, safetyScore: 0, safetyIncidents: 0,
    waterQuality: 0, avgHealth: 0
  };

  // Performance Area Chart
  performanceChartData: ChartData<'line'> = { labels: [], datasets: [] };
  performanceChartOptions: ChartConfiguration<'line'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  // Asset Distribution Doughnut
  assetPieData: ChartData<'doughnut'> = { labels: [], datasets: [] };
  assetPieOptions: ChartConfiguration<'doughnut'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: true, position: 'bottom', labels: { color: '#e2e8f0', padding: 12 } } },
    cutout: '65%',
  };

  // System Health Radar
  radarData: ChartData<'radar'> = { labels: [], datasets: [] };
  radarOptions: ChartConfiguration<'radar'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      r: {
        min: 0, max: 100,
        ticks: { color: '#94a3b8', backdropColor: 'transparent' },
        grid: { color: '#334155' },
        pointLabels: { color: '#94a3b8' },
        angleLines: { color: '#334155' },
      }
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  assetDistribution: { name: string; value: number; color: string }[] = [];
  recentAlerts: any[] = [];

  modules = [
    { icon: 'cpu', title: 'Connected Assets', subtitle: 'Loading...', color: 'from-blue-600 to-blue-700', route: '/connected-assets' },
    { icon: 'wifi', title: 'Private 5G', subtitle: 'Loading...', color: 'from-purple-600 to-purple-700', route: '/private-5g' },
    { icon: 'map', title: 'Geo-Spatial', subtitle: 'Live Tracking', color: 'from-green-600 to-green-700', route: '/geo-spatial' },
    { icon: 'shield', title: 'Security', subtitle: '24/7 Monitoring', color: 'from-red-600 to-red-700', route: '/security' },
    { icon: 'droplet', title: 'Water Mgmt', subtitle: 'Loading...', color: 'from-cyan-600 to-cyan-700', route: '/water-management' },
    { icon: 'hardhat', title: 'Safety Training', subtitle: 'Loading...', color: 'from-orange-600 to-orange-700', route: '/safety-training' },
  ];

  activities: any[] = [];

  private timer: any;

  ngOnInit(): void {
    this.timer = setInterval(() => this.currentTime = new Date(), 1000);

    try {
      const stored = localStorage.getItem('selectedSite');
      if (stored) { this.siteName = JSON.parse(stored).name || 'Mining Site'; }
    } catch {}

    this.loadData();
    this.subscribeToRealtime();
  }

  ngOnDestroy(): void {
    clearInterval(this.timer);
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadData(): void {
    forkJoin({
      summary: this.dashboardService.getSummary(),
      performance: this.dashboardService.getPerformance(),
      distribution: this.dashboardService.getAssetDistribution(),
      health: this.dashboardService.getSystemHealth(),
      activity: this.dashboardService.getRecentActivity(),
    }).pipe(takeUntil(this.destroy$)).subscribe({
      next: ({ summary, performance, distribution, health, activity }) => {
        this.metrics = {
          totalAssets: summary.assets?.total || 847,
          activeAssets: summary.assets?.active || 687,
          networkUptime: summary.network?.uptime || 99.8,
          activeAlerts: summary.alerts?.active || 3,
          safetyScore: summary.safety?.score || 98.5,
          safetyIncidents: summary.safety?.incidents30d || 1,
          waterQuality: summary.water?.quality || 97.8,
          avgHealth: summary.assets?.avgHealth || 92,
        };

        // Update module subtitles with live data
        this.modules[0].subtitle = `${this.metrics.activeAssets} Active`;
        this.modules[1].subtitle = `${this.metrics.networkUptime}% Uptime`;
        this.modules[4].subtitle = `${this.metrics.waterQuality}% Quality`;
        this.modules[5].subtitle = `Score: ${this.metrics.safetyScore}`;

        // Performance chart
        this.performanceChartData = {
          labels: performance.map((d: any) => d.time),
          datasets: [
            { data: performance.map((d: any) => d.efficiency), label: 'Efficiency %', borderColor: '#3b82f6', backgroundColor: 'rgba(59,130,246,0.15)', fill: true, tension: 0.4 },
            { data: performance.map((d: any) => d.output), label: 'Output (tons)', borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.15)', fill: true, tension: 0.4 },
          ],
        };

        // Asset pie chart
        this.assetDistribution = distribution;
        this.assetPieData = {
          labels: distribution.map((d: any) => d.name),
          datasets: [{
            data: distribution.map((d: any) => d.value),
            backgroundColor: distribution.map((d: any) => d.color),
            borderWidth: 0,
          }],
        };

        // Radar chart
        this.radarData = {
          labels: health.map((d: any) => d.system),
          datasets: [{
            data: health.map((d: any) => d.score),
            label: 'Health Score',
            backgroundColor: 'rgba(59,130,246,0.3)',
            borderColor: '#3b82f6',
            pointBackgroundColor: '#3b82f6',
          }],
        };

        // Recent activity from alerts
        if (activity && activity.length > 0) {
          this.activities = activity.slice(0, 5).map((a: any) => ({
            icon: this.getAlertIcon(a.alert_type),
            color: this.getSeverityColor(a.severity),
            title: a.title || a.alert_type,
            desc: a.message || '',
            time: this.timeAgo(a.triggered_at),
          }));
        } else {
          this.activities = this.getDefaultActivities();
        }

        this.loading = false;
      },
      error: () => {
        this.activities = this.getDefaultActivities();
        this.loading = false;
      }
    });
  }

  private subscribeToRealtime(): void {
    this.wsService.emit('subscribe:dashboard');
    this.wsService.on('dashboard:metrics')
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data.activeAssets) this.metrics.activeAssets = data.activeAssets;
        if (data.networkUptime) this.metrics.networkUptime = data.networkUptime;
        if (data.safetyScore) this.metrics.safetyScore = data.safetyScore;
        // Update module subtitles
        this.modules[0].subtitle = `${this.metrics.activeAssets} Active`;
        this.modules[1].subtitle = `${this.metrics.networkUptime}% Uptime`;
      });

    this.wsService.subscribeToAlerts()
      .pipe(takeUntil(this.destroy$))
      .subscribe((alert: any) => {
        this.recentAlerts.unshift(alert);
        if (this.recentAlerts.length > 10) this.recentAlerts.pop();
        this.metrics.activeAlerts = this.recentAlerts.length;
      });
  }

  private getAlertIcon(type: string): string {
    const m: Record<string, string> = {
      asset_malfunction: 'cpu', network_outage: 'wifi', maintenance_due: 'check',
      safety_violation: 'hardhat', water_quality: 'droplet', security_breach: 'shield',
    };
    return m[type] || 'alert';
  }

  private getSeverityColor(severity: string): string {
    const m: Record<string, string> = { critical: 'red', warning: 'amber', info: 'blue' };
    return m[severity] || 'slate';
  }

  private timeAgo(dateStr: string): string {
    if (!dateStr) return 'just now';
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins} min ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    return `${Math.floor(hours / 24)} day${Math.floor(hours / 24) > 1 ? 's' : ''} ago`;
  }

  private getDefaultActivities(): any[] {
    return [
      { icon: 'check', color: 'green', title: 'Digital Twin sync completed', desc: '847 assets synchronized successfully', time: '2 min ago' },
      { icon: 'alert', color: 'amber', title: 'Water usage spike detected', desc: 'Zone C exceeded threshold by 15%', time: '15 min ago' },
      { icon: 'wifi', color: 'blue', title: '5G network optimization', desc: 'Cell tower #4 signal improved to 98%', time: '1 hour ago' },
      { icon: 'hardhat', color: 'slate', title: 'Safety training scheduled', desc: 'Emergency response drill - Thursday 09:00 AM', time: '2 hours ago' },
      { icon: 'cpu', color: 'purple', title: 'Asset maintenance completed', desc: 'Excavator EX-042 returned to active service', time: '3 hours ago' },
    ];
  }
}
