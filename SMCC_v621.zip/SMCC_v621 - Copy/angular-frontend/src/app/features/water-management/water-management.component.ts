import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subject, takeUntil, forkJoin } from 'rxjs';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartConfiguration } from 'chart.js';
import { WaterService } from '../../core/services/water.service';
import { WebSocketService } from '../../core/services/websocket.service';

@Component({
  selector: 'app-water-management',
  standalone: true,
  imports: [CommonModule, BaseChartDirective],
  templateUrl: './water-management.component.html',
  styleUrls: ['./water-management.component.scss']
})
export class WaterManagementComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private waterService = inject(WaterService);
  private wsService = inject(WebSocketService);
  loading = true;
  selectedPipeline: string | null = null;

  summary = { dailyUsage: '10,000 m³', waterQuality: 97.8, systemPressure: 44, activePipelines: '5/6' };

  pipelineData: any[] = [];
  qualityMetrics: any[] = [];

  conservationCards = [
    { title: 'Water Savings', value: '12%', desc: 'Compared to last month', color: 'from-blue-600 to-blue-700' },
    { title: 'Reclaimed Water', value: '45%', desc: 'Of total water recycled', color: 'from-green-600 to-green-700' },
    { title: 'Treatment Efficiency', value: '98.5%', desc: 'Quality meets standards', color: 'from-purple-600 to-purple-700' },
  ];

  // Usage & Quality Chart
  usageChartData: ChartData<'line'> = { labels: [], datasets: [] };
  usageChartOptions: ChartConfiguration<'line'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { position: 'left', ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y1: { position: 'right', ticks: { color: '#94a3b8' }, grid: { display: false }, min: 90, max: 100 },
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  // Zone Usage Bar Chart
  zoneChartData: ChartData<'bar'> = { labels: [], datasets: [] };
  zoneChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8', maxRotation: 20 }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
    },
    plugins: { legend: { display: false } },
  };

  ngOnInit(): void {
    this.loadData();
    this.subscribeToRealtime();
  }

  ngOnDestroy(): void { this.destroy$.next(); this.destroy$.complete(); }

  loadData(): void {
    forkJoin({
      summary: this.waterService.getSummary(),
      pipelines: this.waterService.getPipelines(),
      quality: this.waterService.getWaterQuality(),
      usageChart: this.waterService.getUsageChartData(),
      zoneUsage: this.waterService.getUsageByZone(),
    }).pipe(takeUntil(this.destroy$)).subscribe({
      next: ({ summary, pipelines, quality, usageChart, zoneUsage }) => {
        // Summary
        this.summary = {
          dailyUsage: summary.dailyUsage || '10,000 m³',
          waterQuality: summary.waterQuality || 97.8,
          systemPressure: summary.systemPressure || 44,
          activePipelines: summary.activePipelines ? `${summary.activePipelines}/${summary.totalPipelines || 6}` : '5/6',
        };

        // Pipelines from API
        if (pipelines && pipelines.length > 0) {
          this.pipelineData = pipelines.map((p: any) => ({
            id: p.pipelineId || p.pipeline_id || p.id,
            name: p.name,
            status: p.status || 'optimal',
            flow: parseFloat(p.flowRate || p.flow_rate || 0),
            pressure: parseFloat(p.pressure || 0),
            temp: parseFloat(p.temperature || 18),
            location: p.location || '',
          }));
        } else {
          this.pipelineData = this.getFallbackPipelines();
        }

        // Quality from API
        if (quality && quality.length > 0) {
          this.qualityMetrics = quality.slice(0, 6).map((q: any) => ({
            parameter: q.parameter,
            value: q.value,
            optimal: q.optimalValue || q.optimal_value || q.value,
            unit: q.unit,
            status: q.status || 'good',
          }));
        } else {
          this.qualityMetrics = this.getFallbackQuality();
        }

        // Charts from API or fallback
        this.buildUsageChart(usageChart);
        this.buildZoneChart(zoneUsage);

        this.loading = false;
      },
      error: () => {
        this.pipelineData = this.getFallbackPipelines();
        this.qualityMetrics = this.getFallbackQuality();
        this.buildUsageChart([]);
        this.buildZoneChart([]);
        this.loading = false;
      }
    });
  }

  private subscribeToRealtime(): void {
    this.wsService.subscribeToWaterMetrics()
      .pipe(takeUntil(this.destroy$))
      .subscribe((data: any) => {
        if (data.qualityScore) this.summary.waterQuality = data.qualityScore;
        if (data.systemPressure) this.summary.systemPressure = data.systemPressure;
      });
  }

  private buildUsageChart(data: any[]): void {
    const chartData = data && data.length > 0 ? data : [
      { hour: '00:00', usage: 1250, quality: 98 },
      { hour: '04:00', usage: 980, quality: 97 },
      { hour: '08:00', usage: 1820, quality: 96 },
      { hour: '12:00', usage: 2100, quality: 97 },
      { hour: '16:00', usage: 1950, quality: 98 },
      { hour: '20:00', usage: 1450, quality: 97 },
    ];
    this.usageChartData = {
      labels: chartData.map(d => d.hour || d.time),
      datasets: [
        { data: chartData.map(d => d.usage), label: 'Usage (m³)', borderColor: '#3b82f6', backgroundColor: 'rgba(59,130,246,0.15)', fill: true, tension: 0.4, yAxisID: 'y' },
        { data: chartData.map(d => d.quality), label: 'Quality %', borderColor: '#10b981', backgroundColor: 'transparent', tension: 0.4, yAxisID: 'y1' },
      ],
    };
  }

  private buildZoneChart(data: any[]): void {
    const chartData = data && data.length > 0 ? data : [
      { zone: 'Zone A', usage: 3200 }, { zone: 'Zone B', usage: 2800 },
      { zone: 'Zone C', usage: 1900 }, { zone: 'Zone D', usage: 1200 }, { zone: 'Facilities', usage: 900 },
    ];
    this.zoneChartData = {
      labels: chartData.map(d => d.zone || d.name),
      datasets: [{ data: chartData.map(d => d.usage || d.value), label: 'Usage (m³)', backgroundColor: '#10b981', borderRadius: 4 }],
    };
  }

  private getFallbackPipelines(): any[] {
    return [
      { id: 'P-01', name: 'Main Supply Line', status: 'optimal', flow: 1250, pressure: 45, temp: 18, location: 'Zone A' },
      { id: 'P-02', name: 'Processing Water Feed', status: 'optimal', flow: 890, pressure: 42, temp: 19, location: 'Zone B' },
      { id: 'P-03', name: 'Dust Suppression Line', status: 'optimal', flow: 650, pressure: 48, temp: 17, location: 'Zone C' },
      { id: 'P-04', name: 'Equipment Cooling', status: 'warning', flow: 420, pressure: 38, temp: 22, location: 'Workshop' },
      { id: 'P-05', name: 'Reclaim Water Line', status: 'optimal', flow: 780, pressure: 44, temp: 20, location: 'Treatment' },
      { id: 'P-06', name: 'Emergency Reserve', status: 'optimal', flow: 0, pressure: 50, temp: 16, location: 'Storage' },
    ];
  }

  private getFallbackQuality(): any[] {
    return [
      { parameter: 'pH Level', value: 7.2, optimal: 7.0, unit: 'pH', status: 'good' },
      { parameter: 'Turbidity', value: 2.1, optimal: 2.0, unit: 'NTU', status: 'good' },
      { parameter: 'Dissolved O2', value: 8.5, optimal: 8.0, unit: 'mg/L', status: 'excellent' },
      { parameter: 'Temperature', value: 18, optimal: 18, unit: '°C', status: 'excellent' },
      { parameter: 'Conductivity', value: 420, optimal: 400, unit: 'μS/cm', status: 'good' },
      { parameter: 'Total Solids', value: 150, optimal: 200, unit: 'mg/L', status: 'excellent' },
    ];
  }

  getStatusClass(status: string): string {
    return status === 'optimal' ? 'bg-green-500/10 text-green-400 border-green-500/20' :
           status === 'warning' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
           'bg-red-500/10 text-red-400 border-red-500/20';
  }

  getQualityColorClass(status: string): string {
    return status === 'excellent' ? 'from-green-600 to-green-700' :
           status === 'good' ? 'from-blue-600 to-blue-700' : 'from-amber-600 to-amber-700';
  }
}
