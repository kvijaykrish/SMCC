import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

interface TourScene {
  id: string;
  title: string;
  subtitle: string;
  narration: string;
  duration: number;
  icon: string;
  accentColor: string;
  bullets: string[];
  stats?: { label: string; value: string }[];
}

@Component({
  selector: 'app-video-tour',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './video-tour.component.html',
  styleUrls: ['./video-tour.component.scss']
})
export class VideoTourComponent implements OnInit, OnDestroy {
  @Output() closeTour = new EventEmitter<void>();

  scenes: TourScene[] = [
    { id: 'intro', title: 'SDS Smart Mining Command Center', subtitle: 'Intelligent Operations. Unified Control.',
      narration: 'Welcome to the SDS Smart Mining Command Center — a unified digital platform with eight powerful modules.',
      duration: 12000, icon: '💎', accentColor: '#3b82f6', bullets: [], stats: [] },
    { id: 'dashboard', title: 'Centralized Dashboard', subtitle: 'Your Mine at a Glance',
      narration: 'The main dashboard provides a bird\'s-eye view of your entire operation with live KPI cards and interactive charts.',
      duration: 12000, icon: '📊', accentColor: '#3b82f6',
      bullets: ['Real-time KPI cards', 'Production & efficiency charts', 'Asset fleet radar', 'Quick-launch navigation'],
      stats: [{ label: 'Active Assets', value: '107' }, { label: 'Efficiency', value: '92%' }, { label: 'Uptime', value: '99.7%' }] },
    { id: 'assets', title: 'Connected Assets & Digital Twins', subtitle: 'Live 3D Models with Sensor Overlays',
      narration: 'Every asset has a photorealistic digital twin with animated sensor readouts and predictive maintenance alerts.',
      duration: 12000, icon: '🔧', accentColor: '#f59e0b',
      bullets: ['Isometric 3D models', 'Animated sensor readouts', 'Component-level health scoring', 'Predictive maintenance alerts'],
      stats: [{ label: 'Excavators', value: '24' }, { label: 'Health Avg', value: '91%' }, { label: 'Alerts', value: '3' }] },
    { id: '5g', title: 'Private 5G Network', subtitle: 'Ultra-Low Latency Connectivity',
      narration: 'Monitor your private 5G network with tower health, coverage maps, and sub-10ms latency.',
      duration: 12000, icon: '📡', accentColor: '#8b5cf6',
      bullets: ['Tower health monitoring', 'Signal coverage maps', 'Sub-10ms latency', 'Edge computing support'],
      stats: [{ label: 'Towers', value: '6' }, { label: 'Devices', value: '342' }, { label: 'Latency', value: '<8ms' }] },
    { id: 'geo', title: 'Geo-Spatial Intelligence', subtitle: 'Interactive Mapping',
      narration: 'Full interactive map with satellite views, asset markers, zone overlays and geofence alerting.',
      duration: 12000, icon: '🗺️', accentColor: '#06b6d4',
      bullets: ['Satellite/Terrain map tiles', 'Asset markers with popups', 'Zone overlays', 'Geofence alerting'],
      stats: [{ label: 'Zones', value: '6' }, { label: 'Tracked', value: '107' }, { label: 'Coverage', value: '35 km\u00B2' }] },
    { id: 'security', title: 'Integrated Security', subtitle: 'AI-Powered Surveillance',
      narration: 'Live multi-camera surveillance with AI anomaly detection and zone-based access control.',
      duration: 12000, icon: '🛡️', accentColor: '#ef4444',
      bullets: ['Multi-camera grid', 'AI anomaly detection', 'Access control', 'Incident logging'],
      stats: [{ label: 'Cameras', value: '24' }, { label: 'Events', value: '156' }, { label: 'Compliance', value: '98%' }] },
    { id: 'water', title: 'Water Management', subtitle: 'Animated Flow Diagram',
      narration: 'Animated flow diagram tracing water through treatment, distribution, and reclamation loops.',
      duration: 12000, icon: '💧', accentColor: '#3b82f6',
      bullets: ['Animated water flow', 'Treatment pipeline', '45% reclamation', 'Quality analytics'],
      stats: [{ label: 'Daily Usage', value: '10K m\u00B3' }, { label: 'Quality', value: '97.8%' }, { label: 'Reclaimed', value: '45%' }] },
    { id: 'safety', title: 'Safety & Training', subtitle: 'Certifications & Drills',
      narration: 'Track workforce certifications, safety drills, incident reports, and compliance scores.',
      duration: 12000, icon: '🎓', accentColor: '#10b981',
      bullets: ['Certification tracking', 'Drill scheduling', 'Incident heat maps', 'Compliance dashboard'],
      stats: [{ label: 'Workers', value: '1,247' }, { label: 'Certified', value: '96%' }, { label: 'Incidents', value: '0' }] },
    { id: 'reports', title: 'Historical Reports', subtitle: 'Analytics & Export',
      narration: 'Generate reports across six categories with interactive charts, KPI cards, and CSV/PDF export.',
      duration: 12000, icon: '📄', accentColor: '#6366f1',
      bullets: ['6 report categories', 'Interactive trend charts', 'Custom date ranges', 'CSV & PDF export'],
      stats: [{ label: 'Report Types', value: '6' }, { label: 'Data Points', value: '24K+' }, { label: 'Export', value: '3 formats' }] },
    { id: 'ai', title: 'AI Voice Assistant', subtitle: 'Natural Language Analytics',
      narration: 'Type or speak natural language queries to search 2,000+ mining events with instant visual results.',
      duration: 14000, icon: '🤖', accentColor: '#a855f7',
      bullets: ['Voice input with transcription', 'Natural language parsing', 'Interactive result charts', 'CSV download & reports'],
      stats: [{ label: 'Events', value: '2K+' }, { label: 'Voice Input', value: 'Yes' }, { label: 'Response', value: '<2s' }] },
    { id: 'benefits', title: 'Key Benefits', subtitle: 'Why SDS?',
      narration: '30% reduction in downtime, 12% water efficiency, 99.9% network uptime, AI-powered insights.',
      duration: 12000, icon: '🚀', accentColor: '#3b82f6',
      bullets: ['30% less unplanned downtime', '12% water efficiency gain', '99.9% network uptime', 'AI-powered analytics'],
      stats: [] },
    { id: 'closing', title: 'Ready to Transform Your Mine?', subtitle: 'Get Started with SDS Today',
      narration: 'Thank you for touring SDS. Contact our team to schedule a live demo or begin deployment.',
      duration: 12000, icon: '💎', accentColor: '#f59e0b', bullets: [], stats: [] },
  ];

  currentIndex = 0;
  playing = false;
  started = false;
  elapsed = 0;
  private timer: any;
  private synth = typeof window !== 'undefined' ? window.speechSynthesis : null;

  get scene(): TourScene { return this.scenes[this.currentIndex]; }
  get totalDuration(): number { return this.scenes.reduce((s, sc) => s + sc.duration, 0); }
  get globalElapsed(): number {
    return this.scenes.slice(0, this.currentIndex).reduce((s, sc) => s + sc.duration, 0) + this.elapsed;
  }
  get progressPct(): number { return (this.globalElapsed / this.totalDuration) * 100; }

  ngOnInit(): void {}

  ngOnDestroy(): void {
    this.stopTimer();
    this.synth?.cancel();
  }

  start(): void {
    this.started = true;
    this.playing = true;
    this.speak(this.scene.narration);
    this.startTimer();
  }

  togglePlay(): void {
    if (!this.started) { this.start(); return; }
    this.playing = !this.playing;
    if (this.playing) {
      this.synth?.resume();
      this.startTimer();
    } else {
      this.synth?.pause();
      this.stopTimer();
    }
  }

  next(): void {
    if (this.currentIndex < this.scenes.length - 1) this.goTo(this.currentIndex + 1);
  }

  prev(): void {
    if (this.currentIndex > 0) this.goTo(this.currentIndex - 1);
  }

  goTo(idx: number): void {
    this.synth?.cancel();
    this.stopTimer();
    this.currentIndex = idx;
    this.elapsed = 0;
    if (this.playing) {
      this.speak(this.scene.narration);
      this.startTimer();
    }
  }

  close(): void {
    this.synth?.cancel();
    this.stopTimer();
    this.closeTour.emit();
  }

  formatTime(ms: number): string {
    const s = Math.floor(ms / 1000);
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  }

  private startTimer(): void {
    this.stopTimer();
    this.timer = setInterval(() => {
      this.elapsed += 100;
      if (this.elapsed >= this.scene.duration) {
        if (this.currentIndex < this.scenes.length - 1) {
          this.next();
        } else {
          this.playing = false;
          this.stopTimer();
        }
      }
    }, 100);
  }

  private stopTimer(): void {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
  }

  private speak(text: string): void {
    if (!this.synth) return;
    this.synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.0;
    const voices = this.synth.getVoices();
    const pref = voices.find(v => v.lang.startsWith('en'));
    if (pref) u.voice = pref;
    this.synth.speak(u);
  }
}
