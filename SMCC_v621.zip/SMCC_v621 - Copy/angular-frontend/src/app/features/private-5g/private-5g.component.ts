import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subject, takeUntil, forkJoin } from 'rxjs';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData, ChartConfiguration } from 'chart.js';
import { NetworkService } from '../../core/services/network.service';
import { WebSocketService } from '../../core/services/websocket.service';

@Component({
  selector: 'app-private-5g',
  standalone: true,
  imports: [CommonModule, BaseChartDirective],
  templateUrl: './private-5g.component.html',
  styleUrls: ['./private-5g.component.scss']
})
export class Private5GComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  private networkService = inject(NetworkService);
  private wsService = inject(WebSocketService);

  loading = true;
  selectedTower: string | null = null;

  summary = { uptime: 99.8, activeDevices: 847, avgBandwidth: 890, avgLatency: 10.8, towerCount: 6 };

  towers: any[] = [];

  healthCards = [
    { title: 'Signal Quality', value: 'Excellent', score: 96, color: 'from-green-600 to-green-700' },
    { title: 'Coverage Area', value: '92% Site Coverage', score: 92, color: 'from-blue-600 to-blue-700' },
    { title: 'Infrastructure', value: 'All Systems OK', score: 98, color: 'from-purple-600 to-purple-700' },
  ];

  // Performance Line Chart
  perfChartData: ChartData<'line'> = { labels: [], datasets: [] };
  perfChartOptions: ChartConfiguration<'line'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { position: 'left', ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y1: { position: 'right', ticks: { color: '#94a3b8' }, grid: { display: false } },
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  // Devices Area Chart
  devicesChartData: ChartData<'line'> = { labels: [], datasets: [] };
  devicesChartOptions: ChartConfiguration<'line'>['options'] = {
    responsive: true, maintainAspectRatio: false,
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
    },
    plugins: { legend: { labels: { color: '#e2e8f0' } } },
  };

  // Bandwidth Bar Chart
  bwChartData: ChartData<'bar'> = { labels: [], datasets: [] };
  bwChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true, maintainAspectRatio: false, indexAxis: 'y',
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
      y: { ticks: { color: '#94a3b8' }, grid: { color: '#334155' } },
    },
    plugins: { legend: { display: false } },
  };

  ngOnInit(): void {
    this.loadData();
    this.subscribeToRealtime();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  loadData(): void {
    forkJoin({
      towers: this.networkService.getTowers(),
      summary: this.networkService.getSummary(),
      perfChart: this.networkService.getPerformanceChartData(),
      bwUsage: this.networkService.getBandwidthUsage(),
    }).pipe(takeUntil(this.destroy$)).subscribe({
      next: ({ towers, summary, perfChart, bwUsage }) => {
        // Map towers from API
        if (towers && towers.length > 0) {
          this.towers = towers.map((t: any) => ({
            id: t.tower_id || t.towerId || t.id,
            name: t.name,
            status: t.status === 'active' ? 'operational' : t.status,
            signal: Math.round(parseFloat(t.uptime_percentage || t.signal_strength || 95)),
            coverage: t.coverage_radius ? Math.min(100, Math.round(t.coverage_radius / 10)) : 90,
            devices: parseInt(t.connected_devices) || 100,
            location: t.location || `Lat: ${parseFloat(t.latitude || 0).toFixed(2)}`,
          }));
        } else {
          this.towers = this.getFallbackTowers();
        }

        // Summary
        this.summary = {
          uptime: summary.uptime || 99.8,
          activeDevices: summary.totalDevices || 847,
          avgBandwidth: summary.avgBandwidth || 890,
          avgLatency: summary.avgLatency || 10.8,
          towerCount: summary.towerCount || this.towers.length,
        };

        // Performance chart from API
        if (perfChart && perfChart.length > 0) {
          this.perfChartData = {
            labels: perfChart.map((d: any) => d.time),
            datasets: [
              { data: perfChart.map((d: any) => d.bandwidth), label: 'Bandwidth (Mbps)', borderColor: '#3b82f6', backgroundColor: 'transparent', yAxisID: 'y', tension: 0.4 },
              { data: perfChart.map((d: any) => d.latency), label: 'Latency (ms)', borderColor: '#f59e0b', backgroundColor: 'transparent', yAxisID: 'y1', tension: 0.4 },
            ],
          };
          this.devicesChartData = {
            labels: perfChart.map((d: any) => d.time),
            datasets: [
              { data: perfChart.map((d: any) => d.devices), label: 'Connected Devices', borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.15)', fill: true, tension: 0.4 },
            ],
          };
        } else {
          this.buildFallbackPerfChart();
        }

        // Bandwidth usage chart
        if (bwUsage && bwUsage.length > 0) {
          this.bwChartData = {
            labels: bwUsage.map((d: any) => d.category),
            datasets: [{ data: bwUsage.map((d: any) => d.usage), label: 'Usage (Mbps)', backgroundColor: bwUsage.map((d: any) => d.color) }],
          };
        } else {
          this.buildFallbackBwChart();
        }

        this.loading = false;
      },
      error: () => {
        this.towers = this.getFallbackTowers();
        this.buildFallbackPerfChart();
        this.buildFallbackBwChart();
        this.loading = false;
      }
    });
  }

  private subscribeToRealtime(): void {
    this.wsService.subscribeToNetworkMetrics()
      .pipe(takeUntil(this.destroy$))
      .subscribe((metrics: any) => {
        // Update matching tower in real-time
        const tower = this.towers.find(t => t.id === metrics.towerIdLabel || t.id === metrics.towerId);
        if (tower) {
          tower.devices = metrics.connectedDevices || tower.devices;
          tower.signal = Math.round(metrics.signalStrength || tower.signal);
        }
      });
  }

  selectTower(id: string): void {
    this.selectedTower = this.selectedTower === id ? null : id;
  }

  private getFallbackTowers(): any[] {
    return [
      { id: 'TOWER-01', name: 'North Sector Alpha', status: 'operational', signal: 98, coverage: 95, devices: 142, location: 'Zone A-1' },
      { id: 'TOWER-02', name: 'South Sector Beta', status: 'operational', signal: 96, coverage: 92, devices: 138, location: 'Zone B-2' },
      { id: 'TOWER-03', name: 'East Sector Gamma', status: 'operational', signal: 94, coverage: 89, devices: 125, location: 'Zone C-3' },
      { id: 'TOWER-04', name: 'West Sector Delta', status: 'warning', signal: 85, coverage: 78, devices: 98, location: 'Zone D-4' },
      { id: 'TOWER-05', name: 'Central Hub Epsilon', status: 'operational', signal: 99, coverage: 97, devices: 156, location: 'Central' },
      { id: 'TOWER-06', name: 'Mining Pit Zeta', status: 'operational', signal: 92, coverage: 88, devices: 112, location: 'Pit Zone' },
    ];
  }

  private buildFallbackPerfChart(): void {
    const data = [
      { time: '00:00', bandwidth: 850, latency: 12, devices: 645 },
      { time: '04:00', bandwidth: 720, latency: 15, devices: 580 },
      { time: '08:00', bandwidth: 920, latency: 10, devices: 720 },
      { time: '12:00', bandwidth: 880, latency: 11, devices: 695 },
      { time: '16:00', bandwidth: 950, latency: 9, devices: 750 },
      { time: '20:00', bandwidth: 890, latency: 11, devices: 680 },
    ];
    this.perfChartData = {
      labels: data.map(d => d.time),
      datasets: [
        { data: data.map(d => d.bandwidth), label: 'Bandwidth (Mbps)', borderColor: '#3b82f6', backgroundColor: 'transparent', yAxisID: 'y', tension: 0.4 },
        { data: data.map(d => d.latency), label: 'Latency (ms)', borderColor: '#f59e0b', backgroundColor: 'transparent', yAxisID: 'y1', tension: 0.4 },
      ],
    };
    this.devicesChartData = {
      labels: data.map(d => d.time),
      datasets: [{ data: data.map(d => d.devices), label: 'Devices', borderColor: '#10b981', backgroundColor: 'rgba(16,185,129,0.15)', fill: true, tension: 0.4 }],
    };
  }

  private buildFallbackBwChart(): void {
    const bw = [
      { category: 'Asset Telemetry', usage: 320, color: '#3b82f6' },
      { category: 'Video Surveillance', usage: 280, color: '#10b981' },
      { category: 'Digital Twin Sync', usage: 180, color: '#f59e0b' },
      { category: 'Safety Systems', usage: 120, color: '#ef4444' },
      { category: 'Management', usage: 80, color: '#8b5cf6' },
    ];
    this.bwChartData = {
      labels: bw.map(d => d.category),
      datasets: [{ data: bw.map(d => d.usage), label: 'Usage (Mbps)', backgroundColor: bw.map(d => d.color) }],
    };
  }
}
