export interface MiningZone {
  id: string;
  zoneId: string;
  name: string;
  type: ZoneType;
  status: 'active' | 'inactive' | 'restricted' | 'maintenance';
  coordinates: Coordinate[];
  areaSqKm: number;
  assetCount: number;
  personnelCount: number;
  color: string;
  description?: string;
  centerLatitude?: number;
  centerLongitude?: number;
}

export type ZoneType = 'mining' | 'processing' | 'storage' | 'maintenance' | 'administration' | 'restricted' | 'primary_pit' | 'secondary_pit' | 'office';

export interface Coordinate {
  latitude: number;
  longitude: number;
  altitude?: number;
}

export interface AssetLocation {
  id: string;
  assetId: string;
  assetType: string;
  name: string;
  latitude: number;
  longitude: number;
  altitude?: number;
  heading?: number;
  speed?: number;
  zone: string;
  status: 'active' | 'idle' | 'maintenance';
  lastUpdated: Date;
}

// Enhanced asset for Leaflet map display
export interface MapAsset {
  id: string;
  type: string;
  lat: number;
  lng: number;
  zone: string;
  status: string;
  speed: number;
  heading: number;
}

export interface GeoFence {
  id: string;
  name: string;
  type: 'inclusion' | 'exclusion' | 'speed_limit';
  coordinates: Coordinate[];
  radius?: number;
  speedLimit?: number;
  alertOnBreach: boolean;
  isActive: boolean;
}

export interface GeoSpatialAlert {
  id: string;
  type: 'boundary_breach' | 'speed_violation' | 'unauthorized_zone' | 'proximity_warning';
  assetId: string;
  assetName: string;
  zone: string;
  message: string;
  severity: 'low' | 'medium' | 'high';
  timestamp: Date;
  resolved: boolean;
}