export interface Asset {
  id: string;
  assetId: string;
  name: string;
  type: AssetType;
  manufacturer?: string;
  model?: string;
  serialNumber?: string;
  status: AssetStatus;
  currentZoneId?: string;
  assignedOperatorId?: string;
  operatingHours: number;
  lastMaintenanceAt?: Date;
  nextMaintenanceAt?: Date;
  maintenanceIntervalHours: number;
  metadata?: any;
  createdAt: Date;
  updatedAt: Date;
}

export type AssetType = 'excavator' | 'haul_truck' | 'drill' | 'dozer' | 'loader' | 'grader' | 'water_truck';
export type AssetStatus = 'active' | 'maintenance' | 'inactive' | 'retired';

export interface AssetTelemetry {
  id: number;
  assetId: string;
  timestamp: Date;
  latitude?: number;
  longitude?: number;
  altitude?: number;
  heading?: number;
  speed?: number;
  engineTemp?: number;
  hydraulicPressure?: number;
  fuelLevel?: number;
  batteryVoltage?: number;
  loadWeight?: number;
  vibrationLevel?: number;
  rpm?: number;
  gear?: number;
  isOperating: boolean;
  errorCodes?: string[];
}

export interface AssetComponent {
  id: string;
  assetId: string;
  componentId: string;
  name: string;
  healthScore: number;
  status: ComponentStatus;
  temperature?: number;
  pressure?: number;
  vibration?: number;
  wearLevel?: number;
  operatingHours: number;
  lastMaintenanceAt?: Date;
  nextMaintenanceHours?: number;
  metadata?: any;
  updatedAt: Date;
}

export type ComponentStatus = 'optimal' | 'good' | 'warning' | 'critical';

export interface DigitalTwin {
  id: string;
  assetId: string;
  modelVersion: string;
  polygonCount: number;
  vertexCount: number;
  meshData?: any;
  textureUrls?: string[];
  lastSyncAt: Date;
  syncIntervalSeconds: number;
  positionAccuracy: number;
  predictedFailures?: any[];
  maintenanceRecommendations?: any[];
}

export interface MaintenanceRecord {
  id: string;
  assetId: string;
  maintenanceType: MaintenanceType;
  priority: Priority;
  scheduledAt?: Date;
  startedAt?: Date;
  completedAt?: Date;
  description: string;
  componentsServiced?: string[];
  partsReplaced?: any[];
  technicianId?: string;
  laborHours?: number;
  totalCost?: number;
  status: MaintenanceStatus;
  notes?: string;
  attachments?: string[];
}

export type MaintenanceType = 'scheduled' | 'preventive' | 'corrective' | 'emergency';
export type Priority = 'low' | 'medium' | 'high' | 'critical';
export type MaintenanceStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';