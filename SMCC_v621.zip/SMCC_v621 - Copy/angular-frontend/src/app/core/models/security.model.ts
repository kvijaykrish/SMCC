export interface SecurityEvent {
  id: string;
  type: SecurityEventType;
  severity: EventSeverity;
  location: string;
  cameraId?: string;
  description: string;
  status: EventStatus;
  detectedAt: Date;
  resolvedAt?: Date;
  assignedTo?: string;
  metadata?: any;
}

export type SecurityEventType = 'access_alert' | 'perimeter_breach' | 'unauthorized_vehicle' | 'motion_detected' | 'personnel_safety';
export type EventSeverity = 'critical' | 'warning' | 'info';
export type EventStatus = 'new' | 'reviewing' | 'investigating' | 'resolved' | 'dismissed';

export interface Camera {
  id: string;
  cameraId: string;
  name: string;
  location: string;
  zone: string;
  status: CameraStatus;
  resolution: string;
  fps: number;
  recording: boolean;
  ptzEnabled: boolean;
  nightVision: boolean;
  motionDetection: boolean;
  streamUrl?: string;
  thumbnailUrl?: string;
  installedAt?: Date;
  lastMaintenanceAt?: Date;
}

export type CameraStatus = 'active' | 'warning' | 'offline' | 'maintenance';

export interface AccessLog {
  id: string;
  timestamp: Date;
  accessPointId: string;
  accessPointName: string;
  personId?: string;
  personName?: string;
  direction: 'entry' | 'exit';
  accessType: 'authorized' | 'unauthorized' | 'denied';
  credentialType: 'badge' | 'biometric' | 'pin' | 'vehicle';
  vehicleId?: string;
}

export interface SecurityZone {
  id: string;
  name: string;
  type: 'perimeter' | 'restricted' | 'general' | 'emergency';
  status: 'secure' | 'alert' | 'breach';
  cameras: number;
  sensors: number;
  accessPoints: number;
}
