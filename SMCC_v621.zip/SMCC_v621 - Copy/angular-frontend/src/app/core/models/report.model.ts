export interface Report {
  id: string;
  report_id: string;
  report_type: ReportType;
  title: string;
  description?: string;
  time_range_start: string;
  time_range_end: string;
  time_range_preset?: string;
  generated_by?: string;
  status: 'pending' | 'generating' | 'completed' | 'failed';
  format: 'json' | 'csv' | 'pdf';
  data?: any;
  kpi_summary?: ReportKpi[];
  site_id?: string;
  created_at: string;
  updated_at: string;
}

export type ReportType = 'production' | 'safety' | 'equipment' | 'water' | 'energy' | 'security';

export interface ReportKpi {
  label: string;
  value: string;
  change: number;
  trend: 'up' | 'down';
}

export interface ReportGenerateRequest {
  reportType: ReportType;
  timeRangeStart: string;
  timeRangeEnd: string;
  timeRangePreset?: string;
  siteId?: string;
}
