export interface SafetyIncident {
  id: string;
  type: IncidentType;
  severity: IncidentSeverity;
  location: string;
  zone: string;
  description: string;
  reportedBy: string;
  reportedAt: Date;
  resolvedAt?: Date;
  status: 'open' | 'investigating' | 'resolved' | 'closed';
  injuriesCount: number;
  rootCause?: string;
  correctiveActions?: string[];
}

export type IncidentType = 'equipment' | 'slip_fall' | 'near_miss' | 'ppe_violation' | 'chemical' | 'electrical' | 'environmental';
export type IncidentSeverity = 'minor' | 'moderate' | 'major' | 'critical';

export interface TrainingProgram {
  id: string;
  programId: string;
  name: string;
  type: TrainingType;
  status: 'active' | 'scheduled' | 'completed' | 'cancelled';
  enrolledCount: number;
  completedCount: number;
  duration: string;
  description?: string;
  instructor?: string;
  scheduledDate?: Date;
  completionDeadline?: Date;
}

export type TrainingType = 'vr_simulation' | 'classroom' | 'practical' | 'online' | 'on_the_job';

export interface VRSimulation {
  id: string;
  simulationId: string;
  name: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  completionRate: number;
  averageScore: number;
  totalSessions: number;
  description?: string;
  scenarioType: string;
}

export interface Certification {
  id: string;
  employeeId: string;
  employeeName: string;
  certificationName: string;
  issuedAt: Date;
  expiresAt: Date;
  status: 'current' | 'expiring_soon' | 'expired';
  issuingAuthority: string;
}

export interface SafetyMetrics {
  safetyScore: number;
  daysWithoutIncident: number;
  totalIncidents30d: number;
  nearMisses30d: number;
  trainingCompletionRate: number;
  complianceRate: number;
  activeCertifications: number;
  expiringSoonCertifications: number;
  expiredCertifications: number;
}
