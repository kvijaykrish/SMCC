export interface MiningEvent {
  id: string;
  event_id: string;
  event_type: string;
  category: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  title: string;
  description: string;
  equipment_type?: string;
  equipment_id?: string;
  equipment_name?: string;
  location?: string;
  zone_name?: string;
  latitude?: number;
  longitude?: number;
  reported_by?: string;
  assigned_to?: string;
  duration_minutes?: number;
  cost_impact?: number;
  production_impact_tonnes?: number;
  resolution_notes?: string;
  tags?: string[];
  site_id?: string;
  occurred_at: string;
  resolved_at?: string;
  created_at: string;
}

export interface AiQueryFilters {
  equipmentTypes?: string[];
  eventTypes?: string[];
  severities?: string[];
  statuses?: string[];
  locations?: string[];
  categories?: string[];
  timeRangeStart?: string;
  timeRangeEnd?: string;
}

export interface AiQueryRequest {
  filters: AiQueryFilters;
  queryText: string;
  sessionId: string;
  inputMethod: 'text' | 'voice';
}

export interface AiQueryResponse {
  events: MiningEvent[];
  summary: {
    totalResults: number;
    severityCounts: Record<string, number>;
    typeCounts: Record<string, number>;
    responseTimeMs: number;
  };
  responseText: string;
}

export interface SuggestedPrompt {
  text: string;
  category: string;
}
