export interface Pipeline {
  id: string;
  pipelineId: string;
  name: string;
  location: string;
  status: PipelineStatus;
  flowRate: number;
  pressure: number;
  temperature: number;
  capacity: number;
  material: string;
  diameterMm: number;
  lengthM: number;
  installedAt?: Date;
  lastInspectionAt?: Date;
}

export type PipelineStatus = 'optimal' | 'warning' | 'critical' | 'offline';

export interface WaterQualityMetric {
  id: string;
  parameter: string;
  value: number;
  unit: string;
  optimalValue: number;
  minThreshold: number;
  maxThreshold: number;
  status: 'excellent' | 'good' | 'warning' | 'critical';
  measuredAt: Date;
  sensorId: string;
}

export interface WaterUsageRecord {
  id: string;
  timestamp: Date;
  zone: string;
  usageLiters: number;
  qualityPercentage: number;
  pressure: number;
  temperature: number;
}

export interface WaterTreatmentPlant {
  id: string;
  name: string;
  status: 'operational' | 'maintenance' | 'offline';
  capacityLitersPerDay: number;
  currentThroughput: number;
  efficiencyPercentage: number;
  lastMaintenanceAt?: Date;
}

export interface WaterFlowNode {
  key: string;
  label: string;
  subtitle: string;
  type: string;
  icon: string;
  color: string;
  x: number;
  y: number;
  capacityLiters: number;
  currentLevelPercentage: number;
  flowRate: number;
  status: 'active' | 'warning' | 'offline' | 'maintenance';
}

export interface WaterFlowConnection {
  from: string;
  to: string;
  pipelineId: string;
  flowRate: number;
  status: PipelineStatus;
  isReclaim: boolean;
}

export interface WaterFlowNetwork {
  nodes: WaterFlowNode[];
  connections: WaterFlowConnection[];
}