export interface NetworkTower {
  id: string;
  towerId: string;
  name: string;
  latitude: number;
  longitude: number;
  altitude?: number;
  frequencyBand: string;
  maxBandwidth: number;
  coverageRadius: number;
  antennaType: string;
  status: TowerStatus;
  uptimePercentage: number;
  currentLoad: number;
  connectedDevices: number;
  signalStrength: number;
  installedAt?: Date;
  lastMaintenanceAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export type TowerStatus = 'active' | 'maintenance' | 'offline';

export interface NetworkDevice {
  id: string;
  deviceId: string;
  deviceName: string;
  deviceType: DeviceType;
  assetId?: string;
  towerId?: string;
  ipAddress?: string;
  macAddress?: string;
  imei?: string;
  simCardId?: string;
  signalStrength: number;
  latency: number;
  bandwidthUp: number;
  bandwidthDown: number;
  packetLoss: number;
  status: DeviceStatus;
  lastSeenAt: Date;
  createdAt: Date;
  updatedAt: Date;
}

export type DeviceType = 'asset' | 'sensor' | 'camera' | 'gateway' | 'router';
export type DeviceStatus = 'online' | 'offline' | 'error';

export interface NetworkMetrics {
  id: number;
  towerId: string;
  timestamp: Date;
  throughputMbps: number;
  latencyMs: number;
  packetLoss: number;
  connectedDevices: number;
  bandwidthUtilization: number;
  errorRate: number;
}
