export interface Site {
  id: string;
  siteId: string;
  name: string;
  location: string;
  country: string;
  region: string;
  siteType: SiteType;
  status: SiteStatus;
  latitude?: number;
  longitude?: number;
  timezone: string;
  establishedDate?: Date;
  areaSqKm?: number;
  maxDepthMeters?: number;
  primaryCommodity: string;
  secondaryCommodities?: string[];
  annualCapacityTonnes?: number;
  workforceCount?: number;
  siteManagerId?: string;
  siteManagerName?: string;
  siteManagerEmail?: string;
  siteManagerPhone?: string;
  contactEmail?: string;
  contactPhone?: string;
  imageUrl?: string;
  description?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  
  // Metrics (from join)
  totalAssets?: number;
  activeAssets?: number;
  assetsInMaintenance?: number;
  productionTonnesToday?: number;
  productionTonnesMtd?: number;
  networkUptimePercentage?: number;
  activeAlerts?: number;
  criticalAlerts?: number;
  safetyIncidentsToday?: number;
  safetyIncidentsMtd?: number;
  workforcePresent?: number;
  operationalEfficiency?: number;
  environmentalComplianceScore?: number;
  metricsUpdatedAt?: Date;
}

export type SiteType = 'open_pit' | 'underground' | 'processing_plant' | 'exploration';
export type SiteStatus = 'operational' | 'maintenance' | 'commissioning' | 'decommissioning' | 'closed';

export interface SiteMetrics {
  id: number;
  siteId: string;
  timestamp: Date;
  totalAssets: number;
  activeAssets: number;
  assetsInMaintenance: number;
  productionTonnesToday: number;
  productionTonnesMtd: number;
  networkUptimePercentage: number;
  activeAlerts: number;
  criticalAlerts: number;
  safetyIncidentsToday: number;
  safetyIncidentsMtd: number;
  waterConsumptionLitersToday: number;
  powerConsumptionKwhToday: number;
  workforcePresent: number;
  operationalEfficiency: number;
  environmentalComplianceScore: number;
}

export interface SiteDetail extends Site {
  metrics: SiteMetrics | null;
  assetsByType: { type: string; count: number }[];
  totalZones: number;
  totalNetworkTowers: number;
}
