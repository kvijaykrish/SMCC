import { inject } from '@angular/core';
import { Router, CanActivateFn } from '@angular/router';
import { SiteService } from '../services/site.service';
import { map } from 'rxjs/operators';

export const SiteSelectionGuard: CanActivateFn = (route, state) => {
  const siteService = inject(SiteService);
  const router = inject(Router);

  return siteService.selectedSite$.pipe(
    map(selectedSite => {
      if (selectedSite) {
        return true;
      } else {
        router.navigate(['/sites']);
        return false;
      }
    })
  );
};
