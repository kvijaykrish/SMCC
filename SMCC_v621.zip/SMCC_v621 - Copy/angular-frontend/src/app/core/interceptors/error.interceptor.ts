import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      let errorMessage = 'An error occurred';

      if (error.error instanceof ErrorEvent) {
        // Client-side error
        errorMessage = `Error: ${error.error.message}`;
      } else {
        // Server-side error
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        
        // Handle specific status codes
        switch (error.status) {
          case 401:
            // Unauthorized - redirect to login
            router.navigate(['/login']);
            break;
          case 403:
            // Forbidden
            errorMessage = 'You do not have permission to access this resource';
            break;
          case 404:
            // Not found
            errorMessage = 'Resource not found';
            break;
          case 500:
            // Server error
            errorMessage = 'Internal server error';
            break;
        }
      }

      console.error(errorMessage);
      return throwError(() => error);
    })
  );
};
