import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { AiQueryRequest, AiQueryResponse, SuggestedPrompt, MiningEvent } from '../models/mining-event.model';

@Injectable({ providedIn: 'root' })
export class AiAssistantService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/ai-assistant`;

  query(request: AiQueryRequest): Observable<AiQueryResponse> {
    return this.http.post<AiQueryResponse>(`${this.baseUrl}/query`, request);
  }

  getEvents(params?: { limit?: number; offset?: number; category?: string; severity?: string }): Observable<{ events: MiningEvent[]; total: number }> {
    return this.http.get<{ events: MiningEvent[]; total: number }>(`${this.baseUrl}/events`, { params: params as any });
  }

  getEventStatistics(): Observable<any> {
    return this.http.get(`${this.baseUrl}/events/statistics`);
  }

  getSuggestedPrompts(): Observable<SuggestedPrompt[]> {
    return this.http.get<SuggestedPrompt[]>(`${this.baseUrl}/prompts`);
  }

  getConversationHistory(sessionId?: string): Observable<any[]> {
    // build params object only when a sessionId exists; leave undefined otherwise
    const params = sessionId ? { session_id: sessionId } : undefined;
    // tslint:disable-next-line: ban-ts-comment
    // @ts-ignore: overload resolution problems force HttpEvent return
    return this.http.get<any[]>(
      `${this.baseUrl}/conversations`,
      { params, observe: 'body' as const } as any
    ) as Observable<any[]>;
  }
}
