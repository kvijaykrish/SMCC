import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { MiningZone, AssetLocation, GeoFence, GeoSpatialAlert } from '../models/geospatial.model';

@Injectable({
  providedIn: 'root'
})
export class GeoSpatialService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/geospatial`;

  // Mining Zones
  getZones(params?: any): Observable<MiningZone[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get<MiningZone[]>(`${this.baseUrl}/zones`, { params: httpParams });
  }

  getZone(id: string): Observable<MiningZone> {
    return this.http.get<MiningZone>(`${this.baseUrl}/zones/${id}`);
  }

  // Asset Locations
  getAssetLocations(params?: any): Observable<AssetLocation[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }
    return this.http.get<AssetLocation[]>(`${this.baseUrl}/assets`, { params: httpParams });
  }

  getAssetLocation(assetId: string): Observable<AssetLocation> {
    return this.http.get<AssetLocation>(`${this.baseUrl}/assets/${assetId}`);
  }

  // Geo-Fences
  getGeoFences(): Observable<GeoFence[]> {
    return this.http.get<GeoFence[]>(`${this.baseUrl}/geofences`);
  }

  createGeoFence(fence: Partial<GeoFence>): Observable<GeoFence> {
    return this.http.post<GeoFence>(`${this.baseUrl}/geofences`, fence);
  }

  updateGeoFence(id: string, fence: Partial<GeoFence>): Observable<GeoFence> {
    return this.http.put<GeoFence>(`${this.baseUrl}/geofences/${id}`, fence);
  }

  deleteGeoFence(id: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/geofences/${id}`);
  }

  // Alerts
  getGeoAlerts(params?: any): Observable<GeoSpatialAlert[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }
    return this.http.get<GeoSpatialAlert[]>(`${this.baseUrl}/alerts`, { params: httpParams });
  }

  // Statistics
  getGeoStatistics(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/statistics`);
  }
}
