import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject, of, catchError } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { 
  Asset, 
  AssetTelemetry, 
  AssetComponent, 
  DigitalTwin,
  MaintenanceRecord 
} from '../models/asset.model';

@Injectable({
  providedIn: 'root'
})
export class AssetService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/assets`;
  
  private assetsSubject = new BehaviorSubject<Asset[]>([]);
  public assets$ = this.assetsSubject.asObservable();

  // Get all assets
  getAssets(params?: any): Observable<Asset[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }

    return this.http.get<Asset[]>(this.baseUrl, { params: httpParams }).pipe(
      tap(assets => this.assetsSubject.next(assets))
    );
  }

  // Get single asset
  getAsset(id: string): Observable<Asset> {
    return this.http.get<Asset>(`${this.baseUrl}/${id}`);
  }

  // Create asset
  createAsset(asset: Partial<Asset>): Observable<Asset> {
    return this.http.post<Asset>(this.baseUrl, asset).pipe(
      tap(() => this.refreshAssets())
    );
  }

  // Update asset
  updateAsset(id: string, asset: Partial<Asset>): Observable<Asset> {
    return this.http.put<Asset>(`${this.baseUrl}/${id}`, asset).pipe(
      tap(() => this.refreshAssets())
    );
  }

  // Delete asset
  deleteAsset(id: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`).pipe(
      tap(() => this.refreshAssets())
    );
  }

  // Get asset telemetry
  getAssetTelemetry(assetId: string, params?: any): Observable<AssetTelemetry[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }

    return this.http.get<AssetTelemetry[]>(`${this.baseUrl}/${assetId}/telemetry`, { params: httpParams });
  }

  // Get latest telemetry
  getLatestTelemetry(assetId: string): Observable<AssetTelemetry> {
    return this.http.get<AssetTelemetry>(`${this.baseUrl}/${assetId}/telemetry/latest`);
  }

  // Get asset components
  getAssetComponents(assetId: string): Observable<AssetComponent[]> {
    return this.http.get<AssetComponent[]>(`${this.baseUrl}/${assetId}/components`);
  }

  // Update component
  updateComponent(assetId: string, componentId: string, data: Partial<AssetComponent>): Observable<AssetComponent> {
    return this.http.put<AssetComponent>(
      `${this.baseUrl}/${assetId}/components/${componentId}`, 
      data
    );
  }

  // Get digital twin
  getDigitalTwin(assetId: string): Observable<DigitalTwin> {
    return this.http.get<DigitalTwin>(`${this.baseUrl}/${assetId}/digital-twin`);
  }

  // Update digital twin
  updateDigitalTwin(assetId: string, data: Partial<DigitalTwin>): Observable<DigitalTwin> {
    return this.http.put<DigitalTwin>(`${this.baseUrl}/${assetId}/digital-twin`, data);
  }

  // Get maintenance records
  getMaintenanceRecords(assetId: string): Observable<MaintenanceRecord[]> {
    return this.http.get<MaintenanceRecord[]>(`${this.baseUrl}/${assetId}/maintenance`);
  }

  // Create maintenance record
  createMaintenanceRecord(assetId: string, record: Partial<MaintenanceRecord>): Observable<MaintenanceRecord> {
    return this.http.post<MaintenanceRecord>(`${this.baseUrl}/${assetId}/maintenance`, record);
  }

  // Update maintenance record
  updateMaintenanceRecord(assetId: string, recordId: string, data: Partial<MaintenanceRecord>): Observable<MaintenanceRecord> {
    return this.http.put<MaintenanceRecord>(
      `${this.baseUrl}/${assetId}/maintenance/${recordId}`, 
      data
    );
  }

  // Get asset statistics
  getAssetStatistics(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/statistics`);
  }

  // Get assets by zone
  getAssetsByZone(zoneId: string): Observable<Asset[]> {
    return this.http.get<Asset[]>(`${this.baseUrl}/by-zone/${zoneId}`);
  }

  // Get assets by type
  getAssetsByType(type: string): Observable<Asset[]> {
    return this.http.get<Asset[]>(`${this.baseUrl}/by-type/${type}`);
  }

  // Private helper to refresh assets
  private refreshAssets(): void {
    this.getAssets().subscribe();
  }

  // Chart data endpoints
  getActivityChartData(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/activity`).pipe(
      catchError(() => of([
        { hour: '00:00', active: 45, idle: 12, maintenance: 3 },
        { hour: '04:00', active: 38, idle: 18, maintenance: 4 },
        { hour: '08:00', active: 52, idle: 6, maintenance: 2 },
        { hour: '12:00', active: 48, idle: 10, maintenance: 2 },
        { hour: '16:00', active: 50, idle: 8, maintenance: 2 },
        { hour: '20:00', active: 46, idle: 11, maintenance: 3 },
      ]))
    );
  }

  getTypeDistribution(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/type-distribution`).pipe(
      catchError(() => of([
        { name: 'Excavators', value: 24, color: '#3b82f6' },
        { name: 'Haul Trucks', value: 45, color: '#10b981' },
        { name: 'Drills', value: 18, color: '#f59e0b' },
        { name: 'Dozers', value: 12, color: '#8b5cf6' },
        { name: 'Loaders', value: 15, color: '#ef4444' },
      ]))
    );
  }
}