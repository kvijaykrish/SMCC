import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { io, Socket } from 'socket.io-client';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class WebSocketService {
  private socket: Socket | null = null;
  private subjects: Map<string, Subject<any>> = new Map();

  // Connect to WebSocket server
  connect(): void {
    if (!this.socket) {
      this.socket = io(environment.wsUrl, {
        transports: ['websocket'],
        autoConnect: true
      });

      this.socket.on('connect', () => {
        console.log('WebSocket connected');
      });

      this.socket.on('disconnect', () => {
        console.log('WebSocket disconnected');
      });

      this.socket.on('error', (error: any) => {
        console.error('WebSocket error:', error);
      });
    }
  }

  // Disconnect from WebSocket server
  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.subjects.clear();
    }
  }

  // Subscribe to a specific event
  on<T>(event: string): Observable<T> {
    if (!this.socket) {
      this.connect();
    }

    if (!this.subjects.has(event)) {
      const subject = new Subject<T>();
      this.subjects.set(event, subject);

      this.socket?.on(event, (data: T) => {
        subject.next(data);
      });
    }

    return this.subjects.get(event)!.asObservable();
  }

  // Emit an event
  emit(event: string, data?: any): void {
    if (!this.socket) {
      this.connect();
    }
    this.socket?.emit(event, data);
  }

  // Subscribe to asset telemetry updates
  subscribeToAssetTelemetry(assetId: string): Observable<any> {
    this.emit('subscribe:asset:telemetry', { assetId });
    return this.on(`asset:telemetry:${assetId}`);
  }

  // Unsubscribe from asset telemetry
  unsubscribeFromAssetTelemetry(assetId: string): void {
    this.emit('unsubscribe:asset:telemetry', { assetId });
    this.socket?.off(`asset:telemetry:${assetId}`);
  }

  // Subscribe to network metrics
  subscribeToNetworkMetrics(towerId?: string): Observable<any> {
    const event = towerId ? `network:metrics:${towerId}` : 'network:metrics';
    this.emit('subscribe:network:metrics', { towerId });
    return this.on(event);
  }

  // Subscribe to alerts
  subscribeToAlerts(): Observable<any> {
    this.emit('subscribe:alerts');
    return this.on('alert:new');
  }

  // Subscribe to security events
  subscribeToSecurityEvents(): Observable<any> {
    this.emit('subscribe:security:events');
    return this.on('security:event:new');
  }

  // Subscribe to water management updates
  subscribeToWaterMetrics(): Observable<any> {
    this.emit('subscribe:water:metrics');
    return this.on('water:metrics:update');
  }

  // Subscribe to water flow network updates
  subscribeToWaterFlow(): Observable<any> {
    this.emit('subscribe:water:flow');
    return this.on('water:flow:update');
  }

  // Subscribe to geo-spatial updates
  subscribeToGeoSpatial(): Observable<any> {
    this.emit('subscribe:geospatial');
    return this.on('geospatial:update');
  }

  // Subscribe to digital twin sensor updates
  subscribeToDigitalTwin(assetId: string): Observable<any> {
    this.emit('subscribe:digital-twin', { assetId });
    return this.on(`digital-twin:sensor:${assetId}`);
  }

  // Unsubscribe from digital twin
  unsubscribeFromDigitalTwin(assetId: string): void {
    this.emit('unsubscribe:digital-twin', { assetId });
    this.socket?.off(`digital-twin:sensor:${assetId}`);
  }
}