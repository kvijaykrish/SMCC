import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, catchError, forkJoin, map } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class DashboardService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/dashboard`;
  private assetsUrl = `${environment.apiUrl}/api/assets`;

  getSummary(): Observable<any> {
    return forkJoin({
      dashboard: this.http.get<any>(`${this.baseUrl}/summary`).pipe(
        catchError(() => of({
          assets: { total: 847, active: 687, maintenance: 23 },
          network: { uptime: 99.8, devices: 847 },
          alerts: { active: 3, critical: 1 },
          safety: { score: 98.5, incidents30d: 1 },
          water: { quality: 97.8 },
        }))
      ),
      assetStats: this.http.get<any>(`${this.assetsUrl}/statistics/summary`).pipe(
        catchError(() => of({ avg_health: null }))
      ),
    }).pipe(
      map(({ dashboard, assetStats }) => ({
        ...dashboard,
        assets: {
          ...(dashboard.assets || {}),
          avgHealth: assetStats.avg_health != null ? assetStats.avg_health : 92,
        },
      }))
    );
  }

  getPerformance(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/performance`).pipe(
      catchError(() => of([
        { time: '00:00', efficiency: 85, output: 420, energy: 340 },
        { time: '04:00', efficiency: 78, output: 390, energy: 320 },
        { time: '08:00', efficiency: 92, output: 460, energy: 380 },
        { time: '12:00', efficiency: 88, output: 440, energy: 360 },
        { time: '16:00', efficiency: 90, output: 450, energy: 370 },
        { time: '20:00', efficiency: 86, output: 430, energy: 350 },
      ]))
    );
  }

  getAssetDistribution(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/asset-distribution`).pipe(
      catchError(() => of([
        { name: 'Excavators', value: 24, color: '#3b82f6' },
        { name: 'Haul Trucks', value: 45, color: '#10b981' },
        { name: 'Drills', value: 18, color: '#f59e0b' },
        { name: 'Dozers', value: 12, color: '#8b5cf6' },
        { name: 'Maintenance', value: 8, color: '#ef4444' },
      ]))
    );
  }

  getSystemHealth(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/system-health`).pipe(
      catchError(() => of([
        { system: 'Network', score: 98 },
        { system: 'Assets', score: 94 },
        { system: 'Security', score: 99 },
        { system: 'Water', score: 96 },
        { system: 'Safety', score: 97 },
        { system: 'Digital Twin', score: 93 },
      ]))
    );
  }

  getRecentActivity(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/recent-activity`).pipe(
      catchError(() => of([]))
    );
  }
}