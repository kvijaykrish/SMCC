import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of, catchError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { SecurityEvent, Camera, AccessLog, SecurityZone } from '../models/security.model';

@Injectable({
  providedIn: 'root'
})
export class SecurityService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/security`;

  // Alias used by security component
  getEvents(params?: any): Observable<SecurityEvent[]> {
    return this.getSecurityEvents(params);
  }

  // Security Events
  getSecurityEvents(params?: any): Observable<SecurityEvent[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get<SecurityEvent[]>(`${this.baseUrl}/events`, { params: httpParams });
  }

  getSecurityEvent(id: string): Observable<SecurityEvent> {
    return this.http.get<SecurityEvent>(`${this.baseUrl}/events/${id}`);
  }

  updateSecurityEvent(id: string, data: Partial<SecurityEvent>): Observable<SecurityEvent> {
    return this.http.put<SecurityEvent>(`${this.baseUrl}/events/${id}`, data);
  }

  // Cameras
  getCameras(params?: any): Observable<Camera[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get<Camera[]>(`${this.baseUrl}/cameras`, { params: httpParams });
  }

  getCamera(id: string): Observable<Camera> {
    return this.http.get<Camera>(`${this.baseUrl}/cameras/${id}`);
  }

  // Access Logs
  getAccessLogs(params?: any): Observable<AccessLog[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }
    return this.http.get<AccessLog[]>(`${this.baseUrl}/access-logs`, { params: httpParams });
  }

  // Security Zones
  getSecurityZones(): Observable<SecurityZone[]> {
    return this.http.get<SecurityZone[]>(`${this.baseUrl}/zones`);
  }

  // Statistics
  getSecurityStatistics(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/statistics`);
  }

  // Chart data endpoints
  getSummary(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/summary`).pipe(
      catchError(() => of({
        activeCameras: 128, totalCameras: 128, events24h: 24,
        accessPoints: 16, personnelOnSite: 342, securityScore: 98.5,
      }))
    );
  }

  getAccessChartData(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/access`).pipe(
      catchError(() => of([]))
    );
  }

  getEventTypeChartData(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/event-types`).pipe(
      catchError(() => of([]))
    );
  }
}