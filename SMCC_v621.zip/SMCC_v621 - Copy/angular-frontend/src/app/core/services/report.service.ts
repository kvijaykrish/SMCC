import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Report, ReportGenerateRequest } from '../models/report.model';

@Injectable({ providedIn: 'root' })
export class ReportService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/reports`;

  getReports(params?: { report_type?: string; site_id?: string; limit?: number; offset?: number }): Observable<Report[]> {
    return this.http.get<Report[]>(this.baseUrl, { params: params as any });
  }

  getReport(id: string): Observable<Report> {
    return this.http.get<Report>(`${this.baseUrl}/${id}`);
  }

  generateReport(request: ReportGenerateRequest): Observable<Report> {
    return this.http.post<Report>(`${this.baseUrl}/generate`, request);
  }

  getStatistics(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/statistics/summary`);
  }

  deleteReport(id: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}
