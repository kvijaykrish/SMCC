import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { Site, SiteDetail, SiteMetrics } from '../models/site.model';

@Injectable({
  providedIn: 'root'
})
export class SiteService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/sites`;
  
  private selectedSiteSubject = new BehaviorSubject<Site | null>(this.getSelectedSiteFromStorage());
  public selectedSite$ = this.selectedSiteSubject.asObservable();

  // Get all sites
  getSites(params?: any): Observable<Site[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }

    return this.http.get<Site[]>(this.baseUrl, { params: httpParams });
  }

  // Get single site with detailed metrics
  getSite(id: string): Observable<SiteDetail> {
    return this.http.get<SiteDetail>(`${this.baseUrl}/${id}`);
  }

  // Get site metrics history
  getSiteMetrics(siteId: string, hours: number = 24): Observable<SiteMetrics[]> {
    return this.http.get<SiteMetrics[]>(`${this.baseUrl}/${siteId}/metrics`, {
      params: { hours: hours.toString() }
    });
  }

  // Create site
  createSite(site: Partial<Site>): Observable<Site> {
    return this.http.post<Site>(this.baseUrl, site);
  }

  // Update site
  updateSite(id: string, site: Partial<Site>): Observable<Site> {
    return this.http.put<Site>(`${this.baseUrl}/${id}`, site);
  }

  // Get sites statistics
  getSitesStatistics(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/statistics/summary`);
  }

  // Select a site (store in localStorage and subject)
  selectSite(site: Site): void {
    localStorage.setItem('selectedSite', JSON.stringify(site));
    this.selectedSiteSubject.next(site);
  }

  // Get selected site
  getSelectedSite(): Site | null {
    return this.selectedSiteSubject.value;
  }

  // Clear selected site
  clearSelectedSite(): void {
    localStorage.removeItem('selectedSite');
    this.selectedSiteSubject.next(null);
  }

  // Private helper to get site from localStorage
  private getSelectedSiteFromStorage(): Site | null {
    const siteStr = localStorage.getItem('selectedSite');
    if (siteStr) {
      try {
        return JSON.parse(siteStr);
      } catch {
        return null;
      }
    }
    return null;
  }
}
