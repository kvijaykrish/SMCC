import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, interval, of, catchError } from 'rxjs';
import { switchMap, shareReplay } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { NetworkTower, NetworkDevice, NetworkMetrics } from '../models/network.model';

@Injectable({
  providedIn: 'root'
})
export class NetworkService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/network`;

  // Real-time tower metrics (polls every 5 seconds)
  public towerMetrics$ = interval(5000).pipe(
    switchMap(() => this.getTowers()),
    shareReplay(1)
  );

  // Get all towers
  getTowers(params?: any): Observable<NetworkTower[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }

    return this.http.get<NetworkTower[]>(`${this.baseUrl}/towers`, { params: httpParams });
  }

  // Get single tower
  getTower(id: string): Observable<NetworkTower> {
    return this.http.get<NetworkTower>(`${this.baseUrl}/towers/${id}`);
  }

  // Create tower
  createTower(tower: Partial<NetworkTower>): Observable<NetworkTower> {
    return this.http.post<NetworkTower>(`${this.baseUrl}/towers`, tower);
  }

  // Update tower
  updateTower(id: string, tower: Partial<NetworkTower>): Observable<NetworkTower> {
    return this.http.put<NetworkTower>(`${this.baseUrl}/towers/${id}`, tower);
  }

  // Delete tower
  deleteTower(id: string): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/towers/${id}`);
  }

  // Get tower metrics
  getTowerMetrics(towerId: string, params?: any): Observable<NetworkMetrics[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }

    return this.http.get<NetworkMetrics[]>(`${this.baseUrl}/towers/${towerId}/metrics`, { params: httpParams });
  }

  // Get all devices
  getDevices(params?: any): Observable<NetworkDevice[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }

    return this.http.get<NetworkDevice[]>(`${this.baseUrl}/devices`, { params: httpParams });
  }

  // Get single device
  getDevice(id: string): Observable<NetworkDevice> {
    return this.http.get<NetworkDevice>(`${this.baseUrl}/devices/${id}`);
  }

  // Get devices by tower
  getDevicesByTower(towerId: string): Observable<NetworkDevice[]> {
    return this.http.get<NetworkDevice[]>(`${this.baseUrl}/towers/${towerId}/devices`);
  }

  // Get devices by asset
  getDevicesByAsset(assetId: string): Observable<NetworkDevice[]> {
    return this.http.get<NetworkDevice[]>(`${this.baseUrl}/devices/by-asset/${assetId}`);
  }

  // Update device
  updateDevice(id: string, device: Partial<NetworkDevice>): Observable<NetworkDevice> {
    return this.http.put<NetworkDevice>(`${this.baseUrl}/devices/${id}`, device);
  }

  // Get network statistics
  getNetworkStatistics(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/statistics`);
  }

  // Get coverage map data
  getCoverageMap(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/coverage-map`);
  }

  // Ping device
  pingDevice(deviceId: string): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/devices/${deviceId}/ping`, {});
  }

  // Restart device
  restartDevice(deviceId: string): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/devices/${deviceId}/restart`, {});
  }

  // Chart data endpoints
  getSummary(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/summary`).pipe(
      catchError(() => of({
        uptime: 99.8, totalDevices: 847, avgBandwidth: 890, avgLatency: 10.8,
      }))
    );
  }

  getPerformanceChartData(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/performance`).pipe(
      catchError(() => of([]))
    );
  }

  getBandwidthUsage(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/bandwidth-usage`).pipe(
      catchError(() => of([]))
    );
  }
}