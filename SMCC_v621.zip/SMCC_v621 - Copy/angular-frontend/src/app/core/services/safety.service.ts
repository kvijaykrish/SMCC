import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of, catchError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { SafetyIncident, TrainingProgram, VRSimulation, Certification, SafetyMetrics } from '../models/safety.model';

@Injectable({
  providedIn: 'root'
})
export class SafetyService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/safety`;

  // Safety Incidents
  getIncidents(params?: any): Observable<SafetyIncident[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get<SafetyIncident[]>(`${this.baseUrl}/incidents`, { params: httpParams });
  }

  getIncident(id: string): Observable<SafetyIncident> {
    return this.http.get<SafetyIncident>(`${this.baseUrl}/incidents/${id}`);
  }

  createIncident(incident: Partial<SafetyIncident>): Observable<SafetyIncident> {
    return this.http.post<SafetyIncident>(`${this.baseUrl}/incidents`, incident);
  }

  // Training Programs
  getTrainingPrograms(params?: any): Observable<TrainingProgram[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }
    return this.http.get<TrainingProgram[]>(`${this.baseUrl}/training`, { params: httpParams });
  }

  getTrainingProgram(id: string): Observable<TrainingProgram> {
    return this.http.get<TrainingProgram>(`${this.baseUrl}/training/${id}`);
  }

  // VR Simulations
  getVRSimulations(): Observable<VRSimulation[]> {
    return this.http.get<VRSimulation[]>(`${this.baseUrl}/vr-simulations`);
  }

  // Certifications
  getCertifications(params?: any): Observable<Certification[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }
    return this.http.get<Certification[]>(`${this.baseUrl}/certifications`, { params: httpParams });
  }

  // Safety Metrics
  getSafetyMetrics(): Observable<SafetyMetrics> {
    return this.http.get<SafetyMetrics>(`${this.baseUrl}/metrics`);
  }

  // Statistics
  getSafetyStatistics(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/statistics`);
  }

  // Chart data endpoints
  getSummary(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/summary`).pipe(
      catchError(() => of({
        safetyScore: 98.5, activeTraining: 342, incidents30d: 1,
        certifications: 285, certExpiring: 45, certExpired: 12,
      }))
    );
  }

  getMetricsChartData(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/metrics`).pipe(
      catchError(() => of([]))
    );
  }

  getCertificationChartData(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/certifications`).pipe(
      catchError(() => of([]))
    );
  }
}