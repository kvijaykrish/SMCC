import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of, catchError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Pipeline, WaterQualityMetric, WaterUsageRecord, WaterTreatmentPlant } from '../models/water.model';

@Injectable({
  providedIn: 'root'
})
export class WaterService {
  private http = inject(HttpClient);
  private baseUrl = `${environment.apiUrl}/api/water`;

  // Pipelines
  getPipelines(params?: any): Observable<Pipeline[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get<Pipeline[]>(`${this.baseUrl}/pipelines`, { params: httpParams });
  }

  getPipeline(id: string): Observable<Pipeline> {
    return this.http.get<Pipeline>(`${this.baseUrl}/pipelines/${id}`);
  }

  // Water Quality
  getWaterQuality(params?: any): Observable<WaterQualityMetric[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }
    return this.http.get<WaterQualityMetric[]>(`${this.baseUrl}/quality`, { params: httpParams });
  }

  // Water Usage
  getWaterUsage(params?: any): Observable<WaterUsageRecord[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        httpParams = httpParams.set(key, params[key]);
      });
    }
    return this.http.get<WaterUsageRecord[]>(`${this.baseUrl}/usage`, { params: httpParams });
  }

  // Treatment Plants
  getTreatmentPlants(): Observable<WaterTreatmentPlant[]> {
    return this.http.get<WaterTreatmentPlant[]>(`${this.baseUrl}/treatment-plants`);
  }

  // Statistics
  getWaterStatistics(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/statistics`);
  }

  // Flow Network (animated flow diagram)
  getFlowNetwork(params?: any): Observable<any> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get<any>(`${this.baseUrl}/flow-network`, { params: httpParams });
  }

  // Update flow node
  updateFlowNode(nodeKey: string, data: any): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/flow-network/nodes/${nodeKey}`, data);
  }

  // Water Sources
  getSources(params?: any): Observable<any[]> {
    let httpParams = new HttpParams();
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key]);
        }
      });
    }
    return this.http.get<any[]>(`${this.baseUrl}/sources`, { params: httpParams }).pipe(
      catchError(() => of([]))
    );
  }

  // Chart data endpoints
  getSummary(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/summary`).pipe(
      catchError(() => of({
        dailyUsage: '10,000 m³', waterQuality: 97.8,
        systemPressure: 44, activePipelines: 5, totalPipelines: 6,
      }))
    );
  }

  getUsageChartData(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/usage`).pipe(
      catchError(() => of([]))
    );
  }

  getUsageByZone(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/chart/usage-by-zone`).pipe(
      catchError(() => of([]))
    );
  }
}