import { Routes } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { SiteSelectionGuard } from './core/guards/site-selection.guard';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'sites',
    canActivate: [AuthGuard],
    loadComponent: () => import('./features/site-selection/site-selection.component').then(m => m.SiteSelectionComponent)
  },
  {
    path: '',
    canActivate: [AuthGuard, SiteSelectionGuard],
    loadComponent: () => import('./layout/main-layout/main-layout.component').then(m => m.MainLayoutComponent),
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      {
        path: 'dashboard',
        loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent)
      },
      {
        path: 'video-tour',
        loadComponent: () => import('./features/video-tour/video-tour.component').then(m => m.VideoTourComponent)
      },
      {
        path: 'connected-assets',
        loadComponent: () => import('./features/connected-assets/connected-assets.component').then(m => m.ConnectedAssetsComponent)
      },
      {
        path: 'digital-twin/:id',
        loadComponent: () => import('./features/digital-twin/digital-twin.component').then(m => m.DigitalTwinComponent)
      },
      {
        path: 'private-5g',
        loadComponent: () => import('./features/private-5g/private-5g.component').then(m => m.Private5GComponent)
      },
      {
        path: 'geo-spatial',
        loadComponent: () => import('./features/geo-spatial/geo-spatial.component').then(m => m.GeoSpatialComponent)
      },
      {
        path: 'security',
        loadComponent: () => import('./features/security/security.component').then(m => m.SecurityComponent)
      },
      {
        path: 'video-stream',
        loadComponent: () => import('./features/video-stream/video-stream.component').then(m => m.VideoStreamComponent)
      },
      {
        path: 'water-management',
        loadComponent: () => import('./features/water-management/water-management.component').then(m => m.WaterManagementComponent)
      },
      {
        path: 'safety-training',
        loadComponent: () => import('./features/safety-training/safety-training.component').then(m => m.SafetyTrainingComponent)
      },
      {
        path: 'historical-reports',
        loadComponent: () => import('./features/historical-reports/historical-reports.component').then(m => m.HistoricalReportsComponent)
      },
      {
        path: 'ai-assistant',
        loadComponent: () => import('./features/ai-assistant/ai-assistant.component').then(m => m.AiAssistantComponent)
      }
    ]
  },
  {
    path: '**',
    redirectTo: 'sites'
  }
];
