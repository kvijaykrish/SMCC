import { Component, Input, Output, EventEmitter, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { User } from '../../core/services/auth.service';
import { SiteService } from '../../core/services/site.service';
import { Site } from '../../core/models/site.model';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() user: User | null = null;
  @Output() toggleSidebar = new EventEmitter<void>();
  @Output() logout = new EventEmitter<void>();

  private siteService = inject(SiteService);
  private router = inject(Router);

  showUserMenu = false;
  showNotifications = false;
  notificationCount = 3;
  selectedSite: Site | null = null;

  ngOnInit(): void {
    this.siteService.selectedSite$.subscribe(site => {
      this.selectedSite = site;
    });
  }

  onToggleSidebar(): void {
    this.toggleSidebar.emit();
  }

  onLogout(): void {
    this.logout.emit();
    this.showUserMenu = false;
  }

  toggleUserMenu(): void {
    this.showUserMenu = !this.showUserMenu;
    this.showNotifications = false;
  }

  toggleNotifications(): void {
    this.showNotifications = !this.showNotifications;
    this.showUserMenu = false;
  }

  changeSite(): void {
    this.router.navigate(['/sites']);
  }
}
