import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, OnChanges, SimpleChanges, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Site } from '../core/models/site.model';

// dynamic Leaflet loader (same URLs used in React version)
const LEAFLET_CSS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
const LEAFLET_JS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
let leafletPromise: Promise<any> | null = null;

function loadLeaflet(): Promise<any> {
  if (leafletPromise) {
    return leafletPromise;
  }
  leafletPromise = new Promise((resolve, reject) => {
    if ((window as any).L) {
      resolve((window as any).L);
      return;
    }
    // inject CSS
    if (!document.querySelector(`link[href="${LEAFLET_CSS}"]`)) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = LEAFLET_CSS;
      document.head.appendChild(link);
    }
    // inject JS
    const script = document.createElement('script');
    script.src = LEAFLET_JS;
    script.onload = () => resolve((window as any).L);
    script.onerror = () => {
      leafletPromise = null;
      reject(new Error('Failed to load Leaflet'));
    };
    document.head.appendChild(script);
  });
  return leafletPromise;
}

@Component({
  selector: 'app-mine-map',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div class="relative w-full h-full">
    <div #mapContainer class="w-full h-full"></div>
    <div *ngIf="isLoading" class="absolute inset-0 flex items-center justify-center">
      <svg class="animate-spin w-10 h-10 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
      </svg>
    </div>
    <div *ngIf="error" class="absolute inset-0 flex items-center justify-center bg-black/50 text-red-300">{{ error }}</div>
    <button
      class="absolute top-2 right-2 bg-slate-800/60 hover:bg-slate-800 text-white rounded-md px-2 py-1 flex items-center gap-1 text-xs z-20"
      (click)="toggleStyle()"
      [title]="mapStyle === 'satellite' ? 'Switch to Dark Map' : 'Switch to Satellite'">
      <span *ngIf="mapStyle === 'satellite'">Dark</span>
      <span *ngIf="mapStyle === 'dark'">Sat</span>
    </button>
  </div>
  `
})
export class MineMapComponent implements OnInit, OnDestroy, OnChanges {
  @Input() sites: Site[] = [];
  @Input() selectedSiteId?: string | null;
  @Output() siteSelected = new EventEmitter<string>();
  @Output() navigate = new EventEmitter<string>();

  @ViewChild('mapContainer', { static: true }) mapContainer!: ElementRef<HTMLDivElement>;

  map: any;
  markers: Array<{ siteId: string; marker: any }> = [];
  tileLayers: { base: any | null; labels: any | null } = { base: null, labels: null };
  isLoading = true;
  tilesLoading = false;
  error: string | null = null;
  mapStyle: 'satellite' | 'dark' = 'satellite';

  ngOnInit() {
    this.initializeMap();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.sites && this.map) {
      this.updateMarkers();
    }

    if (changes.selectedSiteId && this.map && this.selectedSiteId) {
      const entry = this.markers.find(m => m.siteId === this.selectedSiteId);
      if (entry) {
        this.map.flyTo(entry.marker.getLatLng(), 6);
        entry.marker.openPopup();
      }
    }
  }

  ngOnDestroy() {
    if (this.map) {
      // remove resize observer if attached
      const obs = (this.map as any)._resizeObserver;
      if (obs) obs.disconnect();
      this.map.remove();
    }
  }

  async initializeMap() {
    try {
      const L = await loadLeaflet();
      if (!this.mapContainer) return;
      const container = this.mapContainer.nativeElement;
      if (container.clientHeight === 0) {
        container.style.minHeight = '400px';
      }
      this.map = L.map(container, {
        center: [20, 20],
        zoom: 2,
        minZoom: 2,
        maxZoom: 18,
        zoomControl: false,
        attributionControl: false,
        preferCanvas: true,
        updateWhenZooming: false,
        updateWhenIdle: true,
        keepBuffer: 4
      });

      const dark = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        subdomains: 'abcd',
        maxZoom: 19,
        attribution: ''
      }).addTo(this.map);

      const sat = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 18,
        tileSize: 256,
        attribution: ''
      }).addTo(this.map);

      const labels = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png', {
        subdomains: 'abcd',
        maxZoom: 18,
        pane: 'overlayPane',
        attribution: ''
      }).addTo(this.map);

      this.tileLayers = { base: sat, labels };

      // track loading
      let loadingCount = 0;
      sat.on('loading', () => { loadingCount++; this.tilesLoading = true; });
      sat.on('load', () => { loadingCount = Math.max(0, loadingCount - 1); if (loadingCount === 0) this.tilesLoading = false; });

      L.control.zoom({ position: 'topright' }).addTo(this.map);

      this.map.whenReady(() => {
        this.isLoading = false;
        setTimeout(() => this.map.invalidateSize({ animate: false }), 100);
      });

      const resizeObserver = new ResizeObserver(() => {
        this.map.invalidateSize({ animate: false });
      });
      resizeObserver.observe(container);
      (this.map as any)._resizeObserver = resizeObserver;

      this.updateMarkers();
    } catch (err) {
      console.error('Map init error', err);
      this.error = 'Failed to load map. Please refresh page.';
      this.isLoading = false;
    }
  }

  updateMarkers() {
    // clear existing
    this.markers.forEach(m => this.map.removeLayer(m.marker));
    this.markers = [];

    const L = (window as any).L;
    if (!L || !this.map) return;

    this.sites.forEach(site => {
      const lat = site.latitude || 0;
      const lng = site.longitude || 0;
      const marker = L.circleMarker([lat, lng], {
        radius: 8,
        fillColor: COMMODITY_COLORS[site.primaryCommodity] || '#3b82f6',
        color: '#000',
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8
      });

      const popupContent = `
        <div class="text-sm font-semibold mb-1">${site.name}</div>
        <button data-site-id="${site.id}" class="mine-map-enter px-2 py-1 bg-blue-600 text-white rounded text-xs">Enter</button>
      `;
      marker.bindPopup(popupContent, { closeButton: false, autoClose: false, className: 'mine-map-popup' });

      marker.on('click', () => {
        this.siteSelected.emit(site.id);
      });

      marker.addTo(this.map);
      this.markers.push({ siteId: site.id, marker });
    });

    // hook popup click once map is ready
    this.map.on('popupopen', (e: any) => {
      const el: HTMLElement | null = e.popup.getElement()?.querySelector('.mine-map-enter');
      if (el) {
        const id = el.getAttribute('data-site-id');
        if (id) {
          el.addEventListener('click', () => {
            this.navigate.emit(id);
          });
        }
      }
    });
  }

  toggleStyle() {
    if (!this.tileLayers.base) return;
    if (this.mapStyle === 'satellite') {
      // switch to dark
      this.map.removeLayer(this.tileLayers.base);
      const dark = (window as any).L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        subdomains: 'abcd', maxZoom: 19, attribution: ''
      });
      dark.addTo(this.map);
      this.tileLayers.base = dark;
      this.mapStyle = 'dark';
    } else {
      this.map.removeLayer(this.tileLayers.base);
      const sat = (window as any).L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 18, tileSize: 256, attribution: ''
      });
      sat.addTo(this.map);
      this.tileLayers.base = sat;
      this.mapStyle = 'satellite';
    }
  }
}

// static helpers reused
const COMMODITY_COLORS: Record<string, string> = {
  'Iron Ore': '#ef4444',
  'Copper': '#f97316',
  'Gold': '#eab308',
  'Bauxite': '#f59e0b',
  'Platinum': '#cbd5e1',
  'Processing Plant': '#06b6d4',
};
