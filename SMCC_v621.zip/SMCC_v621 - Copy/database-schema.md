# SDS Smart Mining Command Center - Database Schema

## Overview
Complete database schema for the Smart Mining Command Center covering all 6 main modules: Digital Infrastructure, Security, Resource Management, Safety, and Training.

---

## 1. CORE SYSTEM TABLES

### `users`
User authentication and profile management
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL, -- 'admin', 'operator', 'supervisor', 'engineer', 'safety_officer'
  department VARCHAR(100),
  phone VARCHAR(20),
  avatar_url TEXT,
  is_active BOOLEAN DEFAULT true,
  last_login_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_active ON users(is_active);
```

### `audit_logs`
System-wide audit trail
```sql
CREATE TABLE audit_logs (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  action VARCHAR(100) NOT NULL, -- 'login', 'asset_update', 'alert_acknowledged', etc.
  entity_type VARCHAR(100), -- 'asset', 'alert', 'zone', etc.
  entity_id VARCHAR(100),
  old_values JSONB,
  new_values JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_created ON audit_logs(created_at DESC);
```

### `system_settings`
Global system configuration
```sql
CREATE TABLE system_settings (
  id SERIAL PRIMARY KEY,
  setting_key VARCHAR(100) UNIQUE NOT NULL,
  setting_value JSONB NOT NULL,
  category VARCHAR(50), -- 'network', 'alerts', 'thresholds', etc.
  description TEXT,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_settings_category ON system_settings(category);
```

---

## 2. ASSET MANAGEMENT TABLES

### `assets`
All mining equipment and vehicles
```sql
CREATE TABLE assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id VARCHAR(50) UNIQUE NOT NULL, -- 'EXC-001', 'HTK-045', etc.
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL, -- 'excavator', 'haul_truck', 'drill', 'dozer', 'loader', etc.
  manufacturer VARCHAR(100),
  model VARCHAR(100),
  serial_number VARCHAR(100) UNIQUE,
  year_manufactured INTEGER,
  purchase_date DATE,
  warranty_expires_at DATE,
  status VARCHAR(50) DEFAULT 'active', -- 'active', 'maintenance', 'inactive', 'retired'
  current_zone_id UUID, -- REFERENCES zones(id)
  assigned_operator_id UUID REFERENCES users(id),
  operating_hours DECIMAL(10,2) DEFAULT 0,
  last_maintenance_at TIMESTAMP,
  next_maintenance_at TIMESTAMP,
  maintenance_interval_hours INTEGER DEFAULT 250,
  metadata JSONB, -- Additional flexible data
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_assets_type ON assets(type);
CREATE INDEX idx_assets_status ON assets(status);
CREATE INDEX idx_assets_zone ON assets(current_zone_id);
CREATE INDEX idx_assets_operator ON assets(assigned_operator_id);
```

### `asset_telemetry`
Real-time sensor data from assets (time-series data)
```sql
CREATE TABLE asset_telemetry (
  id BIGSERIAL PRIMARY KEY,
  asset_id UUID REFERENCES assets(id) ON DELETE CASCADE,
  timestamp TIMESTAMP NOT NULL,
  
  -- Location data
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  altitude DECIMAL(8, 2),
  heading DECIMAL(5, 2), -- 0-360 degrees
  speed DECIMAL(6, 2), -- km/h
  
  -- Operational data
  engine_temp DECIMAL(5, 2), -- Fahrenheit
  hydraulic_pressure DECIMAL(6, 2), -- PSI
  fuel_level DECIMAL(5, 2), -- Percentage
  battery_voltage DECIMAL(4, 2),
  
  -- Performance metrics
  load_weight DECIMAL(10, 2), -- kg
  vibration_level DECIMAL(5, 2), -- mm/s
  rpm INTEGER,
  gear INTEGER,
  
  -- Status flags
  is_operating BOOLEAN DEFAULT false,
  error_codes TEXT[], -- Array of error codes
  
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_telemetry_asset ON asset_telemetry(asset_id, timestamp DESC);
CREATE INDEX idx_telemetry_timestamp ON asset_telemetry(timestamp DESC);
-- Consider partitioning this table by timestamp for performance
```

### `asset_components`
Individual components/systems within each asset
```sql
CREATE TABLE asset_components (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id UUID REFERENCES assets(id) ON DELETE CASCADE,
  component_id VARCHAR(50) NOT NULL, -- 'engine', 'hydraulics', 'transmission', 'tracks', etc.
  name VARCHAR(255) NOT NULL,
  health_score DECIMAL(5, 2) DEFAULT 100, -- 0-100
  status VARCHAR(50) DEFAULT 'optimal', -- 'optimal', 'good', 'warning', 'critical'
  
  -- Component-specific metrics
  temperature DECIMAL(5, 2),
  pressure DECIMAL(6, 2),
  vibration DECIMAL(5, 2),
  wear_level DECIMAL(5, 2), -- Percentage
  
  operating_hours DECIMAL(10, 2) DEFAULT 0,
  last_maintenance_at TIMESTAMP,
  next_maintenance_hours INTEGER,
  
  metadata JSONB, -- Component-specific data
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_components_asset ON asset_components(asset_id);
CREATE INDEX idx_components_status ON asset_components(status);
CREATE INDEX idx_components_health ON asset_components(health_score);
```

### `digital_twins`
Digital twin model data
```sql
CREATE TABLE digital_twins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id UUID REFERENCES assets(id) ON DELETE CASCADE UNIQUE,
  model_version VARCHAR(50) NOT NULL,
  polygon_count INTEGER,
  vertex_count INTEGER,
  
  -- 3D model data
  mesh_data JSONB, -- Vertex, face, normal data
  texture_urls TEXT[],
  
  -- Sync metrics
  last_sync_at TIMESTAMP,
  sync_interval_seconds INTEGER DEFAULT 1,
  position_accuracy DECIMAL(5, 2), -- Percentage
  
  -- Predictive analytics
  predicted_failures JSONB, -- Array of predicted component failures
  maintenance_recommendations JSONB,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_twins_asset ON digital_twins(asset_id);
CREATE INDEX idx_twins_sync ON digital_twins(last_sync_at);
```

### `maintenance_records`
Historical maintenance activities
```sql
CREATE TABLE maintenance_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  asset_id UUID REFERENCES assets(id) ON DELETE CASCADE,
  maintenance_type VARCHAR(50) NOT NULL, -- 'scheduled', 'preventive', 'corrective', 'emergency'
  priority VARCHAR(20), -- 'low', 'medium', 'high', 'critical'
  
  scheduled_at TIMESTAMP,
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  
  description TEXT NOT NULL,
  components_serviced TEXT[],
  parts_replaced JSONB, -- [{part_id, part_name, quantity, cost}]
  
  technician_id UUID REFERENCES users(id),
  labor_hours DECIMAL(6, 2),
  total_cost DECIMAL(10, 2),
  
  status VARCHAR(50) DEFAULT 'scheduled', -- 'scheduled', 'in_progress', 'completed', 'cancelled'
  notes TEXT,
  attachments TEXT[], -- URLs to photos/documents
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_maintenance_asset ON maintenance_records(asset_id);
CREATE INDEX idx_maintenance_status ON maintenance_records(status);
CREATE INDEX idx_maintenance_scheduled ON maintenance_records(scheduled_at);
```

---

## 3. NETWORK & CONNECTIVITY TABLES

### `network_towers`
5G network tower infrastructure
```sql
CREATE TABLE network_towers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tower_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  
  -- Location
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  altitude DECIMAL(8, 2),
  
  -- Technical specs
  frequency_band VARCHAR(20), -- 'n77', 'n78', 'n79', etc.
  max_bandwidth INTEGER, -- Mbps
  coverage_radius INTEGER, -- meters
  antenna_type VARCHAR(100),
  
  -- Status
  status VARCHAR(50) DEFAULT 'active', -- 'active', 'maintenance', 'offline'
  uptime_percentage DECIMAL(5, 2),
  
  -- Metrics
  current_load DECIMAL(5, 2), -- Percentage
  connected_devices INTEGER DEFAULT 0,
  signal_strength DECIMAL(5, 2), -- dBm
  
  installed_at DATE,
  last_maintenance_at TIMESTAMP,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_towers_status ON network_towers(status);
CREATE INDEX idx_towers_location ON network_towers(latitude, longitude);
```

### `network_devices`
Connected devices on the network
```sql
CREATE TABLE network_devices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_id VARCHAR(100) UNIQUE NOT NULL,
  device_name VARCHAR(255),
  device_type VARCHAR(50), -- 'asset', 'sensor', 'camera', 'gateway', 'router'
  
  asset_id UUID REFERENCES assets(id), -- If device is attached to an asset
  tower_id UUID REFERENCES network_towers(id),
  
  -- Network info
  ip_address INET,
  mac_address MACADDR,
  imei VARCHAR(20),
  sim_card_id VARCHAR(50),
  
  -- Connection metrics
  signal_strength DECIMAL(5, 2), -- dBm
  latency INTEGER, -- ms
  bandwidth_up INTEGER, -- Mbps
  bandwidth_down INTEGER, -- Mbps
  packet_loss DECIMAL(5, 2), -- Percentage
  
  status VARCHAR(50) DEFAULT 'online', -- 'online', 'offline', 'error'
  last_seen_at TIMESTAMP,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_devices_type ON network_devices(device_type);
CREATE INDEX idx_devices_asset ON network_devices(asset_id);
CREATE INDEX idx_devices_tower ON network_devices(tower_id);
CREATE INDEX idx_devices_status ON network_devices(status);
```

### `network_metrics`
Time-series network performance data
```sql
CREATE TABLE network_metrics (
  id BIGSERIAL PRIMARY KEY,
  tower_id UUID REFERENCES network_towers(id) ON DELETE CASCADE,
  timestamp TIMESTAMP NOT NULL,
  
  throughput_mbps DECIMAL(8, 2),
  latency_ms INTEGER,
  packet_loss DECIMAL(5, 2),
  connected_devices INTEGER,
  bandwidth_utilization DECIMAL(5, 2), -- Percentage
  error_rate DECIMAL(5, 2),
  
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_network_metrics_tower ON network_metrics(tower_id, timestamp DESC);
CREATE INDEX idx_network_metrics_timestamp ON network_metrics(timestamp DESC);
```

---

## 4. GEO-SPATIAL TABLES

### `zones`
Operational zones in the mining site
```sql
CREATE TABLE zones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id VARCHAR(50) UNIQUE NOT NULL, -- 'zone-a', 'zone-b', etc.
  name VARCHAR(255) NOT NULL,
  zone_type VARCHAR(50), -- 'primary_pit', 'secondary_pit', 'processing', 'maintenance', 'office', 'restricted'
  
  -- Location bounds (polygon)
  boundary GEOGRAPHY(POLYGON, 4326), -- PostGIS geography type
  area_sq_meters DECIMAL(12, 2),
  
  -- Center point
  center_latitude DECIMAL(10, 8),
  center_longitude DECIMAL(11, 8),
  
  status VARCHAR(50) DEFAULT 'active', -- 'active', 'inactive', 'maintenance', 'restricted'
  max_capacity INTEGER, -- Maximum assets allowed
  current_asset_count INTEGER DEFAULT 0,
  
  -- Safety
  speed_limit INTEGER, -- km/h
  requires_permit BOOLEAN DEFAULT false,
  hazard_level VARCHAR(20), -- 'low', 'medium', 'high', 'critical'
  
  supervisor_id UUID REFERENCES users(id),
  
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_zones_type ON zones(zone_type);
CREATE INDEX idx_zones_status ON zones(status);
-- Spatial index for PostGIS
CREATE INDEX idx_zones_boundary ON zones USING GIST(boundary);
```

### `haul_routes`
Predefined routes for haul trucks
```sql
CREATE TABLE haul_routes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  route_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  
  from_zone_id UUID REFERENCES zones(id),
  to_zone_id UUID REFERENCES zones(id),
  
  -- Route path (line string)
  path GEOGRAPHY(LINESTRING, 4326),
  distance_meters DECIMAL(10, 2),
  
  status VARCHAR(50) DEFAULT 'active', -- 'active', 'closed', 'restricted'
  speed_limit INTEGER, -- km/h
  
  -- Traffic metrics
  average_travel_time INTEGER, -- seconds
  current_traffic_level VARCHAR(20), -- 'low', 'medium', 'high'
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_routes_from_zone ON haul_routes(from_zone_id);
CREATE INDEX idx_routes_to_zone ON haul_routes(to_zone_id);
CREATE INDEX idx_routes_status ON haul_routes(status);
CREATE INDEX idx_routes_path ON haul_routes USING GIST(path);
```

### `geofence_events`
Log when assets enter/exit zones
```sql
CREATE TABLE geofence_events (
  id BIGSERIAL PRIMARY KEY,
  asset_id UUID REFERENCES assets(id) ON DELETE CASCADE,
  zone_id UUID REFERENCES zones(id) ON DELETE CASCADE,
  event_type VARCHAR(20) NOT NULL, -- 'enter', 'exit'
  
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  
  timestamp TIMESTAMP NOT NULL,
  duration_seconds INTEGER, -- For exit events, how long was asset in zone
  
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_geofence_asset ON geofence_events(asset_id, timestamp DESC);
CREATE INDEX idx_geofence_zone ON geofence_events(zone_id, timestamp DESC);
CREATE INDEX idx_geofence_timestamp ON geofence_events(timestamp DESC);
```

### `waypoints`
GPS waypoints for navigation
```sql
CREATE TABLE waypoints (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  waypoint_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  altitude DECIMAL(8, 2),
  
  waypoint_type VARCHAR(50), -- 'loading_point', 'dump_point', 'checkpoint', 'parking'
  zone_id UUID REFERENCES zones(id),
  
  is_active BOOLEAN DEFAULT true,
  metadata JSONB,
  
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_waypoints_type ON waypoints(waypoint_type);
CREATE INDEX idx_waypoints_zone ON waypoints(zone_id);
```

---

## 5. SECURITY & SURVEILLANCE TABLES

### `cameras`
Security cameras and video feeds
```sql
CREATE TABLE cameras (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  camera_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  
  -- Location
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  zone_id UUID REFERENCES zones(id),
  installation_location VARCHAR(255), -- 'Tower A', 'Gate 1', etc.
  
  -- Camera specs
  camera_type VARCHAR(50), -- 'fixed', 'ptz', 'thermal', '360'
  resolution VARCHAR(20), -- '1080p', '4K', etc.
  field_of_view INTEGER, -- degrees
  has_night_vision BOOLEAN DEFAULT false,
  has_motion_detection BOOLEAN DEFAULT false,
  
  -- Stream info
  stream_url TEXT,
  rtsp_url TEXT,
  
  -- Status
  status VARCHAR(50) DEFAULT 'online', -- 'online', 'offline', 'maintenance', 'error'
  is_recording BOOLEAN DEFAULT true,
  
  -- Metrics
  uptime_percentage DECIMAL(5, 2),
  last_maintenance_at TIMESTAMP,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_cameras_zone ON cameras(zone_id);
CREATE INDEX idx_cameras_status ON cameras(status);
CREATE INDEX idx_cameras_type ON cameras(camera_type);
```

### `security_events`
Security incidents and detections
```sql
CREATE TABLE security_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id VARCHAR(50) UNIQUE NOT NULL,
  event_type VARCHAR(50) NOT NULL, -- 'intrusion', 'unauthorized_access', 'perimeter_breach', 'motion_detected'
  severity VARCHAR(20) NOT NULL, -- 'low', 'medium', 'high', 'critical'
  
  camera_id UUID REFERENCES cameras(id),
  zone_id UUID REFERENCES zones(id),
  
  -- Location
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  
  description TEXT,
  detected_at TIMESTAMP NOT NULL,
  
  -- AI/ML detection data
  confidence_score DECIMAL(5, 2), -- Percentage
  detection_metadata JSONB, -- Bounding boxes, object types, etc.
  
  -- Response
  status VARCHAR(50) DEFAULT 'new', -- 'new', 'acknowledged', 'investigating', 'resolved', 'false_positive'
  acknowledged_by UUID REFERENCES users(id),
  acknowledged_at TIMESTAMP,
  resolution_notes TEXT,
  resolved_at TIMESTAMP,
  
  -- Media
  snapshot_url TEXT,
  video_clip_url TEXT,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_security_events_type ON security_events(event_type);
CREATE INDEX idx_security_events_severity ON security_events(severity);
CREATE INDEX idx_security_events_status ON security_events(status);
CREATE INDEX idx_security_events_detected ON security_events(detected_at DESC);
CREATE INDEX idx_security_events_camera ON security_events(camera_id);
```

### `access_control_points`
Physical access control gates/checkpoints
```sql
CREATE TABLE access_control_points (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  access_point_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  zone_id UUID REFERENCES zones(id),
  
  access_type VARCHAR(50), -- 'gate', 'door', 'turnstile', 'barrier'
  
  status VARCHAR(50) DEFAULT 'active', -- 'active', 'inactive', 'maintenance'
  is_locked BOOLEAN DEFAULT false,
  
  requires_authorization BOOLEAN DEFAULT true,
  authorized_roles TEXT[], -- Array of role names
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_access_points_zone ON access_control_points(zone_id);
CREATE INDEX idx_access_points_status ON access_control_points(status);
```

### `access_logs`
Access control event logs
```sql
CREATE TABLE access_logs (
  id BIGSERIAL PRIMARY KEY,
  access_point_id UUID REFERENCES access_control_points(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  
  access_type VARCHAR(20) NOT NULL, -- 'entry', 'exit'
  access_method VARCHAR(50), -- 'card', 'biometric', 'code', 'manual'
  
  granted BOOLEAN NOT NULL,
  denial_reason VARCHAR(255),
  
  timestamp TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_access_logs_point ON access_logs(access_point_id, timestamp DESC);
CREATE INDEX idx_access_logs_user ON access_logs(user_id, timestamp DESC);
CREATE INDEX idx_access_logs_timestamp ON access_logs(timestamp DESC);
```

---

## 6. WATER MANAGEMENT TABLES

### `water_sources`
Water storage and sources
```sql
CREATE TABLE water_sources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  source_type VARCHAR(50) NOT NULL, -- 'reservoir', 'tank', 'well', 'treatment_plant'
  
  -- Location
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  zone_id UUID REFERENCES zones(id),
  
  -- Capacity
  capacity_liters DECIMAL(12, 2) NOT NULL,
  current_level_liters DECIMAL(12, 2) DEFAULT 0,
  
  -- Quality
  water_quality_score DECIMAL(5, 2), -- Percentage
  ph_level DECIMAL(4, 2),
  turbidity DECIMAL(6, 2), -- NTU
  temperature DECIMAL(5, 2), -- Celsius
  dissolved_oxygen DECIMAL(5, 2), -- mg/L
  
  status VARCHAR(50) DEFAULT 'optimal', -- 'optimal', 'warning', 'critical', 'offline'
  
  -- Flow
  inflow_rate DECIMAL(8, 2), -- L/min
  outflow_rate DECIMAL(8, 2), -- L/min
  
  last_inspection_at TIMESTAMP,
  next_inspection_at TIMESTAMP,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_water_sources_type ON water_sources(source_type);
CREATE INDEX idx_water_sources_status ON water_sources(status);
CREATE INDEX idx_water_sources_zone ON water_sources(zone_id);
```

### `water_equipment`
Pumps, motors, valves
```sql
CREATE TABLE water_equipment (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  equipment_id VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  equipment_type VARCHAR(50) NOT NULL, -- 'pump', 'motor', 'valve'
  
  source_id UUID REFERENCES water_sources(id),
  
  -- Operational data
  status VARCHAR(50) DEFAULT 'running', -- 'running', 'stopped', 'maintenance', 'error'
  flow_rate DECIMAL(8, 2), -- L/min
  pressure DECIMAL(6, 2), -- bar
  temperature DECIMAL(5, 2), -- Fahrenheit
  
  -- For motors and pumps
  rpm INTEGER,
  power_consumption DECIMAL(8, 2), -- kW
  
  -- For valves
  position_percentage DECIMAL(5, 2), -- 0-100, valve opening
  
  operating_hours DECIMAL(10, 2) DEFAULT 0,
  last_maintenance_at TIMESTAMP,
  next_maintenance_hours INTEGER,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_water_equipment_type ON water_equipment(equipment_type);
CREATE INDEX idx_water_equipment_status ON water_equipment(status);
CREATE INDEX idx_water_equipment_source ON water_equipment(source_id);
```

### `water_usage_zones`
Water consumption by zone
```sql
CREATE TABLE water_usage_zones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  zone_id UUID REFERENCES zones(id) ON DELETE CASCADE,
  
  -- Usage metrics
  current_usage DECIMAL(10, 2), -- L/hour
  daily_usage DECIMAL(12, 2), -- Liters
  monthly_usage DECIMAL(14, 2), -- Liters
  
  -- Targets
  daily_target DECIMAL(12, 2),
  monthly_target DECIMAL(14, 2),
  
  -- Conservation
  recycled_percentage DECIMAL(5, 2),
  
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_water_usage_zone ON water_usage_zones(zone_id);
```

### `water_quality_tests`
Regular water quality testing results
```sql
CREATE TABLE water_quality_tests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id UUID REFERENCES water_sources(id) ON DELETE CASCADE,
  tested_at TIMESTAMP NOT NULL,
  
  -- Test results
  ph_level DECIMAL(4, 2),
  turbidity DECIMAL(6, 2), -- NTU
  temperature DECIMAL(5, 2), -- Celsius
  dissolved_oxygen DECIMAL(5, 2), -- mg/L
  conductivity DECIMAL(8, 2), -- μS/cm
  
  -- Contaminants
  total_dissolved_solids DECIMAL(8, 2), -- mg/L
  heavy_metals JSONB, -- {metal: concentration}
  bacteria_count INTEGER,
  
  -- Compliance
  meets_standards BOOLEAN,
  violations TEXT[],
  
  tested_by UUID REFERENCES users(id),
  lab_reference VARCHAR(100),
  notes TEXT,
  
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_quality_tests_source ON water_quality_tests(source_id, tested_at DESC);
CREATE INDEX idx_quality_tests_timestamp ON water_quality_tests(tested_at DESC);
```

---

## 7. SAFETY & TRAINING TABLES

### `safety_incidents`
Safety incidents and near-misses
```sql
CREATE TABLE safety_incidents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  incident_id VARCHAR(50) UNIQUE NOT NULL,
  incident_type VARCHAR(50) NOT NULL, -- 'injury', 'near_miss', 'equipment_failure', 'spill', 'fire'
  severity VARCHAR(20) NOT NULL, -- 'minor', 'moderate', 'serious', 'critical', 'fatal'
  
  -- Location
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  zone_id UUID REFERENCES zones(id),
  location_description TEXT,
  
  -- Involved parties
  reported_by UUID REFERENCES users(id),
  involved_personnel UUID[], -- Array of user IDs
  involved_assets UUID[], -- Array of asset IDs
  
  occurred_at TIMESTAMP NOT NULL,
  reported_at TIMESTAMP NOT NULL,
  
  description TEXT NOT NULL,
  immediate_actions_taken TEXT,
  
  -- Investigation
  status VARCHAR(50) DEFAULT 'reported', -- 'reported', 'investigating', 'resolved', 'closed'
  investigated_by UUID REFERENCES users(id),
  investigation_notes TEXT,
  root_cause TEXT,
  corrective_actions TEXT,
  
  -- Follow-up
  requires_medical_attention BOOLEAN DEFAULT false,
  requires_regulatory_report BOOLEAN DEFAULT false,
  lost_time_injury BOOLEAN DEFAULT false,
  
  closed_at TIMESTAMP,
  
  attachments TEXT[], -- Photos, documents
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_incidents_type ON safety_incidents(incident_type);
CREATE INDEX idx_incidents_severity ON safety_incidents(severity);
CREATE INDEX idx_incidents_status ON safety_incidents(status);
CREATE INDEX idx_incidents_occurred ON safety_incidents(occurred_at DESC);
CREATE INDEX idx_incidents_zone ON safety_incidents(zone_id);
```

### `training_courses`
Safety training courses
```sql
CREATE TABLE training_courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id VARCHAR(50) UNIQUE NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  
  course_type VARCHAR(50), -- 'safety', 'equipment', 'emergency', 'compliance'
  duration_minutes INTEGER NOT NULL,
  
  -- Content
  content_type VARCHAR(50), -- 'vr', 'video', 'classroom', 'online', 'hands_on'
  content_url TEXT,
  vr_scenario_id VARCHAR(100),
  
  -- Requirements
  is_mandatory BOOLEAN DEFAULT false,
  required_for_roles TEXT[],
  prerequisites UUID[], -- Array of course IDs
  
  -- Certification
  provides_certification BOOLEAN DEFAULT false,
  certification_valid_days INTEGER, -- Validity period
  
  passing_score DECIMAL(5, 2), -- Percentage
  
  is_active BOOLEAN DEFAULT true,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_courses_type ON training_courses(course_type);
CREATE INDEX idx_courses_mandatory ON training_courses(is_mandatory);
CREATE INDEX idx_courses_active ON training_courses(is_active);
```

### `training_enrollments`
User course enrollments and progress
```sql
CREATE TABLE training_enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  course_id UUID REFERENCES training_courses(id) ON DELETE CASCADE,
  
  enrolled_at TIMESTAMP DEFAULT NOW(),
  started_at TIMESTAMP,
  completed_at TIMESTAMP,
  
  status VARCHAR(50) DEFAULT 'enrolled', -- 'enrolled', 'in_progress', 'completed', 'failed'
  
  -- Progress
  progress_percentage DECIMAL(5, 2) DEFAULT 0,
  time_spent_minutes INTEGER DEFAULT 0,
  
  -- Assessment
  score DECIMAL(5, 2),
  passed BOOLEAN,
  attempts_count INTEGER DEFAULT 0,
  
  -- Certification
  certificate_issued_at TIMESTAMP,
  certificate_expires_at TIMESTAMP,
  certificate_url TEXT,
  
  notes TEXT,
  
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_enrollments_user ON training_enrollments(user_id);
CREATE INDEX idx_enrollments_course ON training_enrollments(course_id);
CREATE INDEX idx_enrollments_status ON training_enrollments(status);
CREATE UNIQUE INDEX idx_enrollments_user_course ON training_enrollments(user_id, course_id);
```

### `vr_training_sessions`
VR training session data
```sql
CREATE TABLE vr_training_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  enrollment_id UUID REFERENCES training_enrollments(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id),
  
  scenario_id VARCHAR(100) NOT NULL,
  scenario_name VARCHAR(255) NOT NULL,
  
  started_at TIMESTAMP NOT NULL,
  ended_at TIMESTAMP,
  duration_seconds INTEGER,
  
  -- Performance metrics
  completion_percentage DECIMAL(5, 2),
  score DECIMAL(5, 2),
  
  -- Detailed metrics
  tasks_completed INTEGER,
  tasks_failed INTEGER,
  safety_violations INTEGER,
  reaction_time_ms INTEGER,
  
  -- VR-specific data
  vr_device_type VARCHAR(50),
  session_data JSONB, -- Detailed telemetry, interactions, etc.
  
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_vr_sessions_user ON vr_training_sessions(user_id, started_at DESC);
CREATE INDEX idx_vr_sessions_enrollment ON vr_training_sessions(enrollment_id);
```

### `safety_permits`
Work permits and authorizations
```sql
CREATE TABLE safety_permits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  permit_id VARCHAR(50) UNIQUE NOT NULL,
  permit_type VARCHAR(50) NOT NULL, -- 'hot_work', 'confined_space', 'height_work', 'excavation'
  
  zone_id UUID REFERENCES zones(id),
  location_description TEXT,
  
  requested_by UUID REFERENCES users(id),
  approved_by UUID REFERENCES users(id),
  
  work_description TEXT NOT NULL,
  hazards_identified TEXT[],
  safety_measures TEXT[],
  
  required_ppe TEXT[], -- Personal protective equipment
  required_training UUID[], -- Required course IDs
  
  valid_from TIMESTAMP NOT NULL,
  valid_until TIMESTAMP NOT NULL,
  
  status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'approved', 'active', 'expired', 'revoked'
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_permits_type ON safety_permits(permit_type);
CREATE INDEX idx_permits_status ON safety_permits(status);
CREATE INDEX idx_permits_zone ON safety_permits(zone_id);
CREATE INDEX idx_permits_validity ON safety_permits(valid_from, valid_until);
```

---

## 8. ALERTS & NOTIFICATIONS TABLES

### `alerts`
System-wide alerts and warnings
```sql
CREATE TABLE alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  alert_id VARCHAR(50) UNIQUE NOT NULL,
  
  alert_type VARCHAR(50) NOT NULL, -- 'asset_malfunction', 'network_outage', 'safety_violation', 'maintenance_due', etc.
  category VARCHAR(50), -- 'operational', 'safety', 'maintenance', 'security'
  severity VARCHAR(20) NOT NULL, -- 'info', 'warning', 'critical', 'emergency'
  
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  
  -- Source
  source_type VARCHAR(50), -- 'asset', 'zone', 'camera', 'sensor', 'system'
  source_id VARCHAR(100),
  
  -- Location (if applicable)
  zone_id UUID REFERENCES zones(id),
  
  triggered_at TIMESTAMP NOT NULL,
  
  -- Status
  status VARCHAR(50) DEFAULT 'active', -- 'active', 'acknowledged', 'resolved', 'dismissed'
  acknowledged_by UUID REFERENCES users(id),
  acknowledged_at TIMESTAMP,
  resolved_by UUID REFERENCES users(id),
  resolved_at TIMESTAMP,
  resolution_notes TEXT,
  
  -- Auto-resolution
  auto_resolve BOOLEAN DEFAULT false,
  auto_resolved_at TIMESTAMP,
  
  metadata JSONB,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_alerts_type ON alerts(alert_type);
CREATE INDEX idx_alerts_severity ON alerts(severity);
CREATE INDEX idx_alerts_status ON alerts(status);
CREATE INDEX idx_alerts_triggered ON alerts(triggered_at DESC);
CREATE INDEX idx_alerts_zone ON alerts(zone_id);
```

### `notifications`
User notifications
```sql
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  
  notification_type VARCHAR(50) NOT NULL, -- 'alert', 'message', 'reminder', 'update'
  
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  
  -- Related entity
  related_type VARCHAR(50), -- 'alert', 'incident', 'maintenance', etc.
  related_id UUID,
  
  priority VARCHAR(20) DEFAULT 'normal', -- 'low', 'normal', 'high', 'urgent'
  
  -- Delivery
  is_read BOOLEAN DEFAULT false,
  read_at TIMESTAMP,
  
  is_sent BOOLEAN DEFAULT false,
  sent_at TIMESTAMP,
  delivery_channels TEXT[], -- 'in_app', 'email', 'sms', 'push'
  
  expires_at TIMESTAMP,
  
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notifications(user_id, created_at DESC);
CREATE INDEX idx_notifications_unread ON notifications(user_id, is_read) WHERE is_read = false;
CREATE INDEX idx_notifications_priority ON notifications(priority, created_at DESC);
```

### `alert_rules`
Configurable alert rules
```sql
CREATE TABLE alert_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_name VARCHAR(255) NOT NULL,
  rule_type VARCHAR(50) NOT NULL, -- 'threshold', 'anomaly', 'pattern', 'schedule'
  
  entity_type VARCHAR(50) NOT NULL, -- 'asset', 'zone', 'water_source', 'network_tower'
  entity_id UUID,
  
  -- Condition
  metric_name VARCHAR(100) NOT NULL, -- 'engine_temp', 'fuel_level', 'signal_strength', etc.
  operator VARCHAR(20) NOT NULL, -- '>', '<', '>=', '<=', '==', '!='
  threshold_value DECIMAL(10, 2),
  
  duration_seconds INTEGER, -- Condition must persist for this long
  
  -- Alert settings
  severity VARCHAR(20) NOT NULL,
  alert_title VARCHAR(255) NOT NULL,
  alert_message TEXT NOT NULL,
  
  -- Notification settings
  notify_roles TEXT[],
  notify_users UUID[],
  
  is_active BOOLEAN DEFAULT true,
  
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_alert_rules_type ON alert_rules(rule_type);
CREATE INDEX idx_alert_rules_entity ON alert_rules(entity_type, entity_id);
CREATE INDEX idx_alert_rules_active ON alert_rules(is_active);
```

---

## 9. ANALYTICS & REPORTING TABLES

### `analytics_snapshots`
Periodic system-wide analytics snapshots
```sql
CREATE TABLE analytics_snapshots (
  id BIGSERIAL PRIMARY KEY,
  snapshot_time TIMESTAMP NOT NULL,
  
  -- Asset metrics
  total_assets INTEGER,
  active_assets INTEGER,
  assets_in_maintenance INTEGER,
  average_asset_health DECIMAL(5, 2),
  
  -- Network metrics
  network_uptime DECIMAL(5, 2),
  average_latency INTEGER,
  total_connected_devices INTEGER,
  
  -- Safety metrics
  incidents_today INTEGER,
  incidents_this_month INTEGER,
  days_since_last_incident INTEGER,
  
  -- Water metrics
  total_water_usage DECIMAL(12, 2),
  water_quality_average DECIMAL(5, 2),
  
  -- Operational metrics
  total_operating_hours DECIMAL(12, 2),
  fuel_consumption DECIMAL(10, 2),
  
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_analytics_time ON analytics_snapshots(snapshot_time DESC);
```

### `performance_metrics`
KPI tracking
```sql
CREATE TABLE performance_metrics (
  id BIGSERIAL PRIMARY KEY,
  metric_name VARCHAR(100) NOT NULL,
  metric_category VARCHAR(50), -- 'productivity', 'safety', 'efficiency', 'quality'
  
  metric_value DECIMAL(12, 4) NOT NULL,
  metric_unit VARCHAR(20),
  
  -- Context
  entity_type VARCHAR(50),
  entity_id VARCHAR(100),
  
  period_start TIMESTAMP,
  period_end TIMESTAMP,
  
  -- Target comparison
  target_value DECIMAL(12, 4),
  variance_percentage DECIMAL(6, 2),
  
  timestamp TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_performance_metric ON performance_metrics(metric_name, timestamp DESC);
CREATE INDEX idx_performance_category ON performance_metrics(metric_category, timestamp DESC);
CREATE INDEX idx_performance_entity ON performance_metrics(entity_type, entity_id);
```

### `reports`
Scheduled and generated reports
```sql
CREATE TABLE reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id VARCHAR(50) UNIQUE NOT NULL,
  report_name VARCHAR(255) NOT NULL,
  report_type VARCHAR(50) NOT NULL, -- 'daily_operations', 'safety_summary', 'maintenance', 'custom'
  
  -- Period
  period_start TIMESTAMP NOT NULL,
  period_end TIMESTAMP NOT NULL,
  
  -- Generation
  generated_by UUID REFERENCES users(id),
  generated_at TIMESTAMP NOT NULL,
  
  -- Content
  report_data JSONB NOT NULL, -- Structured report data
  file_url TEXT, -- PDF/Excel export
  
  -- Distribution
  distributed_to UUID[], -- Array of user IDs
  
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_reports_type ON reports(report_type);
CREATE INDEX idx_reports_generated ON reports(generated_at DESC);
CREATE INDEX idx_reports_period ON reports(period_start, period_end);
```

---

## 10. VIEWS (Materialized for Performance)

### `mv_asset_status_summary`
Real-time asset status summary
```sql
CREATE MATERIALIZED VIEW mv_asset_status_summary AS
SELECT 
  a.type as asset_type,
  COUNT(*) as total_count,
  SUM(CASE WHEN a.status = 'active' THEN 1 ELSE 0 END) as active_count,
  SUM(CASE WHEN a.status = 'maintenance' THEN 1 ELSE 0 END) as maintenance_count,
  AVG(ac.health_score) as avg_health_score,
  SUM(a.operating_hours) as total_operating_hours
FROM assets a
LEFT JOIN asset_components ac ON a.id = ac.asset_id
GROUP BY a.type;

CREATE UNIQUE INDEX idx_mv_asset_status_type ON mv_asset_status_summary(asset_type);

-- Refresh schedule: Every 5 minutes
```

### `mv_zone_activity_summary`
Zone activity and asset distribution
```sql
CREATE MATERIALIZED VIEW mv_zone_activity_summary AS
SELECT 
  z.id as zone_id,
  z.name as zone_name,
  z.zone_type,
  COUNT(DISTINCT a.id) as asset_count,
  COUNT(DISTINCT c.id) as camera_count,
  COUNT(DISTINCT se.id) as security_events_24h
FROM zones z
LEFT JOIN assets a ON z.id = a.current_zone_id AND a.status = 'active'
LEFT JOIN cameras c ON z.id = c.zone_id AND c.status = 'online'
LEFT JOIN security_events se ON z.id = se.zone_id 
  AND se.detected_at > NOW() - INTERVAL '24 hours'
  AND se.status != 'resolved'
GROUP BY z.id, z.name, z.zone_type;

CREATE UNIQUE INDEX idx_mv_zone_activity_id ON mv_zone_activity_summary(zone_id);

-- Refresh schedule: Every 10 minutes
```

---

## MAINTENANCE & OPTIMIZATION

### Partitioning Strategy

```sql
-- Partition asset_telemetry by month (time-series data)
CREATE TABLE asset_telemetry (
  id BIGSERIAL,
  asset_id UUID NOT NULL,
  timestamp TIMESTAMP NOT NULL,
  -- ... other fields
) PARTITION BY RANGE (timestamp);

CREATE TABLE asset_telemetry_2024_01 PARTITION OF asset_telemetry
  FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

-- Create partitions for each month programmatically
```

### Retention Policies

```sql
-- Delete old telemetry data after 90 days
CREATE OR REPLACE FUNCTION cleanup_old_telemetry()
RETURNS void AS $$
BEGIN
  DELETE FROM asset_telemetry 
  WHERE timestamp < NOW() - INTERVAL '90 days';
END;
$$ LANGUAGE plpgsql;

-- Schedule with pg_cron or external scheduler
```

### Useful Triggers

```sql
-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_assets_updated_at
  BEFORE UPDATE ON assets
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Apply to all tables with updated_at column
```

---

## TOTAL TABLES: 38

### Summary by Category:
- **Core System**: 3 tables (users, audit_logs, system_settings)
- **Asset Management**: 6 tables (assets, telemetry, components, twins, maintenance)
- **Network**: 3 tables (towers, devices, metrics)
- **Geo-Spatial**: 4 tables (zones, routes, geofence, waypoints)
- **Security**: 4 tables (cameras, events, access control, logs)
- **Water Management**: 4 tables (sources, equipment, usage, quality)
- **Safety & Training**: 6 tables (incidents, courses, enrollments, VR, permits)
- **Alerts**: 3 tables (alerts, notifications, rules)
- **Analytics**: 3 tables (snapshots, metrics, reports)
- **Materialized Views**: 2 views

---

## RECOMMENDED EXTENSIONS

```sql
-- PostGIS for geo-spatial operations
CREATE EXTENSION IF NOT EXISTS postgis;

-- UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Advanced indexing
CREATE EXTENSION IF NOT EXISTS pg_trgm; -- For text search

-- Time-series data
CREATE EXTENSION IF NOT EXISTS timescaledb; -- Optional, for better time-series performance
```

---

## INITIAL SEED DATA

```sql
-- Create default admin user (password should be hashed in production)
INSERT INTO users (email, password_hash, full_name, role) VALUES
  ('admin@mining-sds.com', '$2b$10$...', 'System Administrator', 'admin');

-- Create default zones
INSERT INTO zones (zone_id, name, zone_type, center_latitude, center_longitude) VALUES
  ('zone-a', 'Zone A - Primary Pit', 'primary_pit', -23.5505, 46.6333),
  ('zone-b', 'Zone B - Processing', 'processing', -23.5515, 46.6343),
  ('zone-c', 'Zone C - Secondary Pit', 'secondary_pit', -23.5525, 46.6353),
  ('zone-d', 'Zone D - Maintenance', 'maintenance', -23.5535, 46.6363);
```

---

This schema supports all features implemented in your Smart Mining Command Center application!
