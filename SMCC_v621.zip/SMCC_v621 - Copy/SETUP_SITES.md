# Site Selection Feature - Setup Guide

## Overview

The application now includes a multi-site landing page where users can:
1. View all available mining sites
2. See real-time metrics for each site
3. Select a site to view its command center dashboard

## Quick Setup

### Option 1: Using Docker (Recommended)

```bash
# Start the application
docker-compose up -d

# Wait for services to start (30 seconds)

# Access the backend container
docker exec -it sds-backend sh

# Run sites migration
psql -h postgres -U postgres -d sds_mining -f src/database/sites-migration.sql

# Build and run site seeding
npm run build
node dist/database/seed-sites.js

# Exit container
exit
```

### Option 2: Manual Setup

```bash
# Navigate to backend directory
cd backend

# Run sites migration
psql -h localhost -U postgres -d sds_mining -f src/database/sites-migration.sql

# Build TypeScript
npm run build

# Run site seeding
node dist/database/seed-sites.js
```

### Option 3: Using npm scripts (after adding to package.json)

```bash
cd backend

# Run all setup at once
npm run setup
```

## What Gets Created

### Database Tables

**sites** - Main site/mine information
- 6 sample mining sites across different countries
- Site details: location, type, capacity, workforce, etc.
- Geo-coordinates for mapping

**site_metrics** - Real-time KPIs for each site
- Asset counts and status
- Production metrics
- Network uptime
- Safety incidents
- Operational efficiency

### Sample Sites Created

1. **Northern Ridge Mine** (Australia)
   - Iron Ore open-pit mine
   - 25M tonnes annual capacity
   - 850 workforce

2. **Sierra Verde Complex** (Chile)
   - Copper open-pit mine
   - 18M tonnes annual capacity
   - 1,200 workforce

3. **Goldstream Underground** (Canada)
   - Gold underground mine
   - 2.5M tonnes annual capacity
   - 450 workforce

4. **Eastern Bauxite Fields** (Australia)
   - Bauxite open-pit mine
   - 12M tonnes annual capacity
   - 320 workforce

5. **Platinum Ridge** (South Africa)
   - Platinum underground mine
   - 1.8M tonnes annual capacity
   - 680 workforce

6. **Central Processing Hub** (USA)
   - Processing plant
   - 5M tonnes annual capacity
   - 280 workforce

## User Flow

1. **Login** → `/login`
   - User enters credentials
   - System authenticates

2. **Site Selection** → `/sites`
   - Shows all available sites with metrics
   - User clicks on a site card
   - Site is saved to localStorage

3. **Dashboard** → `/dashboard`
   - Shows site-specific data
   - All modules filtered by selected site
   - Header displays selected site with option to change

## API Endpoints

### Get All Sites
```bash
GET /api/sites
Authorization: Bearer <token>

Response:
[
  {
    "id": "uuid",
    "siteId": "SITE-001",
    "name": "Northern Ridge Mine",
    "location": "Pilbara, Western Australia",
    "status": "operational",
    "totalAssets": 42,
    "activeAssets": 38,
    "networkUptimePercentage": 99.2,
    "operationalEfficiency": 94.5,
    ...
  }
]
```

### Get Single Site
```bash
GET /api/sites/:id
Authorization: Bearer <token>

Response:
{
  "id": "uuid",
  "name": "Northern Ridge Mine",
  ...
  "metrics": { ... },
  "assetsByType": [ ... ],
  "totalZones": 4,
  "totalNetworkTowers": 3
}
```

### Get Site Metrics History
```bash
GET /api/sites/:id/metrics?hours=24
Authorization: Bearer <token>
```

### Get Sites Statistics
```bash
GET /api/sites/statistics/summary
Authorization: Bearer <token>

Response:
{
  "total_sites": 6,
  "operational_sites": 6,
  "total_annual_capacity": 63800000,
  "total_workforce": 3780,
  "countries_count": 5
}
```

## Testing the Feature

### 1. Access the Application

```bash
# Open browser
http://localhost:4200

# Login
Email: admin@mining-sds.com
Password: admin123
```

### 2. You Should See

- Site selection landing page with 6 mining sites
- Each site card showing:
  - Site image
  - Location and status
  - Real-time metrics (assets, workforce, uptime)
  - Performance indicators
  - Production data

### 3. Click on Any Site

- Site is selected and stored
- Navigated to dashboard
- Dashboard shows site-specific data
- Header displays selected site

### 4. Change Site

- Click "Change Site" button in header
- Returns to site selection page
- Choose a different site

## Customization

### Adding More Sites

```typescript
// Edit backend/src/database/seed-sites.ts

const newSite = {
  site_id: 'SITE-007',
  name: 'Your Mine Name',
  location: 'Location, Country',
  country: 'Country',
  site_type: 'open_pit', // or 'underground', 'processing_plant'
  latitude: -12.3456,
  longitude: 78.9012,
  primary_commodity: 'Gold',
  ...
};

// Run: node dist/database/seed-sites.js
```

### Updating Site Images

Update the `image_url` field in `seed-sites.ts`:
```typescript
image_url: 'https://your-image-url.com/image.jpg'
```

### Filtering Sites by User

Add to `/api/sites` route:
```typescript
// backend/src/routes/sites.routes.ts

// Filter sites by user's assigned regions
const userRegion = req.user.region;
query += ` AND s.region = $${paramIndex}`;
params.push(userRegion);
```

## Troubleshooting

### Sites Not Showing

```bash
# Check if migration ran
docker exec -it sds-postgres psql -U postgres -d sds_mining -c "\d sites"

# Check if seed data exists
docker exec -it sds-postgres psql -U postgres -d sds_mining -c "SELECT COUNT(*) FROM sites"

# Should return: count = 6
```

### Images Not Loading

- Check image URLs are accessible
- Verify CORS allows image loading
- Use Unsplash or other CDN URLs

### Redirects to Login

- Clear browser cache and localStorage
- Check JWT token is valid
- Verify auth guard is working

### Site Not Persisting

- Check browser localStorage
- Verify SiteService is saving site
- Check selectedSite$ observable

## Architecture

```
┌─────────────────┐
│  Login Page     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Site Selection  │ ◄── Shows all sites with metrics
│   /sites        │
└────────┬────────┘
         │ User selects site
         │ Site saved to localStorage
         ▼
┌─────────────────┐
│   Dashboard     │ ◄── Site-specific data
│   /dashboard    │     (filtered by selected site)
└─────────────────┘
         │
         │ User can change site
         │
         ▼
     [Back to Site Selection]
```

## Features Included

✅ **Landing Page**
- Beautiful site cards with images
- Real-time metrics display
- Status indicators
- Performance bars
- Alert badges

✅ **Site Selection**
- Persistent selection (localStorage)
- Observable-based state management
- Site details with metrics

✅ **Dashboard Integration**
- Site filter in data queries
- Header shows selected site
- Quick site switcher

✅ **Security**
- Site selection guard
- JWT authentication
- User-based site access (ready for implementation)

✅ **Responsive Design**
- Mobile-first approach
- Tablet and desktop optimized
- Touch-friendly interactions

## Next Steps

1. **Add Site-Specific Filtering**
   - Update all API routes to filter by site_id
   - Modify asset queries to include site filter
   - Update dashboard queries

2. **Add User-Site Permissions**
   - Create user_site_access table
   - Implement site access control
   - Filter sites by user permissions

3. **Add Site Switching Without Page Reload**
   - Implement site switcher modal
   - Update data in real-time
   - Smooth transitions

4. **Add Site Analytics**
   - Historical metrics charts
   - Comparative analysis
   - Performance trends

---

**Site Selection Feature is Ready! 🎉**

Users can now select from multiple mine sites and view site-specific command center data.
