@echo off
REM Fix Landing Page Script for Windows

echo ==========================================
echo 🔧 Fixing Landing Page Issues
echo ==========================================
echo.

echo Step 1: Checking if sites table exists...
docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT to_regclass('public.sites')"
if %errorlevel% equ 0 (
    echo ✓ Sites table exists
) else (
    echo Creating sites table...
    docker exec sds-postgres psql -U postgres -d sds_mining -f /app/src/database/sites-migration.sql
)

echo.
echo Step 2: Checking if sites data exists...
docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT COUNT(*) FROM sites"

echo.
echo Step 3: Seeding sites if needed...
docker exec sds-backend npm run build
docker exec sds-backend node dist/database/seed-sites.js

echo.
echo Step 4: Listing sites...
docker exec sds-postgres psql -U postgres -d sds_mining -c "SELECT site_id, name, location FROM sites"

echo.
echo Step 5: Restarting frontend...
docker-compose restart frontend

echo.
echo ==========================================
echo ✅ Fix Complete!
echo ==========================================
echo.
echo Next steps:
echo 1. Wait 10 seconds for frontend to restart
echo 2. Clear your browser cache (Ctrl+Shift+Delete)
echo 3. Open http://localhost:4200
echo 4. Login with: admin@mining-sds.com / admin123
echo 5. You should see 6 mining sites!
echo.
echo If still not working:
echo - Check browser console (F12) for errors
echo - Run: docker-compose logs -f backend
echo - Try: docker-compose down -v ^&^& setup.bat
echo.
pause
