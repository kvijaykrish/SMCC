# 🚀 Quick Start Guide - SDS Mining Command Center

## Prerequisites

You need **Docker Desktop** installed. That's it!

### Install Docker Desktop

**Windows:**
1. Download: https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe
2. Run installer
3. Restart computer
4. Open Docker Desktop

**Mac:**
1. Download: https://desktop.docker.com/mac/main/amd64/Docker.dmg
2. Drag to Applications
3. Open Docker Desktop

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install docker.io docker-compose
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker $USER
# Log out and log back in
```

## Start the Application (2 Simple Steps)

### Step 1: Extract/Clone Project

Extract the ZIP file or clone the repository to a folder.

### Step 2: Run Setup Script

**Linux/Mac:**
```bash
cd sds-mining-command-center
chmod +x MUST_RUN_AFTER_DOCKER_UP.sh
docker-compose up -d
./MUST_RUN_AFTER_DOCKER_UP.sh
```

**Windows:**
```bash
cd sds-mining-command-center
docker-compose up -d
MUST_RUN_AFTER_DOCKER_UP.bat
```

The script will:
- Create database tables
- Seed 6 mining sites
- Build and restart services
- Verify everything works

**Total time: ~2 minutes**

## Access the Application

Open your web browser and go to:

**Main Application:**
```
http://localhost:4200
```

**Login Credentials:**
```
Email: admin@mining-sds.com
Password: admin123
```

**Other URLs:**
- Backend API: http://localhost:3000/health
- Database Admin: http://localhost:5050

## Verify Everything is Running

```bash
docker-compose ps
```

You should see:
```
NAME              STATUS
sds-postgres      Up (healthy)
sds-backend       Up
sds-frontend      Up
sds-pgadmin       Up
```

## Common Commands

### Stop the Application
```bash
docker-compose down
```

### Restart the Application
```bash
docker-compose restart
```

### View Logs
```bash
docker-compose logs -f
```

### Stop and Remove All Data
```bash
docker-compose down -v
```

## Troubleshooting

### Port Already in Use

If you get "port already in use" error:

**Option 1: Stop the conflicting service**
```bash
# Windows
netstat -ano | findstr :4200
taskkill /PID <PID> /F

# Mac/Linux
sudo lsof -i :4200
kill -9 <PID>
```

**Option 2: Change the port**

Edit `docker-compose.yml` and change:
```yaml
frontend:
  ports:
    - "8080:80"  # Changed from 4200 to 8080
```

Then access at http://localhost:8080

### Docker Not Running

Make sure Docker Desktop is running:
- Windows/Mac: Look for Docker icon in system tray
- Linux: `sudo systemctl status docker`

### Services Not Starting

```bash
# View logs to see what's wrong
docker-compose logs

# Try rebuilding
docker-compose down
docker-compose build
docker-compose up -d
```

### Reset Everything

```bash
# Stop and remove everything
docker-compose down -v

# Rebuild and start fresh
docker-compose build
docker-compose up -d
```

## What's Running?

### Frontend (Port 4200)
- Angular application
- User interface for the command center
- http://localhost:4200

### Backend (Port 3000)
- Node.js REST API
- WebSocket server for real-time updates
- http://localhost:3000

### Database (Port 5432)
- PostgreSQL with PostGIS
- All application data stored here
- Not directly accessible (security)

### PgAdmin (Port 5050)
- Database management UI
- Login: admin@mining-sds.com / admin
- http://localhost:5050

## Next Steps

1. **Login** to the application
2. **Explore** the dashboard
3. **View** the different modules:
   - Connected Assets
   - Private 5G Network
   - Geo-Spatial Intelligence
   - Security & Surveillance
   - Water Management
   - Safety & Training

## Need Help?

- Check **README.md** for detailed documentation
- Check **DEPLOYMENT.md** for deployment options
- View logs: `docker-compose logs -f`
- Contact: support@mining-sds.com

## Production Deployment

For production deployment to a server or cloud:
- See **DEPLOYMENT.md**
- Change default passwords in `backend/.env`
- Configure domain and HTTPS
- Set up automated backups

---

**That's it! You're ready to use the SDS Mining Command Center! 🎉**
