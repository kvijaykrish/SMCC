#!/bin/bash

# MUST RUN AFTER docker-compose up
# This ensures the landing page works correctly

echo "=========================================="
echo "🚀 Post-Deployment Setup"
echo "=========================================="
echo ""
echo "This script ensures all fixes are applied"
echo "and the landing page works correctly."
echo ""

# Wait for services to be ready
echo "⏳ Waiting for services to initialize (15 seconds)..."
sleep 15

# 1. Create sites table
echo ""
echo "📊 Step 1/4: Creating sites table..."
docker exec sds-postgres psql -U postgres -d sds_mining -f /app/src/database/sites-migration.sql 2>&1 | grep -v "already exists" || true

# 2. Build backend
echo ""
echo "🔨 Step 2/4: Building backend..."
docker exec sds-backend npm run build

# 3. Seed sites
echo ""
echo "🌱 Step 3/4: Seeding sites data..."
docker exec sds-backend node dist/database/seed-sites.js

# 4. Rebuild and restart frontend with fixes
echo ""
echo "🔄 Step 4/4: Rebuilding frontend with fixes..."
docker-compose build frontend
docker-compose restart frontend

echo ""
echo "⏳ Waiting for frontend to restart (10 seconds)..."
sleep 10

# Verification
echo ""
echo "=========================================="
echo "✅ Verification"
echo "=========================================="
echo ""

# Check sites count
SITES_COUNT=$(docker exec sds-postgres psql -U postgres -d sds_mining -t -c "SELECT COUNT(*) FROM sites" 2>&1 | tr -d ' ')
if [ "$SITES_COUNT" -ge 6 ]; then
    echo "✓ Sites created: $SITES_COUNT sites"
else
    echo "⚠ Warning: Only $SITES_COUNT sites found (expected 6)"
fi

# List sites
echo ""
echo "Sites in database:"
docker exec sds-postgres psql -U postgres -d sds_mining -c "SELECT site_id, name FROM sites" 2>&1 | head -20

echo ""
echo "=========================================="
echo "🎉 Setup Complete!"
echo "=========================================="
echo ""
echo "📱 Access the application:"
echo "   http://localhost:4200"
echo ""
echo "🔑 Login credentials:"
echo "   Email:    admin@mining-sds.com"
echo "   Password: admin123"
echo ""
echo "✨ What to expect:"
echo "   1. Login page appears"
echo "   2. Enter credentials and click 'Sign In'"
echo "   3. You'll see the SITE SELECTION PAGE with 6 mining sites"
echo "   4. Click any site to view its dashboard"
echo ""
echo "🔍 If you don't see the landing page:"
echo "   1. Clear browser cache (Ctrl+Shift+Delete)"
echo "   2. Open browser console (F12) and check for errors"
echo "   3. Run: ./diagnose.sh"
echo "   4. Run: ./fix-landing-page.sh"
echo ""
echo "📚 Documentation:"
echo "   - See FIXES_APPLIED.md for details on fixes"
echo "   - See TEST_LANDING_PAGE.md for testing guide"
echo "   - See QUICK_REFERENCE.md for commands"
echo ""
