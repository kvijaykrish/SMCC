# SDS Mining Command Center - Architecture Overview

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER BROWSER                             │
│                      http://localhost:4200                       │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ HTTPS/WSS
                 │
┌────────────────▼────────────────────────────────────────────────┐
│                      NGINX (Frontend)                            │
│               Angular 17 Single Page App                         │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │    Login     │  │     Site     │  │  Dashboard   │          │
│  │     Page     │─▶│  Selection   │─▶│   & Modules  │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                  │
│  Services: AuthService, SiteService, AssetService, etc.         │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ REST API (HTTP)
                 │ WebSocket (WS)
                 │
┌────────────────▼────────────────────────────────────────────────┐
│                   Node.js/Express Backend                        │
│                      Port 3000                                   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    API Routes                            │   │
│  │  /api/auth     - Authentication & Users                 │   │
│  │  /api/sites    - Mining Sites Management                │   │
│  │  /api/assets   - Asset & Equipment Management           │   │
│  │  /api/network  - Network Infrastructure                 │   │
│  │  /api/zones    - Geo-spatial Zones                      │   │
│  │  /api/security - Cameras & Security                     │   │
│  │  /api/water    - Water Management                       │   │
│  │  /api/safety   - Safety & Training                      │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │               WebSocket Server                           │   │
│  │  - Real-time asset telemetry                            │   │
│  │  - Network metrics streaming                            │   │
│  │  - Alert notifications                                  │   │
│  │  - Live updates                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  Middleware: Auth, CORS, Rate Limiting, Compression             │
└────────────────┬────────────────────────────────────────────────┘
                 │
                 │ SQL Queries
                 │
┌────────────────▼────────────────────────────────────────────────┐
│                  PostgreSQL 14 + PostGIS                         │
│                        Port 5432                                 │
│                                                                  │
│  ┌─────────────────┐  ┌─────────────────┐  ┌────────────────┐  │
│  │  Core Tables    │  │  Site Tables    │  │  Metrics       │  │
│  │  - users        │  │  - sites        │  │  - asset_telem │  │
│  │  - assets       │  │  - site_metrics │  │  - network_met │  │
│  │  - zones        │  │                 │  │  - alerts      │  │
│  └─────────────────┘  └─────────────────┘  └────────────────┘  │
│                                                                  │
│  Extensions: uuid-ossp, postgis                                 │
└──────────────────────────────────────────────────────────────────┘
```

## User Flow

### Authentication & Site Selection

```
┌─────────┐
│  Start  │
└────┬────┘
     │
     ▼
┌──────────────┐
│ Login Page   │◄──────── First Time Visit
└────┬─────────┘
     │ Enter Credentials
     │ (admin@mining-sds.com / admin123)
     ▼
┌──────────────────┐
│ Authenticate     │
│ - Validate user  │
│ - Generate JWT   │
│ - Store token    │
└────┬─────────────┘
     │ Success
     ▼
┌──────────────────────────┐
│ Site Selection Landing   │
│                          │
│ ┌──────┐  ┌──────┐      │
│ │Site 1│  │Site 2│ ...  │
│ └──────┘  └──────┘      │
│                          │
│ - 6 mining sites shown  │
│ - Real-time metrics     │
│ - Production data       │
└────┬─────────────────────┘
     │ User clicks site
     │
     ▼
┌──────────────────┐
│ Store Selection  │
│ - Save to        │
│   localStorage   │
│ - Update service │
└────┬─────────────┘
     │
     ▼
┌──────────────────┐
│ Dashboard        │
│ - Site header    │
│ - KPI metrics    │
│ - Quick access   │
└────┬─────────────┘
     │
     ▼
┌──────────────────┐
│ Explore Modules  │
│ - Assets         │
│ - Network        │
│ - Security       │
│ - Water          │
│ - Safety         │
└──────────────────┘
```

## Data Flow

### Real-time Telemetry Example

```
┌──────────────┐
│   Asset      │  Physical Equipment
│  (Excavator) │  at Mining Site
└──────┬───────┘
       │ Sensors generate data
       │ (GPS, temp, fuel, etc.)
       ▼
┌──────────────────┐
│   IoT Gateway    │
│   (Edge Device)  │
└──────┬───────────┘
       │ MQTT/HTTP
       ▼
┌──────────────────┐
│  Backend API     │
│  POST /telemetry │
└──────┬───────────┘
       │
       ├─────────────┐
       │             │
       ▼             ▼
┌──────────────┐  ┌──────────────┐
│  Database    │  │  WebSocket   │
│  INSERT      │  │  Broadcast   │
└──────────────┘  └──────┬───────┘
                         │
                         ▼
                  ┌──────────────┐
                  │  Dashboard   │
                  │  Live Update │
                  └──────────────┘
```

## Database Schema Organization

```
┌─────────────────────────────────────────────────────────────┐
│                    PostgreSQL Database                       │
│                      sds_mining                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  CORE ENTITIES                                               │
│  ├─ users              (Authentication & Profiles)           │
│  ├─ sites              (Mining Sites)                        │
│  └─ site_metrics       (Site KPIs - Time Series)            │
│                                                              │
│  ASSET MANAGEMENT                                            │
│  ├─ assets             (Equipment/Vehicles)                  │
│  ├─ asset_telemetry    (Real-time Sensor Data)              │
│  ├─ asset_components   (Component Health)                   │
│  └─ maintenance_records (Service History)                   │
│                                                              │
│  NETWORK & CONNECTIVITY                                      │
│  ├─ network_towers     (5G Infrastructure)                   │
│  ├─ network_devices    (Connected Devices)                   │
│  └─ network_metrics    (Performance Data)                    │
│                                                              │
│  GEO-SPATIAL                                                 │
│  ├─ zones              (Operational Areas)                   │
│  ├─ routes             (Transport Routes)                    │
│  └─ waypoints          (GPS Markers)                         │
│                                                              │
│  SECURITY                                                    │
│  ├─ cameras            (Surveillance Devices)                │
│  ├─ security_events    (Event Logs)                          │
│  └─ access_logs        (Entry/Exit Records)                  │
│                                                              │
│  RESOURCES                                                   │
│  ├─ water_sources      (Reservoirs/Tanks)                    │
│  ├─ water_equipment    (Pumps/Valves)                        │
│  └─ water_metrics      (Flow/Quality Data)                   │
│                                                              │
│  SAFETY & COMPLIANCE                                         │
│  ├─ safety_incidents   (Incident Reports)                    │
│  ├─ training_courses   (Training Programs)                   │
│  ├─ certifications     (Worker Certifications)               │
│  └─ inspections        (Safety Inspections)                  │
│                                                              │
│  SYSTEM                                                      │
│  ├─ alerts             (System Alerts)                       │
│  ├─ notifications      (User Notifications)                  │
│  └─ audit_logs         (Activity Tracking)                   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## Technology Stack

### Frontend
```
Angular 17
├── TypeScript 5.x
├── RxJS 7.x (Reactive programming)
├── Tailwind CSS (Styling)
├── Socket.IO Client (WebSocket)
├── Chart.js (Data visualization)
└── Standalone Components (Modern Angular)
```

### Backend
```
Node.js 18
├── Express 4.x (Web framework)
├── TypeScript 5.x
├── PostgreSQL Driver (pg)
├── Socket.IO (WebSocket server)
├── JWT (Authentication)
├── bcrypt (Password hashing)
├── Helmet (Security headers)
└── Morgan (Logging)
```

### Database
```
PostgreSQL 14
├── PostGIS (Geo-spatial)
├── UUID Extension
├── Connection Pooling
└── Triggers & Functions
```

### DevOps
```
Docker & Docker Compose
├── Multi-stage builds
├── Health checks
├── Volume persistence
├── Network isolation
└── Container orchestration
```

## Security Architecture

```
┌─────────────────────────────────────────┐
│          Security Layers                 │
├─────────────────────────────────────────┤
│                                          │
│  1. Network Security                     │
│     ├─ CORS restrictions                │
│     ├─ Rate limiting                    │
│     ├─ Helmet.js headers                │
│     └─ Firewall rules                   │
│                                          │
│  2. Authentication                       │
│     ├─ JWT tokens                       │
│     ├─ bcrypt hashing                   │
│     ├─ Token expiration                 │
│     └─ Refresh tokens                   │
│                                          │
│  3. Authorization                        │
│     ├─ Role-based access                │
│     ├─ Route guards                     │
│     ├─ API middleware                   │
│     └─ Resource permissions             │
│                                          │
│  4. Data Security                        │
│     ├─ SQL injection prevention         │
│     ├─ Input validation                 │
│     ├─ XSS protection                   │
│     └─ HTTPS encryption (prod)          │
│                                          │
│  5. Monitoring                           │
│     ├─ Audit logs                       │
│     ├─ Error tracking                   │
│     ├─ Access logs                      │
│     └─ Performance monitoring           │
│                                          │
└─────────────────────────────────────────┘
```

## Scalability Considerations

### Horizontal Scaling
- Multiple backend instances behind load balancer
- WebSocket sticky sessions
- Shared session store (Redis)
- Database read replicas

### Vertical Scaling
- Increase container resources
- Optimize database queries
- Add database indexes
- Implement caching layer

### Performance Optimization
- CDN for static assets
- Database connection pooling (✓ implemented)
- Gzip compression (✓ implemented)
- Lazy loading modules (✓ implemented)
- API response caching

## Deployment Environments

```
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│ Development  │    │   Staging    │    │  Production  │
├──────────────┤    ├──────────────┤    ├──────────────┤
│ localhost    │    │ staging.com  │    │ prod.com     │
│ Debug ON     │    │ Debug ON     │    │ Debug OFF    │
│ Mock data    │    │ Real data    │    │ Real data    │
│ No SSL       │    │ SSL required │    │ SSL required │
│ Single node  │    │ Single node  │    │ Multi-node   │
└──────────────┘    └──────────────┘    └──────────────┘
```

## Monitoring & Observability

```
Application Metrics
├── Response times
├── Error rates
├── Request throughput
├── WebSocket connections
└── Database queries

Infrastructure Metrics
├── CPU usage
├── Memory usage
├── Disk I/O
├── Network bandwidth
└── Container health

Business Metrics
├── Active users
├── Site selections
├── Module usage
├── Asset telemetry rate
└── Alert frequency
```

---

**Architecture Document v1.0** | For implementation details, see code documentation
