// Safe localStorage wrapper for sandboxed environments
class SafeStorage {
  private memoryStorage: Map<string, string> = new Map();
  private isLocalStorageAvailable: boolean = false;

  constructor() {
    // Test if localStorage is available
    try {
      const testKey = '__storage_test__';
      localStorage.setItem(testKey, 'test');
      localStorage.removeItem(testKey);
      this.isLocalStorageAvailable = true;
    } catch (e) {
      // Silently fall back to memory storage in sandboxed environments
      this.isLocalStorageAvailable = false;
    }
  }

  getItem(key: string): string | null {
    try {
      if (this.isLocalStorageAvailable) {
        return localStorage.getItem(key);
      }
      return this.memoryStorage.get(key) || null;
    } catch (e) {
      console.error('Error getting item from storage:', e);
      return this.memoryStorage.get(key) || null;
    }
  }

  setItem(key: string, value: string): void {
    try {
      if (this.isLocalStorageAvailable) {
        localStorage.setItem(key, value);
      }
      this.memoryStorage.set(key, value);
    } catch (e) {
      console.error('Error setting item in storage:', e);
      this.memoryStorage.set(key, value);
    }
  }

  removeItem(key: string): void {
    try {
      if (this.isLocalStorageAvailable) {
        localStorage.removeItem(key);
      }
      this.memoryStorage.delete(key);
    } catch (e) {
      console.error('Error removing item from storage:', e);
      this.memoryStorage.delete(key);
    }
  }

  clear(): void {
    try {
      if (this.isLocalStorageAvailable) {
        localStorage.clear();
      }
      this.memoryStorage.clear();
    } catch (e) {
      console.error('Error clearing storage:', e);
      this.memoryStorage.clear();
    }
  }
}

// Export singleton instance
export const storage = new SafeStorage();
