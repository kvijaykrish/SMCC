import { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { ConnectedAssets } from './components/ConnectedAssets';
import { Private5G } from './components/Private5G';
import { GeoSpatial } from './components/GeoSpatial';
import { IntegratedSecurity } from './components/IntegratedSecurity';
import { WaterManagement } from './components/WaterManagement';
import { SafetyTraining } from './components/SafetyTraining';
import { DigitalTwinSimulation } from './components/DigitalTwinSimulation';
import { LiveVideoStream } from './components/LiveVideoStream';
import { VideoTour } from './components/VideoTour';
import { HistoricalReports } from './components/HistoricalReports';
import { AIAssistant } from './components/AIAssistant';
import { Header } from './components/Header';
import { Sidebar } from './components/SidebarNav';
import Login from './components/Login';
import SiteSelection from './components/SiteSelection';
import { storage } from './utils/storage';

export type View = 
  | 'dashboard' 
  | 'connected-assets' 
  | 'private-5g' 
  | 'geo-spatial' 
  | 'security' 
  | 'water' 
  | 'safety'
  | 'digital-twin'
  | 'video-stream'
  | 'video-tour'
  | 'historical-reports'
  | 'ai-assistant';

type AppState = 'login' | 'site-selection' | 'app';

export default function App() {
  const [appState, setAppState] = useState<AppState>('login');
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    try {
      // Check if user is authenticated using safe storage
      const token = storage.getItem('authToken');
      const selectedSite = storage.getItem('selectedSite');
      
      if (token) {
        if (selectedSite) {
          setAppState('app');
        } else {
          setAppState('site-selection');
        }
      } else {
        setAppState('login');
      }
    } catch (err) {
      console.error('Error initializing app:', err);
      // Even if there's an error, show login as default
      setAppState('login');
    }
  }, []);

  if (hasError) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Something went wrong</h1>
          <p className="text-slate-400 mb-6">Please refresh the page to try again.</p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors">
            Refresh Page
          </button>
        </div>
      </div>
    );
  }

  const renderView = () => {
    try {
      switch (currentView) {
        case 'dashboard':
          return <Dashboard onNavigate={setCurrentView} />;
        case 'connected-assets':
          return <ConnectedAssets onNavigate={setCurrentView} />;
        case 'private-5g':
          return <Private5G />;
        case 'geo-spatial':
          return <GeoSpatial />;
        case 'security':
          return <IntegratedSecurity onNavigate={setCurrentView} />;
        case 'water':
          return <WaterManagement />;
        case 'safety':
          return <SafetyTraining />;
        case 'digital-twin':
          return <DigitalTwinSimulation onNavigate={setCurrentView} />;
        case 'video-stream':
          return <LiveVideoStream onNavigate={setCurrentView} />;
        case 'video-tour':
          return <VideoTour onClose={() => setCurrentView('dashboard')} />;
        case 'historical-reports':
          return <HistoricalReports />;
        case 'ai-assistant':
          return <AIAssistant />;
        default:
          return <Dashboard onNavigate={setCurrentView} />;
      }
    } catch (err) {
      console.error('Error rendering view:', err);
      return (
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <h2 className="text-xl font-bold text-white mb-2">Error loading view</h2>
            <p className="text-slate-400">Please try a different section</p>
          </div>
        </div>
      );
    }
  };

  try {
    // Show login screen
    if (appState === 'login') {
      return <Login onLoginSuccess={() => setAppState('site-selection')} />;
    }

    // Show site selection
    if (appState === 'site-selection') {
      return <SiteSelection />;
    }

    // Show main app
    return (
      <div className="flex h-screen bg-slate-950">
        <Sidebar currentView={currentView} onNavigate={setCurrentView} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header currentView={currentView} />
          <main className="flex-1 overflow-y-auto bg-slate-950">
            {renderView()}
          </main>
        </div>
      </div>
    );
  } catch (err) {
    console.error('App render error:', err);
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Error Loading Application</h1>
          <p className="text-slate-400 mb-6">Please refresh the page to try again.</p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors">
            Refresh Page
          </button>
        </div>
      </div>
    );
  }
}