import { useState } from 'react';
import { Shield, Camera, AlertTriangle, Lock, Eye, Activity, Clock, Video, MapPin, CheckCircle } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { View } from '../App';

interface IntegratedSecurityProps {
  onNavigate: (view: View) => void;
}

const securityEvents = [
  { id: 'SEC-001', type: 'Access Alert', severity: 'warning', location: 'Gate A', time: '2 min ago', camera: 'CAM-12', status: 'reviewing' },
  { id: 'SEC-002', type: 'Perimeter Breach', severity: 'critical', location: 'Zone C-North', time: '15 min ago', camera: 'CAM-34', status: 'resolved' },
  { id: 'SEC-003', type: 'Unauthorized Vehicle', severity: 'warning', location: 'Parking Lot B', time: '32 min ago', camera: 'CAM-08', status: 'investigating' },
  { id: 'SEC-004', type: 'Motion Detected', severity: 'info', location: 'Warehouse 2', time: '1 hour ago', camera: 'CAM-45', status: 'resolved' },
];

const cameras = [
  { id: 'CAM-01', name: 'Main Gate North', location: 'Entrance', status: 'active', resolution: '4K', fps: 30 },
  { id: 'CAM-02', name: 'Main Gate South', location: 'Entrance', status: 'active', resolution: '4K', fps: 30 },
  { id: 'CAM-12', name: 'Perimeter North-East', location: 'Zone A', status: 'active', resolution: '1080p', fps: 25 },
  { id: 'CAM-23', name: 'Mining Pit Overview', location: 'Zone B', status: 'active', resolution: '4K', fps: 30 },
  { id: 'CAM-34', name: 'Perimeter South-West', location: 'Zone C', status: 'warning', resolution: '1080p', fps: 20 },
  { id: 'CAM-45', name: 'Warehouse Security', location: 'Storage', status: 'active', resolution: '1080p', fps: 25 },
  { id: 'CAM-56', name: 'Office Building Lobby', location: 'HQ', status: 'active', resolution: '4K', fps: 30 },
  { id: 'CAM-67', name: 'Workshop Area', location: 'Maintenance', status: 'active', resolution: '1080p', fps: 25 },
];

const accessData = [
  { hour: '00:00', authorized: 12, unauthorized: 0, denied: 1 },
  { hour: '06:00', authorized: 45, unauthorized: 0, denied: 2 },
  { hour: '08:00', authorized: 89, unauthorized: 1, denied: 3 },
  { hour: '12:00', authorized: 67, unauthorized: 0, denied: 1 },
  { hour: '16:00', authorized: 72, unauthorized: 0, denied: 2 },
  { hour: '20:00', authorized: 34, unauthorized: 0, denied: 1 },
];

const eventTypeData = [
  { type: 'Access Control', count: 145 },
  { type: 'Motion Detection', count: 89 },
  { type: 'Perimeter Alert', count: 23 },
  { type: 'Vehicle Tracking', count: 67 },
  { type: 'Personnel Safety', count: 12 },
];

export function IntegratedSecurity({ onNavigate }: IntegratedSecurityProps) {
  const [selectedCamera, setSelectedCamera] = useState<string | null>(null);

  return (
    <div className="p-6 space-y-6 bg-slate-950 min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Integrated Security & Surveillance</h1>
          <p className="text-slate-400 mt-1">24/7 security monitoring, camera feeds, and access control</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => onNavigate('video-stream')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
            <Video className="w-4 h-4" />
            <span>Live Feeds</span>
          </button>
        </div>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Active Cameras"
          value="128"
          subtitle="2 warnings"
          icon={Camera}
          color="blue"
        />
        <MetricCard
          title="Security Events"
          value="24"
          subtitle="Last 24 hours"
          icon={AlertTriangle}
          color="amber"
        />
        <MetricCard
          title="Access Points"
          value="16"
          subtitle="All secured"
          icon={Lock}
          color="green"
        />
        <MetricCard
          title="Personnel on Site"
          value="342"
          subtitle="Currently active"
          icon={Eye}
          color="purple"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Access Control Analytics */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Access Control (24h)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={accessData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="hour" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Legend wrapperStyle={{ color: '#e2e8f0' }} />
              <Bar dataKey="authorized" fill="#10b981" name="Authorized" />
              <Bar dataKey="denied" fill="#f59e0b" name="Denied" />
              <Bar dataKey="unauthorized" fill="#ef4444" name="Unauthorized" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Event Type Distribution */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Security Events by Type</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={eventTypeData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis type="number" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis type="category" dataKey="type" stroke="#94a3b8" style={{ fontSize: '11px' }} width={120} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Bar dataKey="count" fill="#3b82f6" name="Events" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Camera Grid & Recent Events */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Security Events */}
        <div className="lg:col-span-2 bg-slate-900 rounded-xl border border-slate-800 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Recent Security Events</h3>
            <button className="text-sm text-blue-400 hover:text-blue-300">View All →</button>
          </div>
          <div className="space-y-3">
            {securityEvents.map((event) => (
              <SecurityEventCard key={event.id} event={event} onNavigate={onNavigate} />
            ))}
          </div>
        </div>

        {/* Quick Stats */}
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Security Status</h3>
            <div className="space-y-4">
              <StatusItem label="Perimeter Security" status="Secure" color="green" />
              <StatusItem label="Access Control" status="Active" color="green" />
              <StatusItem label="Video Surveillance" status="2 Warnings" color="amber" />
              <StatusItem label="Alarm Systems" status="Armed" color="green" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-6 text-white">
            <Shield className="w-10 h-10 mb-3" />
            <div className="text-lg font-semibold mb-2">Security Score</div>
            <div className="text-3xl font-bold mb-3">98.5%</div>
            <div className="text-sm opacity-90">All critical systems operational</div>
          </div>
        </div>
      </div>

      {/* Camera Grid */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Camera Network Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {cameras.map((camera) => (
            <CameraCard 
              key={camera.id} 
              camera={camera}
              isSelected={selectedCamera === camera.id}
              onClick={() => setSelectedCamera(camera.id)}
              onNavigate={onNavigate}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, subtitle, icon: Icon, color }: any) {
  const colorClasses: Record<string, string> = {
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    green: 'bg-green-500/10 text-green-400 border-green-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  };

  return (
    <div className={`bg-slate-900 rounded-xl border ${colorClasses[color]} p-6`}>
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm text-slate-400">{title}</p>
          <p className="text-2xl font-bold text-white mt-1">{value}</p>
          <p className="text-xs text-slate-400 mt-1">{subtitle}</p>
        </div>
        <Icon className="w-8 h-8" />
      </div>
    </div>
  );
}

function SecurityEventCard({ event, onNavigate }: any) {
  const severityConfig: Record<string, { color: string; bgColor: string }> = {
    critical: { color: 'text-red-400', bgColor: 'bg-red-500/20' },
    warning: { color: 'text-amber-400', bgColor: 'bg-amber-500/20' },
    info: { color: 'text-blue-400', bgColor: 'bg-blue-500/20' },
  };

  const config = severityConfig[event.severity];

  return (
    <div className="flex items-start gap-4 p-4 bg-slate-800 rounded-lg hover:bg-slate-700 transition-colors">
      <div className={`p-2 rounded-lg ${config.bgColor}`}>
        <AlertTriangle className={`w-5 h-5 ${config.color}`} />
      </div>
      <div className="flex-1">
        <div className="flex items-start justify-between mb-2">
          <div>
            <div className="text-white font-semibold">{event.type}</div>
            <div className="text-sm text-slate-400 mt-1">
              <span className="inline-flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                {event.location}
              </span>
              <span className="mx-2">•</span>
              <span>{event.camera}</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <span className={`text-xs px-2 py-1 rounded-full ${config.bgColor} ${config.color}`}>
              {event.severity}
            </span>
            <span className="text-xs text-slate-500">{event.time}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => onNavigate('video-stream')}
            className="text-xs px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors">
            View Camera
          </button>
          <span className="text-xs text-slate-400 capitalize">{event.status}</span>
        </div>
      </div>
    </div>
  );
}

function CameraCard({ camera, isSelected, onClick, onNavigate }: any) {
  const isWarning = camera.status === 'warning';

  return (
    <button
      onClick={onClick}
      className={`bg-slate-800 border ${isSelected ? 'border-blue-500' : 'border-slate-700'} rounded-lg p-4 text-left hover:border-slate-600 transition-all`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="text-sm font-mono text-blue-400">{camera.id}</div>
          <div className="text-white font-semibold text-sm mt-1">{camera.name}</div>
          <div className="text-xs text-slate-400 mt-1">{camera.location}</div>
        </div>
        {isWarning ? (
          <AlertTriangle className="w-5 h-5 text-amber-400" />
        ) : (
          <Camera className="w-5 h-5 text-green-400" />
        )}
      </div>

      <div className="grid grid-cols-2 gap-2 text-xs mb-3">
        <div>
          <div className="text-slate-400">Resolution</div>
          <div className="text-white font-semibold">{camera.resolution}</div>
        </div>
        <div>
          <div className="text-slate-400">FPS</div>
          <div className="text-white font-semibold">{camera.fps}</div>
        </div>
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-slate-700">
        <span className={`text-xs ${isWarning ? 'text-amber-400' : 'text-green-400'}`}>
          {isWarning ? 'Warning' : 'Active'}
        </span>
        <button 
          onClick={(e) => {
            e.stopPropagation();
            onNavigate('video-stream');
          }}
          className="text-xs text-blue-400 hover:text-blue-300">
          View Feed →
        </button>
      </div>
    </button>
  );
}

function StatusItem({ label, status, color }: any) {
  const colorClasses: Record<string, string> = {
    green: 'text-green-400',
    amber: 'text-amber-400',
    red: 'text-red-400',
  };

  return (
    <div className="flex items-center justify-between">
      <span className="text-slate-300 text-sm">{label}</span>
      <span className={`text-sm font-semibold ${colorClasses[color]}`}>{status}</span>
    </div>
  );
}
