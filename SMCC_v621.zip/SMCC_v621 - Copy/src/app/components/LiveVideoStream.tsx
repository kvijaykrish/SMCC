import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Video, 
  Camera,
  Maximize2,
  Minimize2,
  Volume2,
  VolumeX,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Download,
  Bookmark,
  Grid3x3,
  Maximize,
  Eye,
  ArrowLeft,
  Monitor,
  Radio as RadioIcon,
  AlertCircle,
  CheckCircle,
  ZoomIn,
  ZoomOut,
  Move
} from 'lucide-react';
import type { View } from '../App';

interface LiveVideoStreamProps {
  onNavigate: (view: View) => void;
}

const cameras = [
  {
    id: 'CAM-001',
    name: 'Main Gate',
    location: 'Perimeter - North',
    status: 'live',
    zone: 'Perimeter',
    resolution: '1080p',
    fps: 30,
    recording: true,
    videoUrl: 'https://images.unsplash.com/photo-1769629918261-92d1fac176cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbmclMjBleGNhdmF0b3IlMjBzaXRlJTIwYWVyaWFsfGVufDF8fHx8MTc3MTkxMjAyNXww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'CAM-002',
    name: 'Zone A Entry',
    location: 'Zone A - Primary Pit',
    status: 'live',
    zone: 'Zone A',
    resolution: '1080p',
    fps: 30,
    recording: true,
    videoUrl: 'https://images.unsplash.com/photo-1770869717609-61e4a9c535ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcGVuJTIwcGl0JTIwbWluZSUyMG9wZXJhdGlvbnN8ZW58MXx8fHwxNzcxOTEyMDI2fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'CAM-003',
    name: 'Processing Plant',
    location: 'Zone B - Processing',
    status: 'live',
    zone: 'Zone B',
    resolution: '4K',
    fps: 60,
    recording: true,
    videoUrl: 'https://images.unsplash.com/photo-1597057435443-8a51eeb5538f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbmclMjBwcm9jZXNzaW5nJTIwcGxhbnQlMjBpbmR1c3RyaWFsfGVufDF8fHx8MTc3MTkxMjAyNnww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'CAM-004',
    name: 'Maintenance Bay',
    location: 'Zone D - Maintenance',
    status: 'offline',
    zone: 'Zone D',
    resolution: '1080p',
    fps: 30,
    recording: false,
    videoUrl: '',
  },
  {
    id: 'CAM-005',
    name: 'Fuel Station',
    location: 'Zone B - Fuel Depot',
    status: 'live',
    zone: 'Zone B',
    resolution: '1080p',
    fps: 30,
    recording: true,
    videoUrl: 'https://images.unsplash.com/photo-1722808267592-233d60eb2431?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbmclMjBoYXVsJTIwdHJ1Y2tzJTIwd29ya2luZ3xlbnwxfHx8fDE3NzE5MTIwMjZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'CAM-006',
    name: 'South Perimeter',
    location: 'Perimeter - South',
    status: 'live',
    zone: 'Perimeter',
    resolution: '1080p',
    fps: 30,
    recording: true,
    videoUrl: 'https://images.unsplash.com/photo-1769629918261-92d1fac176cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbmclMjBleGNhdmF0b3IlMjBzaXRlJTIwYWVyaWFsfGVufDF8fHx8MTc3MTkxMjAyNXww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'CAM-007',
    name: 'Loading Zone 1',
    location: 'Zone C - Loading',
    status: 'live',
    zone: 'Zone C',
    resolution: '1080p',
    fps: 30,
    recording: true,
    videoUrl: 'https://images.unsplash.com/photo-1770869717609-61e4a9c535ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcGVuJTIwcGl0JTIwbWluZSUyMG9wZXJhdGlvbnN8ZW58MXx8fHwxNzcxOTEyMDI2fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'CAM-008',
    name: 'Control Room',
    location: 'Admin Building',
    status: 'live',
    zone: 'Admin',
    resolution: '720p',
    fps: 30,
    recording: false,
    videoUrl: 'https://images.unsplash.com/photo-1597057435443-8a51eeb5538f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbmclMjBwcm9jZXNzaW5nJTIwcGxhbnQlMjBpbmR1c3RyaWFsfGVufDF8fHx8MTc3MTkxMjAyNnww&ixlib=rb-4.1.0&q=80&w=1080',
  },
];

const recentEvents = [
  {
    id: 'E-001',
    camera: 'CAM-003',
    type: 'Motion Detected',
    timestamp: '14:32:15',
    severity: 'info',
  },
  {
    id: 'E-002',
    camera: 'CAM-001',
    type: 'Vehicle Entry',
    timestamp: '14:28:42',
    severity: 'info',
  },
  {
    id: 'E-003',
    camera: 'CAM-004',
    type: 'Camera Offline',
    timestamp: '14:15:00',
    severity: 'warning',
  },
];

export function LiveVideoStream({ onNavigate }: LiveVideoStreamProps) {
  const [selectedCamera, setSelectedCamera] = useState(cameras[0]);
  const [viewMode, setViewMode] = useState<'single' | 'quad' | 'grid'>('single');
  const [isMuted, setIsMuted] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [zoom, setZoom] = useState(100);
  const [scanLinePosition, setScanLinePosition] = useState(0);

  const activeCameras = cameras.filter(c => c.status === 'live');

  // Simulate scanning effect
  useEffect(() => {
    const interval = setInterval(() => {
      setScanLinePosition((prev) => (prev >= 100 ? 0 : prev + 1));
    }, 30);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-6 space-y-6 bg-slate-950 min-h-full">
      {/* Header Actions */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => onNavigate('security')}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Security</span>
        </button>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-2 bg-green-500/10 border border-green-500/20 rounded-lg">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-green-400">{activeCameras.length} Cameras Live</span>
          </div>

          <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 rounded-lg p-1">
            <button
              onClick={() => setViewMode('single')}
              className={`p-2 rounded transition-colors ${
                viewMode === 'single' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Monitor className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('quad')}
              className={`p-2 rounded transition-colors ${
                viewMode === 'quad' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Grid3x3 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded transition-colors ${
                viewMode === 'grid' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Maximize className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Video Display */}
        <div className="lg:col-span-3 space-y-6">
          {/* Main Video Feed */}
          {viewMode === 'single' && (
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-lg font-semibold text-white">{selectedCamera.name}</h2>
                  <p className="text-sm text-slate-400">{selectedCamera.id} • {selectedCamera.location}</p>
                </div>
                <div className="flex items-center gap-2">
                  <CameraStatus status={selectedCamera.status} />
                  {selectedCamera.recording && (
                    <div className="flex items-center gap-1 px-2 py-1 bg-red-500/10 border border-red-500/20 rounded text-xs text-red-400">
                      <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                      <span>REC</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Video Player */}
              <div className="relative bg-slate-900 rounded-lg overflow-hidden group">
                <div className="aspect-video flex items-center justify-center">
                  {selectedCamera.status === 'live' ? (
                    <div className="relative w-full h-full">
                      {/* Actual mining site video feed simulation */}
                      <div className="absolute inset-0 bg-black">
                        {/* Background mining site image */}
                        <img 
                          src={selectedCamera.videoUrl} 
                          alt={selectedCamera.name}
                          className="w-full h-full object-cover"
                          style={{ 
                            transform: `scale(${zoom / 100})`,
                            transition: 'transform 0.3s ease'
                          }}
                        />
                        
                        {/* Video feed overlay effects */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/20 pointer-events-none"></div>
                        
                        {/* Scanline effect */}
                        <motion.div
                          className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                          style={{ top: `${scanLinePosition}%` }}
                        />
                        
                        {/* Subtle noise/grain overlay for video effect */}
                        <div className="absolute inset-0 opacity-5 mix-blend-overlay"
                          style={{
                            backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' /%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")',
                          }}
                        />
                        
                        {/* Timestamp */}
                        <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-sm px-3 py-1.5 rounded text-white text-sm font-mono">
                          {new Date().toLocaleString()}
                        </div>

                        {/* Camera info */}
                        <div className="absolute top-4 right-4 bg-black/70 backdrop-blur-sm px-3 py-1.5 rounded text-white text-xs">
                          {selectedCamera.resolution} @ {selectedCamera.fps}fps
                        </div>

                        {/* Detection zones with animation */}
                        <motion.div 
                          className="absolute top-1/4 left-1/4 w-1/2 h-1/2 border-2 border-green-500/60 rounded-lg"
                          animate={{
                            opacity: [0.4, 0.8, 0.4],
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                        >
                          <div className="absolute -top-6 left-0 bg-green-500 px-2 py-0.5 rounded text-white text-xs">
                            Detection Zone
                          </div>
                        </motion.div>

                        {/* Simulated movement indicator - moving across screen */}
                        <motion.div
                          className="absolute w-16 h-16 bg-blue-500/30 rounded-full border-2 border-blue-500"
                          animate={{
                            x: [100, 400, 100],
                            y: [100, 200, 100],
                            scale: [1, 1.2, 1],
                          }}
                          transition={{
                            duration: 8,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                        >
                          <div className="absolute inset-2 bg-blue-500 rounded-full"></div>
                        </motion.div>

                        {/* Motion tracking boxes */}
                        <motion.div
                          className="absolute w-24 h-24 border-2 border-red-500/70 rounded"
                          initial={{ top: '40%', left: '20%' }}
                          animate={{
                            top: ['40%', '45%', '40%'],
                            left: ['20%', '25%', '20%'],
                          }}
                          transition={{
                            duration: 3,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                        >
                          <div className="absolute -top-5 left-0 bg-red-500 px-2 py-0.5 rounded text-white text-xs">
                            Vehicle
                          </div>
                        </motion.div>

                        {/* Grid overlay (subtle) */}
                        <div className="absolute inset-0 opacity-5"
                          style={{
                            backgroundImage: 'linear-gradient(rgba(255,255,255,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.3) 1px, transparent 1px)',
                            backgroundSize: '50px 50px'
                          }}
                        />
                      </div>

                      {/* Zoom indicator */}
                      {zoom !== 100 && (
                        <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm px-3 py-1.5 rounded text-white text-sm">
                          Zoom: {zoom}%
                        </div>
                      )}

                      {/* Controls Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="absolute bottom-0 left-0 right-0 p-4">
                          {/* Playback bar */}
                          <div className="mb-3">
                            <div className="w-full bg-white/30 rounded-full h-1 cursor-pointer">
                              <div className="bg-red-500 h-1 rounded-full" style={{ width: '100%' }}></div>
                            </div>
                          </div>

                          {/* Control buttons */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <button 
                                onClick={() => setIsPlaying(!isPlaying)}
                                className="p-2 bg-white/20 hover:bg-white/30 rounded-lg text-white transition-colors"
                              >
                                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                              </button>
                              <button className="p-2 bg-white/20 hover:bg-white/30 rounded-lg text-white transition-colors">
                                <SkipBack className="w-5 h-5" />
                              </button>
                              <button className="p-2 bg-white/20 hover:bg-white/30 rounded-lg text-white transition-colors">
                                <SkipForward className="w-5 h-5" />
                              </button>
                              <button 
                                onClick={() => setIsMuted(!isMuted)}
                                className="p-2 bg-white/20 hover:bg-white/30 rounded-lg text-white transition-colors"
                              >
                                {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                              </button>
                              <span className="text-white text-sm font-mono">LIVE</span>
                            </div>

                            <div className="flex items-center gap-2">
                              <button className="p-2 bg-white/20 hover:bg-white/30 rounded-lg text-white transition-colors">
                                <Bookmark className="w-5 h-5" />
                              </button>
                              <button className="p-2 bg-white/20 hover:bg-white/30 rounded-lg text-white transition-colors">
                                <Download className="w-5 h-5" />
                              </button>
                              <button 
                                onClick={() => setIsFullscreen(!isFullscreen)}
                                className="p-2 bg-white/20 hover:bg-white/30 rounded-lg text-white transition-colors"
                              >
                                {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center text-white">
                      <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p className="text-lg mb-2">Camera Offline</p>
                      <p className="text-sm opacity-70">{selectedCamera.name} is currently unavailable</p>
                    </div>
                  )}
                </div>
              </div>

              {/* PTZ Controls */}
              {selectedCamera.status === 'live' && (
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="border border-slate-700 rounded-lg p-4">
                    <h3 className="text-sm font-semibold text-slate-300 mb-3">Pan/Tilt Control</h3>
                    <div className="grid grid-cols-3 gap-2">
                      <div></div>
                      <button className="p-3 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors">
                        <span className="text-xl text-slate-300">↑</span>
                      </button>
                      <div></div>
                      <button className="p-3 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors">
                        <span className="text-xl text-slate-300">←</span>
                      </button>
                      <button className="p-3 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors">
                        <Move className="w-5 h-5 text-slate-300" />
                      </button>
                      <button className="p-3 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors">
                        <span className="text-xl text-slate-300">→</span>
                      </button>
                      <div></div>
                      <button className="p-3 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center justify-center transition-colors">
                        <span className="text-xl text-slate-300">↓</span>
                      </button>
                      <div></div>
                    </div>
                  </div>

                  <div className="border border-slate-700 rounded-lg p-4">
                    <h3 className="text-sm font-semibold text-slate-300 mb-3">Zoom Control</h3>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => setZoom(Math.max(100, zoom - 10))}
                          className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                        >
                          <ZoomOut className="w-5 h-5 text-slate-300" />
                        </button>
                        <input
                          type="range"
                          min="100"
                          max="400"
                          value={zoom}
                          onChange={(e) => setZoom(parseInt(e.target.value))}
                          className="flex-1"
                        />
                        <button 
                          onClick={() => setZoom(Math.min(400, zoom + 10))}
                          className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                        >
                          <ZoomIn className="w-5 h-5 text-slate-300" />
                        </button>
                      </div>
                      <div className="text-center text-sm text-slate-400">
                        Current Zoom: {zoom}%
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        <button 
                          onClick={() => setZoom(100)}
                          className="px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded text-sm text-slate-300 transition-colors"
                        >
                          1x
                        </button>
                        <button 
                          onClick={() => setZoom(200)}
                          className="px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded text-sm text-slate-300 transition-colors"
                        >
                          2x
                        </button>
                        <button 
                          onClick={() => setZoom(400)}
                          className="px-3 py-2 bg-slate-800 hover:bg-slate-700 rounded text-sm text-slate-300 transition-colors"
                        >
                          4x
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Quad View */}
          {viewMode === 'quad' && (
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
              <h2 className="text-lg font-semibold text-white mb-4">Quad View - Live Cameras</h2>
              <div className="grid grid-cols-2 gap-4">
                {activeCameras.slice(0, 4).map((camera) => (
                  <button
                    key={camera.id}
                    onClick={() => {
                      setSelectedCamera(camera);
                      setViewMode('single');
                    }}
                    className="relative bg-slate-900 rounded-lg overflow-hidden aspect-video group hover:ring-2 hover:ring-blue-500 transition-all"
                  >
                    <div className="absolute inset-0 bg-black">
                      <img 
                        src={camera.videoUrl} 
                        alt={camera.name}
                        className="w-full h-full object-cover opacity-90"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/40"></div>
                      <div className="absolute top-2 left-2 bg-black/70 px-2 py-1 rounded text-white text-xs">
                        {camera.name}
                      </div>
                      {camera.recording && (
                        <div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                      )}
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/30">
                        <Eye className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Grid View */}
          {viewMode === 'grid' && (
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
              <h2 className="text-lg font-semibold text-white mb-4">All Active Cameras</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {activeCameras.map((camera) => (
                  <button
                    key={camera.id}
                    onClick={() => {
                      setSelectedCamera(camera);
                      setViewMode('single');
                    }}
                    className="relative bg-slate-900 rounded-lg overflow-hidden aspect-video group hover:ring-2 hover:ring-blue-500 transition-all"
                  >
                    <div className="absolute inset-0 bg-black">
                      <img 
                        src={camera.videoUrl} 
                        alt={camera.name}
                        className="w-full h-full object-cover opacity-90"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/40"></div>
                      <div className="absolute top-2 left-2 bg-black/70 px-2 py-1 rounded text-white text-xs">
                        {camera.name}
                      </div>
                      {camera.recording && (
                        <div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                      )}
                      <div className="absolute bottom-2 left-2 text-white text-xs opacity-70">
                        {camera.zone}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          {/* Camera List */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-4">
            <h3 className="text-sm font-semibold text-white mb-3">Camera List</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {cameras.map((camera) => (
                <button
                  key={camera.id}
                  onClick={() => {
                    setSelectedCamera(camera);
                    setViewMode('single');
                  }}
                  className={`w-full p-3 border rounded-lg text-left transition-all ${
                    selectedCamera.id === camera.id
                      ? 'border-blue-500 bg-blue-500/10'
                      : 'border-slate-700 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-semibold text-white">{camera.name}</span>
                    <CameraStatus status={camera.status} />
                  </div>
                  <div className="text-xs text-slate-400">{camera.location}</div>
                  <div className="flex items-center justify-between mt-2 text-xs">
                    <span className="text-slate-400">{camera.resolution}</span>
                    {camera.recording && (
                      <div className="flex items-center gap-1 text-red-400">
                        <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                        <span>REC</span>
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Recent Events */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-4">
            <h3 className="text-sm font-semibold text-white mb-3">Recent Events</h3>
            <div className="space-y-2">
              {recentEvents.map((event) => (
                <div
                  key={event.id}
                  className={`p-3 rounded-lg border ${
                    event.severity === 'warning'
                      ? 'bg-amber-500/10 border-amber-500/20'
                      : 'bg-blue-500/10 border-blue-500/20'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {event.severity === 'warning' ? (
                      <AlertCircle className="w-4 h-4 text-amber-400 mt-0.5" />
                    ) : (
                      <Video className="w-4 h-4 text-blue-400 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <div className={`text-sm font-semibold mb-1 ${
                        event.severity === 'warning' ? 'text-amber-300' : 'text-blue-300'
                      }`}>
                        {event.type}
                      </div>
                      <div className="text-xs text-slate-400">{event.camera}</div>
                      <div className="text-xs text-slate-500 mt-1">{event.timestamp}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Camera Info */}
          {selectedCamera && (
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-4">
              <h3 className="text-sm font-semibold text-white mb-3">Camera Information</h3>
              <div className="space-y-3">
                <InfoItem label="Camera ID" value={selectedCamera.id} />
                <InfoItem label="Location" value={selectedCamera.location} />
                <InfoItem label="Zone" value={selectedCamera.zone} />
                <InfoItem label="Resolution" value={selectedCamera.resolution} />
                <InfoItem label="Frame Rate" value={`${selectedCamera.fps} fps`} />
                <InfoItem 
                  label="Recording" 
                  value={selectedCamera.recording ? 'Active' : 'Inactive'} 
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function CameraStatus({ status }: { status: string }) {
  if (status === 'live') {
    return (
      <div className="flex items-center gap-1 text-xs font-semibold text-green-400">
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
        <span>Live</span>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-1 text-xs font-semibold text-red-400">
      <div className="w-2 h-2 bg-red-500 rounded-full"></div>
      <span>Offline</span>
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-slate-400">{label}</span>
      <span className="font-semibold text-white">{value}</span>
    </div>
  );
}
