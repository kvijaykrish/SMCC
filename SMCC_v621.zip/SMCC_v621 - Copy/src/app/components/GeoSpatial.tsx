import { useState, useEffect, useRef } from 'react';
import { MapPin, Layers, Navigation, Crosshair, Square, Ruler, Download, ZoomIn, ZoomOut, Satellite, Mountain, Map as MapIcon, Loader2 } from 'lucide-react';

const LEAFLET_CSS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
const LEAFLET_JS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';

let leafletPromise: Promise<any> | null = null;
function loadLeaflet(): Promise<any> {
  if (leafletPromise) return leafletPromise;
  leafletPromise = new Promise((resolve, reject) => {
    if ((window as any).L) { resolve((window as any).L); return; }
    if (!document.querySelector(`link[href="${LEAFLET_CSS}"]`)) {
      const link = document.createElement('link'); link.rel = 'stylesheet'; link.href = LEAFLET_CSS; document.head.appendChild(link);
    }
    const s = document.createElement('script'); s.src = LEAFLET_JS;
    s.onload = () => resolve((window as any).L);
    s.onerror = () => { leafletPromise = null; reject(new Error('Failed to load Leaflet')); };
    document.head.appendChild(s);
  });
  return leafletPromise;
}
loadLeaflet().catch(() => {});

// Mine site center coordinates (Pilbara, Western Australia as example mine)
const MINE_CENTER: [number, number] = [-22.31, 118.42];

const assetLocations = [
  { id: 'EX-042', type: 'Excavator', lat: -22.305, lng: 118.415, zone: 'Zone A', status: 'active', speed: 0, heading: 45 },
  { id: 'HT-128', type: 'Haul Truck', lat: -22.315, lng: 118.425, zone: 'Zone B', status: 'active', speed: 28, heading: 180 },
  { id: 'DR-056', type: 'Drill', lat: -22.302, lng: 118.435, zone: 'Zone C', status: 'active', speed: 0, heading: 0 },
  { id: 'DZ-019', type: 'Dozer', lat: -22.322, lng: 118.410, zone: 'Workshop', status: 'maintenance', speed: 0, heading: 90 },
  { id: 'EX-043', type: 'Excavator', lat: -22.310, lng: 118.420, zone: 'Zone A', status: 'active', speed: 0, heading: 270 },
  { id: 'HT-129', type: 'Haul Truck', lat: -22.318, lng: 118.430, zone: 'Zone B', status: 'active', speed: 35, heading: 90 },
  { id: 'DR-057', type: 'Drill', lat: -22.298, lng: 118.440, zone: 'Zone D', status: 'active', speed: 0, heading: 0 },
  { id: 'LD-034', type: 'Loader', lat: -22.308, lng: 118.432, zone: 'Zone C', status: 'active', speed: 5, heading: 135 },
  { id: 'HT-130', type: 'Haul Truck', lat: -22.320, lng: 118.418, zone: 'Zone B', status: 'active', speed: 42, heading: 315 },
  { id: 'EX-044', type: 'Excavator', lat: -22.300, lng: 118.438, zone: 'Zone D', status: 'active', speed: 0, heading: 0 },
  { id: 'WK-015', type: 'Water Truck', lat: -22.312, lng: 118.428, zone: 'Zone B', status: 'active', speed: 18, heading: 225 },
  { id: 'GD-007', type: 'Grader', lat: -22.306, lng: 118.422, zone: 'Zone A', status: 'active', speed: 12, heading: 60 },
];

const zones = [
  { id: 'zone-a', name: 'Zone A - North Pit', bounds: [[-22.308, 118.410], [-22.296, 118.425]] as [[number, number], [number, number]], color: '#3b82f6', assets: 12 },
  { id: 'zone-b', name: 'Zone B - South Sector', bounds: [[-22.324, 118.414], [-22.312, 118.435]] as [[number, number], [number, number]], color: '#10b981', assets: 18 },
  { id: 'zone-c', name: 'Zone C - East Mining', bounds: [[-22.312, 118.428], [-22.300, 118.440]] as [[number, number], [number, number]], color: '#f59e0b', assets: 15 },
  { id: 'zone-d', name: 'Zone D - West Expansion', bounds: [[-22.304, 118.434], [-22.294, 118.446]] as [[number, number], [number, number]], color: '#8b5cf6', assets: 8 },
];

const ASSET_ICONS: Record<string, { emoji: string; color: string }> = {
  'Excavator': { emoji: '🏗️', color: '#f59e0b' },
  'Haul Truck': { emoji: '🚛', color: '#3b82f6' },
  'Drill': { emoji: '⛏️', color: '#ef4444' },
  'Dozer': { emoji: '🚜', color: '#f97316' },
  'Loader': { emoji: '🏗️', color: '#10b981' },
  'Water Truck': { emoji: '🚿', color: '#06b6d4' },
  'Grader': { emoji: '🔧', color: '#8b5cf6' },
};

const TILE_LAYERS = {
  satellite: { url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', options: { maxZoom: 19 } },
  terrain: { url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', options: { maxZoom: 17, subdomains: 'abc' } },
  dark: { url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', options: { maxZoom: 19, subdomains: 'abcd' } },
  labels: { url: 'https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png', options: { maxZoom: 19, subdomains: 'abcd', pane: 'overlayPane' } },
};

export function GeoSpatial() {
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null);
  const [mapView, setMapView] = useState<'satellite' | 'terrain' | 'dark'>('satellite');
  const [showZones, setShowZones] = useState(true);
  const [showLabels, setShowLabels] = useState(true);
  const [mapReady, setMapReady] = useState(false);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const leafletRef = useRef<any>(null);
  const baseLayerRef = useRef<any>(null);
  const labelsLayerRef = useRef<any>(null);
  const darkBaseRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const zonesLayerRef = useRef<any[]>([]);
  const initRef = useRef(false);

  // Init map
  useEffect(() => {
    if (initRef.current) return;
    let cancelled = false;

    async function init() {
      try {
        const L = await loadLeaflet();
        if (cancelled || !mapContainerRef.current) return;
        leafletRef.current = L;
        initRef.current = true;

        const map = L.map(mapContainerRef.current, {
          center: MINE_CENTER,
          zoom: 15,
          minZoom: 12,
          maxZoom: 19,
          zoomControl: false,
          attributionControl: false,
          preferCanvas: true,
          updateWhenIdle: true,
          keepBuffer: 4,
        });

        // Dark base (fast fallback)
        const darkBase = L.tileLayer(TILE_LAYERS.dark.url, { ...TILE_LAYERS.dark.options, attribution: '' }).addTo(map);
        darkBaseRef.current = darkBase;

        // Satellite layer
        const satLayer = L.tileLayer(TILE_LAYERS.satellite.url, { ...TILE_LAYERS.satellite.options, attribution: '' }).addTo(map);
        baseLayerRef.current = satLayer;

        // Labels overlay
        const labelsLayer = L.tileLayer(TILE_LAYERS.labels.url, { ...TILE_LAYERS.labels.options, attribution: '' }).addTo(map);
        labelsLayerRef.current = labelsLayer;

        L.control.zoom({ position: 'topright' }).addTo(map);

        mapRef.current = map;

        map.whenReady(() => {
          setMapReady(true);
          setTimeout(() => map.invalidateSize({ animate: false }), 100);
        });

        const ro = new ResizeObserver(() => map.invalidateSize({ animate: false }));
        ro.observe(mapContainerRef.current!);
        (map as any)._ro = ro;

      } catch {
        setMapReady(true);
      }
    }
    init();
    return () => {
      cancelled = true;
      if (mapRef.current) {
        (mapRef.current as any)?._ro?.disconnect();
        mapRef.current.remove();
        mapRef.current = null;
        initRef.current = false;
      }
    };
  }, []);

  // Switch tile layers
  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L) return;

    // Remove current base
    if (baseLayerRef.current && map.hasLayer(baseLayerRef.current)) map.removeLayer(baseLayerRef.current);

    if (mapView === 'satellite') {
      const layer = L.tileLayer(TILE_LAYERS.satellite.url, { ...TILE_LAYERS.satellite.options, attribution: '' }).addTo(map);
      baseLayerRef.current = layer;
      if (labelsLayerRef.current && !map.hasLayer(labelsLayerRef.current)) labelsLayerRef.current.addTo(map);
    } else if (mapView === 'terrain') {
      const layer = L.tileLayer(TILE_LAYERS.terrain.url, { ...TILE_LAYERS.terrain.options, attribution: '' }).addTo(map);
      baseLayerRef.current = layer;
      if (labelsLayerRef.current && map.hasLayer(labelsLayerRef.current)) map.removeLayer(labelsLayerRef.current);
    } else {
      baseLayerRef.current = null;
      if (labelsLayerRef.current && map.hasLayer(labelsLayerRef.current)) map.removeLayer(labelsLayerRef.current);
    }
  }, [mapView]);

  // Render asset markers
  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L || !mapReady) return;

    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    assetLocations.forEach(asset => {
      const cfg = ASSET_ICONS[asset.type] || { emoji: '📍', color: '#3b82f6' };
      const isSelected = asset.id === selectedAsset;

      const icon = L.divIcon({
        html: `
          <div style="position:relative;display:flex;align-items:center;justify-content:center;width:${isSelected ? 42 : 32}px;height:${isSelected ? 42 : 32}px;">
            <span style="position:absolute;width:100%;height:100%;border-radius:50%;background:${cfg.color};opacity:0.12;animation:geopulse 2.5s ease-out infinite;"></span>
            <span style="
              width:${isSelected ? 32 : 24}px;height:${isSelected ? 32 : 24}px;
              border-radius:50%;
              background:${asset.status === 'active' ? cfg.color : '#f59e0b'};
              border:2px solid ${isSelected ? '#fff' : 'rgba(255,255,255,0.7)'};
              box-shadow:0 0 ${isSelected ? 14 : 8}px ${cfg.color}80;
              display:flex;align-items:center;justify-content:center;
              font-size:${isSelected ? 14 : 11}px;
              position:relative;z-index:2;
              transition:all .2s;
            ">${cfg.emoji}</span>
          </div>
        `,
        className: 'geo-asset-marker',
        iconSize: [isSelected ? 42 : 32, isSelected ? 42 : 32],
        iconAnchor: [isSelected ? 21 : 16, isSelected ? 21 : 16],
      });

      const marker = L.marker([asset.lat, asset.lng], { icon }).addTo(map);

      marker.bindPopup(`
        <div style="background:#0f172a;color:#f1f5f9;padding:12px 16px;border-radius:10px;min-width:200px;font-family:system-ui;border:1px solid rgba(71,85,105,0.4);box-shadow:0 8px 30px rgba(0,0,0,0.5);">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
            <span style="font-size:20px;">${cfg.emoji}</span>
            <div>
              <div style="font-size:14px;font-weight:700;">${asset.id}</div>
              <div style="font-size:11px;color:#94a3b8;">${asset.type}</div>
            </div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:11px;">
            <div style="background:rgba(30,41,59,0.6);padding:6px 8px;border-radius:6px;">
              <div style="color:#64748b;font-size:9px;margin-bottom:2px;">Zone</div>
              <div style="font-weight:600;">${asset.zone}</div>
            </div>
            <div style="background:rgba(30,41,59,0.6);padding:6px 8px;border-radius:6px;">
              <div style="color:#64748b;font-size:9px;margin-bottom:2px;">Status</div>
              <div style="color:${asset.status === 'active' ? '#4ade80' : '#fbbf24'};font-weight:600;">${asset.status === 'active' ? 'Active' : 'Maintenance'}</div>
            </div>
            <div style="background:rgba(30,41,59,0.6);padding:6px 8px;border-radius:6px;">
              <div style="color:#64748b;font-size:9px;margin-bottom:2px;">Speed</div>
              <div style="font-weight:600;">${asset.speed} km/h</div>
            </div>
            <div style="background:rgba(30,41,59,0.6);padding:6px 8px;border-radius:6px;">
              <div style="color:#64748b;font-size:9px;margin-bottom:2px;">Heading</div>
              <div style="font-weight:600;">${asset.heading}&deg;</div>
            </div>
          </div>
          <div style="margin-top:8px;font-size:10px;color:#64748b;font-family:monospace;">
            ${asset.lat.toFixed(4)}&deg;S, ${asset.lng.toFixed(4)}&deg;E
          </div>
        </div>
      `, {
        className: 'geo-asset-popup',
        closeButton: true,
        maxWidth: 260,
        offset: [0, -8],
      });

      marker.on('click', () => setSelectedAsset(asset.id));
      markersRef.current.push(marker);
    });
  }, [mapReady, selectedAsset]);

  // Render zone overlays
  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L || !mapReady) return;

    zonesLayerRef.current.forEach(z => z.remove());
    zonesLayerRef.current = [];

    if (showZones) {
      zones.forEach(zone => {
        const rect = L.rectangle(zone.bounds, {
          color: zone.color,
          fillColor: zone.color,
          fillOpacity: 0.12,
          weight: 2,
          dashArray: '6,4',
        }).addTo(map);

        if (showLabels) {
          rect.bindTooltip(zone.name, {
            permanent: true,
            direction: 'center',
            className: 'geo-zone-label',
          });
        }

        zonesLayerRef.current.push(rect);
      });
    }
  }, [mapReady, showZones, showLabels]);

  // Fly to selected asset
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !selectedAsset) return;
    const asset = assetLocations.find(a => a.id === selectedAsset);
    if (asset) {
      map.flyTo([asset.lat, asset.lng], 17, { duration: 0.8 });
      const idx = assetLocations.findIndex(a => a.id === selectedAsset);
      if (idx >= 0 && markersRef.current[idx]) {
        setTimeout(() => markersRef.current[idx]?.openPopup(), 900);
      }
    }
  }, [selectedAsset]);

  const selectedAssetData = assetLocations.find(a => a.id === selectedAsset);

  return (
    <div className="p-6 space-y-6 bg-slate-950 min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl text-white">Geo-Spatial Intelligence</h1>
          <p className="text-slate-400 mt-1">Real-time asset tracking, zone management, and spatial analytics</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 rounded-lg transition-colors">
          <Download className="w-4 h-4" /><span>Export Map</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <SummaryCard title="Active Zones" value="4" icon={Layers} color="blue" />
        <SummaryCard title="Tracked Assets" value={`${assetLocations.length}`} icon={MapPin} color="green" />
        <SummaryCard title="Geo-Fences" value="12" icon={Square} color="purple" />
        <SummaryCard title="Coverage Area" value="245 km&sup2;" icon={Ruler} color="amber" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Map */}
        <div className="lg:col-span-3 bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-slate-800">
            <h3 className="text-lg text-white">Live Asset Map</h3>
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex bg-slate-800 rounded-lg p-1">
                <button onClick={() => setMapView('satellite')} className={`px-3 py-1.5 text-sm rounded transition-colors flex items-center gap-1.5 ${mapView === 'satellite' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}>
                  <Satellite className="w-3.5 h-3.5" /> Satellite
                </button>
                <button onClick={() => setMapView('terrain')} className={`px-3 py-1.5 text-sm rounded transition-colors flex items-center gap-1.5 ${mapView === 'terrain' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}>
                  <Mountain className="w-3.5 h-3.5" /> Terrain
                </button>
                <button onClick={() => setMapView('dark')} className={`px-3 py-1.5 text-sm rounded transition-colors flex items-center gap-1.5 ${mapView === 'dark' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}>
                  <MapIcon className="w-3.5 h-3.5" /> Dark
                </button>
              </div>
              <button onClick={() => setShowZones(!showZones)} className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${showZones ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
                Zones
              </button>
              <button onClick={() => setShowLabels(!showLabels)} className={`px-3 py-1.5 text-sm rounded-lg transition-colors ${showLabels ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'}`}>
                Labels
              </button>
            </div>
          </div>

          <div className="relative" style={{ height: '520px' }}>
            {!mapReady && (
              <div className="absolute inset-0 z-[2000] bg-slate-900 flex flex-col items-center justify-center gap-3">
                <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
                <p className="text-sm text-slate-400">Loading {mapView} map...</p>
              </div>
            )}
            <div ref={mapContainerRef} style={{ width: '100%', height: '100%', minHeight: 400 }} />

            {/* Map info overlay */}
            <div className="absolute bottom-4 left-4 z-[1000] pointer-events-none">
              <div className="bg-slate-900/80 backdrop-blur-sm border border-slate-700/60 rounded-lg px-3 py-2">
                <p className="text-[10px] text-slate-500 mb-1.5 uppercase tracking-wider">Asset Types</p>
                <div className="flex flex-wrap gap-x-3 gap-y-1">
                  {Object.entries(ASSET_ICONS).slice(0, 5).map(([type, cfg]) => (
                    <div key={type} className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ background: cfg.color }} />
                      <span className="text-[10px] text-slate-400">{type}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Asset Details */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <h3 className="text-lg text-white mb-4">Asset Details</h3>
            {selectedAssetData ? (
              <div className="space-y-3">
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-3xl">{ASSET_ICONS[selectedAssetData.type]?.emoji || '📍'}</span>
                  <div>
                    <div className="text-white">{selectedAssetData.id}</div>
                    <div className="text-sm text-slate-400">{selectedAssetData.type}</div>
                  </div>
                </div>
                <DetailRow label="Zone" value={selectedAssetData.zone} />
                <DetailRow label="Status" value={selectedAssetData.status === 'active' ? 'Active' : 'Maintenance'} valueColor={selectedAssetData.status === 'active' ? 'text-green-400' : 'text-amber-400'} />
                <DetailRow label="Speed" value={`${selectedAssetData.speed} km/h`} />
                <DetailRow label="Heading" value={`${selectedAssetData.heading}°`} />
                <DetailRow label="Coordinates" value={`${selectedAssetData.lat.toFixed(4)}°, ${selectedAssetData.lng.toFixed(4)}°`} mono />
                <button className="w-full mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
                  Track Asset
                </button>
              </div>
            ) : (
              <div className="text-center py-8">
                <MapPin className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                <p className="text-slate-400 text-sm">Select an asset on the map to view details</p>
              </div>
            )}
          </div>

          {/* Zone Summary */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <h3 className="text-lg text-white mb-4">Zone Summary</h3>
            <div className="space-y-3">
              {zones.map(zone => (
                <div key={zone.id} className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
                  <div>
                    <div className="text-white text-sm">{zone.name.split(' - ')[0]}</div>
                    <div className="text-slate-400 text-xs">{zone.assets} assets</div>
                  </div>
                  <div className="w-8 h-8 rounded" style={{ backgroundColor: zone.color + '60' }} />
                </div>
              ))}
            </div>
          </div>

          {/* Asset List */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <h3 className="text-lg text-white mb-4">All Assets</h3>
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {assetLocations.map(asset => (
                <button key={asset.id} onClick={() => setSelectedAsset(asset.id)}
                  className={`w-full flex items-center gap-3 p-2 rounded-lg text-left transition-all ${selectedAsset === asset.id ? 'bg-blue-500/10 border border-blue-500/30' : 'hover:bg-slate-800 border border-transparent'}`}
                >
                  <span className="text-sm">{ASSET_ICONS[asset.type]?.emoji || '📍'}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-white truncate">{asset.id}</div>
                    <div className="text-xs text-slate-500">{asset.type} &middot; {asset.zone}</div>
                  </div>
                  <div className={`w-2 h-2 rounded-full ${asset.status === 'active' ? 'bg-green-500' : 'bg-amber-500'}`} />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Custom map styles */}
      <style>{`
        @keyframes geopulse {
          0% { transform:scale(1); opacity:0.12; }
          70% { transform:scale(2.5); opacity:0; }
          100% { transform:scale(2.5); opacity:0; }
        }
        .geo-asset-marker { background:none!important; border:none!important; }
        .geo-asset-popup .leaflet-popup-content-wrapper { background:transparent!important; box-shadow:none!important; padding:0!important; border-radius:10px!important; }
        .geo-asset-popup .leaflet-popup-content { margin:0!important; line-height:1.4!important; }
        .geo-asset-popup .leaflet-popup-tip { background:#0f172a!important; border:1px solid rgba(71,85,105,0.4)!important; }
        .geo-asset-popup .leaflet-popup-close-button { color:#94a3b8!important; font-size:18px!important; top:6px!important; right:8px!important; z-index:10!important; text-shadow:0 1px 4px rgba(0,0,0,0.8)!important; }
        .geo-zone-label { background:rgba(15,23,42,0.8)!important; border:1px solid rgba(71,85,105,0.4)!important; color:#94a3b8!important; font-size:11px!important; padding:2px 8px!important; border-radius:4px!important; box-shadow:none!important; }
        .geo-zone-label::before { display:none!important; }
        .leaflet-control-zoom a { background:rgba(15,23,42,0.85)!important; color:#e2e8f0!important; border-color:rgba(71,85,105,0.5)!important; backdrop-filter:blur(8px)!important; }
        .leaflet-control-zoom a:hover { background:rgba(30,41,59,0.9)!important; color:#fff!important; }
        .leaflet-tile-pane { will-change:transform; }
      `}</style>
    </div>
  );
}

function SummaryCard({ title, value, icon: Icon, color }: any) {
  const colorClasses: Record<string, string> = {
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    green: 'bg-green-500/10 text-green-400 border-green-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  };
  return (
    <div className={`bg-slate-900 rounded-xl border ${colorClasses[color]} p-6`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-400">{title}</p>
          <p className="text-2xl text-white mt-1" dangerouslySetInnerHTML={{ __html: value }} />
        </div>
        <Icon className="w-8 h-8" />
      </div>
    </div>
  );
}

function DetailRow({ label, value, valueColor = 'text-white', mono = false }: { label: string; value: string; valueColor?: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-slate-400">{label}</span>
      <span className={`text-sm ${valueColor} ${mono ? 'font-mono' : ''}`}>{value}</span>
    </div>
  );
}
