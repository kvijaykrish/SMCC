import { 
  LayoutDashboard, 
  Network, 
  Radio, 
  MapPin, 
  Shield, 
  Droplet, 
  GraduationCap,
  ChevronRight,
  Box,
  Video,
  Play,
  FileText,
  Bot
} from 'lucide-react';
import type { View } from '../App';
import { BrandIcon } from './BrandIcon';

interface SidebarProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

interface NavItem {
  id: View;
  label: string;
  icon: React.ElementType;
  category?: string;
}

const navItems: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'video-tour', label: 'Feature Tour', icon: Play, category: 'Digital Infrastructure' },
  { id: 'connected-assets', label: 'Connected Assets', icon: Network, category: 'Digital Infrastructure' },
  { id: 'digital-twin', label: 'Digital Twin Viewer', icon: Box, category: 'Digital Infrastructure' },
  { id: 'private-5g', label: 'Private 5G Network', icon: Radio, category: 'Digital Infrastructure' },
  { id: 'geo-spatial', label: 'Geo-Spatial Intelligence', icon: MapPin, category: 'Digital Infrastructure' },
  { id: 'security', label: 'Integrated Security', icon: Shield, category: 'Safety & Resources' },
  { id: 'video-stream', label: 'Live Video Stream', icon: Video, category: 'Safety & Resources' },
  { id: 'water', label: 'Water Management', icon: Droplet, category: 'Safety & Resources' },
  { id: 'safety', label: 'Safety & Training', icon: GraduationCap, category: 'Safety & Resources' },
  { id: 'historical-reports', label: 'Historical Reports', icon: FileText, category: 'Analytics' },
  { id: 'ai-assistant', label: 'AI Assistant', icon: Bot, category: 'Analytics' },
];

export function Sidebar({ currentView, onNavigate }: SidebarProps) {
  let lastCategory = '';

  return (
    <aside className="w-72 bg-slate-900 text-white flex flex-col">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <BrandIcon size="md" />
          <div>
            <div className="text-sm text-slate-400">SDS Mining</div>
            <div className="text-xs text-slate-500">v2.1.0</div>
          </div>
        </div>
      </div>
      
      <nav className="flex-1 p-4 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const showCategory = item.category && item.category !== lastCategory;
          if (item.category) lastCategory = item.category;
          
          return (
            <div key={item.id}>
              {showCategory && (
                <div className="px-3 py-2 mt-4 first:mt-0">
                  <div className="text-xs text-slate-400 uppercase tracking-wider">
                    {item.category}
                  </div>
                </div>
              )}
              <button
                onClick={() => onNavigate(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                  currentView === item.id
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="flex-1 text-left text-sm">{item.label}</span>
                {currentView === item.id && <ChevronRight className="w-4 h-4" />}
              </button>
            </div>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800 rounded-lg p-3">
          <div className="text-xs text-slate-400 mb-2">System Status</div>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">CPU Usage</span>
              <span className="text-green-400">32%</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Network</span>
              <span className="text-green-400">Active</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300">Devices</span>
              <span className="text-blue-400">847 Online</span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}