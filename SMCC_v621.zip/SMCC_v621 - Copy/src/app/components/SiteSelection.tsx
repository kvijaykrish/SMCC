import { useState, useEffect, useCallback } from 'react';
import { storage } from '../utils/storage';
import { MineMap } from './MineMap';
import { MapPin, LayoutGrid, Map, Factory, Users, Boxes, ChevronRight, Activity, Globe } from 'lucide-react';
import { BrandIcon } from './BrandIcon';

interface Site {
  id: string;
  site_id: string;
  name: string;
  location: string;
  country: string;
  status: string;
  site_type: string;
  primary_commodity: string;
  total_assets?: number;
  active_assets?: number;
  assets_in_maintenance?: number;
  workforce_present?: number;
  workforce_count?: number;
  network_uptime_percentage?: number;
  operational_efficiency?: number;
  production_tonnes_today?: number;
  active_alerts?: number;
  critical_alerts?: number;
  image_url?: string;
  lat: number;
  lng: number;
}

export default function SiteSelection() {
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');
  const [selectedMapSite, setSelectedMapSite] = useState<string | null>(null);
  const [stats, setStats] = useState({
    totalSites: 0,
    operationalSites: 0,
    totalAnnualCapacity: 0,
    totalWorkforce: 0,
    countriesCount: 0
  });

  useEffect(() => {
    loadSites();
    loadStatistics();
  }, []);

  // Listen for map popup navigation events
  useEffect(() => {
    const handler = (e: Event) => {
      const siteId = (e as CustomEvent).detail;
      const site = sites.find(s => s.id === siteId);
      if (site) selectSite(site);
    };
    window.addEventListener('mine-site-navigate', handler);
    return () => window.removeEventListener('mine-site-navigate', handler);
  }, [sites]);

  const loadSites = async () => {
    const mockSites: Site[] = [
      {
        id: '1',
        site_id: 'NRM-001',
        name: 'Northern Ridge Mine',
        location: 'Pilbara, Australia',
        country: 'Australia',
        status: 'operational',
        site_type: 'open_pit',
        primary_commodity: 'Iron Ore',
        total_assets: 342,
        active_assets: 287,
        assets_in_maintenance: 12,
        workforce_present: 456,
        workforce_count: 520,
        network_uptime_percentage: 99.8,
        operational_efficiency: 94.5,
        production_tonnes_today: 45600,
        active_alerts: 2,
        critical_alerts: 0,
        image_url: 'https://images.unsplash.com/photo-1664578867628-dae621194f4e?w=800&h=600&fit=crop',
        lat: -22.3,
        lng: 118.4
      },
      {
        id: '2',
        site_id: 'SVC-002',
        name: 'Sierra Verde Complex',
        location: 'Antofagasta, Chile',
        country: 'Chile',
        status: 'operational',
        site_type: 'open_pit',
        primary_commodity: 'Copper',
        total_assets: 298,
        active_assets: 265,
        assets_in_maintenance: 8,
        workforce_present: 389,
        workforce_count: 450,
        network_uptime_percentage: 98.5,
        operational_efficiency: 92.3,
        production_tonnes_today: 32400,
        active_alerts: 1,
        critical_alerts: 0,
        image_url: 'https://images.unsplash.com/photo-1559774898-ca11626da35e?w=800&h=600&fit=crop',
        lat: -23.6,
        lng: -70.4
      },
      {
        id: '3',
        site_id: 'GU-003',
        name: 'Goldstream Underground',
        location: 'Ontario, Canada',
        country: 'Canada',
        status: 'operational',
        site_type: 'underground',
        primary_commodity: 'Gold',
        total_assets: 156,
        active_assets: 142,
        assets_in_maintenance: 5,
        workforce_present: 234,
        workforce_count: 280,
        network_uptime_percentage: 99.2,
        operational_efficiency: 88.7,
        production_tonnes_today: 8900,
        active_alerts: 3,
        critical_alerts: 1,
        image_url: 'https://images.unsplash.com/photo-1647485938389-91df46750f1b?w=800&h=600&fit=crop',
        lat: 48.5,
        lng: -80.0
      },
      {
        id: '4',
        site_id: 'EBF-004',
        name: 'Eastern Bauxite Fields',
        location: 'Queensland, Australia',
        country: 'Australia',
        status: 'operational',
        site_type: 'open_pit',
        primary_commodity: 'Bauxite',
        total_assets: 189,
        active_assets: 167,
        assets_in_maintenance: 6,
        workforce_present: 298,
        workforce_count: 340,
        network_uptime_percentage: 97.8,
        operational_efficiency: 90.1,
        production_tonnes_today: 28500,
        active_alerts: 2,
        critical_alerts: 0,
        image_url: 'https://images.unsplash.com/photo-1668985305739-2e52f016e50c?w=800&h=600&fit=crop',
        lat: -20.7,
        lng: 139.5
      },
      {
        id: '5',
        site_id: 'PR-005',
        name: 'Platinum Ridge',
        location: 'Limpopo, South Africa',
        country: 'South Africa',
        status: 'operational',
        site_type: 'underground',
        primary_commodity: 'Platinum',
        total_assets: 134,
        active_assets: 118,
        assets_in_maintenance: 4,
        workforce_present: 267,
        workforce_count: 320,
        network_uptime_percentage: 98.9,
        operational_efficiency: 86.4,
        production_tonnes_today: 5600,
        active_alerts: 1,
        critical_alerts: 0,
        image_url: 'https://images.unsplash.com/photo-1681298357240-61ce20489514?w=800&h=600&fit=crop',
        lat: -23.4,
        lng: 29.5
      },
      {
        id: '6',
        site_id: 'CPH-006',
        name: 'Central Processing Hub',
        location: 'Nevada, USA',
        country: 'USA',
        status: 'operational',
        site_type: 'processing_plant',
        primary_commodity: 'Processing Plant',
        total_assets: 245,
        active_assets: 228,
        assets_in_maintenance: 7,
        workforce_present: 178,
        workforce_count: 200,
        network_uptime_percentage: 99.5,
        operational_efficiency: 95.2,
        production_tonnes_today: 18700,
        active_alerts: 0,
        critical_alerts: 0,
        image_url: 'https://images.unsplash.com/photo-1764377975946-1649b873b306?w=800&h=600&fit=crop',
        lat: 39.5,
        lng: -116.8
      }
    ];

    setTimeout(() => {
      setSites(mockSites);
      setLoading(false);
    }, 800);
  };

  const loadStatistics = async () => {
    setTimeout(() => {
      setStats({
        totalSites: 6,
        operationalSites: 6,
        totalAnnualCapacity: 63100000,
        totalWorkforce: 2110,
        countriesCount: 5
      });
    }, 500);
  };

  const selectSite = (site: Site) => {
    storage.setItem('selectedSite', JSON.stringify(site));
    window.location.reload();
  };

  const handleMapSiteSelect = useCallback((siteId: string) => {
    setSelectedMapSite(siteId);
  }, []);

  const handleMapNavigate = useCallback((siteId: string) => {
    const site = sites.find(s => s.id === siteId);
    if (site) selectSite(site);
  }, [sites]);

  const formatNumber = (num: number | undefined): string => {
    if (!num) return '0';
    return num.toLocaleString();
  };

  const formatCapacity = (tonnes: number): string => {
    if (tonnes >= 1000000) {
      return (tonnes / 1000000).toFixed(1) + 'M';
    }
    if (tonnes >= 1000) {
      return (tonnes / 1000).toFixed(0) + 'K';
    }
    return tonnes.toString();
  };

  const getStatusColor = (status: string): string => {
    const colors: Record<string, string> = {
      'operational': 'bg-green-500/20 text-green-400 border-green-500/30',
      'maintenance': 'bg-amber-500/20 text-amber-400 border-amber-500/30',
      'commissioning': 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    };
    return colors[status] || 'bg-slate-500/20 text-slate-400 border-slate-500/30';
  };

  const getSiteTypeLabel = (type: string): string => {
    const labels: Record<string, string> = {
      'open_pit': 'Open Pit',
      'underground': 'Underground',
      'processing_plant': 'Processing Plant',
      'exploration': 'Exploration'
    };
    return labels[type] || type;
  };

  const getCommodityColor = (commodity: string): string => {
    const colors: Record<string, string> = {
      'Iron Ore': 'text-red-400',
      'Copper': 'text-orange-400',
      'Gold': 'text-yellow-400',
      'Bauxite': 'text-amber-400',
      'Platinum': 'text-slate-300',
      'Processing Plant': 'text-cyan-400',
    };
    return colors[commodity] || 'text-blue-400';
  };

  const selectedSiteData = sites.find(s => s.id === selectedMapSite);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-900/50 border-b border-slate-700 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <BrandIcon />
              <div>
                <h1 className="text-2xl text-white">SDS Mining Command Center</h1>
                <p className="text-sm text-slate-400">Select a mining site to continue</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {/* View Mode Toggle */}
              <div className="flex bg-slate-800 rounded-lg border border-slate-700 p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm transition-colors ${
                    viewMode === 'grid' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <LayoutGrid className="w-4 h-4" />
                  <span className="hidden sm:inline">Grid</span>
                </button>
                <button
                  onClick={() => setViewMode('map')}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm transition-colors ${
                    viewMode === 'map' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Map className="w-4 h-4" />
                  <span className="hidden sm:inline">Map</span>
                </button>
              </div>
              <button 
                onClick={() => {
                  storage.removeItem('authToken');
                  storage.removeItem('selectedSite');
                  window.location.reload();
                }}
                className="px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition-colors">
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500/10 border border-blue-500/20 rounded-lg flex items-center justify-center shrink-0">
              <Factory className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Total Sites</p>
              <p className="text-2xl text-white">{stats.totalSites}</p>
            </div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500/10 border border-green-500/20 rounded-lg flex items-center justify-center shrink-0">
              <Activity className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Operational</p>
              <p className="text-2xl text-green-400">{stats.operationalSites}</p>
            </div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500/10 border border-blue-500/20 rounded-lg flex items-center justify-center shrink-0">
              <Globe className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Countries</p>
              <p className="text-2xl text-blue-400">{stats.countriesCount}</p>
            </div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-500/10 border border-purple-500/20 rounded-lg flex items-center justify-center shrink-0">
              <Boxes className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Total Capacity</p>
              <p className="text-2xl text-purple-400">{formatCapacity(stats.totalAnnualCapacity)}t</p>
            </div>
          </div>
          <div className="bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl p-4 flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500/10 border border-orange-500/20 rounded-lg flex items-center justify-center shrink-0">
              <Users className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-0.5">Total Workforce</p>
              <p className="text-2xl text-orange-400">{formatNumber(stats.totalWorkforce)}</p>
            </div>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          </div>
        )}

        {/* Error State */}
        {error && !loading && (
          <div className="bg-red-900/20 border border-red-500/50 rounded-xl p-6 text-center">
            <p className="text-red-300 text-lg">{error}</p>
            <button 
              onClick={loadSites}
              className="mt-4 px-6 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
              Retry
            </button>
          </div>
        )}

        {/* Map View */}
        {!loading && !error && viewMode === 'map' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Map */}
            <div className="lg:col-span-2 h-[600px]">
              <MineMap
                sites={sites}
                onSelectSite={handleMapSiteSelect}
                selectedSiteId={selectedMapSite}
                onNavigateToSite={handleMapNavigate}
              />
            </div>

            {/* Site List Sidebar */}
            <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
              <h3 className="text-sm text-slate-400 uppercase tracking-wider mb-3 px-1">Mining Sites</h3>
              {sites.map(site => (
                <div
                  key={site.id}
                  onClick={() => setSelectedMapSite(site.id)}
                  className={`group bg-slate-800/50 backdrop-blur-sm border rounded-xl p-4 cursor-pointer transition-all hover:border-blue-500/50 ${
                    selectedMapSite === site.id ? 'border-blue-500 shadow-lg shadow-blue-500/10' : 'border-slate-700'
                  }`}
                >
                  <div className="flex gap-3">
                    <div className="w-16 h-16 rounded-lg overflow-hidden shrink-0 bg-slate-700">
                      <img 
                        src={site.image_url} 
                        alt={site.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm text-white truncate">{site.name}</h4>
                      <div className="flex items-center gap-1 text-xs text-slate-400 mt-0.5">
                        <MapPin className="w-3 h-3" />
                        <span className="truncate">{site.location}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-2">
                        <span className={`text-xs ${getCommodityColor(site.primary_commodity)}`}>
                          {site.primary_commodity}
                        </span>
                        <span className="text-slate-600">|</span>
                        <span className="text-xs text-slate-500">{getSiteTypeLabel(site.site_type)}</span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Expanded details when selected */}
                  {selectedMapSite === site.id && (
                    <div className="mt-4 pt-3 border-t border-slate-700">
                      <div className="grid grid-cols-3 gap-3 mb-3">
                        <div>
                          <p className="text-[10px] text-slate-500">Assets</p>
                          <p className="text-sm text-white">{formatNumber(site.total_assets)}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500">Workforce</p>
                          <p className="text-sm text-white">{formatNumber(site.workforce_present)}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-500">Efficiency</p>
                          <p className="text-sm text-white">{site.operational_efficiency}%</p>
                        </div>
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); selectSite(site); }}
                        className="w-full px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors flex items-center justify-center gap-2"
                      >
                        Enter Command Center
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Grid View */}
        {!loading && !error && viewMode === 'grid' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sites.map(site => (
              <div 
                key={site.id}
                onClick={() => selectSite(site)}
                className="group bg-slate-800/50 backdrop-blur-sm border border-slate-700 rounded-xl overflow-hidden hover:border-blue-500/50 hover:shadow-xl hover:shadow-blue-500/10 transition-all cursor-pointer transform hover:-translate-y-1">
                
                {/* Site Image */}
                <div className="relative h-48 overflow-hidden bg-slate-700">
                  {site.image_url ? (
                    <img 
                      src={site.image_url} 
                      alt={site.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Factory className="w-16 h-16 text-slate-600" />
                    </div>
                  )}
                  
                  {/* Gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent" />
                  
                  {/* Status Badge */}
                  <div className="absolute top-3 right-3">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs border ${getStatusColor(site.status)}`}>
                      <span className="w-1.5 h-1.5 rounded-full bg-current mr-1.5"></span>
                      {site.status}
                    </span>
                  </div>

                  {/* Site Type + Commodity Badge */}
                  <div className="absolute bottom-3 left-3 flex items-center gap-2">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs bg-slate-900/80 text-slate-200 border border-slate-600 backdrop-blur-sm">
                      {getSiteTypeLabel(site.site_type)}
                    </span>
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs bg-slate-900/80 border border-slate-600 backdrop-blur-sm ${getCommodityColor(site.primary_commodity)}`}>
                      {site.primary_commodity}
                    </span>
                  </div>
                </div>

                {/* Site Details */}
                <div className="p-6">
                  <h3 className="text-xl text-white mb-1 group-hover:text-blue-400 transition-colors">
                    {site.name}
                  </h3>
                  <div className="flex items-center gap-2 text-slate-400 text-sm mb-4">
                    <MapPin className="w-4 h-4" />
                    <span>{site.location}</span>
                  </div>

                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Assets</p>
                      <p className="text-lg text-white">{formatNumber(site.total_assets)}</p>
                      <p className="text-xs text-green-400">{formatNumber(site.active_assets)} active</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Workforce</p>
                      <p className="text-lg text-white">{formatNumber(site.workforce_present)}</p>
                      <p className="text-xs text-slate-400">of {formatNumber(site.workforce_count)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Efficiency</p>
                      <p className="text-lg text-white">{site.operational_efficiency}%</p>
                      <div className="w-full bg-slate-700 rounded-full h-1 mt-1">
                        <div 
                          className="bg-blue-500 h-1 rounded-full" 
                          style={{ width: `${site.operational_efficiency}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Production + Alerts */}
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-4 py-2 border-t border-slate-700/50">
                    <span>Production: <span className="text-white">{formatNumber(site.production_tonnes_today)}t/day</span></span>
                    <span>
                      Alerts: 
                      <span className={`ml-1 ${(site.critical_alerts || 0) > 0 ? 'text-red-400' : 'text-green-400'}`}>
                        {site.active_alerts || 0}
                      </span>
                    </span>
                  </div>

                  {/* View Button */}
                  <button className="w-full px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center justify-center gap-2">
                    <span>View Command Center</span>
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}