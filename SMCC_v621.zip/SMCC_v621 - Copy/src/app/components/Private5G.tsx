import { useState } from 'react';
import { Radio, Wifi, Signal, Activity, TrendingUp, Server, AlertCircle, CheckCircle } from 'lucide-react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

const networkPerformanceData = [
  { time: '00:00', bandwidth: 850, latency: 12, devices: 645 },
  { time: '04:00', bandwidth: 720, latency: 15, devices: 580 },
  { time: '08:00', bandwidth: 920, latency: 10, devices: 720 },
  { time: '12:00', bandwidth: 880, latency: 11, devices: 695 },
  { time: '16:00', bandwidth: 950, latency: 9, devices: 750 },
  { time: '20:00', bandwidth: 890, latency: 11, devices: 680 },
];

const cellTowerData = [
  { id: 'TOWER-01', name: 'North Sector Alpha', status: 'operational', signal: 98, coverage: 95, devices: 142, location: 'Zone A-1' },
  { id: 'TOWER-02', name: 'South Sector Beta', status: 'operational', signal: 96, coverage: 92, devices: 138, location: 'Zone B-2' },
  { id: 'TOWER-03', name: 'East Sector Gamma', status: 'operational', signal: 94, coverage: 89, devices: 125, location: 'Zone C-3' },
  { id: 'TOWER-04', name: 'West Sector Delta', status: 'warning', signal: 85, coverage: 78, devices: 98, location: 'Zone D-4' },
  { id: 'TOWER-05', name: 'Central Hub Epsilon', status: 'operational', signal: 99, coverage: 97, devices: 156, location: 'Central' },
  { id: 'TOWER-06', name: 'Mining Pit Zeta', status: 'operational', signal: 92, coverage: 88, devices: 112, location: 'Pit Zone' },
];

const bandwidthUsageData = [
  { category: 'Asset Telemetry', usage: 320, color: '#3b82f6' },
  { category: 'Video Surveillance', usage: 280, color: '#10b981' },
  { category: 'Digital Twin Sync', usage: 180, color: '#f59e0b' },
  { category: 'Safety Systems', usage: 120, color: '#ef4444' },
  { category: 'Management', usage: 80, color: '#8b5cf6' },
];

export function Private5G() {
  const [selectedTower, setSelectedTower] = useState<string | null>(null);

  return (
    <div className="p-6 space-y-6 bg-slate-950 min-h-full">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Private 5G Network</h1>
        <p className="text-slate-400 mt-1">Network performance, coverage analysis, and infrastructure monitoring</p>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Network Uptime"
          value="99.8%"
          change="+0.2%"
          icon={Wifi}
          color="green"
        />
        <MetricCard
          title="Active Devices"
          value="847"
          change="+23"
          icon={Radio}
          color="blue"
        />
        <MetricCard
          title="Avg. Bandwidth"
          value="890 Mbps"
          change="+45 Mbps"
          icon={TrendingUp}
          color="purple"
        />
        <MetricCard
          title="Avg. Latency"
          value="10.8ms"
          change="-1.2ms"
          icon={Activity}
          color="amber"
        />
      </div>

      {/* Network Performance Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bandwidth & Latency */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Network Performance (24h)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={networkPerformanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="time" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis yAxisId="left" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Legend wrapperStyle={{ color: '#e2e8f0' }} />
              <Line yAxisId="left" type="monotone" dataKey="bandwidth" stroke="#3b82f6" strokeWidth={2} name="Bandwidth (Mbps)" />
              <Line yAxisId="right" type="monotone" dataKey="latency" stroke="#f59e0b" strokeWidth={2} name="Latency (ms)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Connected Devices */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Connected Devices (24h)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={networkPerformanceData}>
              <defs>
                <linearGradient id="colorDevices" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="time" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Area 
                type="monotone" 
                dataKey="devices" 
                stroke="#10b981" 
                fillOpacity={1} 
                fill="url(#colorDevices)"
                name="Devices"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bandwidth Usage by Category */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Bandwidth Usage by Category</h3>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={bandwidthUsageData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis type="number" stroke="#94a3b8" style={{ fontSize: '12px' }} />
            <YAxis type="category" dataKey="category" stroke="#94a3b8" style={{ fontSize: '12px' }} width={150} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
              labelStyle={{ color: '#e2e8f0' }}
            />
            <Bar dataKey="usage" name="Usage (Mbps)">
              {bandwidthUsageData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Cell Tower Status */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Cell Tower Infrastructure</h3>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded-full" />
              <span className="text-slate-300">Operational: 5</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-amber-500 rounded-full" />
              <span className="text-slate-300">Warning: 1</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
          {cellTowerData.map((tower) => (
            <TowerCard 
              key={tower.id} 
              tower={tower} 
              isSelected={selectedTower === tower.id}
              onClick={() => setSelectedTower(tower.id)}
            />
          ))}
        </div>
      </div>

      {/* Network Health Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <HealthCard
          title="Signal Quality"
          value="Excellent"
          score={96}
          icon={Signal}
          color="green"
        />
        <HealthCard
          title="Coverage Area"
          value="92% Site Coverage"
          score={92}
          icon={Radio}
          color="blue"
        />
        <HealthCard
          title="Infrastructure"
          value="All Systems OK"
          score={98}
          icon={Server}
          color="purple"
        />
      </div>
    </div>
  );
}

function MetricCard({ title, value, change, icon: Icon, color }: any) {
  const colorClasses: Record<string, string> = {
    green: 'bg-green-500/10 text-green-400 border-green-500/20',
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  };

  return (
    <div className={`bg-slate-900 rounded-xl border ${colorClasses[color]} p-6`}>
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm text-slate-400">{title}</p>
          <p className="text-2xl font-bold text-white mt-1">{value}</p>
          <p className="text-sm text-green-400 mt-1">{change}</p>
        </div>
        <Icon className="w-8 h-8" />
      </div>
    </div>
  );
}

function TowerCard({ tower, isSelected, onClick }: any) {
  const isWarning = tower.status === 'warning';

  return (
    <button
      onClick={onClick}
      className={`bg-slate-800 border ${isSelected ? 'border-blue-500' : 'border-slate-700'} rounded-lg p-4 text-left hover:border-slate-600 transition-all`}
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="text-sm font-mono text-blue-400">{tower.id}</div>
          <div className="text-white font-semibold mt-1">{tower.name}</div>
          <div className="text-xs text-slate-400 mt-1">{tower.location}</div>
        </div>
        {isWarning ? (
          <AlertCircle className="w-5 h-5 text-amber-400" />
        ) : (
          <CheckCircle className="w-5 h-5 text-green-400" />
        )}
      </div>

      <div className="grid grid-cols-3 gap-3 text-sm">
        <div>
          <div className="text-slate-400 text-xs">Signal</div>
          <div className={`font-semibold ${isWarning ? 'text-amber-400' : 'text-green-400'}`}>{tower.signal}%</div>
        </div>
        <div>
          <div className="text-slate-400 text-xs">Coverage</div>
          <div className="text-white font-semibold">{tower.coverage}%</div>
        </div>
        <div>
          <div className="text-slate-400 text-xs">Devices</div>
          <div className="text-white font-semibold">{tower.devices}</div>
        </div>
      </div>

      <div className="mt-3 pt-3 border-t border-slate-700">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400">Status</span>
          <span className={`font-semibold ${isWarning ? 'text-amber-400' : 'text-green-400'}`}>
            {tower.status === 'operational' ? 'Operational' : 'Warning'}
          </span>
        </div>
      </div>
    </button>
  );
}

function HealthCard({ title, value, score, icon: Icon, color }: any) {
  const colorClasses: Record<string, string> = {
    green: 'from-green-600 to-green-700',
    blue: 'from-blue-600 to-blue-700',
    purple: 'from-purple-600 to-purple-700',
  };

  return (
    <div className={`bg-gradient-to-br ${colorClasses[color]} rounded-xl p-6 text-white`}>
      <Icon className="w-8 h-8 mb-4" />
      <div className="text-lg font-semibold mb-1">{title}</div>
      <div className="text-2xl font-bold mb-2">{value}</div>
      <div className="flex items-center gap-2">
        <div className="flex-1 h-2 bg-white/20 rounded-full overflow-hidden">
          <div className="h-full bg-white rounded-full" style={{ width: `${score}%` }} />
        </div>
        <span className="text-sm">{score}%</span>
      </div>
    </div>
  );
}