/**
 * SDS Mining Insights Brand Icon
 * A faceted diamond gem with a radar pulse ring — mining meets real-time intelligence.
 * Used consistently across Login, Site Selection, Sidebar, VideoTour, and Header.
 */

interface BrandIconProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const sizes = {
  sm: { container: 'w-8 h-8', svg: 'w-5 h-5' },
  md: { container: 'w-10 h-10', svg: 'w-6 h-6' },
  lg: { container: 'w-12 h-12', svg: 'w-7 h-7' },
  xl: { container: 'w-16 h-16', svg: 'w-10 h-10' },
};

export function BrandIcon({ size = 'md', className = '' }: BrandIconProps) {
  const s = sizes[size];

  return (
    <div
      className={`${s.container} bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-700 rounded-xl flex items-center justify-center shadow-lg shadow-blue-600/25 ${className}`}
    >
      <svg
        className={s.svg}
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Outer radar pulse ring */}
        <circle
          cx="16"
          cy="15"
          r="13"
          stroke="rgba(255,255,255,0.12)"
          strokeWidth="1"
        />
        {/* Inner radar pulse ring */}
        <circle
          cx="16"
          cy="15"
          r="9.5"
          stroke="rgba(255,255,255,0.2)"
          strokeWidth="0.8"
          strokeDasharray="3 2"
        />

        {/* Diamond gem — top half (crown) */}
        <path
          d="M16 4L22 11H10L16 4Z"
          fill="rgba(255,255,255,0.9)"
        />
        {/* Diamond gem — bottom half (pavilion) */}
        <path
          d="M10 11L16 25L22 11H10Z"
          fill="rgba(255,255,255,0.7)"
        />
        {/* Diamond facet line — center */}
        <path
          d="M13 11L16 4L19 11"
          stroke="rgba(59,130,246,0.5)"
          strokeWidth="0.7"
          strokeLinejoin="round"
        />
        {/* Diamond inner facet lines */}
        <line x1="10" y1="11" x2="16" y2="25" stroke="rgba(59,130,246,0.3)" strokeWidth="0.5" />
        <line x1="22" y1="11" x2="16" y2="25" stroke="rgba(59,130,246,0.3)" strokeWidth="0.5" />
        <line x1="16" y1="4" x2="16" y2="11" stroke="rgba(59,130,246,0.35)" strokeWidth="0.5" />

        {/* Sparkle / insight flash — top right */}
        <line x1="23" y1="5" x2="23" y2="9" stroke="white" strokeWidth="1.2" strokeLinecap="round" />
        <line x1="21" y1="7" x2="25" y2="7" stroke="white" strokeWidth="1.2" strokeLinecap="round" />

        {/* Tiny sparkle — bottom left */}
        <circle cx="8" cy="20" r="0.8" fill="rgba(255,255,255,0.6)" />
        <line x1="8" y1="18.5" x2="8" y2="21.5" stroke="rgba(255,255,255,0.4)" strokeWidth="0.6" strokeLinecap="round" />
        <line x1="6.5" y1="20" x2="9.5" y2="20" stroke="rgba(255,255,255,0.4)" strokeWidth="0.6" strokeLinecap="round" />

        {/* Pulse / heartbeat line across bottom */}
        <path
          d="M3 27L8 27L10 24L12 29L14 26L16 28L18 24L20 27L29 27"
          stroke="rgba(255,255,255,0.55)"
          strokeWidth="1.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    </div>
  );
}
