import { Bell, User, Settings, AlertCircle, LogOut } from 'lucide-react';
import type { View } from '../App';
import { storage } from '../utils/storage';
import { useState, useEffect } from 'react';

interface HeaderProps {
  currentView: View;
}

const viewTitles: Record<View, string> = {
  'dashboard': 'Command Center Dashboard',
  'connected-assets': 'Connected Assets & Digital Twins',
  'private-5g': 'Private 5G Network',
  'geo-spatial': 'Geo-Spatial Intelligence',
  'security': 'Integrated Security',
  'water': 'Water Management',
  'safety': 'Safety & Smart Training',
  'digital-twin': 'Digital Twin Simulation',
  'video-stream': 'Live Video Stream',
  'video-tour': 'Feature Tour',
  'historical-reports': 'Historical Reports',
  'ai-assistant': 'AI Mining Assistant'
};

export function Header({ currentView }: HeaderProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  let selectedSite: any = {};
  
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  try {
    const siteData = storage.getItem('selectedSite');
    if (siteData) {
      selectedSite = JSON.parse(siteData);
    }
  } catch (err) {
    console.error('Error parsing selected site:', err);
  }

  const changeSite = () => {
    storage.removeItem('selectedSite');
    window.location.reload();
  };

  const logout = () => {
    storage.removeItem('authToken');
    storage.removeItem('selectedSite');
    window.location.reload();
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div>
            <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">
              SDS - Smart Mining Command Center
            </div>
            <h1 className="text-xl font-semibold text-white">{viewTitles[currentView]}</h1>
          </div>
          
          {selectedSite.name && (
            <div className="flex items-center gap-2 px-3 py-2 bg-slate-800 rounded-lg border border-slate-700">
              <div>
                <div className="text-xs text-slate-400">Current Site</div>
                <div className="text-sm font-semibold text-white">{selectedSite.name}</div>
              </div>
              <button 
                onClick={changeSite}
                className="ml-2 p-1 hover:bg-slate-700 rounded transition-colors"
                title="Change site">
                <svg className="w-4 h-4 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                </svg>
              </button>
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-2 bg-amber-500/10 border border-amber-500/20 rounded-lg">
            <AlertCircle className="w-4 h-4 text-amber-400" />
            <span className="text-sm text-amber-300">3 Active Alerts</span>
          </div>
          
          <button className="p-2 hover:bg-slate-800 rounded-lg relative transition-colors">
            <Bell className="w-5 h-5 text-slate-300" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
          </button>
          
          <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
            <Settings className="w-5 h-5 text-slate-300" />
          </button>
          
          <div className="flex items-center gap-2 px-3 py-2 bg-slate-800 rounded-lg border border-slate-700">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-white" />
            </div>
            <div className="text-left">
              <div className="text-sm font-semibold text-white">John Smith</div>
              <div className="text-xs text-slate-400">Operations Manager</div>
            </div>
            <button 
              onClick={logout}
              className="ml-2 p-1.5 hover:bg-slate-700 rounded transition-colors"
              title="Logout">
              <LogOut className="w-4 h-4 text-slate-400" />
            </button>
          </div>
        </div>
      </div>
      
      <div className="mt-3 flex items-center gap-6 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span>All Systems Operational</span>
        </div>
        <div>Last Updated: {currentTime.toLocaleTimeString()}</div>
        {selectedSite.location && <div>Location: {selectedSite.location}</div>}
      </div>
    </header>
  );
}