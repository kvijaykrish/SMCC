import { useState } from 'react';
import { HardHat, AlertTriangle, CheckCircle, Users, BookOpen, Video, Award, TrendingUp, Clock, Target } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const safetyMetrics = [
  { week: 'Week 1', incidents: 0, nearMiss: 2, inspections: 145, training: 32 },
  { week: 'Week 2', incidents: 1, nearMiss: 1, inspections: 152, training: 28 },
  { week: 'Week 3', incidents: 0, nearMiss: 3, inspections: 148, training: 35 },
  { week: 'Week 4', incidents: 0, nearMiss: 1, inspections: 156, training: 40 },
];

const trainingPrograms = [
  { id: 'TR-001', name: 'Emergency Response Procedures', type: 'VR Simulation', status: 'active', enrolled: 145, completed: 132, duration: '2 hours' },
  { id: 'TR-002', name: 'Heavy Equipment Operation', type: 'VR Simulation', status: 'active', enrolled: 89, completed: 76, duration: '4 hours' },
  { id: 'TR-003', name: 'Hazard Identification', type: 'Classroom', status: 'active', enrolled: 210, completed: 198, duration: '3 hours' },
  { id: 'TR-004', name: 'First Aid & CPR', type: 'Practical', status: 'active', enrolled: 156, completed: 143, duration: '6 hours' },
  { id: 'TR-005', name: 'Mine Safety Protocols', type: 'VR Simulation', status: 'scheduled', enrolled: 67, completed: 0, duration: '5 hours' },
];

const incidentData = [
  { category: 'Equipment', count: 3, severity: 'minor' },
  { category: 'Slip/Fall', count: 2, severity: 'minor' },
  { category: 'Near Miss', count: 7, severity: 'low' },
  { category: 'PPE Violation', count: 5, severity: 'low' },
];

const certificationStatus = [
  { name: 'Current', value: 285, color: '#10b981' },
  { name: 'Expiring Soon', value: 45, color: '#f59e0b' },
  { name: 'Expired', value: 12, color: '#ef4444' },
];

const vrSimulations = [
  { id: 'VR-001', name: 'Underground Evacuation', difficulty: 'Advanced', completionRate: 87, avgScore: 92 },
  { id: 'VR-002', name: 'Fire Response Training', difficulty: 'Intermediate', completionRate: 94, avgScore: 88 },
  { id: 'VR-003', name: 'Equipment Failure Scenarios', difficulty: 'Advanced', completionRate: 78, avgScore: 85 },
  { id: 'VR-004', name: 'Chemical Spill Response', difficulty: 'Expert', completionRate: 65, avgScore: 81 },
];

export function SafetyTraining() {
  const [selectedProgram, setSelectedProgram] = useState<string | null>(null);

  return (
    <div className="p-6 space-y-6 bg-slate-950 min-h-full">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Safety & Smart Training</h1>
        <p className="text-slate-400 mt-1">VR training simulations, safety protocols, and certification management</p>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Safety Score"
          value="98.5"
          change="+1.2 points"
          icon={HardHat}
          color="green"
        />
        <MetricCard
          title="Active Training"
          value="342"
          change="Employees enrolled"
          icon={BookOpen}
          color="blue"
        />
        <MetricCard
          title="Incidents (30d)"
          value="1"
          change="-3 vs last month"
          icon={AlertTriangle}
          color="amber"
        />
        <MetricCard
          title="Certifications"
          value="285"
          change="12 expiring soon"
          icon={Award}
          color="purple"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Safety Metrics Timeline */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Safety Metrics (Monthly)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={safetyMetrics}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="week" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Legend wrapperStyle={{ color: '#e2e8f0' }} />
              <Bar dataKey="incidents" fill="#ef4444" name="Incidents" />
              <Bar dataKey="nearMiss" fill="#f59e0b" name="Near Miss" />
              <Bar dataKey="inspections" fill="#10b981" name="Inspections" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Certification Status */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Certification Status</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={certificationStatus}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {certificationStatus.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-3 gap-2 mt-4">
            {certificationStatus.map((status) => (
              <div key={status.name} className="text-center">
                <div className="w-full h-2 rounded-full mb-2" style={{ backgroundColor: status.color }} />
                <div className="text-sm text-slate-300">{status.name}</div>
                <div className="text-lg font-bold text-white">{status.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* VR Training Simulations */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">VR Training Simulations</h3>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
            <Video className="w-4 h-4" />
            <span>Launch VR Suite</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {vrSimulations.map((simulation) => (
            <VRSimulationCard key={simulation.id} simulation={simulation} />
          ))}
        </div>
      </div>

      {/* Training Programs */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Active Training Programs</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-800 border-b border-slate-700">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Program ID</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Name</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Type</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Enrolled</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Completed</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Progress</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Duration</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {trainingPrograms.map((program) => (
                <tr 
                  key={program.id}
                  onClick={() => setSelectedProgram(program.id)}
                  className="hover:bg-slate-800/50 transition-colors cursor-pointer"
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm font-mono text-blue-400">{program.id}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-white">{program.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <TypeBadge type={program.type} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-1 text-sm text-slate-300">
                      <Users className="w-4 h-4" />
                      <span>{program.enrolled}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-1 text-sm text-green-400">
                      <CheckCircle className="w-4 h-4" />
                      <span>{program.completed}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <ProgressBar percentage={Math.round((program.completed / program.enrolled) * 100)} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-1 text-sm text-slate-300">
                      <Clock className="w-4 h-4" />
                      <span>{program.duration}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <StatusBadge status={program.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Safety Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-xl p-6 text-white">
          <CheckCircle className="w-10 h-10 mb-3" />
          <div className="text-lg font-semibold mb-2">Days Without Incident</div>
          <div className="text-4xl font-bold mb-2">87</div>
          <div className="text-sm opacity-90">Target: 365 days</div>
        </div>

        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-6 text-white">
          <TrendingUp className="w-10 h-10 mb-3" />
          <div className="text-lg font-semibold mb-2">Training Completion</div>
          <div className="text-4xl font-bold mb-2">94%</div>
          <div className="text-sm opacity-90">Above industry average</div>
        </div>

        <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-xl p-6 text-white">
          <Target className="w-10 h-10 mb-3" />
          <div className="text-lg font-semibold mb-2">Safety Compliance</div>
          <div className="text-4xl font-bold mb-2">99.2%</div>
          <div className="text-sm opacity-90">Meets all regulations</div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, change, icon: Icon, color }: any) {
  const colorClasses: Record<string, string> = {
    green: 'bg-green-500/10 text-green-400 border-green-500/20',
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  };

  return (
    <div className={`bg-slate-900 rounded-xl border ${colorClasses[color]} p-6`}>
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm text-slate-400">{title}</p>
          <p className="text-2xl font-bold text-white mt-1">{value}</p>
          <p className="text-xs text-slate-400 mt-1">{change}</p>
        </div>
        <Icon className="w-8 h-8" />
      </div>
    </div>
  );
}

function VRSimulationCard({ simulation }: any) {
  const difficultyColor: Record<string, string> = {
    'Beginner': 'text-green-400',
    'Intermediate': 'text-blue-400',
    'Advanced': 'text-amber-400',
    'Expert': 'text-red-400',
  };

  return (
    <div className="bg-slate-800 rounded-lg p-4 border border-slate-700 hover:border-blue-500 transition-all">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="text-sm font-mono text-blue-400">{simulation.id}</div>
          <div className="text-white font-semibold text-sm mt-1">{simulation.name}</div>
        </div>
        <Video className="w-5 h-5 text-blue-400" />
      </div>

      <div className="space-y-2 text-xs">
        <div className="flex items-center justify-between">
          <span className="text-slate-400">Difficulty</span>
          <span className={`font-semibold ${difficultyColor[simulation.difficulty]}`}>
            {simulation.difficulty}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-slate-400">Completion</span>
          <span className="text-white font-semibold">{simulation.completionRate}%</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-slate-400">Avg Score</span>
          <span className="text-green-400 font-semibold">{simulation.avgScore}%</span>
        </div>
      </div>

      <button className="w-full mt-3 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded transition-colors">
        Launch Simulation
      </button>
    </div>
  );
}

function TypeBadge({ type }: { type: string }) {
  const typeConfig: Record<string, string> = {
    'VR Simulation': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    'Classroom': 'bg-green-500/10 text-green-400 border-green-500/20',
    'Practical': 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  };

  return (
    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full border ${typeConfig[type]}`}>
      {type}
    </span>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusConfig: Record<string, string> = {
    active: 'bg-green-500/10 text-green-400 border-green-500/20',
    scheduled: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    completed: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  };

  return (
    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full border ${statusConfig[status]}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

function ProgressBar({ percentage }: { percentage: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
        <div 
          className="h-full bg-blue-500 rounded-full transition-all" 
          style={{ width: `${percentage}%` }}
        />
      </div>
      <span className="text-sm text-slate-300 w-12 text-right">{percentage}%</span>
    </div>
  );
}
