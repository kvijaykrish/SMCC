import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Play, Pause, SkipForward, SkipBack, Volume2, VolumeX,
  Maximize, Minimize, RotateCcw, X, Subtitles,
  LayoutDashboard, Radio, MapPin, Shield, Droplet, GraduationCap, Box, ChevronRight,
  FileText, Bot
} from 'lucide-react';
import { BrandIcon } from './BrandIcon';

/* ────────────────────────────────────────────
   SCENE DATA – 12 scenes, ~12 s each = ~2.5 min
   ──────────────────────────────────────────── */
interface TourScene {
  id: string;
  title: string;
  subtitle: string;
  narration: string;
  duration: number;            // ms
  bgImage: string;
  bgOverlay: string;           // tailwind gradient over image
  icon: React.ElementType | null;
  accentColor: string;
  bulletPoints: string[];
  statsCards?: { label: string; value: string; color: string }[];
  visualType: 'intro' | 'module' | 'benefits' | 'closing';
}

const SCENES: TourScene[] = [
  {
    id: 'intro',
    title: 'SDS Smart Mining Command Center',
    subtitle: 'Intelligent Operations. Unified Control.',
    narration:
      'Welcome to the SDS Smart Mining Command Center — a unified digital platform that transforms how mining operations are monitored, managed, and optimized. In the next two and a half minutes, we will walk you through eight powerful modules — including advanced historical analytics and an AI-powered voice assistant — that bring real-time intelligence to every aspect of your mine site.',
    duration: 14000,
    bgImage: 'https://images.unsplash.com/photo-1769629918261-92d1fac176cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbmclMjBvcGVyYXRpb24lMjBhZXJpYWwlMjB2aWV3fGVufDF8fHx8MTc3MTk0NDA3MHww&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-slate-950/90 via-slate-950/70 to-blue-950/80',
    icon: null,
    accentColor: '#3b82f6',
    bulletPoints: [],
    visualType: 'intro',
  },
  {
    id: 'dashboard',
    title: 'Centralized Dashboard',
    subtitle: 'Your Mine at a Glance',
    narration:
      'The main dashboard provides a bird\'s-eye view of your entire operation. Key performance indicators such as production output, asset health, safety incidents, and network uptime are visualized through interactive charts and live metric cards — giving decision-makers instant situational awareness.',
    duration: 13000,
    bgImage: 'https://images.unsplash.com/photo-1765734482991-7c60829a0bff?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwY29udHJvbCUyMHJvb20lMjBkYXNoYm9hcmR8ZW58MXx8fHwxNzcxODQ5ODE3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-slate-950/90 via-slate-900/70 to-slate-950/85',
    icon: LayoutDashboard,
    accentColor: '#3b82f6',
    bulletPoints: [
      'Real-time KPI cards with trend indicators',
      'Production, efficiency, and energy charts',
      'Asset fleet status with radar analytics',
      'Quick-launch to every module',
    ],
    statsCards: [
      { label: 'Active Assets', value: '107', color: '#10b981' },
      { label: 'Efficiency', value: '92%', color: '#3b82f6' },
      { label: 'Uptime', value: '99.7%', color: '#8b5cf6' },
      { label: 'Production', value: '52K T', color: '#f59e0b' },
    ],
    visualType: 'module',
  },
  {
    id: 'assets',
    title: 'Connected Assets & Digital Twins',
    subtitle: 'Live 3D Models with Sensor Overlays',
    narration:
      'Every excavator, haul truck, drill rig, and dozer has a photorealistic digital twin rendered as a detailed isometric model. Animated sensor readouts for engine RPM, hydraulic pressure, and track wear update in real time. The view supports wireframe and solid modes, with per-component health scoring and predictive maintenance alerts.',
    duration: 14000,
    bgImage: 'https://images.unsplash.com/photo-1582280871722-424e91cbee8b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleGNhdmF0b3IlMjBoZWF2eSUyMG1hY2hpbmVyeSUyMG1pbmluZ3xlbnwxfHx8fDE3NzE5NDQwODl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-amber-950/80 via-slate-950/80 to-slate-950/90',
    icon: Box,
    accentColor: '#f59e0b',
    bulletPoints: [
      'Detailed isometric models per asset type',
      'Animated hydraulic and sensor readouts',
      'Component-level health scoring (engine, tracks, etc.)',
      'Predictive maintenance with remaining-hours alerts',
    ],
    statsCards: [
      { label: 'Excavators', value: '24', color: '#f59e0b' },
      { label: 'Haul Trucks', value: '45', color: '#3b82f6' },
      { label: 'Health Avg', value: '91%', color: '#10b981' },
      { label: 'Alerts', value: '3', color: '#ef4444' },
    ],
    visualType: 'module',
  },
  {
    id: '5g',
    title: 'Private 5G Network',
    subtitle: 'Ultra-Low Latency Connectivity',
    narration:
      'The Private 5-G module monitors your dedicated on-site network. Tower health, signal coverage heat maps, bandwidth utilization, and device connection counts are displayed in real time. Sub-10-millisecond latency ensures reliable telemetry, video streaming, and autonomous vehicle control across the entire mine site.',
    duration: 13000,
    bgImage: 'https://images.unsplash.com/photo-1614157561595-dc25d28cfa85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHw1RyUyMG5ldHdvcmslMjB0b3dlciUyMHRlY2hub2xvZ3l8ZW58MXx8fHwxNzcxOTQ0MDc1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-purple-950/80 via-slate-950/80 to-slate-950/90',
    icon: Radio,
    accentColor: '#8b5cf6',
    bulletPoints: [
      '5G tower health & signal coverage maps',
      'Bandwidth utilization & device monitoring',
      'Sub-10ms latency for autonomous operations',
      'Automatic failover & edge computing support',
    ],
    statsCards: [
      { label: 'Towers', value: '6', color: '#8b5cf6' },
      { label: 'Devices', value: '342', color: '#06b6d4' },
      { label: 'Latency', value: '<8ms', color: '#10b981' },
      { label: 'Uptime', value: '99.9%', color: '#3b82f6' },
    ],
    visualType: 'module',
  },
  {
    id: 'geo',
    title: 'Geo-Spatial Intelligence',
    subtitle: 'Interactive Satellite & Terrain Mapping',
    narration:
      'The Geo-Spatial module loads a full interactive map with satellite, terrain, and standard view toggles. Color-coded markers pinpoint every asset, with rich popups showing speed, heading, and zone. Shaded overlays visualize mining zones, restricted areas, and processing regions — complete with fly-to navigation on click.',
    duration: 13000,
    bgImage: 'https://images.unsplash.com/photo-1517917635448-93c0dc320860?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXRlbGxpdGUlMjBtYXAlMjB0ZXJyYWluJTIwZ2VvbG9naWNhbHxlbnwxfHx8fDE3NzE5NDQwNzh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-cyan-950/80 via-slate-950/75 to-slate-950/90',
    icon: MapPin,
    accentColor: '#06b6d4',
    bulletPoints: [
      'Interactive map with Satellite / Terrain / Standard tiles',
      'Color-coded asset markers with rich popups',
      'Zone overlays with visual color coding',
      'Fly-to navigation & geofence alerting',
    ],
    statsCards: [
      { label: 'Zones', value: '6', color: '#06b6d4' },
      { label: 'Tracked', value: '107', color: '#f59e0b' },
      { label: 'Geofences', value: '14', color: '#ef4444' },
      { label: 'Coverage', value: '35 km\u00B2', color: '#10b981' },
    ],
    visualType: 'module',
  },
  {
    id: 'security',
    title: 'Integrated Security',
    subtitle: 'AI-Powered Surveillance & Access Control',
    narration:
      'Integrated Security combines live video feeds from 24 cameras, A-I anomaly detection, and zone-based access control. The system detects unauthorized personnel, perimeter breaches, and unusual vehicle behavior — triggering instant alerts to security teams. Multi-stream layouts support up to 16 simultaneous camera views.',
    duration: 13000,
    bgImage: 'https://images.unsplash.com/photo-1755260904813-929ec10da3ac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWN1cml0eSUyMHN1cnZlaWxsYW5jZSUyMGNhbWVyYSUyMGluZHVzdHJpYWx8ZW58MXx8fHwxNzcxOTQ0MDgxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-red-950/80 via-slate-950/80 to-slate-950/90',
    icon: Shield,
    accentColor: '#ef4444',
    bulletPoints: [
      'Live multi-camera surveillance grid',
      'AI anomaly & perimeter breach detection',
      'Zone-based access control & badge tracking',
      'Automated incident logging & alert escalation',
    ],
    statsCards: [
      { label: 'Cameras', value: '24', color: '#ef4444' },
      { label: 'Events', value: '156', color: '#f59e0b' },
      { label: 'Zones', value: '8', color: '#8b5cf6' },
      { label: 'Compliance', value: '98%', color: '#10b981' },
    ],
    visualType: 'module',
  },
  {
    id: 'water',
    title: 'Water Management System',
    subtitle: 'Animated Flow Diagram with Live Telemetry',
    narration:
      'Water Management features an animated flow diagram that traces water from the reservoir through pump stations, treatment plants, distribution hubs, and into mining, processing, and dust suppression zones. Color-coded flowing particles show real-time flow rates. A reclaim loop tracks recycled water — achieving up to 45 percent reclamation.',
    duration: 14000,
    bgImage: 'https://images.unsplash.com/photo-1701146125128-b0b03267e58a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlciUyMHRyZWF0bWVudCUyMGluZHVzdHJpYWwlMjBwaXBlbGluZXxlbnwxfHx8fDE3NzE5NDQwODR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-blue-950/80 via-slate-950/80 to-slate-950/90',
    icon: Droplet,
    accentColor: '#3b82f6',
    bulletPoints: [
      'Animated water flow with color-coded particles',
      'Reservoir \u2192 Treatment \u2192 Distribution \u2192 Zones',
      'Reclaim loop with 45% water recycling',
      'Pipeline pressure, quality, and usage analytics',
    ],
    statsCards: [
      { label: 'Daily Usage', value: '10K m\u00B3', color: '#3b82f6' },
      { label: 'Quality', value: '97.8%', color: '#10b981' },
      { label: 'Reclaimed', value: '45%', color: '#22c55e' },
      { label: 'Pipelines', value: '5/6', color: '#f59e0b' },
    ],
    visualType: 'module',
  },
  {
    id: 'safety',
    title: 'Safety & Smart Training',
    subtitle: 'Certifications, Drills & Incident Tracking',
    narration:
      'The Safety module tracks workforce certifications, safety drill completion, incident reports, and compliance scores across the entire site. Interactive training programs with progress tracking ensure every worker meets regulatory requirements. Real-time incident heat maps highlight high-risk zones for proactive safety management.',
    duration: 13000,
    bgImage: 'https://images.unsplash.com/photo-1603516270950-26e4f5004ffd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYWZldHklMjB0cmFpbmluZyUyMGhlbG1ldCUyMGNvbnN0cnVjdGlvbiUyMHdvcmtlcnxlbnwxfHx8fDE3NzE5NDQwODd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-green-950/80 via-slate-950/80 to-slate-950/90',
    icon: GraduationCap,
    accentColor: '#10b981',
    bulletPoints: [
      'Workforce certification & expiry tracking',
      'Safety drill scheduling & completion monitoring',
      'Incident reporting with heat map analysis',
      'Regulatory compliance dashboard',
    ],
    statsCards: [
      { label: 'Workers', value: '1,247', color: '#10b981' },
      { label: 'Certified', value: '96%', color: '#3b82f6' },
      { label: 'Incidents', value: '0 today', color: '#22c55e' },
      { label: 'Drills', value: '12/12', color: '#8b5cf6' },
    ],
    visualType: 'module',
  },
  {
    id: 'reports',
    title: 'Historical Reports & Analytics',
    subtitle: 'Visualize, Generate & Download Operational Reports',
    narration:
      'The Historical Reports module lets you dive deep into your operational data across any time period. Choose from six report categories — production, safety, equipment, water, energy, and security — and instantly visualize trends with interactive charts, KPI summary cards, and detailed data tables. Select preset time ranges or custom dates, then generate downloadable CSV exports or print-ready PDF reports with a single click. Every metric is computed dynamically so your reports always reflect the latest data.',
    duration: 14000,
    bgImage: 'https://images.unsplash.com/photo-1763038311036-6d18805537e5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwYW5hbHl0aWNzJTIwcmVwb3J0JTIwZGFzaGJvYXJkJTIwdmlzdWFsaXphdGlvbnxlbnwxfHx8fDE3NzE5ODQ4MTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-indigo-950/80 via-slate-950/80 to-slate-950/90',
    icon: FileText,
    accentColor: '#6366f1',
    bulletPoints: [
      '6 report types: Production, Safety, Equipment, Water, Energy, Security',
      'Interactive trend charts with bar, area, and line visualizations',
      'Preset time ranges (7d to 1y) plus custom date pickers',
      'One-click CSV export and printable PDF report generation',
    ],
    statsCards: [
      { label: 'Report Types', value: '6', color: '#6366f1' },
      { label: 'Data Points', value: '24K+', color: '#3b82f6' },
      { label: 'Export Formats', value: '3', color: '#10b981' },
      { label: 'Avg Gen Time', value: '<2s', color: '#f59e0b' },
    ],
    visualType: 'module',
  },
  {
    id: 'ai-assistant',
    title: 'AI Voice Assistant',
    subtitle: 'Natural Language Query & Voice-Powered Analytics',
    narration:
      'The AI Mining Assistant is your conversational gateway to operational intelligence. Simply type or speak a natural language query like "show me all excavator breakdowns in the past 3 months" and the system instantly searches over 2,000 indexed mining events, filters by equipment type, event category, severity, location, and time range, then presents results with interactive charts, breakdown pie graphs, and a scrollable data table. Every query result can be downloaded as CSV or generated as a full printable report. The voice interface uses Web Speech A-P-I for hands-free operation, and the assistant speaks back a summary of its findings.',
    duration: 16000,
    bgImage: 'https://images.unsplash.com/photo-1761311984112-ce2c5db45984?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpZmljaWFsJTIwaW50ZWxsaWdlbmNlJTIwdm9pY2UlMjBhc3Npc3RhbnQlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc3MTk4NDgxMHww&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-violet-950/85 via-slate-950/75 to-slate-950/90',
    icon: Bot,
    accentColor: '#a855f7',
    bulletPoints: [
      'Voice input via Web Speech API with real-time transcription',
      'Natural language parsing: equipment, events, severity, time ranges',
      'Interactive timeline charts and type-breakdown pie graphs per query',
      'One-click CSV download and printable report from any query result',
    ],
    statsCards: [
      { label: 'Events Indexed', value: '2K+', color: '#a855f7' },
      { label: 'Query Types', value: '20+', color: '#3b82f6' },
      { label: 'Voice Input', value: 'Yes', color: '#10b981' },
      { label: 'Response', value: '<2s', color: '#f59e0b' },
    ],
    visualType: 'module',
  },
  {
    id: 'benefits',
    title: 'Key Benefits',
    subtitle: 'Why SDS Command Center?',
    narration:
      'SDS delivers measurable ROI across every dimension: 30 percent reduction in unplanned downtime through predictive maintenance, 12 percent improvement in water efficiency via smart reclamation, 99.9 percent network uptime with private 5-G, and zero-incident operations supported by AI-powered safety monitoring. Historical analytics and the AI voice assistant give your team instant access to trends and events using natural language — dramatically reducing the time from question to insight. The platform can be deployed on private data centers for maximum security, or scaled through cloud infrastructure to match your operational needs.',
    duration: 15000,
    bgImage: 'https://images.unsplash.com/photo-1760629863094-5b1e8d1aae74?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwdGVjaG5vbG9neSUyMGlubm92YXRpb24lMjBmdXR1cmlzdGljfGVufDF8fHx8MTc3MTk0NDA5M3ww&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-slate-950/90 via-blue-950/70 to-slate-950/85',
    icon: null,
    accentColor: '#3b82f6',
    bulletPoints: [
      '30% reduction in unplanned downtime',
      '12% improvement in water efficiency',
      '99.9% network uptime with Private 5G',
      'AI-powered analytics: question to insight in seconds',
    ],
    visualType: 'benefits',
  },
  {
    id: 'closing',
    title: 'Ready to Transform Your Mine?',
    subtitle: 'Get Started with SDS Today',
    narration:
      'Thank you for touring the SDS Smart Mining Command Center. From digital twins and 5-G connectivity to geo-spatial intelligence, water management, historical reporting, and AI-powered voice analytics, every module is designed to make your operation safer, smarter, and more efficient. Whether deployed on-premise in your private data center or hosted in the cloud, SDS adapts to your infrastructure. Contact our team to schedule a live demo or begin your deployment today.',
    duration: 15000,
    bgImage: 'https://images.unsplash.com/photo-1571422657383-e21eeff747c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcGVuJTIwcGl0JTIwbWluZSUyMGhhdWwlMjB0cnVjayUyMHN1bnNldHxlbnwxfHx8fDE3NzE5NDQwOTV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    bgOverlay: 'from-slate-950/85 via-amber-950/50 to-slate-950/90',
    icon: null,
    accentColor: '#f59e0b',
    bulletPoints: [],
    visualType: 'closing',
  },
];

const TOTAL_DURATION = SCENES.reduce((s, sc) => s + sc.duration, 0);

/* ────────────────────────────────────────────
   COMPONENT
   ──────────────────────────────────────────── */
interface VideoTourProps {
  onClose?: () => void;
}

export function VideoTour({ onClose }: VideoTourProps) {
  const [sceneIndex, setSceneIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [captionsOn, setCaptionsOn] = useState(true);
  const [fullscreen, setFullscreen] = useState(false);
  const [elapsed, setElapsed] = useState(0);        // ms into current scene
  const [started, setStarted] = useState(false);
  const [transitioning, setTransitioning] = useState(false);
  const [captionText, setCaptionText] = useState('');
  const [captionWords, setCaptionWords] = useState<string[]>([]);
  const [spokenWordIdx, setSpokenWordIdx] = useState(0);
  const [speechDone, setSpeechDone] = useState(false);
  const [timerDone, setTimerDone] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const synthRef = useRef(typeof window !== 'undefined' ? window.speechSynthesis : null);
  const utterRef = useRef<SpeechSynthesisUtterance | null>(null);

  const scene = SCENES[sceneIndex];

  /* ── global elapsed ── */
  const globalElapsed = SCENES.slice(0, sceneIndex).reduce((s, sc) => s + sc.duration, 0) + elapsed;
  const progressPct = (globalElapsed / TOTAL_DURATION) * 100;

  /* ── format time ── */
  const fmt = (ms: number) => {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    return `${m}:${String(s % 60).padStart(2, '0')}`;
  };

  /* ── speak current scene narration ── */
  const speak = useCallback((text: string) => {
    if (!synthRef.current) return;
    synthRef.current.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.0;
    u.pitch = 1.0;
    u.volume = muted ? 0 : 1;

    // Pick a good voice
    const voices = synthRef.current.getVoices();
    const preferred = voices.find(
      v => v.lang.startsWith('en') && (v.name.includes('Google') || v.name.includes('Samantha') || v.name.includes('Daniel') || v.name.includes('Microsoft'))
    ) || voices.find(v => v.lang.startsWith('en')) || voices[0];
    if (preferred) u.voice = preferred;

    const words = text.split(/\s+/);
    setCaptionWords(words);
    setSpokenWordIdx(0);

    u.onboundary = (e) => {
      if (e.name === 'word') {
        const before = text.substring(0, e.charIndex);
        const idx = before.split(/\s+/).filter(Boolean).length;
        setSpokenWordIdx(idx);
        // Build caption window – show ~12 words around current word
        const start = Math.max(0, idx - 3);
        const end = Math.min(words.length, idx + 10);
        setCaptionText(words.slice(start, end).join(' '));
      }
    };

    u.onend = () => {
      setCaptionText('');
      setSpeechDone(true);
    };

    utterRef.current = u;
    synthRef.current.speak(u);
  }, [muted]);

  /* ── stop speech ── */
  const stopSpeech = useCallback(() => {
    if (synthRef.current) synthRef.current.cancel();
    setCaptionText('');
    setCaptionWords([]);
    setSpokenWordIdx(0);
    setSpeechDone(false);
  }, []);

  /* ── go to scene ── */
  const goToScene = useCallback((idx: number, autoPlay = true) => {
    if (idx < 0 || idx >= SCENES.length) return;
    setTransitioning(true);
    setTimerDone(false);
    setSpeechDone(false);
    stopSpeech();
    setTimeout(() => {
      setSceneIndex(idx);
      setElapsed(0);
      setTransitioning(false);
      if (autoPlay) {
        speak(SCENES[idx].narration);
      }
    }, 400);
  }, [speak, stopSpeech]);

  /* ── play / pause ── */
  const togglePlay = useCallback(() => {
    if (!started) {
      setStarted(true);
      setPlaying(true);
      speak(scene.narration);
      return;
    }
    if (playing) {
      setPlaying(false);
      if (synthRef.current) synthRef.current.pause();
    } else {
      setPlaying(true);
      if (synthRef.current) synthRef.current.resume();
    }
  }, [playing, started, speak, scene.narration]);

  /* ── timer tick ── */
  useEffect(() => {
    if (playing) {
      timerRef.current = setInterval(() => {
        setElapsed(prev => {
          const next = prev + 100;
          if (next >= scene.duration) {
            setTimerDone(true);
            return scene.duration; // cap at duration, don't auto-advance yet
          }
          return next;
        });
      }, 100);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [playing, scene.duration]);

  /* ── advance scene when BOTH timer and speech are done ── */
  useEffect(() => {
    if (timerDone && speechDone && playing) {
      setTimerDone(false);
      setSpeechDone(false);
      if (sceneIndex < SCENES.length - 1) {
        goToScene(sceneIndex + 1);
      } else {
        setPlaying(false);
        stopSpeech();
      }
    }
  }, [timerDone, speechDone, playing, sceneIndex, goToScene, stopSpeech]);

  /* ── also advance if timer done and speech already finished (muted / short narration) ── */
  useEffect(() => {
    if (timerDone && muted && playing) {
      setTimerDone(false);
      setSpeechDone(false);
      if (sceneIndex < SCENES.length - 1) {
        goToScene(sceneIndex + 1);
      } else {
        setPlaying(false);
        stopSpeech();
      }
    }
  }, [timerDone, muted, playing, sceneIndex, goToScene, stopSpeech]);

  /* ── mute change ── */
  useEffect(() => {
    if (utterRef.current) {
      utterRef.current.volume = muted ? 0 : 1;
    }
  }, [muted]);

  /* ── fullscreen ── */
  const toggleFullscreen = useCallback(() => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setFullscreen(false)).catch(() => {});
    }
  }, []);

  /* ── restart ── */
  const restart = useCallback(() => {
    stopSpeech();
    setSceneIndex(0);
    setElapsed(0);
    setStarted(false);
    setPlaying(false);
  }, [stopSpeech]);

  /* ── cleanup ── */
  useEffect(() => () => stopSpeech(), [stopSpeech]);

  /* ── load voices ── */
  useEffect(() => {
    if (synthRef.current) {
      synthRef.current.getVoices(); // trigger load
      synthRef.current.onvoiceschanged = () => synthRef.current!.getVoices();
    }
  }, []);

  /* ── progress bar click ── */
  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    const targetMs = pct * TOTAL_DURATION;
    let acc = 0;
    for (let i = 0; i < SCENES.length; i++) {
      if (acc + SCENES[i].duration >= targetMs) {
        goToScene(i, playing);
        setElapsed(targetMs - acc);
        return;
      }
      acc += SCENES[i].duration;
    }
  };

  /* ── scene visuals ── */
  const scenePct = Math.min(100, (elapsed / scene.duration) * 100);

  const renderSceneContent = () => {
    switch (scene.visualType) {
      case 'intro':
        return (
          <div className="flex flex-col items-center justify-center h-full text-center px-8 relative z-10">
            <div className="relative mb-6">
              <div className="w-24 h-24 rounded-2xl flex items-center justify-center backdrop-blur-sm"
                style={{ animation: 'pulse 2s ease-in-out infinite' }}>
                <BrandIcon size="xl" className="!w-24 !h-24 !rounded-2xl" />
              </div>
              <div className="absolute -inset-3 bg-blue-500/10 rounded-3xl animate-ping" style={{ animationDuration: '3s' }} />
            </div>
            <h1 className="text-4xl md:text-5xl text-white mb-4 tracking-tight" style={{ fontWeight: 700 }}>
              {scene.title}
            </h1>
            <p className="text-xl text-blue-300/80 max-w-xl">{scene.subtitle}</p>
            <div className="mt-10 flex items-center gap-3 text-slate-400 text-sm">
              <div className="w-8 h-[1px] bg-slate-600" />
              <span>8 Modules</span>
              <span className="text-slate-600">&bull;</span>
              <span>Real-Time Intelligence</span>
              <span className="text-slate-600">&bull;</span>
              <span>Unified Platform</span>
              <div className="w-8 h-[1px] bg-slate-600" />
            </div>
          </div>
        );

      case 'module':
        return (
          <div className="flex flex-col lg:flex-row items-center justify-center h-full gap-8 px-8 relative z-10">
            {/* Left – title, bullets */}
            <div className="flex-1 max-w-lg">
              <div className="flex items-center gap-3 mb-4">
                {scene.icon && (
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center border backdrop-blur-sm"
                    style={{ background: `${scene.accentColor}20`, borderColor: `${scene.accentColor}40` }}>
                    <scene.icon className="w-6 h-6" style={{ color: scene.accentColor }} />
                  </div>
                )}
                <div>
                  <h2 className="text-2xl md:text-3xl text-white" style={{ fontWeight: 700 }}>{scene.title}</h2>
                  <p className="text-sm" style={{ color: scene.accentColor }}>{scene.subtitle}</p>
                </div>
              </div>
              <ul className="space-y-3 mt-6">
                {scene.bulletPoints.map((bp, i) => (
                  <li key={i}
                    className="flex items-start gap-3 transition-all duration-700"
                    style={{
                      opacity: scenePct > (i + 1) * 15 ? 1 : 0,
                      transform: scenePct > (i + 1) * 15 ? 'translateX(0)' : 'translateX(-20px)',
                    }}>
                    <ChevronRight className="w-4 h-4 mt-0.5 shrink-0" style={{ color: scene.accentColor }} />
                    <span className="text-slate-300 text-sm">{bp}</span>
                  </li>
                ))}
              </ul>
            </div>
            {/* Right – stats cards */}
            {scene.statsCards && (
              <div className="grid grid-cols-2 gap-3 max-w-xs">
                {scene.statsCards.map((card, i) => (
                  <div key={i}
                    className="bg-slate-900/60 backdrop-blur-md border border-slate-700/50 rounded-xl p-4 text-center transition-all duration-500"
                    style={{
                      opacity: scenePct > (i + 1) * 12 ? 1 : 0,
                      transform: scenePct > (i + 1) * 12 ? 'scale(1)' : 'scale(0.85)',
                    }}>
                    <div className="text-2xl text-white" style={{ fontWeight: 700 }}>{card.value}</div>
                    <div className="text-xs text-slate-400 mt-1">{card.label}</div>
                    <div className="w-full h-1 mt-2 rounded-full bg-slate-800">
                      <div className="h-1 rounded-full transition-all duration-1000"
                        style={{
                          background: card.color,
                          width: scenePct > (i + 1) * 12 ? '100%' : '0%',
                        }} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      case 'benefits':
        return (
          <div className="flex flex-col items-center justify-center h-full text-center px-8 relative z-10">
            <h2 className="text-3xl md:text-4xl text-white mb-2" style={{ fontWeight: 700 }}>{scene.title}</h2>
            <p className="text-blue-300/80 mb-10">{scene.subtitle}</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl w-full">
              {scene.bulletPoints.map((bp, i) => {
                const colors = ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b'];
                const icons = ['&#x1F6E0;&#xFE0F;', '&#x1F4A7;', '&#x1F4F6;', '&#x1F916;'];
                return (
                  <div key={i}
                    className="bg-slate-900/60 backdrop-blur-md border border-slate-700/40 rounded-xl p-5 text-left flex items-start gap-4 transition-all duration-700"
                    style={{
                      opacity: scenePct > (i + 1) * 15 ? 1 : 0,
                      transform: scenePct > (i + 1) * 15 ? 'translateY(0)' : 'translateY(20px)',
                    }}>
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0 text-xl"
                      style={{ background: `${colors[i]}20`, border: `1px solid ${colors[i]}40` }}
                      dangerouslySetInnerHTML={{ __html: icons[i] }} />
                    <div>
                      <div className="text-white text-sm">{bp}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );

      case 'closing':
        return (
          <div className="flex flex-col items-center justify-center h-full text-center px-8 relative z-10">
            <div className="mb-6">
              <BrandIcon size="xl" className="!w-20 !h-20 !rounded-full" />
            </div>
            <h2 className="text-3xl md:text-4xl text-white mb-3" style={{ fontWeight: 700 }}>{scene.title}</h2>
            <p className="text-amber-300/70 text-lg mb-8">{scene.subtitle}</p>
            <div className="flex items-center gap-4"
              style={{ opacity: scenePct > 40 ? 1 : 0, transition: 'opacity 1s' }}>
              <button className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors" style={{ fontWeight: 600 }}>
                Schedule a Demo
              </button>
              {onClose && (
                <button onClick={onClose} className="px-8 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-lg border border-slate-700 transition-colors" style={{ fontWeight: 600 }}>
                  Explore the App
                </button>
              )}
            </div>
            <p className="text-slate-500 text-sm mt-8">SDS Smart Mining Command Center &bull; 2026</p>
          </div>
        );
    }
  };

  /* ── scene chapter markers ── */
  const chapterMarkers = SCENES.map((sc, i) => {
    const start = SCENES.slice(0, i).reduce((s, x) => s + x.duration, 0);
    return { ...sc, startPct: (start / TOTAL_DURATION) * 100, widthPct: (sc.duration / TOTAL_DURATION) * 100 };
  });

  return (
    <div ref={containerRef}
      className="relative w-full h-full bg-slate-950 flex flex-col select-none overflow-hidden"
      style={{ minHeight: fullscreen ? '100vh' : '100%' }}>

      {/* ── Background image with Ken Burns ── */}
      <div className="absolute inset-0 overflow-hidden">
        <div
          className={`absolute inset-0 transition-opacity duration-500 ${transitioning ? 'opacity-0' : 'opacity-100'}`}
          style={{
            backgroundImage: `url(${scene.bgImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            animation: playing ? 'kenburns 14s ease-in-out infinite alternate' : 'none',
          }} />
        {/* Gradient overlay */}
        <div className={`absolute inset-0 bg-gradient-to-br ${scene.bgOverlay} transition-all duration-500`} />
        {/* Noise texture */}
        <div className="absolute inset-0 opacity-[0.03]"
          style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 256 256\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23n)\'/%3E%3C/svg%3E")' }} />
      </div>

      {/* ── Close button (if in app) ── */}
      {onClose && !fullscreen && (
        <button onClick={onClose}
          className="absolute top-4 right-4 z-50 p-2 bg-slate-900/60 hover:bg-slate-800 backdrop-blur-sm rounded-lg border border-slate-700/50 text-slate-400 hover:text-white transition-colors">
          <X className="w-5 h-5" />
        </button>
      )}

      {/* ── Scene counter ── */}
      <div className="absolute top-4 left-4 z-50 flex items-center gap-3">
        <div className="bg-slate-900/60 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-slate-700/50 text-xs text-slate-400">
          {sceneIndex + 1} / {SCENES.length}
        </div>
        {playing && (
          <div className="bg-red-600/80 backdrop-blur-sm px-3 py-1.5 rounded-lg text-xs text-white flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
            PLAYING
          </div>
        )}
      </div>

      {/* ── Main Content ── */}
      <div className={`flex-1 relative z-10 transition-all duration-500 ${transitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
        {!started ? (
          /* Splash / start screen */
          <div className="flex flex-col items-center justify-center h-full text-center px-8">
            <div className="relative mb-8">
              <BrandIcon size="xl" className="!w-28 !h-28 !rounded-3xl" />
            </div>
            <h1 className="text-4xl md:text-5xl text-white mb-3 tracking-tight" style={{ fontWeight: 700 }}>SDS Command Center</h1>
            <p className="text-slate-400 text-lg mb-2">Interactive Feature Tour</p>
            <p className="text-slate-500 text-sm mb-10">~2.5 minute guided walkthrough with narration</p>
            <button onClick={togglePlay}
              className="group flex items-center gap-3 px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-all hover:scale-105"
              style={{ fontWeight: 600 }}>
              <Play className="w-5 h-5 group-hover:scale-110 transition-transform" />
              Start Tour
            </button>
            <p className="text-slate-600 text-xs mt-6">Best experienced with sound on &bull; Closed captions available</p>
          </div>
        ) : (
          renderSceneContent()
        )}
      </div>

      {/* ── Closed Captions ── */}
      {started && captionsOn && captionText && (
        <div className="absolute bottom-40 left-1/2 -translate-x-1/2 z-50 max-w-2xl w-[90%]">
          <div className="bg-black/75 backdrop-blur-sm rounded-lg px-6 py-3 text-center">
            <p className="text-white text-sm md:text-base leading-relaxed">
              {captionText}
            </p>
          </div>
        </div>
      )}

      {/* ── Controls Bar ── */}
      {started && (
        <div className="relative z-40 bg-gradient-to-t from-slate-950 via-slate-950/95 to-transparent pt-6 pb-4 px-4">
          {/* Progress bar with chapter markers */}
          <div className="relative mb-4 cursor-pointer group" onClick={handleProgressClick}>
            {/* Chapter segments */}
            <div className="flex h-1.5 rounded-full overflow-hidden bg-slate-800">
              {chapterMarkers.map((ch, i) => (
                <div key={ch.id}
                  className="relative h-full transition-colors"
                  style={{ width: `${ch.widthPct}%`, borderRight: i < SCENES.length - 1 ? '1px solid rgba(30,41,59,0.8)' : 'none' }}
                  title={ch.title}>
                  <div className="absolute inset-0 rounded-sm transition-all"
                    style={{
                      background: i < sceneIndex ? scene.accentColor : i === sceneIndex ? scene.accentColor : 'transparent',
                      width: i < sceneIndex ? '100%' : i === sceneIndex ? `${(elapsed / ch.duration) * 100}%` : '0%',
                      opacity: i < sceneIndex ? 0.5 : 1,
                    }} />
                </div>
              ))}
            </div>
            {/* Playhead */}
            <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-lg shadow-black/30 opacity-0 group-hover:opacity-100 transition-opacity"
              style={{ left: `${progressPct}%`, marginLeft: '-6px' }} />
            {/* Chapter labels on hover */}
            <div className="absolute -top-6 left-0 right-0 flex opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
              {chapterMarkers.map((ch) => (
                <div key={ch.id} className="text-center" style={{ width: `${ch.widthPct}%` }}>
                  <span className="text-[9px] text-slate-500 truncate block px-0.5">{ch.title.split(' ').slice(0, 2).join(' ')}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Controls row */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {/* Prev */}
              <button onClick={() => goToScene(sceneIndex - 1, playing)}
                disabled={sceneIndex === 0}
                className="p-2 text-slate-400 hover:text-white disabled:opacity-30 transition-colors rounded-lg hover:bg-slate-800">
                <SkipBack className="w-4 h-4" />
              </button>
              {/* Play/Pause */}
              <button onClick={togglePlay}
                className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors">
                {playing ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
              </button>
              {/* Next */}
              <button onClick={() => goToScene(sceneIndex + 1, playing)}
                disabled={sceneIndex >= SCENES.length - 1}
                className="p-2 text-slate-400 hover:text-white disabled:opacity-30 transition-colors rounded-lg hover:bg-slate-800">
                <SkipForward className="w-4 h-4" />
              </button>
              {/* Time */}
              <span className="text-xs text-slate-500 ml-2 tabular-nums">{fmt(globalElapsed)} / {fmt(TOTAL_DURATION)}</span>
            </div>

            <div className="flex items-center gap-1">
              {/* Mute */}
              <button onClick={() => setMuted(m => !m)}
                className="p-2 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-slate-800">
                {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
              {/* Captions */}
              <button onClick={() => setCaptionsOn(c => !c)}
                className={`p-2 transition-colors rounded-lg hover:bg-slate-800 ${captionsOn ? 'text-blue-400' : 'text-slate-400 hover:text-white'}`}>
                <Subtitles className="w-4 h-4" />
              </button>
              {/* Restart */}
              <button onClick={restart}
                className="p-2 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-slate-800">
                <RotateCcw className="w-4 h-4" />
              </button>
              {/* Fullscreen */}
              <button onClick={toggleFullscreen}
                className="p-2 text-slate-400 hover:text-white transition-colors rounded-lg hover:bg-slate-800">
                {fullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Scene chips (chapter nav) */}
          <div className="flex items-center gap-1.5 mt-3 overflow-x-auto pb-1 scrollbar-thin">
            {SCENES.map((sc, i) => (
              <button key={sc.id} onClick={() => goToScene(i, playing)}
                className={`shrink-0 px-3 py-1 rounded-full text-xs transition-all ${
                  i === sceneIndex
                    ? 'bg-white/15 text-white border border-white/20'
                    : i < sceneIndex
                    ? 'bg-slate-800/50 text-slate-500 border border-slate-700/30'
                    : 'bg-slate-900/50 text-slate-600 border border-slate-800/30 hover:text-slate-400'
                }`}>
                {sc.title.length > 16 ? sc.title.substring(0, 16) + '...' : sc.title}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ── Ken Burns keyframe ── */}
      <style>{`
        @keyframes kenburns {
          0% { transform: scale(1) translate(0, 0); }
          100% { transform: scale(1.08) translate(-1%, -1%); }
        }
      `}</style>
    </div>
  );
}