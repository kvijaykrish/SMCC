import { useState, useEffect, useRef } from 'react';
import { Droplet, Activity, TrendingDown, AlertTriangle, Gauge, Waves, Filter, Thermometer, Play, Pause } from 'lucide-react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const waterUsageData = [
  { hour: '00:00', usage: 1250, quality: 98, pressure: 45 },
  { hour: '04:00', usage: 980, quality: 97, pressure: 44 },
  { hour: '08:00', usage: 1820, quality: 96, pressure: 42 },
  { hour: '12:00', usage: 2100, quality: 97, pressure: 43 },
  { hour: '16:00', usage: 1950, quality: 98, pressure: 45 },
  { hour: '20:00', usage: 1450, quality: 97, pressure: 44 },
];

const pipelineData = [
  { id: 'P-01', name: 'Main Supply Line', status: 'optimal', flow: 1250, pressure: 45, temp: 18, location: 'Zone A' },
  { id: 'P-02', name: 'Processing Water Feed', status: 'optimal', flow: 890, pressure: 42, temp: 19, location: 'Zone B' },
  { id: 'P-03', name: 'Dust Suppression Line', status: 'optimal', flow: 650, pressure: 48, temp: 17, location: 'Zone C' },
  { id: 'P-04', name: 'Equipment Cooling', status: 'warning', flow: 420, pressure: 38, temp: 22, location: 'Workshop' },
  { id: 'P-05', name: 'Reclaim Water Line', status: 'optimal', flow: 780, pressure: 44, temp: 20, location: 'Treatment' },
  { id: 'P-06', name: 'Emergency Reserve', status: 'optimal', flow: 0, pressure: 50, temp: 16, location: 'Storage' },
];

const qualityMetrics = [
  { parameter: 'pH Level', value: 7.2, optimal: 7.0, unit: 'pH', status: 'good' },
  { parameter: 'Turbidity', value: 2.1, optimal: 2.0, unit: 'NTU', status: 'good' },
  { parameter: 'Dissolved O2', value: 8.5, optimal: 8.0, unit: 'mg/L', status: 'excellent' },
  { parameter: 'Temperature', value: 18, optimal: 18, unit: '°C', status: 'excellent' },
  { parameter: 'Conductivity', value: 420, optimal: 400, unit: 'μS/cm', status: 'good' },
  { parameter: 'Total Solids', value: 150, optimal: 200, unit: 'mg/L', status: 'excellent' },
];

const usageByZone = [
  { zone: 'Zone A - Mining', usage: 3200, percentage: 32 },
  { zone: 'Zone B - Processing', usage: 2800, percentage: 28 },
  { zone: 'Zone C - Dust Suppression', usage: 1900, percentage: 19 },
  { zone: 'Zone D - Equipment', usage: 1200, percentage: 12 },
  { zone: 'Facilities', usage: 900, percentage: 9 },
];

export function WaterManagement() {
  const [selectedPipeline, setSelectedPipeline] = useState<string | null>(null);
  const [flowAnimating, setFlowAnimating] = useState(true);

  return (
    <div className="p-6 space-y-6 bg-slate-950 min-h-full">
      {/* Header */}
      <div>
        <h1 className="text-2xl text-white">Water Management System</h1>
        <p className="text-slate-400 mt-1">Pipeline monitoring, quality control, and usage optimization</p>
      </div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard title="Daily Usage" value="10,000 m³" change="-12% vs yesterday" icon={Droplet} color="blue" />
        <MetricCard title="Water Quality" value="97.8%" change="+0.5% improvement" icon={Filter} color="green" />
        <MetricCard title="System Pressure" value="44 PSI" change="Normal range" icon={Gauge} color="purple" />
        <MetricCard title="Active Pipelines" value="5/6" change="1 maintenance mode" icon={Waves} color="amber" />
      </div>

      {/* ──────── ANIMATED WATER FLOW SYSTEM ──────── */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg text-white">Water Flow System Overview</h3>
            <p className="text-sm text-slate-400">Complete pipeline network with real-time flow animation</p>
          </div>
          <button onClick={() => setFlowAnimating(!flowAnimating)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-colors ${flowAnimating ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white border border-slate-700'}`}
          >
            {flowAnimating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {flowAnimating ? 'Pause Flow' : 'Start Flow'}
          </button>
        </div>

        <WaterFlowDiagram animating={flowAnimating} selectedPipeline={selectedPipeline} onSelectPipeline={setSelectedPipeline} />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg text-white mb-4">Water Usage & Quality (24h)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={waterUsageData}>
              <defs>
                <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="hour" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis yAxisId="left" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }} labelStyle={{ color: '#e2e8f0' }} />
              <Legend wrapperStyle={{ color: '#e2e8f0' }} />
              <Area yAxisId="left" type="monotone" dataKey="usage" stroke="#3b82f6" fillOpacity={1} fill="url(#colorUsage)" name="Usage (m³)" />
              <Line yAxisId="right" type="monotone" dataKey="quality" stroke="#10b981" strokeWidth={2} name="Quality %" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg text-white mb-4">Usage by Zone</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={usageByZone}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="zone" stroke="#94a3b8" style={{ fontSize: '11px' }} angle={-20} textAnchor="end" height={80} />
              <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }} labelStyle={{ color: '#e2e8f0' }} />
              <Bar dataKey="usage" fill="#10b981" name="Usage (m³)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Water Quality */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <h3 className="text-lg text-white mb-4">Water Quality Parameters</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {qualityMetrics.map(m => <QualityMetricCard key={m.parameter} metric={m} />)}
        </div>
      </div>

      {/* Pipeline Table */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg text-white">Pipeline Network Status</h3>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-green-500 rounded-full" /><span className="text-slate-300">Optimal: 5</span></div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-amber-500 rounded-full" /><span className="text-slate-300">Warning: 1</span></div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-800 border-b border-slate-700">
              <tr>
                {['Pipeline ID', 'Name', 'Location', 'Flow Rate', 'Pressure', 'Temp', 'Status'].map(h => (
                  <th key={h} className="px-6 py-4 text-left text-xs text-slate-300 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {pipelineData.map(p => (
                <tr key={p.id} onClick={() => setSelectedPipeline(p.id)} className="hover:bg-slate-800/50 transition-colors cursor-pointer">
                  <td className="px-6 py-4 text-sm font-mono text-blue-400">{p.id}</td>
                  <td className="px-6 py-4 text-sm text-white">{p.name}</td>
                  <td className="px-6 py-4 text-sm text-slate-300">{p.location}</td>
                  <td className="px-6 py-4"><div className="flex items-center gap-2"><Activity className="w-4 h-4 text-blue-400" /><span className="text-sm text-white">{p.flow} L/min</span></div></td>
                  <td className="px-6 py-4"><div className="flex items-center gap-2"><Gauge className="w-4 h-4 text-purple-400" /><span className="text-sm text-white">{p.pressure} PSI</span></div></td>
                  <td className="px-6 py-4"><div className="flex items-center gap-2"><Thermometer className="w-4 h-4 text-cyan-400" /><span className="text-sm text-white">{p.temp}°C</span></div></td>
                  <td className="px-6 py-4"><StatusBadge status={p.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Conservation Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-6 text-white">
          <TrendingDown className="w-10 h-10 mb-3" /><div className="text-lg mb-2">Water Savings</div><div className="text-3xl mb-2">12%</div><div className="text-sm opacity-90">Compared to last month</div>
        </div>
        <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-xl p-6 text-white">
          <Droplet className="w-10 h-10 mb-3" /><div className="text-lg mb-2">Reclaimed Water</div><div className="text-3xl mb-2">45%</div><div className="text-sm opacity-90">Of total water recycled</div>
        </div>
        <div className="bg-gradient-to-br from-purple-600 to-purple-700 rounded-xl p-6 text-white">
          <Filter className="w-10 h-10 mb-3" /><div className="text-lg mb-2">Treatment Efficiency</div><div className="text-3xl mb-2">98.5%</div><div className="text-sm opacity-90">Quality meets standards</div>
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────── */
/*  ANIMATED WATER FLOW DIAGRAM                                */
/* ──────────────────────────────────────────────────────────── */

interface FlowDiagramProps {
  animating: boolean;
  selectedPipeline: string | null;
  onSelectPipeline: (id: string) => void;
}

// Node positions for the flow diagram
const NODES = {
  reservoir:    { x: 60,  y: 85,  label: 'Water Reservoir',     sub: '85% Full',       icon: '💧', color: '#3b82f6' },
  pumpStation1: { x: 195, y: 85,  label: 'Pump Station #1',     sub: '1,250 L/min',    icon: '⚡', color: '#8b5cf6' },
  treatment:    { x: 345, y: 85,  label: 'Treatment Plant',     sub: '98.5% Efficiency',icon: '🧪', color: '#10b981' },
  mainDist:     { x: 500, y: 85,  label: 'Main Distribution',   sub: 'Hub',            icon: '🔀', color: '#06b6d4' },
  zoneA:        { x: 640, y: 35,  label: 'Zone A - Mining',     sub: '3,200 m³/day',   icon: '⛏️', color: '#f59e0b' },
  zoneB:        { x: 640, y: 85,  label: 'Zone B - Processing', sub: '2,800 m³/day',   icon: '🏭', color: '#ef4444' },
  zoneC:        { x: 640, y: 135, label: 'Zone C - Dust Supp.', sub: '1,900 m³/day',   icon: '💨', color: '#f97316' },
  dustSupp:     { x: 780, y: 135, label: 'Dust Suppression',    sub: '650 L/min',      icon: '🚿', color: '#06b6d4' },
  cooling:      { x: 780, y: 85,  label: 'Equipment Cooling',   sub: '420 L/min',      icon: '❄️', color: '#a855f7' },
  tailings:     { x: 780, y: 35,  label: 'Tailings Dam',        sub: '72% Capacity',   icon: '🏗️', color: '#64748b' },
  reclaim:      { x: 640, y: 195, label: 'Reclaim Facility',    sub: '780 L/min',      icon: '♻️', color: '#22c55e' },
  pumpStation2: { x: 345, y: 195, label: 'Pump Station #2',     sub: 'Recirculation',  icon: '⚡', color: '#8b5cf6' },
  storage:      { x: 195, y: 195, label: 'Emergency Storage',   sub: '50 PSI Ready',   icon: '🛢️', color: '#64748b' },
};

// Pipe connections
const PIPES: { from: keyof typeof NODES; to: keyof typeof NODES; flow: number; pipeId: string; status: string }[] = [
  { from: 'reservoir', to: 'pumpStation1', flow: 1250, pipeId: 'P-01', status: 'optimal' },
  { from: 'pumpStation1', to: 'treatment', flow: 1250, pipeId: 'P-01', status: 'optimal' },
  { from: 'treatment', to: 'mainDist', flow: 1100, pipeId: 'P-02', status: 'optimal' },
  { from: 'mainDist', to: 'zoneA', flow: 450, pipeId: 'P-02', status: 'optimal' },
  { from: 'mainDist', to: 'zoneB', flow: 390, pipeId: 'P-02', status: 'optimal' },
  { from: 'mainDist', to: 'zoneC', flow: 260, pipeId: 'P-03', status: 'optimal' },
  { from: 'zoneA', to: 'tailings', flow: 200, pipeId: 'P-05', status: 'optimal' },
  { from: 'zoneB', to: 'cooling', flow: 420, pipeId: 'P-04', status: 'warning' },
  { from: 'zoneC', to: 'dustSupp', flow: 650, pipeId: 'P-03', status: 'optimal' },
  { from: 'tailings', to: 'reclaim', flow: 300, pipeId: 'P-05', status: 'optimal' },
  { from: 'cooling', to: 'reclaim', flow: 350, pipeId: 'P-05', status: 'optimal' },
  { from: 'dustSupp', to: 'reclaim', flow: 130, pipeId: 'P-05', status: 'optimal' },
  { from: 'reclaim', to: 'pumpStation2', flow: 780, pipeId: 'P-05', status: 'optimal' },
  { from: 'pumpStation2', to: 'storage', flow: 200, pipeId: 'P-06', status: 'optimal' },
  { from: 'pumpStation2', to: 'treatment', flow: 580, pipeId: 'P-05', status: 'optimal' },
];

function WaterFlowDiagram({ animating, selectedPipeline, onSelectPipeline }: FlowDiagramProps) {
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (!animating) return;
    const id = setInterval(() => setTick(t => t + 1), 60);
    return () => clearInterval(id);
  }, [animating]);

  return (
    <div className="relative w-full overflow-x-auto">
      <svg viewBox="0 0 900 240" className="w-full min-w-[700px]" style={{ minHeight: 320 }}>
        <defs>
          {/* Water flow gradient */}
          <linearGradient id="waterGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.6} />
            <stop offset="50%" stopColor="#06b6d4" stopOpacity={0.9} />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.6} />
          </linearGradient>
          <linearGradient id="reclaimGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#22c55e" stopOpacity={0.6} />
            <stop offset="50%" stopColor="#10b981" stopOpacity={0.9} />
            <stop offset="100%" stopColor="#22c55e" stopOpacity={0.6} />
          </linearGradient>
          <filter id="flowGlow">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feFlood floodColor="#3b82f6" floodOpacity="0.4" result="color" />
            <feComposite in="color" in2="blur" operator="in" />
            <feMerge><feMergeNode /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="reclaimGlow">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feFlood floodColor="#22c55e" floodOpacity="0.4" result="color" />
            <feComposite in="color" in2="blur" operator="in" />
            <feMerge><feMergeNode /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="nodeGlow">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* Background grid */}
        <pattern id="wfGrid" width="30" height="30" patternUnits="userSpaceOnUse">
          <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(51,65,85,0.15)" strokeWidth="0.5" />
        </pattern>
        <rect width="900" height="240" fill="url(#wfGrid)" rx="8" />

        {/* ── PIPES ── */}
        {PIPES.map((pipe, idx) => {
          const from = NODES[pipe.from];
          const to = NODES[pipe.to];
          const isReclaim = pipe.from === 'reclaim' || pipe.from === 'pumpStation2' || pipe.from === 'tailings' || pipe.from === 'cooling' || pipe.from === 'dustSupp';
          const isSelected = pipe.pipeId === selectedPipeline;
          const isWarning = pipe.status === 'warning';

          // Calculate path (with elbows for vertical transitions)
          let pathD: string;
          if (Math.abs(from.y - to.y) < 5) {
            pathD = `M ${from.x} ${from.y} L ${to.x} ${to.y}`;
          } else {
            const midX = (from.x + to.x) / 2;
            pathD = `M ${from.x} ${from.y} L ${midX} ${from.y} L ${midX} ${to.y} L ${to.x} ${to.y}`;
          }

          const pipeColor = isWarning ? '#f59e0b' : isReclaim ? '#22c55e' : '#3b82f6';

          return (
            <g key={idx} onClick={() => onSelectPipeline(pipe.pipeId)} className="cursor-pointer">
              {/* Pipe background */}
              <path d={pathD} fill="none" stroke="rgba(51,65,85,0.4)" strokeWidth={isSelected ? 8 : 5} strokeLinecap="round" strokeLinejoin="round" />
              {/* Pipe main */}
              <path d={pathD} fill="none" stroke={pipeColor} strokeWidth={isSelected ? 4 : 2.5} strokeLinecap="round" strokeLinejoin="round"
                opacity={isSelected ? 1 : 0.7}
                filter={isSelected ? (isReclaim ? 'url(#reclaimGlow)' : 'url(#flowGlow)') : ''}
              />
              {/* Animated flow particles */}
              {animating && pipe.flow > 0 && (
                <FlowParticles pathD={pathD} tick={tick} color={pipeColor} speed={pipe.flow / 400} isReclaim={isReclaim} pipeIdx={idx} />
              )}
              {/* Flow rate label */}
              {isSelected && (
                <g>
                  <rect x={(from.x + to.x) / 2 - 28} y={(from.y + to.y) / 2 - 10} width="56" height="18" rx="4" fill="rgba(0,0,0,0.8)" stroke={pipeColor} strokeWidth={0.8} />
                  <text x={(from.x + to.x) / 2} y={(from.y + to.y) / 2 + 3} fontSize="8" fill="#e2e8f0" textAnchor="middle" style={{ fontFamily: 'monospace' }}>{pipe.flow} L/min</text>
                </g>
              )}
            </g>
          );
        })}

        {/* ── NODES ── */}
        {Object.entries(NODES).map(([key, node]) => (
          <g key={key}>
            {/* Node glow */}
            <circle cx={node.x} cy={node.y} r={24} fill={node.color} opacity={0.08} filter="url(#nodeGlow)" />
            {/* Node background */}
            <rect x={node.x - 22} y={node.y - 22} width={44} height={44} rx={10}
              fill="rgba(15,23,42,0.9)" stroke={node.color} strokeWidth={1.5}
              className="cursor-pointer" />
            {/* Icon */}
            <text x={node.x} y={node.y + 5} fontSize="16" textAnchor="middle" dominantBaseline="middle">{node.icon}</text>
            {/* Pulse ring for active nodes */}
            {animating && key !== 'storage' && (
              <circle cx={node.x} cy={node.y} r={22} fill="none" stroke={node.color} strokeWidth={0.8} opacity={0.4}>
                <animate attributeName="r" values="22;30;22" dur="3s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.4;0;0.4" dur="3s" repeatCount="indefinite" />
              </circle>
            )}
            {/* Label */}
            <text x={node.x} y={node.y + 32} fontSize="7" fill="#e2e8f0" textAnchor="middle" style={{ fontFamily: 'system-ui' }}>{node.label}</text>
            <text x={node.x} y={node.y + 42} fontSize="6" fill="#64748b" textAnchor="middle" style={{ fontFamily: 'monospace' }}>{node.sub}</text>
          </g>
        ))}

        {/* ── FLOW DIRECTION ARROWS ── */}
        {/* Main flow direction label */}
        <g>
          <rect x="350" y="55" width="110" height="16" rx="4" fill="rgba(59,130,246,0.15)" stroke="rgba(59,130,246,0.3)" strokeWidth={0.5} />
          <text x="405" y="66" fontSize="7" fill="#60a5fa" textAnchor="middle" style={{ fontFamily: 'system-ui' }}>→ Fresh Water Flow →</text>
        </g>
        <g>
          <rect x="380" y="210" width="130" height="16" rx="4" fill="rgba(34,197,94,0.15)" stroke="rgba(34,197,94,0.3)" strokeWidth={0.5} />
          <text x="445" y="221" fontSize="7" fill="#4ade80" textAnchor="middle" style={{ fontFamily: 'system-ui' }}>← Reclaim / Recycling ←</text>
        </g>
      </svg>
    </div>
  );
}

/* Animated flow particles along a pipe path */
function FlowParticles({ pathD, tick, color, speed, isReclaim, pipeIdx }: { pathD: string; tick: number; color: string; speed: number; isReclaim: boolean; pipeIdx: number }) {
  const pathRef = useRef<SVGPathElement>(null);
  const [particles, setParticles] = useState<{ x: number; y: number; opacity: number }[]>([]);

  useEffect(() => {
    if (!pathRef.current) return;
    const totalLen = pathRef.current.getTotalLength();
    const numParticles = Math.max(3, Math.floor(totalLen / 25));
    const pts: typeof particles = [];

    for (let i = 0; i < numParticles; i++) {
      const offset = ((tick * speed * 2 + i * (totalLen / numParticles)) % totalLen);
      const pt = pathRef.current.getPointAtLength(offset);
      pts.push({ x: pt.x, y: pt.y, opacity: 0.5 + Math.sin((tick * 0.1 + i) % (Math.PI * 2)) * 0.3 });
    }
    setParticles(pts);
  }, [tick, speed, pathD]);

  return (
    <g>
      <path ref={pathRef} d={pathD} fill="none" stroke="none" />
      {particles.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={2.5} fill={color} opacity={p.opacity}
          filter={isReclaim ? 'url(#reclaimGlow)' : 'url(#flowGlow)'} />
      ))}
    </g>
  );
}

/* ──────────────────────────────────────────────────────────── */

function MetricCard({ title, value, change, icon: Icon, color }: any) {
  const colorClasses: Record<string, string> = {
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    green: 'bg-green-500/10 text-green-400 border-green-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  };
  return (
    <div className={`bg-slate-900 rounded-xl border ${colorClasses[color]} p-6`}>
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm text-slate-400">{title}</p>
          <p className="text-2xl text-white mt-1">{value}</p>
          <p className="text-xs text-slate-400 mt-1">{change}</p>
        </div>
        <Icon className="w-8 h-8" />
      </div>
    </div>
  );
}

function QualityMetricCard({ metric }: any) {
  const statusColors: Record<string, string> = {
    excellent: 'from-green-600 to-green-700',
    good: 'from-blue-600 to-blue-700',
    warning: 'from-amber-600 to-amber-700',
  };
  const percentage = Math.min(100, (metric.value / (metric.optimal * 1.5)) * 100);
  return (
    <div className={`bg-gradient-to-br ${statusColors[metric.status]} rounded-lg p-4 text-white`}>
      <div className="text-sm opacity-90 mb-2">{metric.parameter}</div>
      <div className="flex items-end justify-between mb-3">
        <div>
          <div className="text-2xl">{metric.value}</div>
          <div className="text-xs opacity-75">{metric.unit}</div>
        </div>
        <div className="text-xs opacity-75">Target: {metric.optimal}</div>
      </div>
      <div className="h-2 bg-white/20 rounded-full overflow-hidden">
        <div className="h-full bg-white rounded-full" style={{ width: `${percentage}%` }} />
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusConfig: Record<string, { label: string; className: string }> = {
    optimal: { label: 'Optimal', className: 'bg-green-500/10 text-green-400 border-green-500/20' },
    warning: { label: 'Warning', className: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
    critical: { label: 'Critical', className: 'bg-red-500/10 text-red-400 border-red-500/20' },
  };
  const config = statusConfig[status] || statusConfig.optimal;
  return <span className={`inline-flex px-2 py-1 text-xs rounded-full border ${config.className}`}>{config.label}</span>;
}
