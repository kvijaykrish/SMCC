import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import {
  Mic, MicOff, Send, Bot, User, Sparkles, Search, FileText, Download,
  FileSpreadsheet, Printer, Loader2, X, Clock, AlertTriangle, Truck,
  Wrench, Droplet, Shield, Zap, HardHat, ChevronDown, ChevronUp,
  Volume2, VolumeX, RotateCcw, Star, CheckCircle2, XCircle, Info,
  MessageSquare, TrendingUp, BarChart3, Activity
} from 'lucide-react';
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import { format, subDays, subMonths, subWeeks, isWithinInterval, parseISO } from 'date-fns';

// ── Types ──────────────────────────────────────────────────────────────────

interface MiningEvent {
  id: string;
  date: string;
  category: 'equipment' | 'safety' | 'water' | 'security' | 'energy' | 'production';
  type: string;
  equipment?: string;
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  location: string;
  description: string;
  duration?: string;
  cost?: number;
  status: 'resolved' | 'open' | 'in-progress';
  assignee?: string;
}

interface ParsedQuery {
  categories: string[];
  equipmentTypes: string[];
  eventTypes: string[];
  severities: string[];
  timeRange: { start: Date; end: Date } | null;
  timeLabel: string;
  statuses: string[];
  locations: string[];
  keywords: string[];
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: Date;
  results?: MiningEvent[];
  parsedQuery?: ParsedQuery;
  chartData?: any[];
  summaryStats?: Record<string, any>;
}

// ── Mock Event Database ────────────────────────────────────────────────────

function generateMockEvents(): MiningEvent[] {
  const events: MiningEvent[] = [];
  const now = new Date();

  const equipmentList = [
    'Excavator EX-101', 'Excavator EX-102', 'Excavator EX-103', 'Excavator EX-104',
    'Haul Truck HT-201', 'Haul Truck HT-202', 'Haul Truck HT-203', 'Haul Truck HT-204', 'Haul Truck HT-205',
    'Drill DR-301', 'Drill DR-302', 'Drill DR-303',
    'Dozer DZ-401', 'Dozer DZ-402',
    'Loader LD-501', 'Loader LD-502', 'Loader LD-503',
    'Crusher CR-601', 'Crusher CR-602',
    'Conveyor CV-701', 'Conveyor CV-702', 'Conveyor CV-703',
    'Pump Station PS-801', 'Pump Station PS-802',
    'Generator GN-901', 'Generator GN-902',
  ];

  const locations = ['Pit A - North', 'Pit A - South', 'Pit B - East', 'Pit B - West', 'Processing Plant', 'Crusher Station', 'Tailings Dam', 'Main Haul Road', 'Workshop', 'Stockpile Area', 'Water Treatment', 'Power Substation'];
  const assignees = ['Mike Torres', 'Sarah Chen', 'Raj Patel', 'Lisa Wong', 'Carlos Mendez', 'Anna Kowalski', 'James McBride', 'David Okafor'];
  const severities: MiningEvent['severity'][] = ['critical', 'high', 'medium', 'low', 'info'];
  const statuses: MiningEvent['status'][] = ['resolved', 'open', 'in-progress'];

  // Equipment events
  const equipFailures = [
    { type: 'Breakdown', descs: ['Engine failure - overheating detected', 'Hydraulic system malfunction', 'Transmission failure', 'Electrical system fault', 'Structural crack detected', 'Bearing failure in main drive', 'Brake system failure', 'Track/tire damage'] },
    { type: 'Unscheduled Maintenance', descs: ['Emergency repair - oil leak', 'Coolant system flush required', 'Filter replacement overdue', 'Belt replacement needed', 'Sensor calibration drift'] },
    { type: 'Scheduled Maintenance', descs: ['500-hour service completed', '1000-hour overhaul', 'Annual inspection', 'Preventive maintenance cycle'] },
    { type: 'Performance Degradation', descs: ['Output below threshold - 72% efficiency', 'Fuel consumption 18% above normal', 'Cycle time increased by 25%', 'Payload variance exceeding limits'] },
    { type: 'Component Replacement', descs: ['Bucket teeth replacement', 'Ground engaging tools swap', 'Filter bank replacement', 'Hydraulic hose replacement'] },
  ];

  for (let d = 0; d < 365; d++) {
    const date = subDays(now, d);
    const numEvents = Math.floor(Math.random() * 4) + 1;
    for (let e = 0; e < numEvents; e++) {
      const failType = equipFailures[Math.floor(Math.random() * equipFailures.length)];
      const desc = failType.descs[Math.floor(Math.random() * failType.descs.length)];
      const equip = equipmentList[Math.floor(Math.random() * equipmentList.length)];
      events.push({
        id: `EQ-${d}-${e}`,
        date: format(date, 'yyyy-MM-dd'),
        category: 'equipment',
        type: failType.type,
        equipment: equip,
        severity: failType.type === 'Breakdown' ? (Math.random() > 0.5 ? 'critical' : 'high') : failType.type === 'Scheduled Maintenance' ? 'info' : severities[Math.floor(Math.random() * severities.length)],
        location: locations[Math.floor(Math.random() * locations.length)],
        description: `${equip}: ${desc}`,
        duration: `${Math.floor(Math.random() * 48) + 1}h`,
        cost: Math.round(Math.random() * 50000 + 500),
        status: statuses[Math.floor(Math.random() * statuses.length)],
        assignee: assignees[Math.floor(Math.random() * assignees.length)],
      });
    }
  }

  // Safety events
  const safetyTypes = [
    { type: 'Near Miss', descs: ['Worker near moving equipment', 'Falling rock near personnel', 'Vehicle proximity alert triggered', 'Unsecured load detected'] },
    { type: 'Incident', descs: ['Minor injury - hand laceration', 'Slip and fall on wet surface', 'Heat exhaustion case', 'Dust exposure above limits'] },
    { type: 'Violation', descs: ['PPE non-compliance observed', 'Speed limit exceeded in pit area', 'Unauthorized zone entry', 'Missing safety barrier'] },
    { type: 'Inspection', descs: ['Daily safety walkthrough completed', 'Weekly equipment inspection', 'Monthly site audit', 'Emergency drill conducted'] },
    { type: 'Training', descs: ['New operator certification completed', 'Refresher safety training', 'First aid course completed', 'Hazard awareness workshop'] },
  ];

  for (let d = 0; d < 365; d++) {
    const date = subDays(now, d);
    if (Math.random() > 0.3) {
      const st = safetyTypes[Math.floor(Math.random() * safetyTypes.length)];
      events.push({
        id: `SF-${d}`,
        date: format(date, 'yyyy-MM-dd'),
        category: 'safety',
        type: st.type,
        severity: st.type === 'Incident' ? 'high' : st.type === 'Violation' ? 'medium' : st.type === 'Near Miss' ? 'medium' : 'low',
        location: locations[Math.floor(Math.random() * locations.length)],
        description: st.descs[Math.floor(Math.random() * st.descs.length)],
        status: statuses[Math.floor(Math.random() * statuses.length)],
        assignee: assignees[Math.floor(Math.random() * assignees.length)],
      });
    }
  }

  // Water events
  const waterTypes = [
    { type: 'Quality Alert', descs: ['pH level outside range (5.2)', 'Turbidity exceeded threshold', 'Heavy metal concentration alert', 'TSS levels elevated'] },
    { type: 'Flow Anomaly', descs: ['Discharge rate 30% above normal', 'Pump flow rate drop detected', 'Pipeline pressure irregularity', 'Sump overflow warning'] },
    { type: 'Leak Detected', descs: ['Pipeline leak at junction B-4', 'Tailings seepage detected', 'Storage tank minor leak', 'Valve seal degradation'] },
    { type: 'Treatment', descs: ['Chemical dosing adjusted', 'Filter backwash completed', 'Settling pond level critical', 'Treatment plant maintenance'] },
  ];

  for (let d = 0; d < 365; d++) {
    const date = subDays(now, d);
    if (Math.random() > 0.5) {
      const wt = waterTypes[Math.floor(Math.random() * waterTypes.length)];
      events.push({
        id: `WA-${d}`,
        date: format(date, 'yyyy-MM-dd'),
        category: 'water',
        type: wt.type,
        severity: wt.type === 'Leak Detected' ? 'high' : wt.type === 'Quality Alert' ? 'medium' : 'low',
        location: ['Water Treatment', 'Tailings Dam', 'Pump Station PS-801', 'Pump Station PS-802', 'Settling Pond'][Math.floor(Math.random() * 5)],
        description: wt.descs[Math.floor(Math.random() * wt.descs.length)],
        status: statuses[Math.floor(Math.random() * statuses.length)],
        assignee: assignees[Math.floor(Math.random() * assignees.length)],
      });
    }
  }

  // Security events
  const securityTypes = [
    { type: 'Access Breach', descs: ['Unauthorized badge scan at Gate 3', 'Tailgating detected at main entrance', 'After-hours access attempt'] },
    { type: 'Perimeter Alert', descs: ['Fence sensor triggered - Sector 7', 'CCTV motion detection - restricted zone', 'Drone detected in airspace'] },
    { type: 'Camera Outage', descs: ['Camera CAM-12 offline', 'Night vision failure on CAM-08', 'PTZ malfunction on CAM-15'] },
  ];

  for (let d = 0; d < 365; d++) {
    const date = subDays(now, d);
    if (Math.random() > 0.6) {
      const sc = securityTypes[Math.floor(Math.random() * securityTypes.length)];
      events.push({
        id: `SC-${d}`,
        date: format(date, 'yyyy-MM-dd'),
        category: 'security',
        type: sc.type,
        severity: sc.type === 'Access Breach' ? 'high' : 'medium',
        location: locations[Math.floor(Math.random() * locations.length)],
        description: sc.descs[Math.floor(Math.random() * sc.descs.length)],
        status: statuses[Math.floor(Math.random() * statuses.length)],
      });
    }
  }

  // Energy events
  const energyTypes = [
    { type: 'Power Outage', descs: ['Grid power loss - 45 minutes', 'Transformer trip at Substation 2', 'Generator auto-start on backup'] },
    { type: 'Consumption Spike', descs: ['Processing plant 22% above baseline', 'Peak demand exceeded contract limit', 'Crusher circuit overload'] },
    { type: 'Solar Performance', descs: ['Solar array output 15% below expected', 'Inverter fault on Panel Bank 3', 'Panel cleaning required - dust buildup'] },
  ];

  for (let d = 0; d < 365; d++) {
    const date = subDays(now, d);
    if (Math.random() > 0.7) {
      const en = energyTypes[Math.floor(Math.random() * energyTypes.length)];
      events.push({
        id: `EN-${d}`,
        date: format(date, 'yyyy-MM-dd'),
        category: 'energy',
        type: en.type,
        severity: en.type === 'Power Outage' ? 'critical' : 'medium',
        location: ['Power Substation', 'Processing Plant', 'Solar Farm', 'Generator GN-901'][Math.floor(Math.random() * 4)],
        description: en.descs[Math.floor(Math.random() * en.descs.length)],
        status: statuses[Math.floor(Math.random() * statuses.length)],
      });
    }
  }

  // Production events
  const prodTypes = [
    { type: 'Target Miss', descs: ['Daily tonnage 12% below target', 'Shift output fell short by 200 tons', 'Grade variance exceeding tolerance'] },
    { type: 'Record Output', descs: ['New daily record: 3,200 tons processed', 'Shift record broken - 890 tons/shift', 'Weekly throughput milestone achieved'] },
    { type: 'Quality Issue', descs: ['Ore grade below cut-off in Block 4', 'Contamination detected in batch #2847', 'Moisture content too high for processing'] },
    { type: 'Blast Event', descs: ['Blast completed - 15,000 tonnes moved', 'Blast delay - weather conditions', 'Blast vibration above limit at monitoring point'] },
  ];

  for (let d = 0; d < 365; d++) {
    const date = subDays(now, d);
    if (Math.random() > 0.4) {
      const pr = prodTypes[Math.floor(Math.random() * prodTypes.length)];
      events.push({
        id: `PR-${d}`,
        date: format(date, 'yyyy-MM-dd'),
        category: 'production',
        type: pr.type,
        severity: pr.type === 'Target Miss' ? 'medium' : pr.type === 'Quality Issue' ? 'high' : 'info',
        location: locations[Math.floor(Math.random() * locations.length)],
        description: pr.descs[Math.floor(Math.random() * pr.descs.length)],
        status: statuses[Math.floor(Math.random() * statuses.length)],
      });
    }
  }

  return events;
}

// ── NLP Query Parser ───────────────────────────────────────────────────────

function parseNaturalLanguage(query: string): ParsedQuery {
  const q = query.toLowerCase();
  const result: ParsedQuery = {
    categories: [],
    equipmentTypes: [],
    eventTypes: [],
    severities: [],
    timeRange: null,
    timeLabel: '',
    statuses: [],
    locations: [],
    keywords: [],
  };

  // Time range
  const now = new Date();
  if (/past\s*(3|three)\s*months|last\s*(3|three)\s*months|3\s*months?\s*ago/i.test(q)) {
    result.timeRange = { start: subMonths(now, 3), end: now }; result.timeLabel = 'Past 3 Months';
  } else if (/past\s*(6|six)\s*months|last\s*(6|six)\s*months/i.test(q)) {
    result.timeRange = { start: subMonths(now, 6), end: now }; result.timeLabel = 'Past 6 Months';
  } else if (/past\s*(year|12\s*months)|last\s*(year|12\s*months)/i.test(q)) {
    result.timeRange = { start: subMonths(now, 12), end: now }; result.timeLabel = 'Past Year';
  } else if (/past\s*(month|1\s*month)|last\s*(month|30\s*days)/i.test(q)) {
    result.timeRange = { start: subMonths(now, 1), end: now }; result.timeLabel = 'Past Month';
  } else if (/past\s*(2|two)\s*months|last\s*(2|two)\s*months/i.test(q)) {
    result.timeRange = { start: subMonths(now, 2), end: now }; result.timeLabel = 'Past 2 Months';
  } else if (/past\s*(week|7\s*days)|last\s*(week|7\s*days)/i.test(q)) {
    result.timeRange = { start: subWeeks(now, 1), end: now }; result.timeLabel = 'Past Week';
  } else if (/past\s*(2|two)\s*weeks|last\s*(2|two)\s*weeks|14\s*days/i.test(q)) {
    result.timeRange = { start: subWeeks(now, 2), end: now }; result.timeLabel = 'Past 2 Weeks';
  } else if (/today/i.test(q)) {
    result.timeRange = { start: subDays(now, 0), end: now }; result.timeLabel = 'Today';
  } else if (/yesterday/i.test(q)) {
    result.timeRange = { start: subDays(now, 1), end: subDays(now, 0) }; result.timeLabel = 'Yesterday';
  } else {
    // Default to past 3 months if no time specified
    result.timeRange = { start: subMonths(now, 3), end: now }; result.timeLabel = 'Past 3 Months (default)';
  }

  // Equipment types
  if (/excavator/i.test(q)) result.equipmentTypes.push('Excavator');
  if (/haul\s*truck|truck/i.test(q)) result.equipmentTypes.push('Haul Truck');
  if (/drill/i.test(q)) result.equipmentTypes.push('Drill');
  if (/dozer|bulldozer/i.test(q)) result.equipmentTypes.push('Dozer');
  if (/loader/i.test(q)) result.equipmentTypes.push('Loader');
  if (/crusher/i.test(q)) result.equipmentTypes.push('Crusher');
  if (/conveyor/i.test(q)) result.equipmentTypes.push('Conveyor');
  if (/pump/i.test(q)) result.equipmentTypes.push('Pump Station');
  if (/generator/i.test(q)) result.equipmentTypes.push('Generator');

  // Event types
  if (/breakdown|failure|broke|broken|malfunction/i.test(q)) result.eventTypes.push('Breakdown');
  if (/maintenance|repair|service/i.test(q)) { result.eventTypes.push('Unscheduled Maintenance'); result.eventTypes.push('Scheduled Maintenance'); }
  if (/degradation|performance|slow|efficiency/i.test(q)) result.eventTypes.push('Performance Degradation');
  if (/incident|injury|accident/i.test(q)) result.eventTypes.push('Incident');
  if (/near\s*miss/i.test(q)) result.eventTypes.push('Near Miss');
  if (/violation|non.?compliance/i.test(q)) result.eventTypes.push('Violation');
  if (/inspection|audit/i.test(q)) result.eventTypes.push('Inspection');
  if (/leak/i.test(q)) result.eventTypes.push('Leak Detected');
  if (/quality|contamination|grade/i.test(q)) { result.eventTypes.push('Quality Alert'); result.eventTypes.push('Quality Issue'); }
  if (/outage|power\s*(loss|cut|failure)/i.test(q)) result.eventTypes.push('Power Outage');
  if (/breach|unauthorized/i.test(q)) result.eventTypes.push('Access Breach');
  if (/blast/i.test(q)) result.eventTypes.push('Blast Event');
  if (/target\s*miss|shortfall|below\s*target/i.test(q)) result.eventTypes.push('Target Miss');
  if (/record|milestone/i.test(q)) result.eventTypes.push('Record Output');
  if (/spike|overload|over.?consumption/i.test(q)) result.eventTypes.push('Consumption Spike');
  if (/training|certification/i.test(q)) result.eventTypes.push('Training');
  if (/camera|cctv/i.test(q)) result.eventTypes.push('Camera Outage');
  if (/perimeter|fence|drone/i.test(q)) result.eventTypes.push('Perimeter Alert');
  if (/flow|discharge|overflow/i.test(q)) result.eventTypes.push('Flow Anomaly');
  if (/solar|panel/i.test(q)) result.eventTypes.push('Solar Performance');

  // Categories
  if (/equipment|fleet|machine|vehicle/i.test(q) || result.equipmentTypes.length > 0) result.categories.push('equipment');
  if (/safety|incident|near\s*miss|violation|ppe|training/i.test(q)) result.categories.push('safety');
  if (/water|leak|ph|treatment|dam|pump/i.test(q)) result.categories.push('water');
  if (/security|breach|camera|perimeter|access/i.test(q)) result.categories.push('security');
  if (/energy|power|solar|generator|electricity/i.test(q)) result.categories.push('energy');
  if (/production|output|tonnage|blast|ore|grade/i.test(q)) result.categories.push('production');

  // Severity
  if (/critical|emergency|urgent/i.test(q)) result.severities.push('critical');
  if (/high\s*severity|major|serious/i.test(q)) result.severities.push('high');
  if (/medium|moderate/i.test(q)) result.severities.push('medium');
  if (/low|minor/i.test(q)) result.severities.push('low');

  // Status
  if (/open|unresolved|pending/i.test(q)) result.statuses.push('open');
  if (/resolved|closed|fixed|completed/i.test(q)) result.statuses.push('resolved');
  if (/in.?progress|ongoing|active/i.test(q)) result.statuses.push('in-progress');

  // Locations
  if (/pit\s*a/i.test(q)) { result.locations.push('Pit A - North'); result.locations.push('Pit A - South'); }
  if (/pit\s*b/i.test(q)) { result.locations.push('Pit B - East'); result.locations.push('Pit B - West'); }
  if (/processing\s*plant/i.test(q)) result.locations.push('Processing Plant');
  if (/workshop/i.test(q)) result.locations.push('Workshop');
  if (/tailings/i.test(q)) result.locations.push('Tailings Dam');
  if (/haul\s*road/i.test(q)) result.locations.push('Main Haul Road');

  return result;
}

function filterEvents(events: MiningEvent[], parsed: ParsedQuery): MiningEvent[] {
  return events.filter(ev => {
    // Time range
    if (parsed.timeRange) {
      const evDate = parseISO(ev.date);
      if (!isWithinInterval(evDate, { start: parsed.timeRange.start, end: parsed.timeRange.end })) return false;
    }
    // Category
    if (parsed.categories.length > 0 && !parsed.categories.includes(ev.category)) return false;
    // Equipment
    if (parsed.equipmentTypes.length > 0 && ev.equipment) {
      if (!parsed.equipmentTypes.some(et => ev.equipment!.toLowerCase().includes(et.toLowerCase()))) return false;
    } else if (parsed.equipmentTypes.length > 0 && !ev.equipment) return false;
    // Event types
    if (parsed.eventTypes.length > 0 && !parsed.eventTypes.includes(ev.type)) return false;
    // Severity
    if (parsed.severities.length > 0 && !parsed.severities.includes(ev.severity)) return false;
    // Status
    if (parsed.statuses.length > 0 && !parsed.statuses.includes(ev.status)) return false;
    // Locations
    if (parsed.locations.length > 0 && !parsed.locations.some(l => ev.location.includes(l))) return false;
    return true;
  });
}

function buildSummary(results: MiningEvent[], parsed: ParsedQuery): string {
  if (results.length === 0) {
    return `I couldn't find any matching events for your query in the ${parsed.timeLabel} period. Try broadening your search or adjusting the time range.`;
  }

  const bySeverity: Record<string, number> = {};
  const byType: Record<string, number> = {};
  const byStatus: Record<string, number> = {};
  let totalCost = 0;

  results.forEach(r => {
    bySeverity[r.severity] = (bySeverity[r.severity] || 0) + 1;
    byType[r.type] = (byType[r.type] || 0) + 1;
    byStatus[r.status] = (byStatus[r.status] || 0) + 1;
    if (r.cost) totalCost += r.cost;
  });

  const topType = Object.entries(byType).sort((a, b) => b[1] - a[1])[0];
  const criticalCount = bySeverity['critical'] || 0;
  const highCount = bySeverity['high'] || 0;
  const openCount = byStatus['open'] || 0;

  let summary = `Found **${results.length} events** in the ${parsed.timeLabel} period. `;

  if (topType) summary += `Most common: **${topType[0]}** (${topType[1]} occurrences). `;
  if (criticalCount > 0) summary += `**${criticalCount} critical** and `;
  if (highCount > 0) summary += `**${highCount} high-severity** events detected. `;
  if (openCount > 0) summary += `**${openCount} events** are still open. `;
  if (totalCost > 0) summary += `Estimated total cost impact: **$${totalCost.toLocaleString()}**. `;

  summary += `\n\nYou can download this data as CSV or generate a printable report using the buttons below.`;
  return summary;
}

function buildChartData(results: MiningEvent[]): any[] {
  const byDate: Record<string, number> = {};
  results.forEach(r => {
    const week = format(parseISO(r.date), 'MMM dd');
    byDate[week] = (byDate[week] || 0) + 1;
  });
  return Object.entries(byDate)
    .map(([date, count]) => ({ date, count }))
    .slice(-30); // last 30 data points
}

function buildBreakdownData(results: MiningEvent[]): any[] {
  const byType: Record<string, number> = {};
  results.forEach(r => { byType[r.type] = (byType[r.type] || 0) + 1; });
  return Object.entries(byType)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 8);
}

// ── CSV / PDF download ─────────────────────────────────────────────────────

function downloadCSV(data: MiningEvent[], filename: string) {
  if (!data.length) return;
  const headers = ['id', 'date', 'category', 'type', 'equipment', 'severity', 'location', 'description', 'duration', 'cost', 'status', 'assignee'];
  const csvContent = [
    headers.join(','),
    ...data.map(row => headers.map(h => `"${(row as any)[h] ?? ''}"`).join(','))
  ].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = `${filename}.csv`; link.click();
  URL.revokeObjectURL(url);
}

function printReport(results: MiningEvent[], query: string, summary: string) {
  const bySeverity: Record<string, number> = {};
  const byType: Record<string, number> = {};
  results.forEach(r => {
    bySeverity[r.severity] = (bySeverity[r.severity] || 0) + 1;
    byType[r.type] = (byType[r.type] || 0) + 1;
  });

  const html = `<!DOCTYPE html><html><head><title>SDS AI Assistant Report</title>
<style>
body{font-family:'Segoe UI',Arial,sans-serif;padding:40px;color:#1e293b}
h1{color:#0f172a;border-bottom:3px solid #3b82f6;padding-bottom:10px}
h2{color:#334155;margin-top:28px}
.meta{color:#64748b;margin-bottom:20px}
.query-box{background:#f1f5f9;border-left:4px solid #3b82f6;padding:12px 16px;border-radius:4px;margin:16px 0;font-style:italic}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:16px 0}
.stat{background:#f1f5f9;border-radius:8px;padding:14px;text-align:center}
.stat-val{font-size:22px;font-weight:700;color:#0f172a}
.stat-label{font-size:11px;color:#64748b;text-transform:uppercase;margin-top:4px}
table{width:100%;border-collapse:collapse;margin-top:12px;font-size:12px}
th{background:#1e293b;color:white;padding:8px 10px;text-align:left}
td{padding:6px 10px;border-bottom:1px solid #e2e8f0}
tr:nth-child(even){background:#f8fafc}
.sev-critical{color:#ef4444;font-weight:600}.sev-high{color:#f59e0b;font-weight:600}
.sev-medium{color:#3b82f6}.sev-low{color:#10b981}.sev-info{color:#94a3b8}
.footer{margin-top:40px;padding-top:12px;border-top:1px solid #e2e8f0;font-size:10px;color:#94a3b8}
@media print{body{padding:20px}}
</style></head><body>
<h1>SDS Smart Mining - AI Query Report</h1>
<div class="meta">Generated: ${format(new Date(), 'PPpp')}</div>
<div class="query-box">"${query}"</div>
<div class="stats">
  <div class="stat"><div class="stat-val">${results.length}</div><div class="stat-label">Total Events</div></div>
  <div class="stat"><div class="stat-val">${bySeverity['critical'] || 0}</div><div class="stat-label">Critical</div></div>
  <div class="stat"><div class="stat-val">${bySeverity['high'] || 0}</div><div class="stat-label">High</div></div>
  <div class="stat"><div class="stat-val">${results.filter(r => r.status === 'open').length}</div><div class="stat-label">Open</div></div>
</div>
<h2>Breakdown by Type</h2>
<table><thead><tr><th>Type</th><th>Count</th></tr></thead><tbody>
${Object.entries(byType).sort((a,b)=>b[1]-a[1]).map(([t,c])=>`<tr><td>${t}</td><td>${c}</td></tr>`).join('')}
</tbody></table>
<h2>Event Details (${Math.min(results.length, 100)} of ${results.length})</h2>
<table><thead><tr><th>Date</th><th>Type</th><th>Equipment</th><th>Severity</th><th>Location</th><th>Description</th><th>Status</th></tr></thead><tbody>
${results.slice(0,100).map(r=>`<tr><td>${r.date}</td><td>${r.type}</td><td>${r.equipment||'-'}</td><td class="sev-${r.severity}">${r.severity}</td><td>${r.location}</td><td>${r.description}</td><td>${r.status}</td></tr>`).join('')}
</tbody></table>
<div class="footer">Report generated by SDS AI Assistant. Data is simulated for demonstration.</div>
</body></html>`;

  const w = window.open('', '_blank');
  if (w) { w.document.write(html); w.document.close(); setTimeout(() => w.print(), 500); }
}

// ── Suggested prompts ──────────────────────────────────────────────────────

const SUGGESTIONS = [
  'Show me all excavator breakdowns in the past 3 months',
  'List critical safety incidents last month',
  'How many water leaks were detected this year?',
  'Show haul truck maintenance events past 6 months',
  'List all power outages in the past week',
  'Security breaches at Pit A last 3 months',
  'Open equipment issues with high severity',
  'Production target misses past 2 months',
  'Drill performance degradation events this quarter',
  'Near miss incidents near the processing plant',
  'All crusher breakdowns and their costs',
  'Show resolved safety violations past year',
];

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4', '#ec4899', '#84cc16'];

const severityColors: Record<string, string> = {
  critical: 'bg-red-500/20 text-red-400 border-red-500/30',
  high: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  medium: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  low: 'bg-green-500/20 text-green-400 border-green-500/30',
  info: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
};

const statusColors: Record<string, string> = {
  open: 'text-red-400',
  'in-progress': 'text-amber-400',
  resolved: 'text-green-400',
};

const categoryIcons: Record<string, React.ElementType> = {
  equipment: Truck,
  safety: HardHat,
  water: Droplet,
  security: Shield,
  energy: Zap,
  production: BarChart3,
};

// ── Main Component ─────────────────────────────────────────────────────────

export function AIAssistant() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [expandedMsg, setExpandedMsg] = useState<string | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(true);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);

  const allEvents = useMemo(() => generateMockEvents(), []);

  // Auto-scroll
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Speech Recognition setup
  const startListening = useCallback(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser. Please use Chrome or Edge.');
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);

    recognition.onresult = (event: any) => {
      const transcript = Array.from(event.results)
        .map((r: any) => r[0].transcript)
        .join('');
      setInputText(transcript);
      if (event.results[0].isFinal) {
        setTimeout(() => processQuery(transcript), 300);
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
  }, []);

  const stopListening = useCallback(() => {
    recognitionRef.current?.stop();
    setIsListening(false);
  }, []);

  // TTS
  const speak = useCallback((text: string) => {
    if (!voiceEnabled) return;
    window.speechSynthesis.cancel();
    const cleaned = text.replace(/\*\*/g, '').replace(/\n/g, '. ');
    const utterance = new SpeechSynthesisUtterance(cleaned);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    synthRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [voiceEnabled]);

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, []);

  // Process query
  const processQuery = useCallback((query: string) => {
    if (!query.trim()) return;
    setShowSuggestions(false);
    setIsProcessing(true);

    // Add user message
    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: query.trim(),
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMsg]);
    setInputText('');

    // Simulate processing delay
    setTimeout(() => {
      const parsed = parseNaturalLanguage(query);
      const results = filterEvents(allEvents, parsed);
      const summary = buildSummary(results, parsed);
      const chartData = buildChartData(results);

      const assistantMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        text: summary,
        timestamp: new Date(),
        results,
        parsedQuery: parsed,
        chartData,
      };

      setMessages(prev => [...prev, assistantMsg]);
      setExpandedMsg(assistantMsg.id);
      setIsProcessing(false);
      speak(summary.split('\n')[0]); // speak first line
    }, 1200 + Math.random() * 800);
  }, [allEvents, speak]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    processQuery(inputText);
  };

  const clearChat = () => {
    setMessages([]);
    setShowSuggestions(true);
    setExpandedMsg(null);
    stopSpeaking();
  };

  // ── Render ─────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col h-full bg-slate-950">
      {/* Header */}
      <div className="p-6 pb-3 flex-shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 bg-gradient-to-br from-blue-500 to-violet-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl text-white flex items-center gap-2">
                AI Mining Assistant
                <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 text-[10px] uppercase tracking-wider rounded-full border border-blue-500/30">Beta</span>
              </h2>
              <p className="text-slate-400 text-xs mt-0.5">Ask questions about mining events, equipment status, and operational data using natural language or voice</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => { setVoiceEnabled(v => !v); if (isSpeaking) stopSpeaking(); }}
              className={`p-2 rounded-lg transition-colors ${voiceEnabled ? 'bg-blue-500/20 text-blue-400' : 'bg-slate-800 text-slate-500'}`}
              title={voiceEnabled ? 'Disable voice responses' : 'Enable voice responses'}
            >
              {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>
            {messages.length > 0 && (
              <button onClick={clearChat} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 transition-colors" title="Clear conversation">
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto px-6 pb-4 space-y-4">
        {/* Welcome + Suggestions */}
        {showSuggestions && messages.length === 0 && (
          <div className="mt-4">
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 mb-6">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-slate-300 text-sm">
                    Welcome! I can help you search and analyze mining operational events. Ask me about equipment breakdowns, safety incidents, water quality alerts, security breaches, energy issues, or production events. You can type your question or use the microphone for voice input.
                  </p>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {['Equipment', 'Safety', 'Water', 'Security', 'Energy', 'Production'].map(cat => {
                      const Icon = categoryIcons[cat.toLowerCase()] || Activity;
                      return (
                        <span key={cat} className="px-2.5 py-1 bg-slate-800 rounded-full text-xs text-slate-400 flex items-center gap-1.5 border border-slate-700">
                          <Icon className="w-3 h-3" /> {cat}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
              {SUGGESTIONS.map((s, i) => (
                <button
                  key={i}
                  onClick={() => { setInputText(s); processQuery(s); }}
                  className="text-left px-4 py-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 rounded-xl text-sm text-slate-300 transition-all group"
                >
                  <div className="flex items-start gap-2">
                    <MessageSquare className="w-3.5 h-3.5 text-slate-500 group-hover:text-blue-400 mt-0.5 flex-shrink-0 transition-colors" />
                    <span className="group-hover:text-white transition-colors">{s}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Messages */}
        {messages.map(msg => (
          <div key={msg.id} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                <Bot className="w-4 h-4 text-white" />
              </div>
            )}
            <div className={`max-w-[85%] ${msg.role === 'user' ? 'order-first' : ''}`}>
              {/* Message bubble */}
              <div className={`rounded-2xl px-4 py-3 ${
                msg.role === 'user'
                  ? 'bg-blue-600 text-white rounded-tr-sm'
                  : 'bg-slate-900 border border-slate-800 text-slate-300 rounded-tl-sm'
              }`}>
                <p className="text-sm whitespace-pre-wrap">
                  {msg.text.split('**').map((part, i) =>
                    i % 2 === 1 ? <strong key={i} className="text-white">{part}</strong> : <span key={i}>{part}</span>
                  )}
                </p>
                <div className="text-[10px] mt-1.5 opacity-50">{format(msg.timestamp, 'HH:mm')}</div>
              </div>

              {/* Results */}
              {msg.role === 'assistant' && msg.results && msg.results.length > 0 && (
                <div className="mt-3 space-y-3">
                  {/* Parsed filters pill */}
                  {msg.parsedQuery && (
                    <div className="flex flex-wrap gap-1.5">
                      {msg.parsedQuery.categories.map(c => (
                        <span key={c} className="px-2 py-0.5 bg-blue-500/15 text-blue-400 text-[10px] rounded-full border border-blue-500/20">
                          {c}
                        </span>
                      ))}
                      {msg.parsedQuery.equipmentTypes.map(e => (
                        <span key={e} className="px-2 py-0.5 bg-violet-500/15 text-violet-400 text-[10px] rounded-full border border-violet-500/20">
                          {e}
                        </span>
                      ))}
                      {msg.parsedQuery.eventTypes.map(e => (
                        <span key={e} className="px-2 py-0.5 bg-amber-500/15 text-amber-400 text-[10px] rounded-full border border-amber-500/20">
                          {e}
                        </span>
                      ))}
                      {msg.parsedQuery.timeLabel && (
                        <span className="px-2 py-0.5 bg-green-500/15 text-green-400 text-[10px] rounded-full border border-green-500/20 flex items-center gap-1">
                          <Clock className="w-2.5 h-2.5" />{msg.parsedQuery.timeLabel}
                        </span>
                      )}
                    </div>
                  )}

                  {/* Toggle expand */}
                  <button
                    onClick={() => setExpandedMsg(expandedMsg === msg.id ? null : msg.id)}
                    className="flex items-center gap-1.5 text-xs text-blue-400 hover:text-blue-300 transition-colors"
                  >
                    {expandedMsg === msg.id ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    {expandedMsg === msg.id ? 'Collapse results' : `Show ${msg.results.length} results with charts`}
                  </button>

                  {expandedMsg === msg.id && (
                    <div className="space-y-4">
                      {/* Chart - Timeline */}
                      {msg.chartData && msg.chartData.length > 1 && (
                        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                          <h4 className="text-xs text-slate-400 mb-3 flex items-center gap-1.5">
                            <TrendingUp className="w-3.5 h-3.5 text-blue-400" /> Event Timeline
                          </h4>
                          <ResponsiveContainer width="100%" height={180}>
                            <BarChart data={msg.chartData}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                              <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 9 }} angle={-45} textAnchor="end" height={50} />
                              <YAxis tick={{ fill: '#94a3b8', fontSize: 10 }} allowDecimals={false} />
                              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', color: '#fff', fontSize: 12 }} />
                              <Bar dataKey="count" name="Events" fill="#3b82f6" radius={[3, 3, 0, 0]} />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      )}

                      {/* Chart - Breakdown pie */}
                      {msg.results.length > 0 && (
                        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
                          <h4 className="text-xs text-slate-400 mb-3 flex items-center gap-1.5">
                            <BarChart3 className="w-3.5 h-3.5 text-blue-400" /> Event Type Breakdown
                          </h4>
                          <div className="flex items-center gap-6">
                            <ResponsiveContainer width="50%" height={160}>
                              <PieChart>
                                <Pie data={buildBreakdownData(msg.results)} cx="50%" cy="50%" innerRadius={35} outerRadius={65} paddingAngle={2} dataKey="value">
                                  {buildBreakdownData(msg.results).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                                </Pie>
                                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', color: '#fff', fontSize: 12 }} />
                              </PieChart>
                            </ResponsiveContainer>
                            <div className="flex-1 space-y-1.5">
                              {buildBreakdownData(msg.results).map((item, i) => (
                                <div key={item.name} className="flex items-center justify-between text-xs">
                                  <div className="flex items-center gap-1.5">
                                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                                    <span className="text-slate-300">{item.name}</span>
                                  </div>
                                  <span className="text-slate-500">{item.value}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Results table */}
                      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                        <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                          <span className="text-xs text-slate-400">{msg.results.length} events found</span>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => downloadCSV(msg.results!, `sds-ai-query-${format(new Date(), 'yyyy-MM-dd-HHmm')}`)}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs text-slate-300 transition-colors"
                            >
                              <FileSpreadsheet className="w-3.5 h-3.5" /> CSV
                            </button>
                            <button
                              onClick={() => printReport(msg.results!, msg.text || '', messages.find(m => m.id === msg.id)?.text || '')}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs text-slate-300 transition-colors"
                            >
                              <Printer className="w-3.5 h-3.5" /> Report
                            </button>
                          </div>
                        </div>
                        <div className="max-h-[400px] overflow-y-auto">
                          <table className="w-full text-xs">
                            <thead className="sticky top-0 bg-slate-800">
                              <tr>
                                <th className="text-left py-2.5 px-3 text-slate-400">Date</th>
                                <th className="text-left py-2.5 px-3 text-slate-400">Type</th>
                                <th className="text-left py-2.5 px-3 text-slate-400">Equipment</th>
                                <th className="text-left py-2.5 px-3 text-slate-400">Severity</th>
                                <th className="text-left py-2.5 px-3 text-slate-400">Location</th>
                                <th className="text-left py-2.5 px-3 text-slate-400">Description</th>
                                <th className="text-left py-2.5 px-3 text-slate-400">Status</th>
                                <th className="text-left py-2.5 px-3 text-slate-400">Cost</th>
                              </tr>
                            </thead>
                            <tbody>
                              {msg.results.slice(0, 50).map(ev => (
                                <tr key={ev.id} className="border-b border-slate-800/50 hover:bg-slate-800/30">
                                  <td className="py-2 px-3 text-slate-400 whitespace-nowrap">{ev.date}</td>
                                  <td className="py-2 px-3 text-slate-300 whitespace-nowrap">{ev.type}</td>
                                  <td className="py-2 px-3 text-slate-300 whitespace-nowrap">{ev.equipment || '-'}</td>
                                  <td className="py-2 px-3">
                                    <span className={`px-1.5 py-0.5 rounded text-[10px] border ${severityColors[ev.severity]}`}>
                                      {ev.severity}
                                    </span>
                                  </td>
                                  <td className="py-2 px-3 text-slate-400 whitespace-nowrap">{ev.location}</td>
                                  <td className="py-2 px-3 text-slate-400 max-w-[250px] truncate">{ev.description}</td>
                                  <td className="py-2 px-3">
                                    <span className={`${statusColors[ev.status]} text-[10px] flex items-center gap-1`}>
                                      {ev.status === 'resolved' ? <CheckCircle2 className="w-3 h-3" /> : ev.status === 'open' ? <XCircle className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                                      {ev.status}
                                    </span>
                                  </td>
                                  <td className="py-2 px-3 text-slate-400">{ev.cost ? `$${ev.cost.toLocaleString()}` : '-'}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                          {msg.results.length > 50 && (
                            <div className="px-4 py-2.5 bg-slate-800/50 text-xs text-slate-500 text-center">
                              Showing 50 of {msg.results.length} results. Download CSV for full dataset.
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Quick actions - always visible */}
                  {expandedMsg !== msg.id && (
                    <div className="flex gap-2 mt-1">
                      <button
                        onClick={() => downloadCSV(msg.results!, `sds-ai-query-${format(new Date(), 'yyyy-MM-dd-HHmm')}`)}
                        className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-[10px] text-slate-400 transition-colors border border-slate-700"
                      >
                        <Download className="w-3 h-3" /> Download CSV
                      </button>
                      <button
                        onClick={() => {
                          const userMsg = messages.find(m => m.role === 'user' && messages.indexOf(m) === messages.indexOf(msg) - 1);
                          printReport(msg.results!, userMsg?.text || '', msg.text);
                        }}
                        className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-[10px] text-slate-400 transition-colors border border-slate-700"
                      >
                        <FileText className="w-3 h-3" /> Generate Report
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
            {msg.role === 'user' && (
              <div className="w-8 h-8 bg-slate-700 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                <User className="w-4 h-4 text-slate-300" />
              </div>
            )}
          </div>
        ))}

        {/* Processing indicator */}
        {isProcessing && (
          <div className="flex gap-3 items-start">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-violet-600 rounded-lg flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-tl-sm px-4 py-3">
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />
                <span className="text-sm text-slate-400">Analyzing mining data...</span>
              </div>
              <div className="flex gap-1 mt-2">
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Input Area */}
      <div className="flex-shrink-0 px-6 pb-6 pt-2">
        {/* Speaking indicator */}
        {isSpeaking && (
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full">
              <Volume2 className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
              <span className="text-[10px] text-blue-400">Speaking...</span>
              <button onClick={stopSpeaking} className="p-0.5 hover:bg-blue-500/20 rounded-full">
                <X className="w-3 h-3 text-blue-400" />
              </button>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="relative">
          <div className={`flex items-center gap-2 bg-slate-900 border rounded-2xl px-4 py-2 transition-all ${
            isListening ? 'border-red-500 shadow-lg shadow-red-500/10' : 'border-slate-700 focus-within:border-blue-500 focus-within:shadow-lg focus-within:shadow-blue-500/10'
          }`}>
            <Bot className="w-5 h-5 text-slate-500 flex-shrink-0" />
            <input
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              placeholder={isListening ? 'Listening... speak your query' : 'Ask about mining events, equipment, safety incidents...'}
              className="flex-1 bg-transparent text-sm text-white placeholder-slate-500 outline-none py-2"
              disabled={isProcessing}
            />
            {inputText && (
              <button type="button" onClick={() => setInputText('')} className="p-1.5 hover:bg-slate-800 rounded-lg transition-colors">
                <X className="w-4 h-4 text-slate-500" />
              </button>
            )}
            <button
              type="button"
              onClick={isListening ? stopListening : startListening}
              disabled={isProcessing}
              className={`p-2.5 rounded-xl transition-all ${
                isListening
                  ? 'bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/30'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-400'
              }`}
              title={isListening ? 'Stop listening' : 'Voice input'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
            <button
              type="submit"
              disabled={!inputText.trim() || isProcessing}
              className="p-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:hover:bg-blue-600 text-white rounded-xl transition-all"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>
        <div className="flex items-center justify-between mt-2 px-2">
          <p className="text-[10px] text-slate-600">
            Try: "excavator breakdowns past 3 months" or "critical safety incidents last week"
          </p>
          <p className="text-[10px] text-slate-600">
            {allEvents.length.toLocaleString()} events indexed
          </p>
        </div>
      </div>
    </div>
  );
}
