import { useState, useRef, useEffect, useCallback } from 'react';
import { Loader2, Satellite, Map as MapIcon } from 'lucide-react';

interface MineSite {
  id: string;
  name: string;
  location: string;
  lat: number;
  lng: number;
  primary_commodity: string;
  status: string;
  site_type: string;
  workforce_present?: number;
  total_assets?: number;
  operational_efficiency?: number;
  image_url?: string;
}

interface MineMapProps {
  sites: MineSite[];
  onSelectSite: (siteId: string) => void;
  selectedSiteId?: string | null;
  onNavigateToSite?: (siteId: string) => void;
}

// Preload Leaflet CSS immediately (before any component mounts)
const LEAFLET_CSS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
const LEAFLET_JS = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';

let leafletPromise: Promise<any> | null = null;

function loadLeaflet(): Promise<any> {
  if (leafletPromise) return leafletPromise;

  leafletPromise = new Promise((resolve, reject) => {
    if ((window as any).L) {
      resolve((window as any).L);
      return;
    }

    // Load CSS (non-blocking)
    if (!document.querySelector(`link[href="${LEAFLET_CSS}"]`)) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = LEAFLET_CSS;
      document.head.appendChild(link);
    }

    // Load JS
    const script = document.createElement('script');
    script.src = LEAFLET_JS;
    script.onload = () => resolve((window as any).L);
    script.onerror = () => {
      leafletPromise = null;
      reject(new Error('Failed to load Leaflet'));
    };
    document.head.appendChild(script);
  });

  return leafletPromise;
}

// Start preloading immediately on module import
loadLeaflet().catch(() => {});

const COMMODITY_COLORS: Record<string, string> = {
  'Iron Ore': '#ef4444',
  'Copper': '#f97316',
  'Gold': '#eab308',
  'Bauxite': '#f59e0b',
  'Platinum': '#cbd5e1',
  'Processing Plant': '#06b6d4',
};

const SITE_TYPE_LABELS: Record<string, string> = {
  'open_pit': 'Open Pit',
  'underground': 'Underground',
  'processing_plant': 'Processing Plant',
  'exploration': 'Exploration',
};

// Tile layer configs
const TILE_LAYERS = {
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    options: { maxZoom: 18, tileSize: 256 },
  },
  labels: {
    url: 'https://{s}.basemaps.cartocdn.com/dark_only_labels/{z}/{x}/{y}{r}.png',
    options: { subdomains: 'abcd', maxZoom: 18, pane: 'overlayPane' },
  },
  dark: {
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    options: { subdomains: 'abcd', maxZoom: 19 },
  },
};

export function MineMap({ sites, onSelectSite, selectedSiteId, onNavigateToSite }: MineMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const tileLayersRef = useRef<{ base: any; labels: any | null }>({ base: null, labels: null });
  const [isLoading, setIsLoading] = useState(true);
  const [tilesLoading, setTilesLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mapStyle, setMapStyle] = useState<'satellite' | 'dark'>('satellite');
  const leafletRef = useRef<any>(null);
  const initDone = useRef(false);

  // Initialize map
  useEffect(() => {
    if (initDone.current) return;
    let cancelled = false;

    async function init() {
      try {
        const L = await loadLeaflet();
        if (cancelled || !mapContainerRef.current) return;
        leafletRef.current = L;
        initDone.current = true;

        const container = mapContainerRef.current;

        // Ensure container has dimensions before creating map
        if (container.clientHeight === 0) {
          container.style.minHeight = '400px';
        }

        const map = L.map(container, {
          center: [20, 20],
          zoom: 2,
          minZoom: 2,
          maxZoom: 18,
          zoomControl: false,
          attributionControl: false,
          preferCanvas: true,         // Use canvas renderer for better perf
          updateWhenZooming: false,    // Don't update tiles during zoom animation
          updateWhenIdle: true,        // Update tiles only when map stops moving
          keepBuffer: 4,              // Keep extra tiles in buffer
        });

        // Start with fast dark tiles, add satellite on top
        const darkBase = L.tileLayer(TILE_LAYERS.dark.url, {
          ...TILE_LAYERS.dark.options,
          attribution: '',
        }).addTo(map);

        // Add satellite layer
        const satLayer = L.tileLayer(TILE_LAYERS.satellite.url, {
          ...TILE_LAYERS.satellite.options,
          attribution: '',
        }).addTo(map);

        // Labels on top of everything
        const labelsLayer = L.tileLayer(TILE_LAYERS.labels.url, {
          ...TILE_LAYERS.labels.options,
          attribution: '',
        }).addTo(map);

        tileLayersRef.current = { base: satLayer, labels: labelsLayer };

        // Track tile loading
        let loadingCount = 0;
        satLayer.on('loading', () => { loadingCount++; setTilesLoading(true); });
        satLayer.on('load', () => { loadingCount = Math.max(0, loadingCount - 1); if (loadingCount === 0) setTilesLoading(false); });

        // Zoom control
        L.control.zoom({ position: 'topright' }).addTo(map);

        mapRef.current = map;

        // Force invalidateSize after a short delay to handle container sizing
        map.whenReady(() => {
          setIsLoading(false);
          setTimeout(() => {
            map.invalidateSize({ animate: false });
          }, 100);
        });

        // ResizeObserver to handle container dimension changes
        const resizeObserver = new ResizeObserver(() => {
          map.invalidateSize({ animate: false });
        });
        resizeObserver.observe(container);

        // Store for cleanup
        (map as any)._resizeObserver = resizeObserver;
        (map as any)._darkBase = darkBase;

      } catch (err) {
        if (!cancelled) {
          setError('Failed to load map. Please refresh the page.');
          setIsLoading(false);
        }
      }
    }

    init();

    return () => {
      cancelled = true;
      if (mapRef.current) {
        const map = mapRef.current;
        if ((map as any)._resizeObserver) {
          (map as any)._resizeObserver.disconnect();
        }
        map.remove();
        mapRef.current = null;
        initDone.current = false;
      }
    };
  }, []);

  // Toggle map style
  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L) return;

    const { base, labels } = tileLayersRef.current;

    if (mapStyle === 'satellite') {
      if (base && !map.hasLayer(base)) {
        base.addTo(map);
      }
    } else {
      if (base && map.hasLayer(base)) {
        map.removeLayer(base);
      }
    }
  }, [mapStyle]);

  // Render / update markers
  useEffect(() => {
    const map = mapRef.current;
    const L = leafletRef.current;
    if (!map || !L || sites.length === 0) return;

    // Remove old markers
    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];

    sites.forEach((site) => {
      const isSelected = site.id === selectedSiteId;
      const color = COMMODITY_COLORS[site.primary_commodity] || '#3b82f6';
      const size = isSelected ? 20 : 14;
      const outerSize = isSelected ? 36 : 26;

      const markerHtml = `
        <div style="position:relative;width:${outerSize}px;height:${outerSize}px;display:flex;align-items:center;justify-content:center;">
          <span style="
            position:absolute;
            width:${outerSize}px;height:${outerSize}px;
            border-radius:50%;
            background:${color};
            opacity:0.15;
            animation:mmpulse 2.5s ease-out infinite;
          "></span>
          <span style="
            width:${size}px;height:${size}px;
            border-radius:50%;
            background:${color};
            border:2.5px solid ${isSelected ? '#fff' : 'rgba(255,255,255,0.75)'};
            box-shadow:0 0 ${isSelected ? 16 : 8}px ${color}90, 0 2px 6px rgba(0,0,0,0.5);
            display:block;
            position:relative;
            z-index:2;
            transition:all .2s;
          "></span>
        </div>
      `;

      const icon = L.divIcon({
        html: markerHtml,
        className: 'mine-map-marker',
        iconSize: [outerSize, outerSize],
        iconAnchor: [outerSize / 2, outerSize / 2],
      });

      const marker = L.marker([site.lat, site.lng], { icon }).addTo(map);

      // Build popup
      const popupContent = buildPopupHtml(site, color);

      marker.bindPopup(popupContent, {
        className: 'mine-satellite-popup',
        closeButton: true,
        maxWidth: 280,
        offset: [0, -(outerSize / 2 + 4)],
        autoPan: true,
        autoPanPadding: [40, 40],
      });

      marker.on('click', () => {
        onSelectSite(site.id);
      });

      markersRef.current.push(marker);
    });

    // Fit bounds
    if (sites.length > 1) {
      const bounds = L.latLngBounds(sites.map((s: MineSite) => [s.lat, s.lng]));
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 4, animate: false });
    } else if (sites.length === 1) {
      map.setView([sites[0].lat, sites[0].lng], 6, { animate: false });
    }

    // Extra invalidateSize after markers placed
    setTimeout(() => map.invalidateSize({ animate: false }), 200);
  }, [sites, selectedSiteId, onSelectSite]);

  // Fly to selected site
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !selectedSiteId) return;
    const site = sites.find((s) => s.id === selectedSiteId);
    if (site) {
      map.flyTo([site.lat, site.lng], 6, { duration: 1 });
      const markerIndex = sites.findIndex((s) => s.id === selectedSiteId);
      if (markerIndex >= 0 && markersRef.current[markerIndex]) {
        setTimeout(() => {
          markersRef.current[markerIndex]?.openPopup();
        }, 1100);
      }
    }
  }, [selectedSiteId, sites]);

  // Global callback for popup "Enter Command Center"
  useEffect(() => {
    (window as any).__mineMapNavigate = (siteId: string) => {
      if (onNavigateToSite) {
        onNavigateToSite(siteId);
      } else {
        onSelectSite(siteId);
        window.dispatchEvent(new CustomEvent('mine-site-navigate', { detail: siteId }));
      }
    };
    return () => { delete (window as any).__mineMapNavigate; };
  }, [onSelectSite, onNavigateToSite]);

  return (
    <div className="relative w-full h-full rounded-xl overflow-hidden border border-slate-700 bg-slate-950">
      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 z-[2000] bg-slate-950 flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
          <p className="text-sm text-slate-400">Initializing satellite map...</p>
        </div>
      )}

      {/* Tile loading indicator */}
      {tilesLoading && !isLoading && (
        <div className="absolute top-4 right-16 z-[1000]">
          <div className="bg-slate-900/80 backdrop-blur-sm border border-slate-700/60 rounded-lg px-3 py-1.5 flex items-center gap-2">
            <Loader2 className="w-3 h-3 text-blue-400 animate-spin" />
            <span className="text-xs text-slate-400">Loading tiles...</span>
          </div>
        </div>
      )}

      {/* Error overlay */}
      {error && (
        <div className="absolute inset-0 z-[2000] bg-slate-950 flex flex-col items-center justify-center gap-3">
          <p className="text-sm text-red-400">{error}</p>
          <button
            onClick={() => { setError(null); setIsLoading(true); initDone.current = false; leafletPromise = null; }}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors"
          >
            Retry
          </button>
        </div>
      )}

      {/* Map container — always rendered so Leaflet can attach */}
      <div ref={mapContainerRef} style={{ width: '100%', height: '100%', minHeight: 400 }} />

      {/* Title overlay */}
      <div className="absolute top-4 left-4 z-[1000] pointer-events-none">
        <div className="bg-slate-900/80 backdrop-blur-sm border border-slate-700/60 rounded-lg px-4 py-2.5">
          <h3 className="text-sm text-white flex items-center gap-2">
            <Satellite className="w-3.5 h-3.5 text-blue-400" />
            Global Mining Operations
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            {sites.length} sites &middot; {mapStyle === 'satellite' ? 'Satellite' : 'Dark'} View
          </p>
        </div>
      </div>

      {/* Map style toggle */}
      <div className="absolute top-4 right-14 z-[1000]">
        <button
          onClick={() => setMapStyle(s => s === 'satellite' ? 'dark' : 'satellite')}
          className="bg-slate-900/80 backdrop-blur-sm border border-slate-700/60 rounded-lg px-3 py-2 flex items-center gap-2 text-xs text-slate-300 hover:text-white hover:border-slate-600 transition-colors"
          title={mapStyle === 'satellite' ? 'Switch to Dark Map' : 'Switch to Satellite'}
        >
          {mapStyle === 'satellite' ? <MapIcon className="w-3.5 h-3.5" /> : <Satellite className="w-3.5 h-3.5" />}
          <span className="hidden sm:inline">{mapStyle === 'satellite' ? 'Dark' : 'Satellite'}</span>
        </button>
      </div>

      {/* Legend */}
      <div className="absolute bottom-6 left-4 z-[1000] pointer-events-none">
        <div className="bg-slate-900/80 backdrop-blur-sm border border-slate-700/60 rounded-lg px-3 py-2">
          <p className="text-[10px] text-slate-500 mb-1.5 uppercase tracking-wider">Commodities</p>
          <div className="flex flex-wrap gap-x-3 gap-y-1">
            {Object.entries(COMMODITY_COLORS).map(([name, color]) => (
              <div key={name} className="flex items-center gap-1.5">
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ background: color, boxShadow: `0 0 6px ${color}80` }}
                />
                <span className="text-[10px] text-slate-400">{name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Styles */}
      <style>{`
        @keyframes mmpulse {
          0% { transform: scale(1); opacity: 0.15; }
          70% { transform: scale(2.5); opacity: 0; }
          100% { transform: scale(2.5); opacity: 0; }
        }
        .mine-map-marker {
          background: none !important;
          border: none !important;
        }
        .mine-satellite-popup .leaflet-popup-content-wrapper {
          background: transparent !important;
          box-shadow: none !important;
          border-radius: 10px !important;
          padding: 0 !important;
        }
        .mine-satellite-popup .leaflet-popup-content {
          margin: 0 !important;
          line-height: 1.4 !important;
          width: auto !important;
        }
        .mine-satellite-popup .leaflet-popup-tip {
          background: #0f172a !important;
          border: 1px solid rgba(71,85,105,0.4) !important;
          box-shadow: 0 4px 12px rgba(0,0,0,0.4) !important;
        }
        .mine-satellite-popup .leaflet-popup-close-button {
          color: #94a3b8 !important;
          font-size: 20px !important;
          top: 6px !important;
          right: 8px !important;
          z-index: 10 !important;
          text-shadow: 0 1px 4px rgba(0,0,0,0.8) !important;
        }
        .mine-satellite-popup .leaflet-popup-close-button:hover {
          color: #f1f5f9 !important;
        }
        .leaflet-control-zoom a {
          background: rgba(15,23,42,0.85) !important;
          color: #e2e8f0 !important;
          border-color: rgba(71,85,105,0.5) !important;
          backdrop-filter: blur(8px) !important;
        }
        .leaflet-control-zoom a:hover {
          background: rgba(30,41,59,0.9) !important;
          color: #fff !important;
        }
        .leaflet-tile-pane { will-change: transform; }
        .leaflet-tile { will-change: auto; image-rendering: auto; }
      `}</style>
    </div>
  );
}

// Extracted popup builder to keep marker logic clean
function buildPopupHtml(site: MineSite, color: string): string {
  return `
    <div style="
      background:#0f172a;
      color:#f1f5f9;
      padding:0;
      border-radius:10px;
      width:260px;
      overflow:hidden;
      font-family:system-ui,-apple-system,sans-serif;
      box-shadow:0 12px 40px rgba(0,0,0,0.6);
      border:1px solid rgba(71,85,105,0.4);
    ">
      ${site.image_url ? `
      <div style="width:100%;height:90px;overflow:hidden;position:relative;">
        <img src="${site.image_url}" style="width:100%;height:100%;object-fit:cover;" loading="lazy" />
        <div style="position:absolute;inset:0;background:linear-gradient(to top,#0f172a 0%,transparent 60%);"></div>
        <span style="
          position:absolute;top:6px;right:6px;
          background:rgba(34,197,94,0.2);
          color:#4ade80;
          border:1px solid rgba(34,197,94,0.3);
          padding:2px 8px;
          border-radius:20px;
          font-size:9px;
          font-weight:600;
          text-transform:capitalize;
        ">${site.status}</span>
      </div>` : ''}
      <div style="padding:10px 14px 14px;">
        <div style="font-size:14px;font-weight:700;margin-bottom:2px;">${site.name}</div>
        <div style="font-size:10px;color:#94a3b8;margin-bottom:8px;display:flex;align-items:center;gap:4px;">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
          ${site.location}
        </div>
        <div style="display:flex;gap:4px;margin-bottom:10px;flex-wrap:wrap;">
          <span style="
            background:${color}22;color:${color};
            border:1px solid ${color}44;
            padding:2px 8px;border-radius:20px;font-size:9px;font-weight:600;
          ">${site.primary_commodity}</span>
          <span style="
            background:rgba(51,65,85,0.5);color:#cbd5e1;
            border:1px solid rgba(71,85,105,0.5);
            padding:2px 8px;border-radius:20px;font-size:9px;font-weight:600;
          ">${SITE_TYPE_LABELS[site.site_type] || site.site_type}</span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;margin-bottom:12px;">
          <div style="text-align:center;background:rgba(30,41,59,0.6);border-radius:6px;padding:5px 3px;">
            <div style="font-size:8px;color:#64748b;margin-bottom:1px;">Assets</div>
            <div style="font-size:13px;font-weight:700;">${site.total_assets || 0}</div>
          </div>
          <div style="text-align:center;background:rgba(30,41,59,0.6);border-radius:6px;padding:5px 3px;">
            <div style="font-size:8px;color:#64748b;margin-bottom:1px;">Workforce</div>
            <div style="font-size:13px;font-weight:700;">${site.workforce_present || 0}</div>
          </div>
          <div style="text-align:center;background:rgba(30,41,59,0.6);border-radius:6px;padding:5px 3px;">
            <div style="font-size:8px;color:#64748b;margin-bottom:1px;">Efficiency</div>
            <div style="font-size:13px;font-weight:700;">${site.operational_efficiency || 0}%</div>
          </div>
        </div>
        <button
          onclick="window.__mineMapNavigate('${site.id}')"
          style="
            width:100%;padding:9px;
            background:#2563eb;color:white;border:none;border-radius:8px;
            font-size:12px;font-weight:600;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:6px;
            transition:background .15s;
          "
          onmouseover="this.style.background='#1d4ed8'"
          onmouseout="this.style.background='#2563eb'"
        >
          Enter Command Center
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
        </button>
      </div>
    </div>
  `;
}
