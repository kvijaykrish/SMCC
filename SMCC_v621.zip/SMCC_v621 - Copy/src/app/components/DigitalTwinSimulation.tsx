import { useState, useEffect, useCallback } from 'react';
import { motion } from 'motion/react';
import { 
  Box, Activity, Cpu, Gauge, Thermometer, Zap, AlertTriangle, CheckCircle,
  RotateCw, Maximize2, Play, Pause, SkipBack, Settings, TrendingUp,
  ArrowLeft, Info, Clock, Layers, Eye, Grid3x3
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import type { View } from '../App';

interface DigitalTwinSimulationProps {
  onNavigate: (view: View) => void;
}

const assets = [
  { id: 'EXC-001', name: 'Excavator Alpha', type: 'Excavator' },
  { id: 'HTK-045', name: 'Haul Truck 45', type: 'Haul Truck' },
  { id: 'DRL-012', name: 'Drill Rig 12', type: 'Drill' },
  { id: 'DOZ-008', name: 'Dozer Delta', type: 'Dozer' },
];

const sensorData = [
  { time: '00:00', temp: 68, pressure: 145, vibration: 2.3, load: 85 },
  { time: '00:15', temp: 72, pressure: 148, vibration: 2.5, load: 88 },
  { time: '00:30', temp: 75, pressure: 151, vibration: 2.8, load: 92 },
  { time: '00:45', temp: 78, pressure: 155, vibration: 3.1, load: 89 },
  { time: '01:00', temp: 76, pressure: 152, vibration: 2.9, load: 87 },
  { time: '01:15', temp: 73, pressure: 149, vibration: 2.6, load: 85 },
];

const components = [
  { id: 'engine', name: 'Engine System', health: 94, status: 'optimal', temp: 78, vibration: 2.8, hours: 1250, nextMaintenance: 250 },
  { id: 'hydraulics', name: 'Hydraulic System', health: 88, status: 'good', temp: 65, pressure: 148, hours: 1250, nextMaintenance: 150 },
  { id: 'transmission', name: 'Transmission', health: 92, status: 'optimal', temp: 72, gear: 3, hours: 1250, nextMaintenance: 200 },
  { id: 'tracks', name: 'Track System', health: 76, status: 'warning', wear: 68, tension: 'normal', hours: 1250, nextMaintenance: 50 },
];

const alerts = [
  { id: 'A-001', severity: 'warning', component: 'Track System', message: 'Increased wear detected - maintenance recommended within 50 hours', time: '15 mins ago' },
  { id: 'A-002', severity: 'info', component: 'Hydraulic System', message: 'Oil temperature within normal range', time: '1 hour ago' },
];

const predictiveData = [
  { hour: 0, current: 94, predicted: 94 },
  { hour: 100, current: null, predicted: 92 },
  { hour: 200, current: null, predicted: 89 },
  { hour: 300, current: null, predicted: 85 },
  { hour: 400, current: null, predicted: 81 },
  { hour: 500, current: null, predicted: 76 },
];

export function DigitalTwinSimulation({ onNavigate }: DigitalTwinSimulationProps) {
  const [selectedAsset, setSelectedAsset] = useState(assets[0]);
  const [selectedComponent, setSelectedComponent] = useState(components[0]);
  const [isSimulating, setIsSimulating] = useState(true);
  const [viewMode, setViewMode] = useState<'3d' | 'wireframe' | 'solid'>('3d');
  const [rotation, setRotation] = useState({ x: 20, y: 0 });
  const [showMesh, setShowMesh] = useState(true);

  useEffect(() => {
    if (isSimulating) {
      const interval = setInterval(() => {
        setRotation((prev) => ({ x: prev.x, y: (prev.y + 0.4) % 360 }));
      }, 50);
      return () => clearInterval(interval);
    }
  }, [isSimulating]);

  const renderAsset3DModel = () => {
    const props = { rotation, showMesh, viewMode };
    switch (selectedAsset.type) {
      case 'Excavator': return <ExcavatorModel {...props} />;
      case 'Haul Truck': return <HaulTruckModel {...props} />;
      case 'Drill': return <DrillRigModel {...props} />;
      case 'Dozer': return <DozerModel {...props} />;
      default: return <ExcavatorModel {...props} />;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-slate-950 min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <button onClick={() => onNavigate('connected-assets')} className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors">
          <ArrowLeft className="w-5 h-5" /><span>Back to Assets</span>
        </button>
        <div className="flex items-center gap-3 flex-wrap">
          <select 
            value={selectedAsset.id}
            onChange={(e) => { const a = assets.find(x => x.id === e.target.value); if (a) setSelectedAsset(a); }}
            className="border border-slate-700 bg-slate-800 text-white rounded-lg px-4 py-2 text-sm"
          >
            {assets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
          </select>
          <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 rounded-lg p-1">
            {(['3d', 'wireframe', 'solid'] as const).map(mode => (
              <button key={mode} onClick={() => setViewMode(mode)}
                className={`px-3 py-1.5 rounded text-sm transition-colors flex items-center gap-1.5 ${viewMode === mode ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-700'}`}
              >
                {mode === '3d' ? <Box className="w-4 h-4" /> : mode === 'wireframe' ? <Grid3x3 className="w-4 h-4" /> : <Layers className="w-4 h-4" />}
                {mode === '3d' ? '3D Mesh' : mode === 'wireframe' ? 'Wireframe' : 'Solid'}
              </button>
            ))}
          </div>
          <button onClick={() => setShowMesh(!showMesh)}
            className={`px-3 py-2 border rounded-lg text-sm transition-colors flex items-center gap-2 ${showMesh ? 'bg-blue-500/10 border-blue-500/20 text-blue-400' : 'border-slate-700 text-slate-300'}`}
          >
            <Eye className="w-4 h-4" /> Mesh Grid
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Model Viewer */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg text-white">{selectedAsset.name}</h2>
                <p className="text-sm text-slate-400">{selectedAsset.id} &bull; 3D Digital Twin Model</p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => setRotation({ x: 20, y: 0 })} className="p-2 hover:bg-slate-800 rounded-lg transition-colors" title="Reset View">
                  <RotateCw className="w-5 h-5 text-slate-300" />
                </button>
                <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors"><Settings className="w-5 h-5 text-slate-300" /></button>
                <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors"><Maximize2 className="w-5 h-5 text-slate-300" /></button>
              </div>
            </div>

            <div className="relative bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 rounded-lg h-[500px] flex items-center justify-center overflow-hidden border border-slate-800/50">
              {/* Floor grid */}
              <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
                <defs>
                  <pattern id="floor-grid" width="50" height="50" patternUnits="userSpaceOnUse">
                    <path d="M 50 0 L 0 0 0 50" fill="none" stroke="rgba(59,130,246,0.06)" strokeWidth="0.5" />
                  </pattern>
                  <linearGradient id="floor-fade" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="transparent" />
                    <stop offset="60%" stopColor="transparent" />
                    <stop offset="100%" stopColor="rgba(59,130,246,0.03)" />
                  </linearGradient>
                </defs>
                <rect width="100%" height="100%" fill="url(#floor-grid)" />
                <rect width="100%" height="100%" fill="url(#floor-fade)" />
              </svg>

              <div className="relative z-10 w-full h-full flex items-center justify-center">
                {renderAsset3DModel()}
              </div>

              {/* HUD overlays */}
              <div className="absolute bottom-4 left-4 bg-black/60 backdrop-blur-sm px-3 py-2 rounded-lg text-xs text-slate-300 flex items-center gap-2">
                <RotateCw className={`w-3 h-3 ${isSimulating ? 'animate-spin' : ''}`} />
                <span>{isSimulating ? 'Live Rotation' : 'Paused'}</span>
              </div>
              <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm px-3 py-2 rounded-lg text-xs text-slate-300 space-y-1">
                <div>Pitch: {rotation.x.toFixed(1)}&deg;</div>
                <div>Yaw: {rotation.y.toFixed(1)}&deg;</div>
              </div>
              <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm px-3 py-2 rounded-lg text-xs flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-green-400">Live Sync: 0.8s</span>
              </div>
              <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-sm px-3 py-2 rounded-lg text-xs text-slate-300 space-y-0.5">
                <div>Polygons: {selectedAsset.type === 'Excavator' ? '42.5K' : selectedAsset.type === 'Haul Truck' ? '36.2K' : selectedAsset.type === 'Drill' ? '28.8K' : '31.3K'}</div>
                <div>Vertices: {selectedAsset.type === 'Excavator' ? '21.3K' : selectedAsset.type === 'Haul Truck' ? '18.1K' : selectedAsset.type === 'Drill' ? '14.4K' : '15.7K'}</div>
                <div>LOD: High</div>
              </div>
            </div>

            {/* Playback Controls */}
            <div className="mt-4 flex items-center justify-center gap-4">
              <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors"><SkipBack className="w-5 h-5 text-slate-300" /></button>
              <button onClick={() => setIsSimulating(!isSimulating)} className="p-3 bg-blue-600 hover:bg-blue-700 rounded-lg text-white transition-colors">
                {isSimulating ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </button>
              <button onClick={() => setRotation({ x: 20, y: 0 })} className="p-2 hover:bg-slate-800 rounded-lg transition-colors"><RotateCw className="w-5 h-5 text-slate-300" /></button>
            </div>
          </div>

          {/* Sensor Data */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <h3 className="text-lg text-white mb-4">Real-Time Sensor Data</h3>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={sensorData}>
                <defs>
                  <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/><stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorVibration" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/><stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="time" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }} labelStyle={{ color: '#e2e8f0' }} />
                <Legend />
                <Area type="monotone" dataKey="temp" stroke="#ef4444" fill="url(#colorTemp)" name="Temperature (&deg;F)" />
                <Area type="monotone" dataKey="vibration" stroke="#3b82f6" fill="url(#colorVibration)" name="Vibration (mm/s)" />
                <Line type="monotone" dataKey="load" stroke="#10b981" strokeWidth={2} name="Load %" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          {/* Component Health */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <h3 className="text-lg text-white mb-4">Component Health</h3>
            <div className="space-y-3">
              {components.map(c => (
                <button key={c.id} onClick={() => setSelectedComponent(c)}
                  className={`w-full p-3 border rounded-lg text-left transition-all ${selectedComponent.id === c.id ? 'border-blue-500 bg-blue-500/10' : 'border-slate-700 hover:border-slate-600'}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-white">{c.name}</span>
                    <ComponentStatus status={c.status} />
                  </div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-slate-400">Health Score</span>
                    <span className="text-white">{c.health}%</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-1.5">
                    <div className={`h-1.5 rounded-full ${c.health >= 90 ? 'bg-green-500' : c.health >= 75 ? 'bg-blue-500' : 'bg-amber-500'}`} style={{ width: `${c.health}%` }} />
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Selected Component Details */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <h3 className="text-sm text-slate-400 mb-3">Selected Component</h3>
            <h4 className="text-lg text-white mb-4">{selectedComponent.name}</h4>
            <div className="space-y-3">
              <DetailItem icon={Activity} label="Health Score" value={`${selectedComponent.health}%`} />
              <DetailItem icon={Clock} label="Operating Hours" value={`${selectedComponent.hours}h`} />
              <DetailItem icon={Thermometer} label="Temperature" value={selectedComponent.temp ? `${selectedComponent.temp}°F` : 'N/A'} />
              <DetailItem icon={Gauge} label="Next Maintenance" value={`${selectedComponent.nextMaintenance}h`} />
            </div>
            <div className={`mt-4 p-3 rounded-lg ${selectedComponent.status === 'warning' ? 'bg-amber-500/10 border border-amber-500/20' : 'bg-green-500/10 border border-green-500/20'}`}>
              <div className="flex items-start gap-2">
                {selectedComponent.status === 'warning' ? <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5" /> : <CheckCircle className="w-4 h-4 text-green-400 mt-0.5" />}
                <div>
                  <div className={`text-sm mb-1 ${selectedComponent.status === 'warning' ? 'text-amber-300' : 'text-green-300'}`}>
                    {selectedComponent.status === 'warning' ? 'Attention Required' : 'Operating Normally'}
                  </div>
                  <div className={`text-xs ${selectedComponent.status === 'warning' ? 'text-amber-400' : 'text-green-400'}`}>
                    {selectedComponent.status === 'warning' ? `Maintenance recommended in ${selectedComponent.nextMaintenance} hours` : 'All parameters within normal range'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Predictive Analytics */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-blue-400" />
              <h3 className="text-lg text-white">Predictive Analysis</h3>
            </div>
            <ResponsiveContainer width="100%" height={150}>
              <LineChart data={predictiveData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="hour" stroke="#94a3b8" style={{ fontSize: '10px' }} />
                <YAxis stroke="#94a3b8" style={{ fontSize: '10px' }} domain={[70, 100]} />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }} labelStyle={{ color: '#e2e8f0' }} />
                <Line type="monotone" dataKey="current" stroke="#3b82f6" strokeWidth={2} name="Current" />
                <Line type="monotone" dataKey="predicted" stroke="#f59e0b" strokeWidth={2} strokeDasharray="5 5" name="Predicted" />
              </LineChart>
            </ResponsiveContainer>
            <div className="mt-3 text-xs text-slate-400">Predicted health degradation over next 500 operating hours</div>
          </div>

          {/* Active Alerts */}
          <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
            <h3 className="text-lg text-white mb-4">Active Alerts</h3>
            <div className="space-y-3">
              {alerts.map(a => (
                <div key={a.id} className={`p-3 rounded-lg border ${a.severity === 'warning' ? 'bg-amber-500/10 border-amber-500/20' : 'bg-blue-500/10 border-blue-500/20'}`}>
                  <div className="flex items-start gap-2">
                    {a.severity === 'warning' ? <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5" /> : <Info className="w-4 h-4 text-blue-400 mt-0.5" />}
                    <div className="flex-1">
                      <div className={`text-sm mb-1 ${a.severity === 'warning' ? 'text-amber-300' : 'text-blue-300'}`}>{a.component}</div>
                      <div className={`text-xs mb-2 ${a.severity === 'warning' ? 'text-amber-400' : 'text-blue-400'}`}>{a.message}</div>
                      <div className="text-xs text-slate-500">{a.time}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────── SVG SHARED DEFS ──────────────────────── */
const sharedDefs = (prefix: string, bodyColor1: string, bodyColor2: string) => (
  <defs>
    <linearGradient id={`${prefix}Body`} x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor={bodyColor1} stopOpacity={0.95} />
      <stop offset="100%" stopColor={bodyColor2} stopOpacity={0.95} />
    </linearGradient>
    <linearGradient id={`${prefix}BodyDark`} x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor={bodyColor2} stopOpacity={0.95} />
      <stop offset="100%" stopColor="#78350f" stopOpacity={0.95} />
    </linearGradient>
    <linearGradient id={`${prefix}Metal`} x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#94a3b8" stopOpacity={0.95} />
      <stop offset="100%" stopColor="#475569" stopOpacity={0.95} />
    </linearGradient>
    <linearGradient id={`${prefix}MetalDark`} x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#64748b" stopOpacity={0.95} />
      <stop offset="100%" stopColor="#334155" stopOpacity={0.95} />
    </linearGradient>
    <linearGradient id={`${prefix}Glass`} x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stopColor="#7dd3fc" stopOpacity={0.7} />
      <stop offset="100%" stopColor="#0284c7" stopOpacity={0.5} />
    </linearGradient>
    <linearGradient id={`${prefix}Track`} x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stopColor="#1e293b" />
      <stop offset="100%" stopColor="#0f172a" />
    </linearGradient>
    <filter id={`${prefix}Shadow`}>
      <feGaussianBlur in="SourceAlpha" stdDeviation="6"/>
      <feOffset dx="4" dy="8" result="offsetblur"/>
      <feComponentTransfer><feFuncA type="linear" slope="0.25"/></feComponentTransfer>
      <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <filter id={`${prefix}InnerGlow`}>
      <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="blur"/>
      <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <radialGradient id={`${prefix}Wheel`} cx="50%" cy="40%" r="60%">
      <stop offset="0%" stopColor="#334155" />
      <stop offset="100%" stopColor="#0f172a" />
    </radialGradient>
    <pattern id={`${prefix}MeshP`} width="12" height="12" patternUnits="userSpaceOnUse">
      <path d="M 12 0 L 0 0 0 12" fill="none" stroke="#60a5fa" strokeWidth="0.4" opacity="0.25" />
    </pattern>
  </defs>
);

interface ModelProps { rotation: { x: number; y: number }; showMesh: boolean; viewMode: string; }
const fill = (vm: string, grad: string) => vm === 'wireframe' ? 'none' : grad;
const stroke = (vm: string, col: string) => vm === 'wireframe' ? '#3b82f6' : col;
const sw = (vm: string) => vm === 'wireframe' ? 1.5 : 2;
const op = (vm: string) => vm === '3d' ? 0.88 : 1;

/* Mesh overlay helper */
function MeshOverlay({ x, y, w, h, show, color = '#60a5fa' }: { x: number; y: number; w: number; h: number; show: boolean; color?: string }) {
  if (!show) return null;
  return <rect x={x} y={y} width={w} height={h} fill="none" stroke={color} strokeWidth={0.3} opacity={0.2} />;
}

function MeshGrid({ x, y, w, h, rows, cols, show, color = '#60a5fa' }: { x: number; y: number; w: number; h: number; rows: number; cols: number; show: boolean; color?: string }) {
  if (!show) return null;
  const cw = w / cols, ch = h / rows;
  const rects = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      rects.push(<rect key={`${r}-${c}`} x={x + c * cw} y={y + r * ch} width={cw} height={ch} fill="none" stroke={color} strokeWidth={0.3} opacity={0.2} />);
    }
  }
  return <g>{rects}</g>;
}

/* Sensor node indicator */
function SensorNode({ cx, cy, label, value, color = '#10b981' }: { cx: number; cy: number; label: string; value: string; color?: string }) {
  return (
    <g>
      <motion.circle cx={cx} cy={cy} r={5} fill={color} stroke="white" strokeWidth={1.5}
        animate={{ opacity: [0.7, 1, 0.7], scale: [1, 1.1, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
        style={{ transformOrigin: `${cx}px ${cy}px` }}
      />
      <motion.circle cx={cx} cy={cy} r={10} fill="none" stroke={color} strokeWidth={0.8}
        animate={{ r: [10, 16, 10], opacity: [0.4, 0, 0.4] }}
        transition={{ duration: 2.5, repeat: Infinity }}
      />
      <rect x={cx + 10} y={cy - 14} width={70} height={24} rx={4} fill="rgba(0,0,0,0.7)" stroke="rgba(59,130,246,0.3)" strokeWidth={0.5} />
      <text x={cx + 14} y={cy - 4} fontSize="6" fill="#94a3b8" style={{ fontFamily: 'monospace' }}>{label}</text>
      <text x={cx + 14} y={cy + 4} fontSize="7" fill="#e2e8f0" style={{ fontFamily: 'monospace' }}>{value}</text>
    </g>
  );
}

/* ──────────────────────── EXCAVATOR ──────────────────────── */
function ExcavatorModel({ rotation, showMesh, viewMode }: ModelProps) {
  return (
    <motion.div className="relative w-[700px] h-[500px]" style={{ transform: `perspective(1200px) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)` }}>
      <svg className="w-full h-full" viewBox="0 0 700 500">
        {sharedDefs('exc', '#fbbf24', '#d97706')}

        {/* Ground shadow */}
        <ellipse cx="310" cy="430" rx="200" ry="25" fill="rgba(0,0,0,0.2)" />

        {/* ── TRACKS ── */}
        <g>
          {/* Left track assembly */}
          <rect x="140" y="385" width="260" height="40" rx="18" fill={fill(viewMode, 'url(#excTrack)')} stroke={stroke(viewMode, '#0f172a')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#excShadow)' : ''} />
          {/* Track pads */}
          {[...Array(14)].map((_, i) => (
            <rect key={`tp-${i}`} x={148 + i * 17.5} y={388} width={14} height={34} rx={2} fill="none" stroke={viewMode === 'wireframe' ? '#3b82f6' : '#1e293b'} strokeWidth={1} opacity={0.6} />
          ))}
          {/* Drive sprocket */}
          <circle cx="168" cy="405" r="16" fill={fill(viewMode, 'url(#excWheel)')} stroke={stroke(viewMode, '#334155')} strokeWidth={2} />
          <circle cx="168" cy="405" r="6" fill="none" stroke="#475569" strokeWidth={1.5} />
          {[...Array(6)].map((_, i) => (
            <line key={`sp-${i}`} x1={168} y1={405} x2={168 + Math.cos(i * Math.PI / 3) * 14} y2={405 + Math.sin(i * Math.PI / 3) * 14} stroke="#475569" strokeWidth={1} />
          ))}
          {/* Idler wheel */}
          <circle cx="372" cy="405" r="14" fill={fill(viewMode, 'url(#excWheel)')} stroke={stroke(viewMode, '#334155')} strokeWidth={2} />
          <circle cx="372" cy="405" r="5" fill="none" stroke="#475569" strokeWidth={1.5} />
          {/* Rollers */}
          {[220, 270, 320].map(cx => (
            <circle key={cx} cx={cx} cy="413" r="8" fill={fill(viewMode, 'url(#excWheel)')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
          ))}
          <MeshGrid x={140} y={385} w={260} h={40} rows={3} cols={14} show={showMesh} />
        </g>

        {/* ── UNDERCARRIAGE FRAME ── */}
        <rect x="155" y="370" width="230" height="18" rx="3" fill={fill(viewMode, 'url(#excMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={sw(viewMode)} />

        {/* ── TURNTABLE / SLEW RING ── */}
        <ellipse cx="270" cy="365" rx="70" ry="12" fill={fill(viewMode, 'url(#excMetal)')} stroke={stroke(viewMode, '#475569')} strokeWidth={sw(viewMode)} />
        {showMesh && [...Array(12)].map((_, i) => (
          <line key={`sl-${i}`} x1={270} y1={365} x2={270 + Math.cos(i * Math.PI / 6) * 65} y2={365 + Math.sin(i * Math.PI / 6) * 10} stroke="#60a5fa" strokeWidth={0.4} opacity={0.25} />
        ))}
        {/* Slew teeth indicator */}
        <ellipse cx="270" cy="365" rx="60" ry="9" fill="none" stroke={viewMode === 'wireframe' ? '#3b82f6' : '#475569'} strokeWidth={0.8} strokeDasharray="3,2" />

        {/* ── MAIN BODY / SUPERSTRUCTURE ── */}
        <g>
          {/* Counter weight */}
          <path d="M 170 300 L 185 260 L 200 255 L 200 355 L 170 355 Z" fill={fill(viewMode, 'url(#excBodyDark)')} stroke={stroke(viewMode, '#92400e')} strokeWidth={sw(viewMode)} opacity={op(viewMode)} />
          <MeshGrid x={172} y={260} w={28} h={95} rows={8} cols={3} show={showMesh} color="#fbbf24" />

          {/* Engine compartment */}
          <path d="M 200 260 L 340 260 L 355 300 L 355 355 L 200 355 Z" fill={fill(viewMode, 'url(#excBody)')} stroke={stroke(viewMode, '#b45309')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#excShadow)' : ''} opacity={op(viewMode)} />
          {/* Engine louvers */}
          {[...Array(6)].map((_, i) => (
            <line key={`lv-${i}`} x1={210} y1={300 + i * 8} x2={250} y2={300 + i * 8} stroke="#92400e" strokeWidth={1.5} opacity={0.5} />
          ))}
          {/* Exhaust stack */}
          <rect x="215" y="235" width="12" height="25" rx="3" fill={fill(viewMode, 'url(#excMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
          <ellipse cx="221" cy="233" rx="7" ry="3" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={1} />
          {/* Heat shimmer from exhaust */}
          <motion.path d="M 218 225 Q 221 218 224 225 Q 227 218 230 225" fill="none" stroke="rgba(239,68,68,0.3)" strokeWidth={0.8}
            animate={{ y: [0, -8], opacity: [0.4, 0] }} transition={{ duration: 2, repeat: Infinity }} />

          <MeshGrid x={200} y={260} w={155} h={95} rows={8} cols={12} show={showMesh} color="#fbbf24" />

          {/* Hydraulic tank */}
          <rect x="320" y="310" width="30" height="40" rx="3" fill={fill(viewMode, 'url(#excMetal)')} stroke={stroke(viewMode, '#475569')} strokeWidth={1.5} />
          <line x1="325" y1="325" x2="345" y2="325" stroke="#64748b" strokeWidth={1} />
          <line x1="325" y1="335" x2="345" y2="335" stroke="#64748b" strokeWidth={1} />

          {/* Fuel tank */}
          <rect x="262" y="320" width="45" height="30" rx="5" fill={fill(viewMode, 'url(#excMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
          <circle cx="284" cy="335" r="4" fill="none" stroke="#475569" strokeWidth={1} />
        </g>

        {/* ── CABIN ── */}
        <g>
          <path d="M 285 220 L 355 220 L 365 260 L 365 300 L 285 300 Z" fill={fill(viewMode, 'url(#excBody)')} stroke={stroke(viewMode, '#b45309')} strokeWidth={sw(viewMode)} opacity={op(viewMode)} />
          {/* Front windshield */}
          <path d="M 345 228 L 360 228 L 363 258 L 345 258 Z" fill={fill(viewMode, 'url(#excGlass)')} stroke={stroke(viewMode, '#0284c7')} strokeWidth={1.5} />
          {/* Side window */}
          <rect x="295" y="232" width="42" height="24" rx="2" fill={fill(viewMode, 'url(#excGlass)')} stroke={stroke(viewMode, '#0284c7')} strokeWidth={1.5} />
          {/* Window reflection */}
          <line x1="300" y1="234" x2="310" y2="254" stroke="rgba(255,255,255,0.15)" strokeWidth={2} />
          {/* Roof */}
          <rect x="282" y="215" width="76" height="8" rx="2" fill={fill(viewMode, 'url(#excBodyDark)')} stroke={stroke(viewMode, '#92400e')} strokeWidth={1.5} />
          {/* Roof light bar */}
          <rect x="290" y="212" width="22" height="5" rx="2" fill="#fbbf24" stroke="#d97706" strokeWidth={0.8} opacity={0.8} />
          <motion.rect x="290" y="212" width="22" height="5" rx="2" fill="#fbbf24" opacity={0.4}
            animate={{ opacity: [0.2, 0.6, 0.2] }} transition={{ duration: 1.5, repeat: Infinity }} />
          <MeshGrid x={285} y={220} w={80} h={80} rows={6} cols={6} show={showMesh} color="#fbbf24" />
        </g>

        {/* ── BOOM ARM ── */}
        <g>
          <motion.g animate={{ rotate: [0, -4, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }} style={{ transformOrigin: "350px 270px" }}>
            {/* Main boom */}
            <path d="M 350 255 L 530 185 L 540 205 L 360 275 Z" fill={fill(viewMode, 'url(#excMetal)')} stroke={stroke(viewMode, '#475569')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#excShadow)' : ''} opacity={op(viewMode)} />
            {/* Boom side plate */}
            <path d="M 355 258 L 535 188 L 540 195 L 360 265 Z" fill={fill(viewMode, 'url(#excMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={1} />
            {/* Hydraulic cylinder - boom */}
            <rect x="380" y="230" width="90" height="10" rx="5" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
            <rect x="440" y="228" width="45" height="14" rx="4" fill={fill(viewMode, '#64748b')} stroke={stroke(viewMode, '#475569')} strokeWidth={1} />
            {/* Hydraulic lines */}
            <path d="M 360 268 Q 400 250 420 242" fill="none" stroke="#1e293b" strokeWidth={2} />
            <path d="M 362 272 Q 405 255 425 247" fill="none" stroke="#1e293b" strokeWidth={1.5} />
            {/* Boom pin */}
            <circle cx="350" cy="265" r="6" fill={fill(viewMode, '#64748b')} stroke={stroke(viewMode, '#334155')} strokeWidth={2} />
            <circle cx="350" cy="265" r="2" fill="#1e293b" />
            {/* Mesh */}
            {showMesh && [...Array(14)].map((_, i) => {
              const t = i / 14;
              return <line key={`bm-${i}`} x1={350 + 190 * t} y1={255 + (185 - 255) * t} x2={360 + 180 * t} y2={275 + (205 - 275) * t} stroke="#60a5fa" strokeWidth={0.4} opacity={0.2} />;
            })}

            {/* ── STICK (Secondary arm) ── */}
            <motion.g animate={{ rotate: [0, 6, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.4 }} style={{ transformOrigin: "535px 195px" }}>
              <path d="M 530 185 L 640 145 L 646 160 L 536 200 Z" fill={fill(viewMode, 'url(#excMetal)')} stroke={stroke(viewMode, '#475569')} strokeWidth={sw(viewMode)} opacity={op(viewMode)} />
              <path d="M 533 188 L 643 148 L 646 155 L 536 195 Z" fill={fill(viewMode, 'url(#excMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={0.8} />
              {/* Stick cylinder */}
              <rect x="550" y="172" width="55" height="8" rx="4" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
              {/* Stick pin */}
              <circle cx="535" cy="193" r="5" fill={fill(viewMode, '#64748b')} stroke={stroke(viewMode, '#334155')} strokeWidth={2} />
              <circle cx="535" cy="193" r="1.5" fill="#1e293b" />
              {showMesh && [...Array(10)].map((_, i) => {
                const t = i / 10;
                return <line key={`st-${i}`} x1={530 + 115 * t} y1={185 + (145 - 185) * t} x2={536 + 110 * t} y2={200 + (160 - 200) * t} stroke="#60a5fa" strokeWidth={0.4} opacity={0.2} />;
              })}

              {/* ── BUCKET ── */}
              <motion.g animate={{ rotate: [0, -12, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.8 }} style={{ transformOrigin: "640px 152px" }}>
                <path d="M 638 145 L 672 132 L 680 155 L 675 172 L 640 165 Z" fill={fill(viewMode, 'url(#excMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={sw(viewMode)} opacity={op(viewMode)} />
                {/* Bucket teeth */}
                {[0, 1, 2, 3].map(i => (
                  <polygon key={`bt-${i}`} points={`${660 + i * 5},135 ${663 + i * 5},122 ${666 + i * 5},135`} fill={fill(viewMode, '#0f172a')} stroke={stroke(viewMode, '#000')} strokeWidth={1} />
                ))}
                {/* Bucket side plate */}
                <path d="M 638 148 L 640 165 L 675 172 L 675 155 Z" fill={fill(viewMode, 'url(#excMetal)')} stroke={stroke(viewMode, '#475569')} strokeWidth={0.8} opacity={0.6} />
                {/* Bucket pin */}
                <circle cx="640" cy="155" r="4" fill={fill(viewMode, '#64748b')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
              </motion.g>
            </motion.g>
          </motion.g>
        </g>

        {/* ── SENSOR NODES ── */}
        <SensorNode cx={230} cy={280} label="ENGINE" value="2,100 RPM" color="#10b981" />
        <SensorNode cx={335} cy={330} label="HYDRAULIC" value="3,200 PSI" color="#3b82f6" />
        <SensorNode cx={270} cy={400} label="TRACK WEAR" value="68%" color="#f59e0b" />
      </svg>
    </motion.div>
  );
}

/* ──────────────────────── HAUL TRUCK ──────────────────────── */
function HaulTruckModel({ rotation, showMesh, viewMode }: ModelProps) {
  return (
    <motion.div className="relative w-[700px] h-[500px]" style={{ transform: `perspective(1200px) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)` }}>
      <svg className="w-full h-full" viewBox="0 0 700 500">
        {sharedDefs('htk', '#fbbf24', '#d97706')}
        <ellipse cx="330" cy="440" rx="220" ry="20" fill="rgba(0,0,0,0.2)" />

        {/* ── MASSIVE TIRES ── */}
        <g>
          {/* Front axle tire */}
          <circle cx="175" cy="395" r="38" fill={fill(viewMode, 'url(#htkWheel)')} stroke={stroke(viewMode, '#0f172a')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#htkShadow)' : ''} />
          <circle cx="175" cy="395" r="22" fill="none" stroke="#334155" strokeWidth={2.5} />
          <circle cx="175" cy="395" r="8" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={2} />
          {[...Array(8)].map((_, i) => <line key={`fw-${i}`} x1={175} y1={395} x2={175 + Math.cos(i * Math.PI / 4) * 20} y2={395 + Math.sin(i * Math.PI / 4) * 20} stroke="#475569" strokeWidth={1.5} />)}
          {/* Tread pattern */}
          {[...Array(16)].map((_, i) => {
            const a = (i * Math.PI * 2) / 16;
            return <line key={`ft-${i}`} x1={175 + Math.cos(a) * 30} y1={395 + Math.sin(a) * 30} x2={175 + Math.cos(a) * 37} y2={395 + Math.sin(a) * 37} stroke="#1e293b" strokeWidth={3} />;
          })}

          {/* Rear dual tires - set 1 */}
          {[395, 475].map(cx => (
            <g key={`rt-${cx}`}>
              <circle cx={cx} cy="395" r="42" fill={fill(viewMode, 'url(#htkWheel)')} stroke={stroke(viewMode, '#0f172a')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#htkShadow)' : ''} />
              <circle cx={cx} cy="395" r="25" fill="none" stroke="#334155" strokeWidth={2.5} />
              <circle cx={cx} cy="395" r="10" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={2} />
              {[...Array(8)].map((_, i) => <line key={i} x1={cx} y1={395} x2={cx + Math.cos(i * Math.PI / 4) * 23} y2={395 + Math.sin(i * Math.PI / 4) * 23} stroke="#475569" strokeWidth={1.5} />)}
              {[...Array(18)].map((_, i) => {
                const a = (i * Math.PI * 2) / 18;
                return <line key={`tt-${i}`} x1={cx + Math.cos(a) * 34} y1={395 + Math.sin(a) * 34} x2={cx + Math.cos(a) * 41} y2={395 + Math.sin(a) * 41} stroke="#1e293b" strokeWidth={3} />;
              })}
            </g>
          ))}
        </g>

        {/* ── CHASSIS FRAME ── */}
        <rect x="135" y="338" width="400" height="22" rx="4" fill={fill(viewMode, 'url(#htkMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={sw(viewMode)} />
        {/* Cross members */}
        {[200, 280, 360, 440].map(x => (
          <rect key={x} x={x} y="340" width="8" height="18" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={0.8} />
        ))}

        {/* ── DUMP BED ── */}
        <motion.g animate={{ rotate: [0, -3, 0] }} transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }} style={{ transformOrigin: "500px 335px" }}>
          {/* Bed floor */}
          <path d="M 195 260 L 520 260 L 530 335 L 185 335 Z" fill={fill(viewMode, 'url(#htkBody)')} stroke={stroke(viewMode, '#b45309')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#htkShadow)' : ''} opacity={op(viewMode)} />
          {/* Bed side panel */}
          <path d="M 195 260 L 195 335 L 185 335 L 195 260 Z" fill={fill(viewMode, 'url(#htkBodyDark)')} stroke={stroke(viewMode, '#92400e')} strokeWidth={1.5} />
          {/* Bed ribs (structural reinforcement) */}
          {[0, 1, 2, 3, 4, 5, 6].map(i => (
            <line key={`rib-${i}`} x1={220 + i * 42} y1={265} x2={215 + i * 42} y2={332} stroke="#b45309" strokeWidth={3} opacity={0.5} />
          ))}
          {/* Bed lip */}
          <rect x="190" y="255" width="340" height="8" rx="2" fill={fill(viewMode, 'url(#htkBodyDark)')} stroke={stroke(viewMode, '#92400e')} strokeWidth={1.5} />
          {/* Material in bed */}
          <path d="M 200 270 Q 280 250 360 265 Q 440 250 515 270 L 525 330 L 190 330 Z" fill={viewMode === 'wireframe' ? 'none' : 'rgba(120,113,108,0.4)'} stroke={viewMode === 'wireframe' ? '#3b82f6' : 'rgba(168,162,158,0.3)'} strokeWidth={1} />
          <MeshGrid x={195} y={260} w={335} h={75} rows={6} cols={18} show={showMesh} color="#fbbf24" />
        </motion.g>

        {/* ── CAB ── */}
        <g>
          {/* Cab body */}
          <path d="M 120 260 L 195 260 L 195 340 L 120 340 Z" fill={fill(viewMode, 'url(#htkBody)')} stroke={stroke(viewMode, '#b45309')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#htkShadow)' : ''} opacity={op(viewMode)} />
          {/* Cab roof */}
          <path d="M 115 210 L 200 210 L 195 260 L 120 260 Z" fill={fill(viewMode, 'url(#htkBody)')} stroke={stroke(viewMode, '#b45309')} strokeWidth={sw(viewMode)} opacity={op(viewMode)} />
          {/* Front windshield */}
          <path d="M 122 215 L 122 255 L 135 255 L 140 218 Z" fill={fill(viewMode, 'url(#htkGlass)')} stroke={stroke(viewMode, '#0284c7')} strokeWidth={1.5} />
          {/* Side windows */}
          <rect x="145" y="218" width="44" height="35" rx="3" fill={fill(viewMode, 'url(#htkGlass)')} stroke={stroke(viewMode, '#0284c7')} strokeWidth={1.5} />
          {/* Window divider */}
          <line x1="167" y1="218" x2="167" y2="253" stroke="#0284c7" strokeWidth={1.5} />
          {/* Reflection */}
          <line x1="150" y1="220" x2="155" y2="250" stroke="rgba(255,255,255,0.12)" strokeWidth={2} />
          {/* Cab stairs */}
          {[305, 318, 331].map(y => (
            <rect key={y} x="113" y={y} width="12" height="4" rx="1" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={0.8} />
          ))}
          {/* Mirror */}
          <rect x="108" y="222" width="6" height="16" rx="2" fill={fill(viewMode, '#64748b')} stroke={stroke(viewMode, '#475569')} strokeWidth={1} />
          {/* Roof light bar */}
          <rect x="130" y="206" width="55" height="6" rx="2" fill={fill(viewMode, '#fbbf24')} stroke="#d97706" strokeWidth={0.8} />
          <motion.rect x="130" y="206" width="55" height="6" rx="2" fill="#fbbf24" opacity={0.3}
            animate={{ opacity: [0.15, 0.5, 0.15] }} transition={{ duration: 1.5, repeat: Infinity }} />
          <MeshGrid x={120} y={210} w={75} h={130} rows={10} cols={6} show={showMesh} color="#fbbf24" />
        </g>

        {/* ── ENGINE COMPARTMENT ── */}
        <g>
          <rect x="120" y="260" width="75" height="75" rx="4" fill={fill(viewMode, 'url(#htkBodyDark)')} stroke={stroke(viewMode, '#92400e')} strokeWidth={sw(viewMode)} opacity={op(viewMode)} />
          {/* Grille */}
          {[...Array(8)].map((_, i) => (
            <line key={`gr-${i}`} x1={128} y1={268 + i * 8} x2={188} y2={268 + i * 8} stroke="#78350f" strokeWidth={2} opacity={0.4} />
          ))}
          {/* Exhaust stack */}
          <rect x="185" y="215" width="10" height="45" rx="3" fill={fill(viewMode, 'url(#htkMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
          <ellipse cx="190" cy="213" rx="6" ry="3" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={1} />
          <motion.path d="M 187 208 Q 190 200 193 208 Q 196 200 199 208" fill="none" stroke="rgba(239,68,68,0.25)" strokeWidth={0.8}
            animate={{ y: [0, -6], opacity: [0.3, 0] }} transition={{ duration: 2, repeat: Infinity }} />
        </g>

        {/* Sensors */}
        <SensorNode cx={157} cy={280} label="ENGINE" value="1,800 RPM" color="#10b981" />
        <SensorNode cx={350} cy={290} label="PAYLOAD" value="220 tonnes" color="#3b82f6" />
        <SensorNode cx={435} cy={380} label="TIRE PSI" value="110 PSI" color="#f59e0b" />
      </svg>
    </motion.div>
  );
}

/* ──────────────────────── DRILL RIG ──────────────────────── */
function DrillRigModel({ rotation, showMesh, viewMode }: ModelProps) {
  return (
    <motion.div className="relative w-[700px] h-[500px]" style={{ transform: `perspective(1200px) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)` }}>
      <svg className="w-full h-full" viewBox="0 0 700 500">
        {sharedDefs('drl', '#ef4444', '#b91c1c')}
        <ellipse cx="330" cy="445" rx="180" ry="20" fill="rgba(0,0,0,0.2)" />

        {/* ── TRACKS ── */}
        {[{ x: 180, w: 130 }, { x: 370, w: 130 }].map((track, idx) => (
          <g key={idx}>
            <rect x={track.x} y="395" width={track.w} height="35" rx="16" fill={fill(viewMode, 'url(#drlTrack)')} stroke={stroke(viewMode, '#0f172a')} strokeWidth={sw(viewMode)} />
            {[...Array(7)].map((_, i) => (
              <rect key={i} x={track.x + 5 + i * 17} y="398" width={13} height="29" rx={2} fill="none" stroke={viewMode === 'wireframe' ? '#3b82f6' : '#1e293b'} strokeWidth={0.8} opacity={0.5} />
            ))}
            <circle cx={track.x + 18} cy="412" r="13" fill={fill(viewMode, 'url(#drlWheel)')} stroke={stroke(viewMode, '#334155')} strokeWidth={2} />
            <circle cx={track.x + track.w - 18} cy="412" r="11" fill={fill(viewMode, 'url(#drlWheel)')} stroke={stroke(viewMode, '#334155')} strokeWidth={2} />
          </g>
        ))}

        {/* ── BASE PLATFORM ── */}
        <path d="M 170 365 L 510 365 L 520 395 L 160 395 Z" fill={fill(viewMode, 'url(#drlMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#drlShadow)' : ''} />
        <MeshGrid x={170} y={365} w={350} h={30} rows={3} cols={20} show={showMesh} />

        {/* ── OPERATOR CABIN ── */}
        <g>
          <rect x="185" y="300" width="80" height="62" rx="4" fill={fill(viewMode, 'url(#drlBody)')} stroke={stroke(viewMode, '#991b1b')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#drlShadow)' : ''} opacity={op(viewMode)} />
          <rect x="192" y="308" width="28" height="22" rx="2" fill={fill(viewMode, 'url(#drlGlass)')} stroke={stroke(viewMode, '#0284c7')} strokeWidth={1.5} />
          <rect x="226" y="308" width="28" height="22" rx="2" fill={fill(viewMode, 'url(#drlGlass)')} stroke={stroke(viewMode, '#0284c7')} strokeWidth={1.5} />
          <line x1="196" y1="310" x2="200" y2="328" stroke="rgba(255,255,255,0.1)" strokeWidth={2} />
          <rect x="190" y="296" width="72" height="6" rx="2" fill={fill(viewMode, 'url(#drlBodyDark)')} stroke={stroke(viewMode, '#7f1d1d')} strokeWidth={1} />
          <MeshGrid x={185} y={300} w={80} h={62} rows={6} cols={6} show={showMesh} color="#fca5a5" />
        </g>

        {/* ── ENGINE HOUSING ── */}
        <rect x="280" y="310" width="100" height="52" rx="4" fill={fill(viewMode, 'url(#drlBody)')} stroke={stroke(viewMode, '#991b1b')} strokeWidth={sw(viewMode)} opacity={op(viewMode)} />
        {[...Array(5)].map((_, i) => (
          <line key={`eng-${i}`} x1={290} y1={318 + i * 8} x2={370} y2={318 + i * 8} stroke="#7f1d1d" strokeWidth={1.5} opacity={0.4} />
        ))}

        {/* ── MAST / DERRICK TOWER ── */}
        <g>
          <motion.g animate={{ scaleY: [1, 1.01, 1] }} transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }} style={{ transformOrigin: "415px 300px" }}>
            {/* Main mast - truss structure */}
            <path d="M 400 365 L 395 90 L 440 90 L 435 365 Z" fill={fill(viewMode, 'url(#drlBody)')} stroke={stroke(viewMode, '#991b1b')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#drlShadow)' : ''} opacity={op(viewMode)} />
            {/* Side plate */}
            <path d="M 435 365 L 440 90 L 460 95 L 455 365 Z" fill={fill(viewMode, 'url(#drlBodyDark)')} stroke={stroke(viewMode, '#7f1d1d')} strokeWidth={1.5} opacity={0.7} />
            {/* Cross bracing */}
            {[...Array(12)].map((_, i) => (
              <g key={`xb-${i}`}>
                <line x1={398} y1={110 + i * 21} x2={438} y2={110 + i * 21} stroke="#991b1b" strokeWidth={1.5} opacity={0.5} />
                <line x1={398} y1={110 + i * 21} x2={438} y2={131 + i * 21} stroke="#991b1b" strokeWidth={0.8} opacity={0.3} />
                <line x1={438} y1={110 + i * 21} x2={398} y2={131 + i * 21} stroke="#991b1b" strokeWidth={0.8} opacity={0.3} />
              </g>
            ))}
            {/* Crown block */}
            <rect x="390" y="82" width="55" height="15" rx="3" fill={fill(viewMode, 'url(#drlMetal)')} stroke={stroke(viewMode, '#475569')} strokeWidth={2} />
            <circle cx="417" cy="88" r="5" fill="none" stroke="#475569" strokeWidth={2} />
            {/* Mast mesh */}
            {showMesh && [...Array(28)].map((_, i) => (
              <line key={`mm-${i}`} x1={397} y1={95 + i * 9.5} x2={437} y2={95 + i * 9.5} stroke="#60a5fa" strokeWidth={0.3} opacity={0.2} />
            ))}
          </motion.g>
        </g>

        {/* ── DRILL STRING ── */}
        <motion.g animate={{ y: [0, 15, 0], rotate: [0, 180, 360] }} transition={{ duration: 4, repeat: Infinity, ease: "linear" }} style={{ transformOrigin: "417px 400px" }}>
          <rect x="412" y="370" width="10" height="85" rx="2" fill={fill(viewMode, 'url(#drlMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
          {/* Drill bit */}
          <polygon points="412,455 417,472 422,455" fill={fill(viewMode, '#0f172a')} stroke={stroke(viewMode, '#000')} strokeWidth={1.5} />
          {/* Spiral fluting */}
          {[...Array(6)].map((_, i) => (
            <path key={`fl-${i}`} d={`M 412 ${380 + i * 12} Q 417 ${374 + i * 12} 422 ${380 + i * 12}`} fill="none" stroke="#475569" strokeWidth={1} opacity={0.6} />
          ))}
        </motion.g>

        {/* ── HYDRAULIC FEED SYSTEM ── */}
        <rect x="390" y="340" width="54" height="25" rx="4" fill={fill(viewMode, 'url(#drlMetal)')} stroke={stroke(viewMode, '#475569')} strokeWidth={1.5} />
        <rect x="395" y="345" width="44" height="15" rx="3" fill={fill(viewMode, '#334155')} stroke={stroke(viewMode, '#1e293b')} strokeWidth={1} />

        {/* Sensors */}
        <SensorNode cx={225} cy={330} label="ENGINE" value="1,650 RPM" color="#10b981" />
        <SensorNode cx={417} cy={200} label="DRILL DEPTH" value="45.2m" color="#3b82f6" />
        <SensorNode cx={330} cy={350} label="TORQUE" value="85 kN·m" color="#f59e0b" />
      </svg>
    </motion.div>
  );
}

/* ──────────────────────── DOZER ──────────────────────── */
function DozerModel({ rotation, showMesh, viewMode }: ModelProps) {
  return (
    <motion.div className="relative w-[700px] h-[500px]" style={{ transform: `perspective(1200px) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)` }}>
      <svg className="w-full h-full" viewBox="0 0 700 500">
        {sharedDefs('doz', '#fbbf24', '#d97706')}
        <ellipse cx="340" cy="440" rx="210" ry="22" fill="rgba(0,0,0,0.2)" />

        {/* ── TRACKS ── */}
        <rect x="145" y="365" width="370" height="50" rx="22" fill={fill(viewMode, 'url(#dozTrack)')} stroke={stroke(viewMode, '#0f172a')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#dozShadow)' : ''} />
        {[...Array(20)].map((_, i) => (
          <rect key={`tp-${i}`} x={152 + i * 17.8} y={368} width={14} height={44} rx={2} fill="none" stroke={viewMode === 'wireframe' ? '#3b82f6' : '#1e293b'} strokeWidth={0.8} opacity={0.5} />
        ))}
        {/* Drive sprocket, idler, rollers */}
        <circle cx="175" cy="390" r="20" fill={fill(viewMode, 'url(#dozWheel)')} stroke={stroke(viewMode, '#334155')} strokeWidth={2.5} />
        <circle cx="175" cy="390" r="7" fill="none" stroke="#475569" strokeWidth={2} />
        {[...Array(6)].map((_, i) => <line key={i} x1={175} y1={390} x2={175 + Math.cos(i * Math.PI / 3) * 18} y2={390 + Math.sin(i * Math.PI / 3) * 18} stroke="#475569" strokeWidth={1.2} />)}
        <circle cx="485" cy="390" r="18" fill={fill(viewMode, 'url(#dozWheel)')} stroke={stroke(viewMode, '#334155')} strokeWidth={2.5} />
        <circle cx="485" cy="390" r="6" fill="none" stroke="#475569" strokeWidth={2} />
        {[260, 330, 400].map(cx => <circle key={cx} cx={cx} cy="400" r="10" fill={fill(viewMode, 'url(#dozWheel)')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />)}
        <MeshGrid x={145} y={365} w={370} h={50} rows={3} cols={20} show={showMesh} />

        {/* ── MAIN BODY ── */}
        <path d="M 185 280 L 480 280 L 500 340 L 500 365 L 165 365 L 165 340 Z" fill={fill(viewMode, 'url(#dozBody)')} stroke={stroke(viewMode, '#b45309')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#dozShadow)' : ''} opacity={op(viewMode)} />
        {/* Side panel details */}
        <rect x="210" y="310" width="60" height="25" rx="3" fill="none" stroke="#b45309" strokeWidth={1.5} opacity={0.4} />
        <rect x="280" y="310" width="60" height="25" rx="3" fill="none" stroke="#b45309" strokeWidth={1.5} opacity={0.4} />
        <MeshGrid x={185} y={280} w={315} h={85} rows={7} cols={18} show={showMesh} color="#fbbf24" />

        {/* ── ENGINE COMPARTMENT ── */}
        <rect x="310" y="238" width="130" height="42" rx="5" fill={fill(viewMode, 'url(#dozBody)')} stroke={stroke(viewMode, '#b45309')} strokeWidth={sw(viewMode)} opacity={op(viewMode)} />
        {[...Array(7)].map((_, i) => (
          <line key={`lv-${i}`} x1={320} y1={244 + i * 5} x2={430} y2={244 + i * 5} stroke="#92400e" strokeWidth={1.5} opacity={0.3} />
        ))}
        {/* Exhaust */}
        <rect x="410" y="216" width="12" height="22" rx="3" fill={fill(viewMode, 'url(#dozMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
        <ellipse cx="416" cy="214" rx="7" ry="3" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={1} />
        <motion.path d="M 413 208 Q 416 200 419 208" fill="none" stroke="rgba(239,68,68,0.25)" strokeWidth={0.8}
          animate={{ y: [0, -6], opacity: [0.3, 0] }} transition={{ duration: 2, repeat: Infinity }} />
        <MeshGrid x={310} y={238} w={130} h={42} rows={4} cols={10} show={showMesh} color="#fbbf24" />

        {/* ── CAB ── */}
        <g>
          <path d="M 195 205 L 300 205 L 300 280 L 195 280 Z" fill={fill(viewMode, 'url(#dozBody)')} stroke={stroke(viewMode, '#b45309')} strokeWidth={sw(viewMode)} opacity={op(viewMode)} />
          <rect x="200" y="215" width="40" height="30" rx="3" fill={fill(viewMode, 'url(#dozGlass)')} stroke={stroke(viewMode, '#0284c7')} strokeWidth={1.5} />
          <rect x="248" y="215" width="40" height="30" rx="3" fill={fill(viewMode, 'url(#dozGlass)')} stroke={stroke(viewMode, '#0284c7')} strokeWidth={1.5} />
          <line x1="205" y1="217" x2="210" y2="243" stroke="rgba(255,255,255,0.1)" strokeWidth={2} />
          <rect x="192" y="200" width="112" height="7" rx="2" fill={fill(viewMode, 'url(#dozBodyDark)')} stroke={stroke(viewMode, '#92400e')} strokeWidth={1.5} />
          {/* ROPS frame indicators */}
          <line x1="195" y1="200" x2="195" y2="280" stroke="#92400e" strokeWidth={3} opacity={0.5} />
          <line x1="300" y1="200" x2="300" y2="280" stroke="#92400e" strokeWidth={3} opacity={0.5} />
          <MeshGrid x={195} y={205} w={105} h={75} rows={6} cols={8} show={showMesh} color="#fbbf24" />
        </g>

        {/* ── BLADE ── */}
        <motion.g animate={{ y: [0, -8, 0] }} transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}>
          {/* Blade face */}
          <path d="M 95 275 L 165 225 L 165 340 L 95 355 Z" fill={fill(viewMode, 'url(#dozMetal)')} stroke={stroke(viewMode, '#475569')} strokeWidth={sw(viewMode)} filter={viewMode !== 'wireframe' ? 'url(#dozShadow)' : ''} opacity={op(viewMode)} />
          {/* Blade cutting edge */}
          <path d="M 92 355 L 95 345 L 165 340 L 165 355 Z" fill={fill(viewMode, '#334155')} stroke={stroke(viewMode, '#1e293b')} strokeWidth={2} />
          {/* Blade top edge */}
          <path d="M 95 275 L 165 225 L 168 230 L 98 280 Z" fill={fill(viewMode, 'url(#dozMetalDark)')} stroke={stroke(viewMode, '#334155')} strokeWidth={1} />
          {/* Push arms */}
          <rect x="140" y="300" width="30" height="10" rx="3" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
          <rect x="140" y="325" width="30" height="10" rx="3" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
          {/* Hydraulic cylinders */}
          <rect x="150" y="265" width="15" height="8" rx="3" fill={fill(viewMode, '#64748b')} stroke={stroke(viewMode, '#475569')} strokeWidth={1} />
          {/* Blade ribs */}
          {[0, 1, 2, 3, 4].map(i => (
            <line key={`br-${i}`} x1={100 + i * 2} y1={285 + i * 15} x2={162} y2={240 + i * 20} stroke="#334155" strokeWidth={2.5} opacity={0.4} />
          ))}
          <MeshGrid x={95} y={225} w={70} h={130} rows={10} cols={5} show={showMesh} />
        </motion.g>

        {/* ── RIPPER (rear) ── */}
        <g>
          <path d="M 485 310 L 530 310 L 540 355 L 495 355 Z" fill={fill(viewMode, 'url(#dozMetal)')} stroke={stroke(viewMode, '#475569')} strokeWidth={sw(viewMode)} />
          <polygon points="510,355 515,388 520,355" fill={fill(viewMode, '#1e293b')} stroke={stroke(viewMode, '#0f172a')} strokeWidth={1.5} />
          <rect x="490" y="300" width="45" height="12" rx="4" fill={fill(viewMode, '#475569')} stroke={stroke(viewMode, '#334155')} strokeWidth={1.5} />
        </g>

        {/* Sensors */}
        <SensorNode cx={247} cy={260} label="ENGINE" value="1,950 RPM" color="#10b981" />
        <SensorNode cx={380} cy={270} label="FUEL LEVEL" value="78%" color="#3b82f6" />
        <SensorNode cx={130} cy={295} label="BLADE LOAD" value="14.2 kN" color="#f59e0b" />
      </svg>
    </motion.div>
  );
}

/* ──────────────────────── HELPERS ──────────────────────── */
function ComponentStatus({ status }: { status: string }) {
  const config: Record<string, { label: string; className: string }> = {
    optimal: { label: 'Optimal', className: 'bg-green-500/10 text-green-400 border border-green-500/20' },
    good: { label: 'Good', className: 'bg-blue-500/10 text-blue-400 border border-blue-500/20' },
    warning: { label: 'Warning', className: 'bg-amber-500/10 text-amber-400 border border-amber-500/20' },
  };
  const c = config[status] || config.optimal;
  return <span className={`px-2 py-0.5 rounded text-xs ${c.className}`}>{c.label}</span>;
}

function DetailItem({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2"><Icon className="w-4 h-4 text-slate-400" /><span className="text-sm text-slate-400">{label}</span></div>
      <span className="text-sm text-white">{value}</span>
    </div>
  );
}
