import { useState, useMemo, useCallback, useRef } from 'react';
import {
  FileText,
  Download,
  Calendar,
  Filter,
  BarChart3,
  TrendingUp,
  ChevronDown,
  Loader2,
  FileSpreadsheet,
  FileDown,
  Printer,
  RefreshCw,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Droplet,
  HardHat,
  Cpu,
  Zap,
  Truck,
  Shield
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  ComposedChart, RadialBarChart, RadialBar
} from 'recharts';
import { format, subDays, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, eachWeekOfInterval, eachMonthOfInterval, differenceInDays } from 'date-fns';

// ── Types ──────────────────────────────────────────────────────────────────

type ReportType = 'production' | 'safety' | 'equipment' | 'water' | 'energy' | 'security';
type TimePreset = '7d' | '30d' | '90d' | '6m' | '1y' | 'custom';
type ReportStatus = 'idle' | 'generating' | 'ready';

interface GeneratedReport {
  id: string;
  name: string;
  type: ReportType;
  dateRange: string;
  generatedAt: Date;
  size: string;
  status: 'ready' | 'generating';
}

// ── Mock Data Generators ───────────────────────────────────────────────────

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4'];

function generateProductionData(startDate: Date, endDate: Date) {
  const days = differenceInDays(endDate, startDate);
  const intervals = days <= 14
    ? eachDayOfInterval({ start: startDate, end: endDate })
    : days <= 90
      ? eachWeekOfInterval({ start: startDate, end: endDate })
      : eachMonthOfInterval({ start: startDate, end: endDate });

  return intervals.map((date, i) => ({
    date: days <= 14 ? format(date, 'MMM dd') : days <= 90 ? format(date, 'MMM dd') : format(date, 'MMM yyyy'),
    oreExtracted: Math.round(2200 + Math.random() * 800 + Math.sin(i * 0.5) * 300),
    processed: Math.round(1800 + Math.random() * 600 + Math.sin(i * 0.5) * 250),
    yield: +(82 + Math.random() * 12).toFixed(1),
    target: 2500,
  }));
}

function generateSafetyData(startDate: Date, endDate: Date) {
  const days = differenceInDays(endDate, startDate);
  const intervals = days <= 14
    ? eachDayOfInterval({ start: startDate, end: endDate })
    : days <= 90
      ? eachWeekOfInterval({ start: startDate, end: endDate })
      : eachMonthOfInterval({ start: startDate, end: endDate });

  return intervals.map((date, i) => ({
    date: days <= 14 ? format(date, 'MMM dd') : days <= 90 ? format(date, 'MMM dd') : format(date, 'MMM yyyy'),
    incidents: Math.floor(Math.random() * 3),
    nearMisses: Math.floor(Math.random() * 5),
    inspections: Math.round(8 + Math.random() * 6),
    complianceScore: +(92 + Math.random() * 7).toFixed(1),
  }));
}

function generateEquipmentData(startDate: Date, endDate: Date) {
  const days = differenceInDays(endDate, startDate);
  const intervals = days <= 14
    ? eachDayOfInterval({ start: startDate, end: endDate })
    : days <= 90
      ? eachWeekOfInterval({ start: startDate, end: endDate })
      : eachMonthOfInterval({ start: startDate, end: endDate });

  return intervals.map((date, i) => ({
    date: days <= 14 ? format(date, 'MMM dd') : days <= 90 ? format(date, 'MMM dd') : format(date, 'MMM yyyy'),
    uptime: +(88 + Math.random() * 10).toFixed(1),
    maintenanceHours: Math.round(4 + Math.random() * 12),
    fuelConsumption: Math.round(1800 + Math.random() * 600),
    activeFleet: Math.round(82 + Math.random() * 15),
  }));
}

function generateWaterData(startDate: Date, endDate: Date) {
  const days = differenceInDays(endDate, startDate);
  const intervals = days <= 14
    ? eachDayOfInterval({ start: startDate, end: endDate })
    : days <= 90
      ? eachWeekOfInterval({ start: startDate, end: endDate })
      : eachMonthOfInterval({ start: startDate, end: endDate });

  return intervals.map((date) => ({
    date: days <= 14 ? format(date, 'MMM dd') : days <= 90 ? format(date, 'MMM dd') : format(date, 'MMM yyyy'),
    consumption: Math.round(4500 + Math.random() * 1500),
    recycled: Math.round(3200 + Math.random() * 800),
    discharged: Math.round(400 + Math.random() * 300),
    phLevel: +(6.8 + Math.random() * 0.8).toFixed(2),
  }));
}

function generateEnergyData(startDate: Date, endDate: Date) {
  const days = differenceInDays(endDate, startDate);
  const intervals = days <= 14
    ? eachDayOfInterval({ start: startDate, end: endDate })
    : days <= 90
      ? eachWeekOfInterval({ start: startDate, end: endDate })
      : eachMonthOfInterval({ start: startDate, end: endDate });

  return intervals.map((date) => ({
    date: days <= 14 ? format(date, 'MMM dd') : days <= 90 ? format(date, 'MMM dd') : format(date, 'MMM yyyy'),
    totalKwh: Math.round(12000 + Math.random() * 4000),
    solarKwh: Math.round(3000 + Math.random() * 1500),
    gridKwh: Math.round(8000 + Math.random() * 3000),
    costPerKwh: +(0.08 + Math.random() * 0.04).toFixed(3),
  }));
}

function generateSecurityData(startDate: Date, endDate: Date) {
  const days = differenceInDays(endDate, startDate);
  const intervals = days <= 14
    ? eachDayOfInterval({ start: startDate, end: endDate })
    : days <= 90
      ? eachWeekOfInterval({ start: startDate, end: endDate })
      : eachMonthOfInterval({ start: startDate, end: endDate });

  return intervals.map((date) => ({
    date: days <= 14 ? format(date, 'MMM dd') : days <= 90 ? format(date, 'MMM dd') : format(date, 'MMM yyyy'),
    accessEvents: Math.round(120 + Math.random() * 60),
    alerts: Math.floor(Math.random() * 4),
    cameraUptime: +(96 + Math.random() * 3.5).toFixed(1),
    perimeterBreaches: Math.floor(Math.random() * 2),
  }));
}

// ── Summary KPIs ──────────────────────────────────────────────────────────

function getKPIs(type: ReportType, data: any[]) {
  switch (type) {
    case 'production': {
      const totalOre = data.reduce((s, d) => s + d.oreExtracted, 0);
      const avgYield = +(data.reduce((s, d) => s + d.yield, 0) / data.length).toFixed(1);
      const peakDay = data.reduce((max, d) => d.oreExtracted > max.oreExtracted ? d : max, data[0]);
      return [
        { label: 'Total Ore Extracted', value: `${(totalOre / 1000).toFixed(1)}K tons`, change: '+4.2%', positive: true, icon: TrendingUp },
        { label: 'Avg Yield Rate', value: `${avgYield}%`, change: '+1.8%', positive: true, icon: BarChart3 },
        { label: 'Peak Output', value: `${peakDay?.oreExtracted} tons`, change: peakDay?.date, positive: true, icon: Zap },
        { label: 'Target Achievement', value: '94.2%', change: '+2.1%', positive: true, icon: CheckCircle2 },
      ];
    }
    case 'safety': {
      const totalIncidents = data.reduce((s, d) => s + d.incidents, 0);
      const avgCompliance = +(data.reduce((s, d) => s + d.complianceScore, 0) / data.length).toFixed(1);
      return [
        { label: 'Total Incidents', value: `${totalIncidents}`, change: '-12%', positive: true, icon: AlertTriangle },
        { label: 'Compliance Score', value: `${avgCompliance}%`, change: '+1.4%', positive: true, icon: CheckCircle2 },
        { label: 'Near Misses', value: `${data.reduce((s, d) => s + d.nearMisses, 0)}`, change: '-8%', positive: true, icon: Shield },
        { label: 'Inspections Done', value: `${data.reduce((s, d) => s + d.inspections, 0)}`, change: '+5%', positive: true, icon: HardHat },
      ];
    }
    case 'equipment': {
      const avgUptime = +(data.reduce((s, d) => s + d.uptime, 0) / data.length).toFixed(1);
      return [
        { label: 'Avg Uptime', value: `${avgUptime}%`, change: '+2.3%', positive: true, icon: Cpu },
        { label: 'Maintenance Hours', value: `${data.reduce((s, d) => s + d.maintenanceHours, 0)}h`, change: '-6%', positive: true, icon: Clock },
        { label: 'Fuel Consumed', value: `${(data.reduce((s, d) => s + d.fuelConsumption, 0) / 1000).toFixed(1)}K L`, change: '-3.2%', positive: true, icon: Truck },
        { label: 'Avg Active Fleet', value: `${Math.round(data.reduce((s, d) => s + d.activeFleet, 0) / data.length)}`, change: '+1', positive: true, icon: Truck },
      ];
    }
    case 'water': {
      return [
        { label: 'Total Consumption', value: `${(data.reduce((s, d) => s + d.consumption, 0) / 1000).toFixed(1)}K m³`, change: '-2.1%', positive: true, icon: Droplet },
        { label: 'Water Recycled', value: `${(data.reduce((s, d) => s + d.recycled, 0) / 1000).toFixed(1)}K m³`, change: '+5.4%', positive: true, icon: RefreshCw },
        { label: 'Avg pH Level', value: `${(data.reduce((s, d) => s + d.phLevel, 0) / data.length).toFixed(2)}`, change: 'In Range', positive: true, icon: CheckCircle2 },
        { label: 'Recycling Rate', value: '71.2%', change: '+3.8%', positive: true, icon: TrendingUp },
      ];
    }
    case 'energy': {
      return [
        { label: 'Total Consumption', value: `${(data.reduce((s, d) => s + d.totalKwh, 0) / 1000).toFixed(0)}K kWh`, change: '-1.5%', positive: true, icon: Zap },
        { label: 'Solar Generation', value: `${(data.reduce((s, d) => s + d.solarKwh, 0) / 1000).toFixed(0)}K kWh`, change: '+8.2%', positive: true, icon: TrendingUp },
        { label: 'Avg Cost/kWh', value: `$${(data.reduce((s, d) => s + d.costPerKwh, 0) / data.length).toFixed(3)}`, change: '-4.1%', positive: true, icon: BarChart3 },
        { label: 'Renewable Share', value: '24.8%', change: '+6.3%', positive: true, icon: CheckCircle2 },
      ];
    }
    case 'security': {
      return [
        { label: 'Access Events', value: `${data.reduce((s, d) => s + d.accessEvents, 0).toLocaleString()}`, change: 'Normal', positive: true, icon: Shield },
        { label: 'Total Alerts', value: `${data.reduce((s, d) => s + d.alerts, 0)}`, change: '-15%', positive: true, icon: AlertTriangle },
        { label: 'Camera Uptime', value: `${(data.reduce((s, d) => s + d.cameraUptime, 0) / data.length).toFixed(1)}%`, change: '+0.5%', positive: true, icon: CheckCircle2 },
        { label: 'Perimeter Breaches', value: `${data.reduce((s, d) => s + d.perimeterBreaches, 0)}`, change: '-20%', positive: true, icon: Shield },
      ];
    }
  }
}

// ── Report Type Config ────────────────────────────────────────────────────

const reportTypes: { id: ReportType; label: string; icon: React.ElementType; color: string }[] = [
  { id: 'production', label: 'Production', icon: BarChart3, color: '#3b82f6' },
  { id: 'safety', label: 'Safety & Compliance', icon: HardHat, color: '#f59e0b' },
  { id: 'equipment', label: 'Equipment & Fleet', icon: Truck, color: '#8b5cf6' },
  { id: 'water', label: 'Water Management', icon: Droplet, color: '#06b6d4' },
  { id: 'energy', label: 'Energy & Power', icon: Zap, color: '#10b981' },
  { id: 'security', label: 'Security', icon: Shield, color: '#ef4444' },
];

const timePresets: { id: TimePreset; label: string }[] = [
  { id: '7d', label: 'Last 7 Days' },
  { id: '30d', label: 'Last 30 Days' },
  { id: '90d', label: 'Last 90 Days' },
  { id: '6m', label: 'Last 6 Months' },
  { id: '1y', label: 'Last Year' },
  { id: 'custom', label: 'Custom Range' },
];

// ── Pie breakdown data ────────────────────────────────────────────────────

function getPieData(type: ReportType) {
  switch (type) {
    case 'production':
      return [
        { name: 'Copper Ore', value: 42 }, { name: 'Gold Ore', value: 18 },
        { name: 'Silver Ore', value: 12 }, { name: 'Iron Ore', value: 20 }, { name: 'Other', value: 8 },
      ];
    case 'safety':
      return [
        { name: 'Equipment Related', value: 35 }, { name: 'Slip/Fall', value: 25 },
        { name: 'Chemical Exposure', value: 15 }, { name: 'Vehicle', value: 18 }, { name: 'Other', value: 7 },
      ];
    case 'equipment':
      return [
        { name: 'Excavators', value: 28 }, { name: 'Haul Trucks', value: 32 },
        { name: 'Drills', value: 15 }, { name: 'Dozers', value: 14 }, { name: 'Loaders', value: 11 },
      ];
    case 'water':
      return [
        { name: 'Process Water', value: 45 }, { name: 'Dust Suppression', value: 20 },
        { name: 'Cooling', value: 15 }, { name: 'Domestic', value: 10 }, { name: 'Other', value: 10 },
      ];
    case 'energy':
      return [
        { name: 'Processing Plant', value: 40 }, { name: 'Hauling', value: 25 },
        { name: 'Drilling', value: 15 }, { name: 'Lighting', value: 10 }, { name: 'Office', value: 10 },
      ];
    case 'security':
      return [
        { name: 'Gate Access', value: 38 }, { name: 'Perimeter', value: 22 },
        { name: 'Restricted Zone', value: 20 }, { name: 'CCTV Alerts', value: 12 }, { name: 'Other', value: 8 },
      ];
  }
}

// ── CSV / PDF Helpers ─────────────────────────────────────────────────────

function downloadCSV(data: any[], filename: string) {
  if (!data.length) return;
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(','),
    ...data.map(row => headers.map(h => `"${row[h]}"`).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

function downloadPDFSummary(type: ReportType, dateRange: string, kpis: any[], data: any[]) {
  // Generate a printable HTML report in a new window
  const reportTitle = reportTypes.find(r => r.id === type)?.label || type;
  const rows = data.slice(0, 50);
  const headers = rows.length ? Object.keys(rows[0]) : [];

  const html = `
<!DOCTYPE html>
<html>
<head>
  <title>SDS Mining - ${reportTitle} Report</title>
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; color: #1e293b; }
    h1 { color: #0f172a; border-bottom: 3px solid #3b82f6; padding-bottom: 10px; }
    h2 { color: #334155; margin-top: 30px; }
    .meta { color: #64748b; margin-bottom: 24px; }
    .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin: 20px 0; }
    .kpi { background: #f1f5f9; border-radius: 8px; padding: 16px; }
    .kpi-label { font-size: 12px; color: #64748b; text-transform: uppercase; }
    .kpi-value { font-size: 24px; font-weight: 700; color: #0f172a; margin: 4px 0; }
    .kpi-change { font-size: 12px; color: #10b981; }
    table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
    th { background: #1e293b; color: white; padding: 10px 12px; text-align: left; }
    td { padding: 8px 12px; border-bottom: 1px solid #e2e8f0; }
    tr:nth-child(even) { background: #f8fafc; }
    .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #e2e8f0; font-size: 11px; color: #94a3b8; }
    @media print { body { padding: 20px; } }
  </style>
</head>
<body>
  <h1>SDS Mining Command Center</h1>
  <h2>${reportTitle} Report</h2>
  <div class="meta">Period: ${dateRange} &nbsp;|&nbsp; Generated: ${format(new Date(), 'PPpp')}</div>
  <div class="kpi-grid">
    ${kpis.map(k => `
      <div class="kpi">
        <div class="kpi-label">${k.label}</div>
        <div class="kpi-value">${k.value}</div>
        <div class="kpi-change">${k.change}</div>
      </div>
    `).join('')}
  </div>
  <h2>Detail Data</h2>
  <table>
    <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
    <tbody>${rows.map(r => `<tr>${headers.map(h => `<td>${r[h]}</td>`).join('')}</tr>`).join('')}</tbody>
  </table>
  <div class="footer">
    This report was automatically generated by SDS Smart Mining Command Center. Data is simulated for demonstration purposes.
  </div>
</body>
</html>`;

  const w = window.open('', '_blank');
  if (w) {
    w.document.write(html);
    w.document.close();
    setTimeout(() => w.print(), 500);
  }
}

// ── Component ─────────────────────────────────────────────────────────────

export function HistoricalReports() {
  const [selectedType, setSelectedType] = useState<ReportType>('production');
  const [timePreset, setTimePreset] = useState<TimePreset>('30d');
  const [customStart, setCustomStart] = useState(format(subDays(new Date(), 30), 'yyyy-MM-dd'));
  const [customEnd, setCustomEnd] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [reportStatus, setReportStatus] = useState<ReportStatus>('idle');
  const [generatedReports, setGeneratedReports] = useState<GeneratedReport[]>([]);
  const [showTypeDropdown, setShowTypeDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Compute date range
  const { startDate, endDate } = useMemo(() => {
    const now = new Date();
    switch (timePreset) {
      case '7d': return { startDate: subDays(now, 7), endDate: now };
      case '30d': return { startDate: subDays(now, 30), endDate: now };
      case '90d': return { startDate: subDays(now, 90), endDate: now };
      case '6m': return { startDate: subMonths(now, 6), endDate: now };
      case '1y': return { startDate: subMonths(now, 12), endDate: now };
      case 'custom': return { startDate: new Date(customStart), endDate: new Date(customEnd) };
      default: return { startDate: subDays(now, 30), endDate: now };
    }
  }, [timePreset, customStart, customEnd]);

  const dateRangeLabel = `${format(startDate, 'MMM dd, yyyy')} – ${format(endDate, 'MMM dd, yyyy')}`;

  // Generate chart data
  const chartData = useMemo(() => {
    switch (selectedType) {
      case 'production': return generateProductionData(startDate, endDate);
      case 'safety': return generateSafetyData(startDate, endDate);
      case 'equipment': return generateEquipmentData(startDate, endDate);
      case 'water': return generateWaterData(startDate, endDate);
      case 'energy': return generateEnergyData(startDate, endDate);
      case 'security': return generateSecurityData(startDate, endDate);
    }
  }, [selectedType, startDate, endDate]);

  const kpis = useMemo(() => getKPIs(selectedType, chartData), [selectedType, chartData]);
  const pieData = useMemo(() => getPieData(selectedType), [selectedType]);

  const handleGenerateReport = useCallback(() => {
    setReportStatus('generating');
    setTimeout(() => {
      const newReport: GeneratedReport = {
        id: Date.now().toString(),
        name: `${reportTypes.find(r => r.id === selectedType)!.label} Report`,
        type: selectedType,
        dateRange: dateRangeLabel,
        generatedAt: new Date(),
        size: `${(Math.random() * 2 + 0.5).toFixed(1)} MB`,
        status: 'ready',
      };
      setGeneratedReports(prev => [newReport, ...prev]);
      setReportStatus('ready');
    }, 2200);
  }, [selectedType, dateRangeLabel]);

  const currentConfig = reportTypes.find(r => r.id === selectedType)!;

  // ── Render Chart ──────────────────────────────────────────────────────

  const renderChart = () => {
    switch (selectedType) {
      case 'production':
        return (
          <ResponsiveContainer width="100%" height={340}>
            <ComposedChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', color: '#fff' }} />
              <Legend />
              <Bar dataKey="oreExtracted" name="Ore Extracted (tons)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="processed" name="Processed (tons)" fill="#06b6d4" radius={[4, 4, 0, 0]} />
              <Line type="monotone" dataKey="target" name="Target" stroke="#f59e0b" strokeDasharray="5 5" strokeWidth={2} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        );
      case 'safety':
        return (
          <ResponsiveContainer width="100%" height={340}>
            <ComposedChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis yAxisId="left" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: '#94a3b8', fontSize: 11 }} domain={[80, 100]} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', color: '#fff' }} />
              <Legend />
              <Bar yAxisId="left" dataKey="incidents" name="Incidents" fill="#ef4444" radius={[4, 4, 0, 0]} />
              <Bar yAxisId="left" dataKey="nearMisses" name="Near Misses" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey="complianceScore" name="Compliance %" stroke="#10b981" strokeWidth={2} dot={{ r: 3 }} />
            </ComposedChart>
          </ResponsiveContainer>
        );
      case 'equipment':
        return (
          <ResponsiveContainer width="100%" height={340}>
            <ComposedChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', color: '#fff' }} />
              <Legend />
              <Area type="monotone" dataKey="uptime" name="Uptime %" fill="#8b5cf6" fillOpacity={0.2} stroke="#8b5cf6" strokeWidth={2} />
              <Bar dataKey="maintenanceHours" name="Maintenance (hrs)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </ComposedChart>
          </ResponsiveContainer>
        );
      case 'water':
        return (
          <ResponsiveContainer width="100%" height={340}>
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', color: '#fff' }} />
              <Legend />
              <Area type="monotone" dataKey="consumption" name="Consumption (m³)" fill="#3b82f6" fillOpacity={0.3} stroke="#3b82f6" strokeWidth={2} />
              <Area type="monotone" dataKey="recycled" name="Recycled (m³)" fill="#10b981" fillOpacity={0.3} stroke="#10b981" strokeWidth={2} />
              <Area type="monotone" dataKey="discharged" name="Discharged (m³)" fill="#ef4444" fillOpacity={0.2} stroke="#ef4444" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        );
      case 'energy':
        return (
          <ResponsiveContainer width="100%" height={340}>
            <ComposedChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', color: '#fff' }} />
              <Legend />
              <Bar dataKey="gridKwh" name="Grid (kWh)" fill="#3b82f6" stackId="a" radius={[0, 0, 0, 0]} />
              <Bar dataKey="solarKwh" name="Solar (kWh)" fill="#10b981" stackId="a" radius={[4, 4, 0, 0]} />
              <Line type="monotone" dataKey="costPerKwh" name="Cost/kWh ($)" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} yAxisId="right" />
              <YAxis yAxisId="right" orientation="right" tick={{ fill: '#94a3b8', fontSize: 11 }} />
            </ComposedChart>
          </ResponsiveContainer>
        );
      case 'security':
        return (
          <ResponsiveContainer width="100%" height={340}>
            <ComposedChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', color: '#fff' }} />
              <Legend />
              <Bar dataKey="accessEvents" name="Access Events" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="alerts" name="Alerts" fill="#ef4444" radius={[4, 4, 0, 0]} />
              <Line type="monotone" dataKey="cameraUptime" name="Camera Uptime %" stroke="#10b981" strokeWidth={2} dot={{ r: 3 }} />
            </ComposedChart>
          </ResponsiveContainer>
        );
    }
  };

  return (
    <div className="p-6 space-y-6 min-h-full">
      {/* Page Title */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl text-white flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600/20 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-blue-400" />
            </div>
            Historical Reports
          </h2>
          <p className="text-slate-400 text-sm mt-1">Generate, visualize, and download operational reports for any time period</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <Clock className="w-4 h-4" />
          Data refreshed: {format(new Date(), 'PPp')}
        </div>
      </div>

      {/* ── Controls Bar ─────────────────────────────────────────────── */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5">
        <div className="flex flex-wrap items-end gap-5">
          {/* Report Type Selector */}
          <div className="relative" ref={dropdownRef}>
            <label className="block text-xs text-slate-400 mb-1.5">Report Type</label>
            <button
              onClick={() => setShowTypeDropdown(p => !p)}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white hover:border-slate-600 transition-colors min-w-[200px]"
            >
              <currentConfig.icon className="w-4 h-4" style={{ color: currentConfig.color }} />
              <span className="flex-1 text-left">{currentConfig.label}</span>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </button>
            {showTypeDropdown && (
              <div className="absolute z-50 top-full mt-1 w-full bg-slate-800 border border-slate-700 rounded-lg shadow-xl overflow-hidden">
                {reportTypes.map(rt => (
                  <button
                    key={rt.id}
                    onClick={() => { setSelectedType(rt.id); setShowTypeDropdown(false); }}
                    className={`w-full flex items-center gap-2 px-4 py-2.5 text-sm transition-colors ${
                      selectedType === rt.id ? 'bg-blue-600/20 text-blue-400' : 'text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    <rt.icon className="w-4 h-4" style={{ color: rt.color }} />
                    {rt.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Time Preset */}
          <div>
            <label className="block text-xs text-slate-400 mb-1.5">Time Period</label>
            <div className="flex bg-slate-800 rounded-lg border border-slate-700 overflow-hidden">
              {timePresets.map(tp => (
                <button
                  key={tp.id}
                  onClick={() => setTimePreset(tp.id)}
                  className={`px-3 py-2.5 text-xs whitespace-nowrap transition-colors ${
                    timePreset === tp.id
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-400 hover:bg-slate-700 hover:text-slate-200'
                  }`}
                >
                  {tp.label}
                </button>
              ))}
            </div>
          </div>

          {/* Custom dates */}
          {timePreset === 'custom' && (
            <div className="flex items-end gap-2">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">From</label>
                <input
                  type="date"
                  value={customStart}
                  onChange={e => setCustomStart(e.target.value)}
                  className="px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">To</label>
                <input
                  type="date"
                  value={customEnd}
                  onChange={e => setCustomEnd(e.target.value)}
                  className="px-3 py-2.5 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white"
                />
              </div>
            </div>
          )}

          {/* Generate + Download */}
          <div className="flex items-end gap-2 ml-auto">
            <button
              onClick={handleGenerateReport}
              disabled={reportStatus === 'generating'}
              className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm rounded-lg transition-colors"
            >
              {reportStatus === 'generating' ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <FileText className="w-4 h-4" />
              )}
              {reportStatus === 'generating' ? 'Generating...' : 'Generate Report'}
            </button>
            <button
              onClick={() => downloadCSV(chartData, `sds-${selectedType}-report-${format(new Date(), 'yyyy-MM-dd')}`)}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-sm rounded-lg transition-colors"
            >
              <FileSpreadsheet className="w-4 h-4" />
              CSV
            </button>
            <button
              onClick={() => downloadPDFSummary(selectedType, dateRangeLabel, kpis, chartData)}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-sm rounded-lg transition-colors"
            >
              <Printer className="w-4 h-4" />
              Print / PDF
            </button>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
          <Calendar className="w-3.5 h-3.5" />
          Showing data for: {dateRangeLabel}
        </div>
      </div>

      {/* ── KPI Cards ────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi, i) => {
          const Icon = kpi.icon;
          return (
            <div key={i} className="bg-slate-900 rounded-xl border border-slate-800 p-5 hover:border-slate-700 transition-colors">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-slate-400 uppercase tracking-wider">{kpi.label}</span>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${currentConfig.color}20` }}>
                  <Icon className="w-4 h-4" style={{ color: currentConfig.color }} />
                </div>
              </div>
              <div className="text-2xl text-white">{kpi.value}</div>
              <div className={`text-xs mt-1 ${kpi.positive ? 'text-green-400' : 'text-red-400'}`}>
                {kpi.change}
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Charts ───────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Main chart */}
        <div className="xl:col-span-2 bg-slate-900 rounded-xl border border-slate-800 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white text-sm flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-400" />
              {currentConfig.label} Trend
            </h3>
            <span className="text-xs text-slate-500">{dateRangeLabel}</span>
          </div>
          {renderChart()}
        </div>

        {/* Pie breakdown */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-5">
          <h3 className="text-white text-sm flex items-center gap-2 mb-4">
            <Filter className="w-4 h-4 text-blue-400" />
            Breakdown Distribution
          </h3>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={3} dataKey="value">
                {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px', color: '#fff' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {pieData.map((item, i) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-slate-300">{item.name}</span>
                </div>
                <span className="text-slate-400">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Data Table ───────────────────────────────────────────────── */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white text-sm flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400" />
            Detail Data
          </h3>
          <span className="text-xs text-slate-500">{chartData.length} records</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-800">
                {Object.keys(chartData[0] || {}).map(key => (
                  <th key={key} className="text-left py-3 px-4 text-xs text-slate-400 uppercase tracking-wider">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {chartData.map((row, i) => (
                <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors">
                  {Object.values(row).map((val, j) => (
                    <td key={j} className="py-2.5 px-4 text-slate-300">
                      {typeof val === 'number' ? val.toLocaleString() : String(val)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── Generated Reports History ────────────────────────────────── */}
      {generatedReports.length > 0 && (
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-5">
          <h3 className="text-white text-sm flex items-center gap-2 mb-4">
            <Download className="w-4 h-4 text-blue-400" />
            Generated Reports
          </h3>
          <div className="space-y-2">
            {generatedReports.map(report => (
              <div key={report.id} className="flex items-center justify-between py-3 px-4 bg-slate-800/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-blue-600/20 rounded-lg flex items-center justify-center">
                    <FileText className="w-4 h-4 text-blue-400" />
                  </div>
                  <div>
                    <div className="text-sm text-white">{report.name}</div>
                    <div className="text-xs text-slate-500">{report.dateRange} &bull; {report.size} &bull; {format(report.generatedAt, 'PPp')}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-green-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Ready
                  </span>
                  <button
                    onClick={() => downloadCSV(chartData, `sds-${report.type}-${report.id}`)}
                    className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
                    title="Download CSV"
                  >
                    <FileDown className="w-4 h-4 text-slate-400" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
