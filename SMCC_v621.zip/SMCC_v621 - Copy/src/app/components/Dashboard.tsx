import { 
  ArrowUpRight, 
  TrendingUp, 
  Activity, 
  AlertTriangle,
  CheckCircle,
  Clock,
  Cpu,
  Database,
  Wifi,
  Shield,
  Droplet,
  HardHat
} from 'lucide-react';
import { AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import type { View } from '../App';
import { storage } from '../utils/storage';
import { useState, useEffect } from 'react';

interface DashboardProps {
  onNavigate: (view: View) => void;
}

const performanceData = [
  { time: '00:00', efficiency: 85, output: 420, energy: 340 },
  { time: '04:00', efficiency: 78, output: 390, energy: 320 },
  { time: '08:00', efficiency: 92, output: 460, energy: 380 },
  { time: '12:00', efficiency: 88, output: 440, energy: 360 },
  { time: '16:00', efficiency: 90, output: 450, energy: 370 },
  { time: '20:00', efficiency: 86, output: 430, energy: 350 },
];

const assetData = [
  { name: 'Excavators', value: 24, status: 'active' },
  { name: 'Haul Trucks', value: 45, status: 'active' },
  { name: 'Drills', value: 18, status: 'active' },
  { name: 'Dozers', value: 12, status: 'active' },
  { name: 'Maintenance', value: 8, status: 'maintenance' },
];

const systemHealthData = [
  { system: 'Network', score: 98 },
  { system: 'Assets', score: 94 },
  { system: 'Security', score: 99 },
  { system: 'Water', score: 96 },
  { system: 'Safety', score: 97 },
  { system: 'Digital Twin', score: 93 },
];

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444'];

export function Dashboard({ onNavigate }: DashboardProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [siteName, setSiteName] = useState('Mining Site');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    
    // Get selected site from storage
    try {
      const selectedSite = storage.getItem('selectedSite');
      if (selectedSite) {
        const site = JSON.parse(selectedSite);
        setSiteName(site.name || 'Mining Site');
      }
    } catch (err) {
      console.error('Error loading site:', err);
    }
    
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="p-6 space-y-6 bg-slate-950 min-h-full">
      {/* Header with Site Info */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Command Center Dashboard</h1>
          <p className="text-slate-400 mt-1">{siteName} - Real-time Operations Overview</p>
        </div>
        <div className="text-right">
          <div className="text-sm text-slate-400">System Time</div>
          <div className="text-lg font-semibold text-white">{currentTime.toLocaleTimeString()}</div>
          <div className="text-xs text-slate-500">{currentTime.toLocaleDateString()}</div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Assets Connected"
          value="847"
          change="+12"
          trend="up"
          icon={Activity}
          color="blue"
          onClick={() => onNavigate('connected-assets')}
        />
        <MetricCard
          title="Network Uptime"
          value="99.8%"
          change="+0.2%"
          trend="up"
          icon={Wifi}
          color="green"
          onClick={() => onNavigate('private-5g')}
        />
        <MetricCard
          title="Active Alerts"
          value="3"
          change="-5"
          trend="down"
          icon={AlertTriangle}
          color="amber"
          onClick={() => onNavigate('security')}
        />
        <MetricCard
          title="Safety Score"
          value="98.5"
          change="+1.2"
          trend="up"
          icon={HardHat}
          color="emerald"
          onClick={() => onNavigate('safety')}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Operational Efficiency */}
        <div className="lg:col-span-2 bg-slate-900 rounded-xl border border-slate-800 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-white">Operational Efficiency (24h)</h2>
            <select className="text-sm border border-slate-700 bg-slate-800 text-slate-300 rounded-lg px-3 py-1.5">
              <option>Last 24 Hours</option>
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={performanceData}>
              <defs>
                <linearGradient id="colorEfficiency" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorOutput" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="time" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Legend wrapperStyle={{ color: '#e2e8f0' }} />
              <Area 
                type="monotone" 
                dataKey="efficiency" 
                stroke="#3b82f6" 
                fillOpacity={1} 
                fill="url(#colorEfficiency)"
                name="Efficiency %"
              />
              <Area 
                type="monotone" 
                dataKey="output" 
                stroke="#10b981" 
                fillOpacity={1} 
                fill="url(#colorOutput)"
                name="Output (tons)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Asset Distribution */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Asset Distribution</h2>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={assetData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
                {assetData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {assetData.map((asset, index) => (
              <div key={asset.name} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <span className="text-slate-300">{asset.name}</span>
                </div>
                <span className="text-white font-semibold">{asset.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* System Health & Quick Access */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* System Health Radar */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h2 className="text-lg font-semibold text-white mb-6">System Health Status</h2>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={systemHealthData}>
              <PolarGrid stroke="#334155" />
              <PolarAngleAxis dataKey="system" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#94a3b8" />
              <Radar name="Health Score" dataKey="score" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.5} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Module Quick Access */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h2 className="text-lg font-semibold text-white mb-6">Command Center Modules</h2>
          <div className="grid grid-cols-2 gap-3">
            <ModuleCard
              icon={Cpu}
              title="Connected Assets"
              subtitle="847 Active"
              color="blue"
              onClick={() => onNavigate('connected-assets')}
            />
            <ModuleCard
              icon={Wifi}
              title="Private 5G"
              subtitle="99.8% Uptime"
              color="purple"
              onClick={() => onNavigate('private-5g')}
            />
            <ModuleCard
              icon={Database}
              title="Geo-Spatial"
              subtitle="Live Tracking"
              color="green"
              onClick={() => onNavigate('geo-spatial')}
            />
            <ModuleCard
              icon={Shield}
              title="Security"
              subtitle="24/7 Monitoring"
              color="red"
              onClick={() => onNavigate('security')}
            />
            <ModuleCard
              icon={Droplet}
              title="Water Mgmt"
              subtitle="All Systems OK"
              color="cyan"
              onClick={() => onNavigate('water')}
            />
            <ModuleCard
              icon={HardHat}
              title="Safety Training"
              subtitle="VR Ready"
              color="orange"
              onClick={() => onNavigate('safety')}
            />
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
        <h2 className="text-lg font-semibold text-white mb-4">Recent Activity & Alerts</h2>
        <div className="space-y-3">
          <ActivityItem
            icon={CheckCircle}
            color="green"
            title="Digital Twin sync completed"
            description="847 assets synchronized successfully"
            time="2 minutes ago"
          />
          <ActivityItem
            icon={AlertTriangle}
            color="amber"
            title="Water usage spike detected"
            description="Zone C exceeded threshold by 15%"
            time="15 minutes ago"
          />
          <ActivityItem
            icon={Wifi}
            color="blue"
            title="5G network optimization"
            description="Cell tower #4 signal strength improved to 98%"
            time="1 hour ago"
          />
          <ActivityItem
            icon={HardHat}
            color="slate"
            title="Safety training scheduled"
            description="Emergency response drill - Thursday 09:00 AM"
            time="2 hours ago"
          />
          <ActivityItem
            icon={Cpu}
            color="purple"
            title="Asset maintenance completed"
            description="Excavator EX-042 returned to active service"
            time="3 hours ago"
          />
        </div>
      </div>
    </div>
  );
}

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: React.ElementType;
  color: 'blue' | 'green' | 'amber' | 'emerald';
  onClick: () => void;
}

function MetricCard({ title, value, change, trend, icon: Icon, color, onClick }: MetricCardProps) {
  const colorClasses = {
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    green: 'bg-green-500/10 text-green-400 border-green-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    emerald: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  };

  const iconColorClasses = {
    blue: 'bg-blue-500/20 text-blue-400',
    green: 'bg-green-500/20 text-green-400',
    amber: 'bg-amber-500/20 text-amber-400',
    emerald: 'bg-emerald-500/20 text-emerald-400',
  };

  return (
    <button 
      onClick={onClick}
      className={`bg-slate-900 rounded-xl border ${colorClasses[color]} p-6 hover:bg-slate-800 transition-all text-left group`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm text-slate-400 mb-2">{title}</p>
          <p className="text-3xl font-bold text-white mb-1">{value}</p>
          <div className={`flex items-center gap-1 text-sm ${trend === 'up' ? 'text-green-400' : 'text-amber-400'}`}>
            <ArrowUpRight className={`w-4 h-4 ${trend === 'down' ? 'rotate-90' : ''}`} />
            <span>{change}</span>
          </div>
        </div>
        <div className={`p-3 rounded-lg ${iconColorClasses[color]}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </button>
  );
}

interface ModuleCardProps {
  icon: React.ElementType;
  title: string;
  subtitle: string;
  color: string;
  onClick: () => void;
}

function ModuleCard({ icon: Icon, title, subtitle, color, onClick }: ModuleCardProps) {
  const colorClasses: Record<string, string> = {
    blue: 'from-blue-600 to-blue-700',
    purple: 'from-purple-600 to-purple-700',
    green: 'from-green-600 to-green-700',
    red: 'from-red-600 to-red-700',
    cyan: 'from-cyan-600 to-cyan-700',
    orange: 'from-orange-600 to-orange-700',
  };

  return (
    <button
      onClick={onClick}
      className={`bg-gradient-to-br ${colorClasses[color]} p-4 rounded-lg text-white hover:shadow-lg hover:scale-105 transition-all`}
    >
      <Icon className="w-8 h-8 mb-3" />
      <div className="text-left">
        <div className="font-semibold mb-1">{title}</div>
        <div className="text-xs opacity-90">{subtitle}</div>
      </div>
    </button>
  );
}

interface ActivityItemProps {
  icon: React.ElementType;
  color: 'green' | 'amber' | 'blue' | 'slate' | 'purple';
  title: string;
  description: string;
  time: string;
}

function ActivityItem({ icon: Icon, color, title, description, time }: ActivityItemProps) {
  const colorClasses = {
    green: 'bg-green-500/20 text-green-400',
    amber: 'bg-amber-500/20 text-amber-400',
    blue: 'bg-blue-500/20 text-blue-400',
    slate: 'bg-slate-500/20 text-slate-400',
    purple: 'bg-purple-500/20 text-purple-400',
  };

  return (
    <div className="flex items-start gap-4 pb-3 border-b border-slate-800 last:border-0 last:pb-0">
      <div className={`p-2 rounded-lg ${colorClasses[color]} mt-1`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="flex-1">
        <p className="text-sm font-semibold text-white">{title}</p>
        <p className="text-sm text-slate-400">{description}</p>
      </div>
      <span className="text-xs text-slate-500 whitespace-nowrap">{time}</span>
    </div>
  );
}
