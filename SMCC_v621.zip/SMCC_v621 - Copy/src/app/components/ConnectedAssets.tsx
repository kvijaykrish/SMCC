import { useState } from 'react';
import { Activity, AlertTriangle, CheckCircle, Cpu, MapPin, Search, Filter, Download, RefreshCw, Box } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import type { View } from '../App';

interface ConnectedAssetsProps {
  onNavigate: (view: View) => void;
}

const assetData = [
  { id: 'EX-042', name: 'Excavator CAT 336', type: 'Excavator', status: 'active', location: 'Zone A', utilization: 87, health: 95, lastMaint: '2 days ago' },
  { id: 'HT-128', name: 'Haul Truck Komatsu 930E', type: 'Haul Truck', status: 'active', location: 'Zone B', utilization: 92, health: 88, lastMaint: '5 days ago' },
  { id: 'DR-056', name: 'Drill Rig Atlas Copco', type: 'Drill', status: 'active', location: 'Zone C', utilization: 78, health: 98, lastMaint: '1 day ago' },
  { id: 'DZ-019', name: 'Dozer CAT D11', type: 'Dozer', status: 'maintenance', location: 'Workshop', utilization: 0, health: 65, lastMaint: 'In progress' },
  { id: 'EX-043', name: 'Excavator Hitachi EX1200', type: 'Excavator', status: 'active', location: 'Zone A', utilization: 95, health: 92, lastMaint: '3 days ago' },
  { id: 'HT-129', name: 'Haul Truck CAT 797F', type: 'Haul Truck', status: 'active', location: 'Zone B', utilization: 89, health: 94, lastMaint: '4 days ago' },
  { id: 'DR-057', name: 'Drill Rig Sandvik', type: 'Drill', status: 'active', location: 'Zone D', utilization: 82, health: 91, lastMaint: '2 days ago' },
  { id: 'LD-034', name: 'Loader CAT 994K', type: 'Loader', status: 'active', location: 'Zone C', utilization: 76, health: 89, lastMaint: '6 days ago' },
];

const performanceData = [
  { hour: '00:00', active: 45, idle: 12, maintenance: 3 },
  { hour: '04:00', active: 38, idle: 18, maintenance: 4 },
  { hour: '08:00', active: 52, idle: 6, maintenance: 2 },
  { hour: '12:00', active: 48, idle: 10, maintenance: 2 },
  { hour: '16:00', active: 50, idle: 8, maintenance: 2 },
  { hour: '20:00', active: 46, idle: 11, maintenance: 3 },
];

const assetTypeDistribution = [
  { name: 'Excavators', value: 24, color: '#3b82f6' },
  { name: 'Haul Trucks', value: 45, color: '#10b981' },
  { name: 'Drills', value: 18, color: '#f59e0b' },
  { name: 'Dozers', value: 12, color: '#8b5cf6' },
  { name: 'Loaders', value: 15, color: '#ef4444' },
];

export function ConnectedAssets({ onNavigate }: ConnectedAssetsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  const filteredAssets = assetData.filter(asset => {
    const matchesSearch = asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         asset.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || asset.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="p-6 space-y-6 bg-slate-950 min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Connected Assets & Digital Twins</h1>
          <p className="text-slate-400 mt-1">Real-time asset monitoring and digital twin management</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => onNavigate('digital-twin')}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
            <Box className="w-4 h-4" />
            <span>Digital Twin Viewer</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 rounded-lg transition-colors">
            <Download className="w-4 h-4" />
            <span>Export Data</span>
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 rounded-lg transition-colors">
            <RefreshCw className="w-4 h-4" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <SummaryCard title="Total Assets" value="847" icon={Activity} color="blue" />
        <SummaryCard title="Active Now" value="687" icon={CheckCircle} color="green" />
        <SummaryCard title="In Maintenance" value="23" icon={AlertTriangle} color="amber" />
        <SummaryCard title="Average Health" value="92%" icon={Cpu} color="purple" />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Asset Activity Timeline */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Asset Activity (24h)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="hour" stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
              <Legend wrapperStyle={{ color: '#e2e8f0' }} />
              <Bar dataKey="active" fill="#10b981" name="Active" />
              <Bar dataKey="idle" fill="#f59e0b" name="Idle" />
              <Bar dataKey="maintenance" fill="#ef4444" name="Maintenance" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Asset Type Distribution */}
        <div className="bg-slate-900 rounded-xl border border-slate-800 p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Asset Type Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={assetTypeDistribution}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {assetTypeDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                labelStyle={{ color: '#e2e8f0' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-2 mt-4">
            {assetTypeDistribution.map((type) => (
              <div key={type.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: type.color }} />
                <span className="text-sm text-slate-300">{type.name}: {type.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex items-center gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by asset ID or name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-700 text-white rounded-lg focus:outline-none focus:border-blue-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-slate-400" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 bg-slate-900 border border-slate-700 text-white rounded-lg focus:outline-none focus:border-blue-500"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="maintenance">Maintenance</option>
            <option value="idle">Idle</option>
          </select>
        </div>
      </div>

      {/* Asset List */}
      <div className="bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-800 border-b border-slate-700">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Asset ID</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Name</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Type</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Location</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Utilization</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Health</th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-slate-300 uppercase tracking-wider">Last Maint.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredAssets.map((asset) => (
                <tr key={asset.id} className="hover:bg-slate-800/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm font-mono text-blue-400">{asset.id}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-white">{asset.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-slate-300">{asset.type}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <StatusBadge status={asset.status} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-1 text-sm text-slate-300">
                      <MapPin className="w-4 h-4" />
                      <span>{asset.location}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 w-20 h-2 bg-slate-700 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-blue-500 rounded-full" 
                          style={{ width: `${asset.utilization}%` }}
                        />
                      </div>
                      <span className="text-sm text-slate-300">{asset.utilization}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <HealthIndicator health={asset.health} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">{asset.lastMaint}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function SummaryCard({ title, value, icon: Icon, color }: { title: string; value: string; icon: any; color: string }) {
  const colorClasses: Record<string, string> = {
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    green: 'bg-green-500/10 text-green-400 border-green-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  };

  return (
    <div className={`bg-slate-900 rounded-xl border ${colorClasses[color]} p-6`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-400">{title}</p>
          <p className="text-2xl font-bold text-white mt-1">{value}</p>
        </div>
        <Icon className="w-8 h-8" />
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const statusConfig: Record<string, { label: string; className: string }> = {
    active: { label: 'Active', className: 'bg-green-500/10 text-green-400 border-green-500/20' },
    maintenance: { label: 'Maintenance', className: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
    idle: { label: 'Idle', className: 'bg-slate-500/10 text-slate-400 border-slate-500/20' },
  };

  const config = statusConfig[status] || statusConfig.idle;

  return (
    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full border ${config.className}`}>
      {config.label}
    </span>
  );
}

function HealthIndicator({ health }: { health: number }) {
  let color = 'text-green-400';
  if (health < 70) color = 'text-red-400';
  else if (health < 85) color = 'text-amber-400';

  return (
    <div className="flex items-center gap-2">
      <div className="w-16 h-2 bg-slate-700 rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full ${health >= 85 ? 'bg-green-500' : health >= 70 ? 'bg-amber-500' : 'bg-red-500'}`}
          style={{ width: `${health}%` }}
        />
      </div>
      <span className={`text-sm font-semibold ${color}`}>{health}%</span>
    </div>
  );
}
