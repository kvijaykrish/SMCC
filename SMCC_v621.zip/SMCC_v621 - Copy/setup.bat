@echo off
REM SDS Mining Command Center - Complete Setup Script for Windows
REM This script sets up the entire application including sites

echo ==========================================
echo 🚀 SDS Mining Command Center Setup
echo ==========================================
echo.

REM Check if Docker is running
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Docker is not running. Please start Docker Desktop and try again.
    exit /b 1
)

echo ✓ Docker is running
echo.

REM Step 1: Start Docker Compose
echo Step 1: Starting Docker containers...
docker-compose up -d

echo Waiting for services to be healthy (30 seconds)...
timeout /t 30 /nobreak >nul

REM Step 2: Check if containers are running
echo Step 2: Checking container status...
docker-compose ps

REM Step 3: Run database migrations
echo Step 3: Running database migrations...
echo   - Creating main schema...
docker exec sds-backend npm run migrate

echo   - Creating sites schema...
docker exec sds-postgres psql -U postgres -d sds_mining -f /app/src/database/sites-migration.sql

REM Step 4: Seed database
echo Step 4: Seeding database...
echo   - Seeding main data...
docker exec sds-backend npm run seed

echo   - Building TypeScript...
docker exec sds-backend npm run build

echo   - Seeding sites...
docker exec sds-backend node dist/database/seed-sites.js

echo.
echo ==========================================
echo ✅ Setup Complete!
echo ==========================================
echo.
echo 📱 Application URLs:
echo   Frontend:      http://localhost:4200
echo   Backend API:   http://localhost:3000
echo   PgAdmin:       http://localhost:5050
echo.
echo 🔑 Login Credentials:
echo   Email:         admin@mining-sds.com
echo   Password:      admin123
echo.
echo 🗄️  Database:
echo   Host:          localhost
echo   Port:          5432
echo   Database:      sds_mining
echo   User:          postgres
echo   Password:      postgres
echo.
echo 📊 Features Available:
echo   ✓ 6 Mining Sites with Real-time Metrics
echo   ✓ Asset Management ^& Digital Twins
echo   ✓ Private 5G Network Monitoring
echo   ✓ Geo-Spatial Intelligence
echo   ✓ Security ^& Surveillance
echo   ✓ Water Management
echo   ✓ Safety ^& Training
echo.
echo Next Steps:
echo 1. Open http://localhost:4200 in your browser
echo 2. Login with the credentials above
echo 3. Select a mining site from the landing page
echo 4. Explore the command center dashboard
echo.
echo 📝 View logs:        docker-compose logs -f
echo 🛑 Stop application: docker-compose down
echo 🔄 Restart:          docker-compose restart
echo.
echo Happy Mining! ⛏️
